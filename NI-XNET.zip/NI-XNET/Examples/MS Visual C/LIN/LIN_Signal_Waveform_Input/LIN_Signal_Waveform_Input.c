/*
// This example reads a waveform signal. Selected samples from the waveform are
// displayed together with its StartTime and sample rate.
// This is used to demonstrate a signal waveform input session.
// For more information about this type of session, please consult the NI-XNET
// manual.
// This example uses hardcoded signal names that use the NIXNET_exampleLDF database.
// To use your own database, you need to add an alias to your database file using
// the NI-XNET Database Editor and then modify the database name and signals used here.
// Please make sure that the bus is properly terminated as this example does not
// enable the on-board termination. Also ensure that the transceivers are
// externally powered when using C Series modules.
*/

#include <stdlib.h>     // Include file for various functions
#include <stdio.h>      // Include file for printf
#include <conio.h>      // Include file for _getch/kbhit
#include <windows.h>    // Include file for Win32 time functions
#include "nixnet.h"     // Include file for XNET functions

#define NUM_SAMP 100
#define NUM_SIGNALS 2

//=============================================================================
// Static global variables
//=============================================================================
static nxSessionRef_t m_SessionRef = 0;

//=============================================================================
// Global functions declarations
//=============================================================================
void DisplayErrorAndExit(nxStatus_t Status, char *Source);
int PrintTimestamp(nxTimestamp_t *Time);

//=============================================================================
// Main function
//=============================================================================
int main(void)
{
   // Declare all variables for the function
   unsigned int i = 0;
   unsigned int l_NumRead = 0;
   int l_TypedChar = 0;
   char *l_pSelectedInterface = "LIN2";
   char *l_pSelectedDatabase = "NIXNET_exampleLDF";
   char *l_pSelectedCluster = "Cluster";
   char *l_pSelectedSignalList = "MasterSignal1_U16,MasterSignal2_U16";
   nxTimestamp_t l_StartTime = 0;
   f64 l_DeltaTime = 0.0;
   f64 l_ValueBuffer[NUM_SIGNALS][NUM_SAMP];
   nxStatus_t l_Status = 0;

   // Change this to set the interface to master mode
   u32 l_IsMaster = 0;

   // The schedule is identified by its index. The index is mapped to
   // the schedules in the database. Index 0 is the first schedule
   // displayed in the Database Editor.
   u32 l_ScheduleIndex = 0;

   // Display parameters that will be used for the example.
   printf("Interface: %s\nDatabase: %s\nSignal List: %s\n",
      l_pSelectedInterface, l_pSelectedDatabase, l_pSelectedSignalList);

   if (l_IsMaster)
   {
      printf("Master?: Yes\n");
   }
   else
   {
      printf("Master?: No\n");
   }

   // Create an XNET session in SignalInWaveform mode
   // Default resample rate (1000 Hz) will be used
   l_Status = nxCreateSession(l_pSelectedDatabase, l_pSelectedCluster,
      l_pSelectedSignalList, l_pSelectedInterface, nxMode_SignalInWaveform,
      &m_SessionRef);
   if (nxSuccess != l_Status)
   {
      DisplayErrorAndExit(l_Status, "nxCreateSession");
   }
   else
   {
      if (0 != l_IsMaster)
      {
         // Set the schedule - this will also automatically enable master mode
         l_Status = nxWriteState(m_SessionRef, nxState_LINScheduleChange,
            sizeof(l_ScheduleIndex), &l_ScheduleIndex);
         if (nxSuccess != l_Status)
         {
            DisplayErrorAndExit(l_Status, "nxWriteState");
         }
      }
      printf("Session Created Successfully.\n");
   }

   // Main loop
   i = 0;
   do
   {
      // Read the signal waveform data
      l_Status = nxReadSignalWaveform(m_SessionRef, 1.0, &l_StartTime,
         &l_DeltaTime, (f64 *)l_ValueBuffer, sizeof(l_ValueBuffer), &l_NumRead);
      if (nxSuccess == l_Status)
      {
         // For each loop, print the StartTime of the waveform, then
         // a few selected samples for each channel.
         printf("Loop %d: StartTime =", ++i);
         PrintTimestamp(&l_StartTime);
         printf(" DeltaTime = %f us\n", l_DeltaTime);
         printf("\tSignal1:  [0] = %2.3f ... [50] = %2.3f, [99] = %2.3f\n",
            l_ValueBuffer[0][0], l_ValueBuffer[0][50], l_ValueBuffer[0][99]);
         printf("\tSignal2:  [0] = %2.3f ... [50] = %2.3f, [99] = %2.3f\n",
            l_ValueBuffer[1][0], l_ValueBuffer[1][50], l_ValueBuffer[1][99]);
         printf("\n");
      }
      else
      {
         DisplayErrorAndExit(l_Status, "nxReadSignalWaveform");
      }

      if (_kbhit())
      {
         l_TypedChar = _getch();
      }
   }
   while ('q' != tolower(l_TypedChar));

   // Clear the XNET session
   l_Status = nxClear(m_SessionRef);
   if (nxSuccess == l_Status)
   {
      printf("\nSession cleared successfully!\n");
   }
   else
   {
      DisplayErrorAndExit(l_Status, "nxClear");
   }

   return 0;
}

//=============================================================================
// Display Error Function
//=============================================================================
void DisplayErrorAndExit(nxStatus_t Status, char *Source)
{
   char l_StatusString[1024];
   nxStatusToString(Status, sizeof(l_StatusString), l_StatusString);

   printf("\n\nERROR at %s!\n%s\n", Source, l_StatusString);
   printf("\nExecution stopped.\nPress any key to quit\n");

   nxClear(m_SessionRef);

   _getch();
   exit(1);
}

//=============================================================================
// Prints a timestamp to stdout
//=============================================================================
int PrintTimestamp(nxTimestamp_t *Time)
{
   SYSTEMTIME l_STime;
   FILETIME l_LocalFTime;
   /* This Win32 function converts from UTC (international) time
   to the local time zone.  The NI-XNET card keeps time in UTC
   format (refer to the description of nxTimestamp_t in
   the NI-XNET reference for Read functions). */
   FileTimeToLocalFileTime((FILETIME *)Time, &l_LocalFTime);

   /* This Win32 function converts an absolute time (FILETIME)
   into SYSTEMTIME, a structure with fields for year, month, day,
   and so on. */
   FileTimeToSystemTime(&l_LocalFTime, &l_STime);

   return printf("%02d/%02d/%04d %02d:%02d:%02d.%03d", l_STime.wMonth, l_STime.wDay,
      l_STime.wYear, l_STime.wHour, l_STime.wMinute, l_STime.wSecond,
      l_STime.wMilliseconds);
}
