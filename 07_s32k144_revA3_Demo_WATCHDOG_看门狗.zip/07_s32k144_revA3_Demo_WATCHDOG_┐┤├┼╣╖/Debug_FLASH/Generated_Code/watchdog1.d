Generated_Code/watchdog1.o: ../Generated_Code/watchdog1.c \
 ../Generated_Code/watchdog1.h ../Generated_Code/clockMan1.h \
 ../Generated_Code/Cpu.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/clock.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/status.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_watchdog\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/lpuart_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/callbacks.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/pal/inc/i2c_pal.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/Generated_Code/i2c_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/pal/inc/i2c_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/lpi2c_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/ftm_mc_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/ftm_common.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/wdog_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/power_manager.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_watchdog\sdk\platform\drivers\src\power\s32k1xx\power_manager_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 ../Generated_Code/pin_mux.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/pins_driver.h \
 ../Generated_Code/dmaController1.h ../Generated_Code/lpuart1.h \
 ../Generated_Code/i2c1.h ../Generated_Code/flexTimer_mc1.h \
 ../Generated_Code/pwrMan1.h

../Generated_Code/watchdog1.h:

../Generated_Code/clockMan1.h:

../Generated_Code/Cpu.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/clock.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/status.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_watchdog\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/lpuart_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/callbacks.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/pal/inc/i2c_pal.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/Generated_Code/i2c_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/pal/inc/i2c_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/lpi2c_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/ftm_mc_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/ftm_common.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/wdog_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/power_manager.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_watchdog\sdk\platform\drivers\src\power\s32k1xx\power_manager_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/devices/S32K144/startup/system_S32K144.h:

../Generated_Code/pin_mux.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_WATCHDOG/SDK/platform/drivers/inc/pins_driver.h:

../Generated_Code/dmaController1.h:

../Generated_Code/lpuart1.h:

../Generated_Code/i2c1.h:

../Generated_Code/flexTimer_mc1.h:

../Generated_Code/pwrMan1.h:
