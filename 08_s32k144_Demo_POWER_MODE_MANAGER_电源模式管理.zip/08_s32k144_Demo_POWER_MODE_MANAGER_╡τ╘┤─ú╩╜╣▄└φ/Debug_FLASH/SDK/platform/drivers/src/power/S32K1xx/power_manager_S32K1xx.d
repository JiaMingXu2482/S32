SDK/platform/drivers/src/power/S32K1xx/power_manager_S32K1xx.o: \
 ../SDK/platform/drivers/src/power/S32K1xx/power_manager_S32K1xx.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/power_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/status.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_power_mode_manager\sdk\platform\drivers\src\power\s32k1xx\power_manager_s32k1xx.h \
 ../SDK/platform/drivers/src/power/S32K1xx/power_smc_hw_access.h \
 ../SDK/platform/drivers/src/power/S32K1xx/power_manager_S32K1xx.h \
 ../SDK/platform/drivers/src/power/S32K1xx/power_rcm_hw_access.h \
 ../SDK/platform/drivers/src/power/S32K1xx/power_scg_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/clock.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_power_mode_manager\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/power_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/devices/status.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_power_mode_manager\sdk\platform\drivers\src\power\s32k1xx\power_manager_s32k1xx.h:

../SDK/platform/drivers/src/power/S32K1xx/power_smc_hw_access.h:

../SDK/platform/drivers/src/power/S32K1xx/power_manager_S32K1xx.h:

../SDK/platform/drivers/src/power/S32K1xx/power_rcm_hw_access.h:

../SDK/platform/drivers/src/power/S32K1xx/power_scg_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_POWER_MODE_MANAGER/SDK/platform/drivers/inc/clock.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_power_mode_manager\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
