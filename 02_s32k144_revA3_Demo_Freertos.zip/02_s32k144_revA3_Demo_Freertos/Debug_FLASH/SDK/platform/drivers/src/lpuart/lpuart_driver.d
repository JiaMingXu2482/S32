SDK/platform/drivers/src/lpuart/lpuart_driver.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_driver.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/lpuart_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/semphr.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/queue.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/callbacks.h \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/clock.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_freertos_02\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/lpuart_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/semphr.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/queue.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/callbacks.h:

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/drivers/inc/clock.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_freertos_02\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
