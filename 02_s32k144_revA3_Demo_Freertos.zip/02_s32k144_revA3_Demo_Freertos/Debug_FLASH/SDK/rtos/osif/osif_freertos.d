SDK/rtos/osif/osif_freertos.o: ../SDK/rtos/osif/osif_freertos.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h \
 ../SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/semphr.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/queue.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/task.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/list.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h:

../SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/semphr.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/queue.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/task.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/list.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/platform/devices/devassert.h:
