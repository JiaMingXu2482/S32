SDK/rtos/FreeRTOS_S32K/Source/list.o: \
 ../SDK/rtos/FreeRTOS_S32K/Source/list.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/list.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/FreeRTOS.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/Generated_Code/FreeRTOSConfig.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/projdefs.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/portable.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/deprecated_definitions.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/mpu_wrappers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_Freertos_02/SDK/rtos/FreeRTOS_S32K/Source/include/list.h:
