/*
 * Ʒ�ǿƼ�S32K144������
 * �ⲿ�����ж�
 * ʵ������:
 * LED4 100ms��תһ��,����ָʾ����״̬
 * KEY1-3ͨ���ⲿ�жϷֱ𴥷� LED1-3��ת
 *
 * IO����
 * KEY1 PTC12
 * KEY2 PTC13
 * KEY3 PTB2
 * LED1 PTD16
 * LED2 PTD15
 * LED3 PTD1
 * LED4 PTD0
*/
#include "Cpu.h"
#include "delay.h"
#include "uart.h"
#include"key.h"
#include"oled.h"
  volatile int exit_code = 0;

#define LED1(x)  PINS_DRV_WritePin(PTD,16,!x);
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!x);
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!x);
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!x);

  uint8_t PTC12_KEY1 = 0;
  uint8_t PTC13_KEY2 = 0;
  uint8_t PTB2_KEY3  = 0;
  void PTC_EXT_IRQ (void)
  {
	  uint32_t buttonsPressed = PINS_DRV_GetPortIntFlag(PORTC) & ( ( 1 <<12 ) | ( 1<<13 ) );  //��ȡ�жϱ�־λ״̬
	  /*����ж�*/
	  if(buttonsPressed !=0 )
	  {
		  if( ((buttonsPressed >>12) & 0x01) == 1 )
		  {
			  PTC12_KEY1 = 1;
			  PINS_DRV_TogglePins(PTD, 1<<16 );
		  }
		  if( ((buttonsPressed >>13) & 0x01) == 1 )
		  {
			  PTC13_KEY2 = 1;
			  PINS_DRV_TogglePins(PTD, 1<<15 );
		  }

	  }
	  PINS_DRV_ClearPortIntFlagCmd(PORTC);
  }

  void PTB_EXT_IRQ (void)
  {
	  uint32_t buttonsPressed = PINS_DRV_GetPortIntFlag(PORTB) & ( 1 << 2 );  //��ȡ�жϱ�־λ״̬
	  /*����ж�*/
	  if(buttonsPressed !=0 )
	  {
		  if( ((buttonsPressed >>2) & 0x01) == 1 )
		  {
			  PTB2_KEY3  = 1;
			 PINS_DRV_TogglePins(PTD, 1<<1 );
		  }
	  }
	  PINS_DRV_ClearPortIntFlagCmd(PORTB);

  }
int main(void)
{
  /* Write your local variable definition here */
	int MCU_Freq;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
	MCU_Freq = delay_init();//��ʼ��delay����
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr); //��ʼ��IO

	/*�����жϴ�������*/
	PINS_DRV_SetPinIntSel(PORTC,12,PORT_INT_RISING_EDGE); //����PTC12�����ش����ж�
	PINS_DRV_SetPinIntSel(PORTC,13,PORT_INT_RISING_EDGE);
	PINS_DRV_SetPinIntSel(PORTB,2,PORT_INT_RISING_EDGE);



	/*���ò�ʹ���жϺ���*/
	INT_SYS_InstallHandler(PORTC_IRQn,&PTC_EXT_IRQ,NULL); //��װ��������Ϊ PTC_EXT_IRQ ���жϺ���
	INT_SYS_InstallHandler(PORTB_IRQn,&PTB_EXT_IRQ,NULL);

	INT_SYS_EnableIRQ(PORTC_IRQn); //ʹ��PTC�ж�
	INT_SYS_EnableIRQ(PORTB_IRQn);


	I2C_MasterInit(&i2c1_instance, &i2c1_MasterConfig0);//��ʼ��I2C����,����OLEDͨѶ
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0); //��ʼ������

	oled_init(); //OLED���ò�����ʼ��
	OLED_TITLE((uint8_t*)"S32K144",(uint8_t*)"EXT INT");//OLED��ʾ����
	u1_printf("��ʼ�����,MCU����Ƶ��Ϊ %d Mhz \r\n",MCU_Freq);
    while(1)
    {

	    if(PTC12_KEY1 == 1)
			{
			u1_printf("KEY1���� \r\n");
			/*OLED��ʾ*/
			OLED_ShowString(0,3,(uint8_t *)"KEY1 INTERRUPT",16,1);
			OLED_ShowString(32,5,(uint8_t *)"TRIGGER",16,1);
			delay_ms(400);
			LCD_clear_L(0,3);
			LCD_clear_L(0,4);
			LCD_clear_L(0,5);
			LCD_clear_L(0,6);
			/*OLED��ʾ*/
			PTC12_KEY1 = 0;
			}
	    else if(PTC13_KEY2 == 1)
			{
			u1_printf("KEY2���� \r\n");
			/*OLED��ʾ*/
			OLED_ShowString(0,3,(uint8_t *)"KEY2 INTERRUPT",16,1);
			OLED_ShowString(32,5,(uint8_t *)"TRIGGER",16,1);
			delay_ms(400);
			LCD_clear_L(0,3);
			LCD_clear_L(0,4);
			LCD_clear_L(0,5);
			LCD_clear_L(0,6);
			/*OLED��ʾ*/
			PTC13_KEY2 = 0;

			}
	    else if(PTB2_KEY3 == 1)
			{
			u1_printf("KEY3���� \r\n");
			/*OLED��ʾ*/
			OLED_ShowString(0,3,(uint8_t *)"KEY3 INTERRUPT",16,1);
			OLED_ShowString(32,5,(uint8_t *)"TRIGGER",16,1);
			delay_ms(400);
			LCD_clear_L(0,3);
			LCD_clear_L(0,4);
			LCD_clear_L(0,5);
			LCD_clear_L(0,6);
			/*OLED��ʾ*/
			PTB2_KEY3 = 0;
			}

		PINS_DRV_TogglePins(PTD, 1 << 0);
		delay_ms(200);
    }
  /*** Don't write any code pass th5is line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
