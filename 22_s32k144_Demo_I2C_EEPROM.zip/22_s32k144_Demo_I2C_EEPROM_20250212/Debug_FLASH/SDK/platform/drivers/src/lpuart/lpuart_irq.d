SDK/platform/drivers/src/lpuart/lpuart_irq.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h:
