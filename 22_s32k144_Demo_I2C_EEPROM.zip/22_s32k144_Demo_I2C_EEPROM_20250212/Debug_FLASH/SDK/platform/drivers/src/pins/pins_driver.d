SDK/platform/drivers/src/pins/pins_driver.o: \
 ../SDK/platform/drivers/src/pins/pins_driver.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h \
 ../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/pins_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h:

../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/pins_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/pins/pins_port_hw_access.h:
