SDK/platform/drivers/src/edma/edma_driver.o: \
 ../SDK/platform/drivers/src/edma/edma_driver.c \
 ../SDK/platform/drivers/src/edma/edma_irq.h \
 ../SDK/platform/drivers/src/edma/edma_hw_access.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_i2c_eeprom\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/edma/edma_irq.h:

../SDK/platform/drivers/src/edma/edma_hw_access.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_i2c_eeprom\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h:
