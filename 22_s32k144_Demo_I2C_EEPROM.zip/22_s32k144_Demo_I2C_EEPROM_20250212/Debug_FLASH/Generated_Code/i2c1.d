Generated_Code/i2c1.o: ../Generated_Code/i2c1.c ../Generated_Code/i2c1.h \
 ../Generated_Code/clockMan1.h ../Generated_Code/Cpu.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_i2c_eeprom\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/rtos/osif/osif.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/lpuart_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/callbacks.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/pal/inc/i2c_pal.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/Generated_Code/i2c_pal_cfg.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/pal/inc/i2c_pal_mapping.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/lpi2c_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 ../Generated_Code/pin_mux.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/pins_driver.h \
 ../Generated_Code/dmaController1.h ../Generated_Code/lpuart1.h

../Generated_Code/i2c1.h:

../Generated_Code/clockMan1.h:

../Generated_Code/Cpu.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/clock.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/status.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_i2c_eeprom\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/rtos/osif/osif.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/lpuart_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/callbacks.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/pal/inc/i2c_pal.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/Generated_Code/i2c_pal_cfg.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/pal/inc/i2c_pal_mapping.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/lpi2c_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/devices/S32K144/startup/system_S32K144.h:

../Generated_Code/pin_mux.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/SDK/platform/drivers/inc/pins_driver.h:

../Generated_Code/dmaController1.h:

../Generated_Code/lpuart1.h:
