Sources/font.o: ../Sources/font.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/include/font.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_I2C_EEPROM/include/font.h:
