/*
 * eeprom_at24c02.h
 *
 *  Created on: 2025��2��12��
 *      Author: Administrator
 */

#ifndef EEPROM_AT24C02_H_
#define EEPROM_AT24C02_H_

uint8_t AT24C02_Read_Byte(uint8_t ReadAddr);

void AT24C02_Write_Byte(uint8_t WriteAddr,uint8_t WriteData);
uint8_t AT24CXX_Check(void);
void AT24CXX_Read(uint8_t ReadAddr,uint8_t *pBuffer,uint16_t NumToRead);
void AT24CXX_Write(uint8_t WriteAddr,uint8_t *pBuffer,uint16_t NumToWrite);
#endif /* EEPROM_AT24C02_H_ */
