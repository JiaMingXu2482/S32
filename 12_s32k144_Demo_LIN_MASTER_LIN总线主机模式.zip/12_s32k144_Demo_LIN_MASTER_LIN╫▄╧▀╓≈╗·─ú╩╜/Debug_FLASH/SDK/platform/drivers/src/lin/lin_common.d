SDK/platform/drivers/src/lin/lin_common.o: \
 ../SDK/platform/drivers/src/lin/lin_common.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/drivers/inc/lin_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/rtos/osif/osif.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/drivers/inc/lin_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_MASTER/SDK/rtos/osif/osif.h:
