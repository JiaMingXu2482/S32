/*
 * Ʒ�ǿƼ�S32K144������
 * DEMO - LIN����ʵ��(������ģʽ)
 * ʵ������
 *
 * KEY1 �������ͱ������ӻ�,����ͨ��������ʾ
 * KEY2 �������ܴӻ������ı��Ĳ�У�������ȷ,LED12����,У��ʧ��LED12���
 * KEY3 ��������/����
 * LED3 ����ʾLIN���߻���״̬,Ϩ���ʾ����������
 * LED4 ��������˸,ָʾ����״̬
 *
 *
 * IO����
 * LIN-LPUART2
 * PTD6 RX
 * PTD7 TX
 *
 * KEY1 PTC12
 * KEY2 PTC13
 * KEY3 PTB2
 * LED1 PTD16
 * LED2 PTD15
 * LED3 PTD1
 * LED4 PTD0
*/
#include "Cpu.h"
#include "delay.h"
#include "uart.h"
#include"key.h"
#include"oled.h"
  volatile int exit_code = 0;

#define LED1(x)  PINS_DRV_WritePin(PTD,16,!x);
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!x);
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!x);
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!x);

  volatile bool Master_Rx_Flag = false;
  volatile bool Master_Tx_Flag = false;
  volatile bool Sleep_Flag = false;
  volatile bool Master_Awake_Flag = false;
  #define TIMER_COMPARE_VAL             (uint16_t)(2000U)
  #define TIMER_TICKS_1US               (uint16_t)(4U)
  #define DATA_SIZE                     (8U)
  #define FRAME_SLAVE_RECEIVE_DATA      (1U)
  #define FRAME_MASTER_RECEIVE_DATA     (2U)
  #define FRAME_GO_TO_SLEEP             (3U)
  #define TIMEOUT					   (500U)


  /* ��������  */
  uint8_t txBuff[DATA_SIZE] = {0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18};
  /* ���ܵ����� */
  uint8_t rxBuff[DATA_SIZE] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
  /* ����У������� */
  uint8_t verifyBuff[DATA_SIZE] = {0x18, 0x17, 0x16, 0x15, 0x14, 0x13, 0x12, 0x11};

  uint16_t timerOverflowInterruptCount = 0U;

  /*LED������˸*/
    void LED_Period_ISR(void)
  	{
  	 PINS_DRV_TogglePins(PTD, 1 << 0);
  	 FTM_DRV_ClearStatusFlags(INST_FLEXTIMER_MC2, (uint32_t)FTM_TIME_OVER_FLOW_FLAG);
  	}



  /* LIN���߳�ʱ����*/
    void ftmTimerISR(void)
  	{
  		LIN_DRV_TimeoutService(INST_LIN1);
  		/* Increment overflow count */
  		timerOverflowInterruptCount++;
  		FTM_DRV_ClearStatusFlags(INST_FLEXTIMER_MC1, (uint32_t)FTM_TIME_OVER_FLOW_FLAG);
  	}

    uint32_t lin1TimerGetTimeIntervalCallback0(uint32_t *ns)
    {
        static uint32_t previousCountValue = 0UL;
        uint32_t counterValue;

        counterValue = FTM_DRV_CounterRead(INST_FLEXTIMER_MC1);
        *ns = ((uint32_t)(counterValue + timerOverflowInterruptCount * TIMER_COMPARE_VAL - previousCountValue)) * 1000U / TIMER_TICKS_1US;
        timerOverflowInterruptCount = 0UL;
        previousCountValue = counterValue;

        return 0UL;
    }




  void KEY1_proc (void)
  {
	  LIN_DRV_MasterSendHeader(INST_LIN1,FRAME_SLAVE_RECEIVE_DATA);

  }


  void KEY2_proc (void)
  {
	  LIN_DRV_MasterSendHeader(INST_LIN1,FRAME_MASTER_RECEIVE_DATA);

  }

  void KEY3_proc (void)
  {
	  if(LIN_NODE_STATE_SLEEP_MODE ==  LIN_DRV_GetCurrentNodeState(INST_LIN1) )
	  {
		  LIN_DRV_SendWakeupSignal(INST_LIN1);
	  }
	  else
	  {
		  LIN_DRV_MasterSendHeader(INST_LIN1,FRAME_GO_TO_SLEEP);
	  }
  }

  /*LIN����ص�����*/
       lin_callback_t CallbackHandler(uint32_t instance, lin_state_t * lin1_State)
       {
         lin_callback_t callbackCurrent;
         callbackCurrent = lin1_State->Callback;
         (void)instance;
         switch (lin1_State->currentEventId)
         {
             case LIN_PID_OK:

                 /* Set timeout */
                 LIN_DRV_SetTimeoutCounter(INST_LIN1, TIMEOUT);

                 /* If PID is FRAME_SLAVE_RECEIVE_DATA, salve node will receive data from master node */
                 if(FRAME_SLAVE_RECEIVE_DATA == lin1_State->currentId) //�����ǰIDЭ��Ϊ�ӻ���������
                 {
                     /* Call to Send Frame DATA Function */
                     LIN_DRV_SendFrameData(INST_LIN1, txBuff, sizeof(txBuff));
                     Master_Tx_Flag =true;
                 }

                 /* If PID is FRAME_MASTER_RECEIVE_DATA, master node will receive data */
                 if(FRAME_MASTER_RECEIVE_DATA == lin1_State->currentId) //�����ǰIDЭ��Ϊ������������
                 {
                     /* Call to Receive Frame DATA Function */
                     LIN_DRV_ReceiveFrameData(INST_LIN1, rxBuff, sizeof(rxBuff));
                     Master_Rx_Flag = true;
                 }

                 /* If PID is FRAME_GO_TO_SLEEP, salve node will go to sleep mode */
                 if(FRAME_GO_TO_SLEEP == lin1_State->currentId)  //�����ǰIDЭ��Ϊ����
                 {
                     /* Go to sleep mode */
                  LIN_DRV_GoToSleepMode(INST_LIN1);
                  Sleep_Flag = true;
            		LED1(0);
            		LED2(0);
            		LED3(0);
            		LED4(0);
                 }
                 break;
             case LIN_PID_ERROR:
                 /* Go to idle mode */
                 LIN_DRV_GoToSleepMode(INST_LIN1);
                 break;
             case LIN_TX_COMPLETED:
             case LIN_RX_COMPLETED:
                 /* Go to idle mode */
                 LIN_DRV_GotoIdleState(INST_LIN1);
                 break;
             case LIN_CHECKSUM_ERROR:
             case LIN_READBACK_ERROR:
             case LIN_FRAME_ERROR:
             case LIN_RECV_BREAK_FIELD_OK:
                 LIN_DRV_SetTimeoutCounter(INST_LIN1, TIMEOUT);
                 break;
             case LIN_WAKEUP_SIGNAL:
                 /* Set wakeup signal flag */
             	Master_Awake_Flag = true;
                 break;
             case LIN_SYNC_ERROR:
             case LIN_BAUDRATE_ADJUSTED:
             case LIN_NO_EVENT:
             case LIN_SYNC_OK:
             default:
             /* do nothing */
                 break;
         }
         return callbackCurrent;
       }


       void Lin_Master_Task (void)
        	{
        	int i;
        	uint8_t byteRemain = 1U;
        	status_t status = STATUS_ERROR;
        	status = LIN_DRV_GetReceiveStatus(INST_LIN1, &byteRemain);
        	if((status == STATUS_SUCCESS) && (0U == byteRemain) && (FRAME_MASTER_RECEIVE_DATA == lin1_State.currentId))
        	{
        		if( Master_Rx_Flag == true)
        		{
        			LED1(1);
        			LED2(1);
        			for(i=0;i<8;i++)
        			{
        				/* У����յ��������Ƿ�һ��,���һ�������,��һ�������*/
        				if( verifyBuff[i] != rxBuff[i])
        				{
        					LED1(0);
        					LED2(0);
        				}
        				if(i==0) u1_printf("*****************\r\n");
        				u1_printf("�������ձ��� data %d : 0x%x\r\n",i,rxBuff[i]);
        				if(i==7) u1_printf("*****************\r\n");
        			}
        			Master_Rx_Flag =false;
        		}
        	}

        	if((status == STATUS_SUCCESS) && (0U == byteRemain) && (FRAME_SLAVE_RECEIVE_DATA == lin1_State.currentId))
        	{
        		if( Master_Tx_Flag == true)
        		{
        				for(i=0;i<8;i++)
        				{
        					if(i==0) u1_printf("*****************\r\n");
        					u1_printf("�������ͱ��� data %d : 0x%x\r\n",i,txBuff[i]);
        					if(i==7) u1_printf("*****************\r\n");
        				}
        			Master_Tx_Flag =false;
        		}
        	}
        	if((status == STATUS_SUCCESS) && (0U == byteRemain) && (FRAME_GO_TO_SLEEP == lin1_State.currentId))
        	{
        		if( Sleep_Flag == true)
        		{
        			u1_printf("���������������� \r\n");
        			LED3(0);
        			Sleep_Flag =false;
        		}
        	}
        	if( Master_Awake_Flag == true)
        	{
        		u1_printf("�������ͻ������� \r\n");
        		LED3(1);
        		Master_Awake_Flag = false;
        	}
        	}








int main(void)
{
  /* Write your local variable definition here */
	uint8_t pinstate;
	int MCU_Freq;
	ftm_state_t ftmStateStruct1;
	ftm_state_t ftmStateStruct2;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

	/*LIN��ʱ����*/
		FTM_DRV_Init(INST_FLEXTIMER_MC1, &flexTimer_mc1_InitConfig,&ftmStateStruct1);
		INT_SYS_InstallHandler(FTM0_Ovf_Reload_IRQn, &ftmTimerISR, (isr_t*) 0U);
		INT_SYS_EnableIRQ(FTM0_Ovf_Reload_IRQn);
		FTM_DRV_InitCounter(INST_FLEXTIMER_MC1, &flexTimer_mc1_TimerConfig);
		FTM_DRV_CounterStart(INST_FLEXTIMER_MC1);

	/*LED������˸*/
		FTM_DRV_Init(INST_FLEXTIMER_MC2, &flexTimer_mc2_InitConfig,&ftmStateStruct2);
		INT_SYS_InstallHandler(FTM1_Ovf_Reload_IRQn, &LED_Period_ISR, (isr_t*) 0U);
		INT_SYS_EnableIRQ(FTM1_Ovf_Reload_IRQn);
		FTM_DRV_InitCounter(INST_FLEXTIMER_MC2, &flexTimer_mc2_TimerConfig);
		FTM_DRV_CounterStart(INST_FLEXTIMER_MC2);

		/* ��ʼ��LIN���� */
		LIN_DRV_Init(INST_LIN1, &lin1_InitConfig0, &lin1_State);
		LIN_DRV_InstallCallback(INST_LIN1,(lin_callback_t)CallbackHandler);


	MCU_Freq = delay_init();//��ʼ��delay����
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr); //��ʼ��IO
	I2C_MasterInit(&i2c1_instance, &i2c1_MasterConfig0);//��ʼ��I2C����,����OLEDͨѶ
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0); //��ʼ������

	oled_init(); //OLED���ò�����ʼ��
	OLED_TITLE((uint8_t*)"S32K144",(uint8_t*)"LIN_M");//OLED��ʾ����
	u1_printf("��ʼ�����,MCU����Ƶ��Ϊ %d Mhz \r\n",MCU_Freq);
    while(1)
    {
    	pinstate = KEY_Proc (0);
		if(pinstate ==BTN1_PRES )
		{
			KEY1_proc();
		}
		else if(pinstate ==BTN2_PRES )
		{
			KEY2_proc();
		}
		else if(pinstate ==BTN3_PRES )
		{
			KEY3_proc();
		}

		Lin_Master_Task();

    }
  /*** Don't write any code pass th5is line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
