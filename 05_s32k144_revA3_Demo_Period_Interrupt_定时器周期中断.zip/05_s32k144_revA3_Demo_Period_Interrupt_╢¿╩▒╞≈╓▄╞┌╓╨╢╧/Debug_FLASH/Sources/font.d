Sources/font.o: ../Sources/font.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/include/font.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/include/font.h:
