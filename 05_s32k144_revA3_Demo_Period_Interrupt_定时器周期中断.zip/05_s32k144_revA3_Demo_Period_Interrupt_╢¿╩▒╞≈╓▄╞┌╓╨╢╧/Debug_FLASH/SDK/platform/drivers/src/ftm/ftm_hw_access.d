SDK/platform/drivers/src/ftm/ftm_hw_access.o: \
 ../SDK/platform/drivers/src/ftm/ftm_hw_access.c \
 ../SDK/platform/drivers/src/ftm/ftm_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/clock.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_period_interrupt\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/ftm_common.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/callbacks.h

../SDK/platform/drivers/src/ftm/ftm_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/clock.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_period_interrupt\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/drivers/inc/ftm_common.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_revA3_Demo_Period_Interrupt/SDK/platform/devices/callbacks.h:
