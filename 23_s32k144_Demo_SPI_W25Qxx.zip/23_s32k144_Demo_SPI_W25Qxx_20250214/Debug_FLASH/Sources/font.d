Sources/font.o: ../Sources/font.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/include/font.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/include/font.h:
