SDK/platform/drivers/src/lpspi/lpspi_slave_driver.o: \
 ../SDK/platform/drivers/src/lpspi/lpspi_slave_driver.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_slave_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_shared_function.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/status.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_spi_w25qxx\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/rtos/osif/osif.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/callbacks.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/interrupt_manager.h \
 ../SDK/platform/drivers/src/lpspi/lpspi_hw_access.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_shared_function.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_slave_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_shared_function.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/status.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_spi_w25qxx\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/rtos/osif/osif.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/callbacks.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/interrupt_manager.h:

../SDK/platform/drivers/src/lpspi/lpspi_hw_access.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/lpspi_shared_function.h:
