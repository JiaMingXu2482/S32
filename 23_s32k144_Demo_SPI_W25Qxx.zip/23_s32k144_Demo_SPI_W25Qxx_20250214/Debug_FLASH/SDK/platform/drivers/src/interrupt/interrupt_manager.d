SDK/platform/drivers/src/interrupt/interrupt_manager.o: \
 ../SDK/platform/drivers/src/interrupt/interrupt_manager.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/devassert.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI_W25Qxx/SDK/platform/devices/devassert.h:
