Sources/font.o: ../Sources/font.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_FREQ/include/font.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_FREQ/include/font.h:
