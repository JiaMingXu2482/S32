/*
 * ADC.c
 *
 *  Created on: 2020��12��5��
 *      Author: Administrator
 */

#include"cpu.h"
#include"ADC.h"



#define ADC_VREFH       3.3f
#define ADC_VREFL       0.0f
  float adcValue;
  uint16_t adcRawValue;
  uint16_t adcMax;


  float ADC1_GET (void)
  {
	float adc_volt;
	adc_volt = ( ADC_GET_EXT2() ) * (100.0/3.3) ; //��ADC0_CH2���в���
	 return adc_volt;
  }


  float ADC2_GET (void)
  {
	 float adc_volt;
	 adc_volt = ( ADC_GET_EXT3() ) * (100.0/3.3) ; //��ADC0_CH3���в���
	 return adc_volt;
  }



  float ADC_GET_EXT2(void)
  {
      /* Configure ADC channel and software trigger a conversion */
      ADC_DRV_ConfigChan(INST_ADCONV1, 0U, &adConv1_ChnConfig0);
      /* Wait for the conversion to be done */
      ADC_DRV_WaitConvDone(INST_ADCONV1);
      /* Store the channel result into a local variable */
      ADC_DRV_GetChanResult(INST_ADCONV1, 0U, &adcRawValue);

      /* Process the result to get the value in volts */
      adcValue = ((float) adcRawValue / adcMax) * (ADC_VREFH - ADC_VREFL);
      return adcValue;
  }



  float ADC_GET_EXT3(void)
  {
      /* Configure ADC channel and software trigger a conversion */
      ADC_DRV_ConfigChan(INST_ADCONV1, 0U, &adConv1_ChnConfig1);
      /* Wait for the conversion to be done */
      ADC_DRV_WaitConvDone(INST_ADCONV1);
      /* Store the channel result into a local variable */
      ADC_DRV_GetChanResult(INST_ADCONV1, 0U, &adcRawValue);

      /* Process the result to get the value in volts */
      adcValue = ((float) adcRawValue / adcMax) * (ADC_VREFH - ADC_VREFL);
      return adcValue;
  }


  void ADC_Init (void)
  {
		/*��������ѡ������*/
	    if (adConv1_ConvConfig0.resolution == ADC_RESOLUTION_8BIT)
	        adcMax = (uint16_t) (1 << 8);
	    else if (adConv1_ConvConfig0.resolution == ADC_RESOLUTION_10BIT)
	        adcMax = (uint16_t) (1 << 10);
	    else
	        adcMax = (uint16_t) (1 << 12);

	    ADC_DRV_ConfigConverter(INST_ADCONV1, &adConv1_ConvConfig0);
	    ADC_DRV_AutoCalibration(INST_ADCONV1);



  }
