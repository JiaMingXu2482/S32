/*
 * ADC.h
 *
 *  Created on: 2020��12��5��
 *      Author: Administrator
 */

#ifndef ADC_H_
#define ADC_H_
  float ADC_GET_EXT2(void);
  float ADC_GET_EXT3(void);
  void ADC_Init (void);
  float ADC1_GET (void);
  float ADC2_GET (void);
#endif /* ADC_H_ */
