/*
 * Ʒ�ǿƼ�S32K144������
 * ADC�������
 * ADC��������������ת��λ�� ����ͨ�����ں���Ļ��ʾ������
 *
 * IO����
 * KEY1 PTC12
 * KEY2 PTC13
 * KEY3 PTB2
 * LED1 PTD16
 * LED2 PTD15
 * LED3 PTD1
 * LED4 PTD0
 *
 * ADC0CH2 PTA6
 * ADC0CH3 PTA7
 *
 * PS **һ��Ҫ��clockMan1�����д�PDB0��PDB1��ʱ�ӣ���Ȼ�����޷�����**
*/
#include "Cpu.h"
#include "delay.h"
#include "uart.h"
#include"key.h"
#include"oled.h"
  volatile int exit_code = 0;

#define LED1(x)  PINS_DRV_WritePin(PTD,16,!x);
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!x);
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!x);
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!x);

#define ADC_INSTANCE    0UL
#define ADC_VREFH       3.3f
#define ADC_VREFL       0.0f
uint8_t selectedGroupIndex;
bool groupConvDone = false;

/*adc�����жϣ�������ɺ󴥷�*/
  void adc_pal1_callback00(const adc_callback_info_t * const callbackInfo, void * userData)
  {
      (void) userData;

      groupConvDone = true;

  }


int main(void)
{
  /* Write your local variable definition here */
	int MCU_Freq;
    uint16_t adcMax;
    uint16_t adc_val_1;
    uint16_t adc_val_2;
    float adc_Volt_1;
    float adc_Volt_2;

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
	MCU_Freq = delay_init();//��ʼ��delay����
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr); //��ʼ��IO
	I2C_MasterInit(&i2c1_instance, &i2c1_MasterConfig0);//��ʼ��I2C����,����OLEDͨѶ
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0); //��ʼ������

	/*����ѡ�����ڴ�����������*/
    adc_resolution_t resolution = ((extension_adc_s32k1xx_t *)(adc_pal1_InitConfig0.extension))->resolution;
    if (resolution == ADC_RESOLUTION_8BIT)
        adcMax = (uint16_t) (1 << 8);
    else if (resolution == ADC_RESOLUTION_10BIT)
        adcMax = (uint16_t) (1 << 10);
    else
        adcMax = (uint16_t) (1 << 12);

    ADC_Init(&adc_pal1_instance, &adc_pal1_InitConfig0); //adc��ʼ��

	oled_init(); //OLED���ò�����ʼ��
	OLED_TITLE((uint8_t*)"S32K144",(uint8_t*)"ADC");//OLED��ʾ����
	OLED_ShowString(0,3,(uint8_t*)"ADC1:",16,0);
	OLED_ShowString(0,5,(uint8_t*)"ADC2:",16,0);
	u1_printf("��ʼ�����,MCU����Ƶ��Ϊ %d Mhz \r\n",MCU_Freq);
    while(1)
    {
    	/*ѡ���������󣬽��в���*/
	selectedGroupIndex =0;
	ADC_StartGroupConversion(&adc_pal1_instance, selectedGroupIndex);
	/*�ȴ������жϲ�����ɺ�������*/
	 if(groupConvDone == true)
	 {
		adc_val_1 = adc_pal1_Results00[0];
		adc_val_2 = adc_pal1_Results00[1];

		adc_Volt_1 = ((float) adc_val_1 / adcMax) * (ADC_VREFH - ADC_VREFL);
		adc_Volt_2 = ((float) adc_val_2 / adcMax) * (ADC_VREFH - ADC_VREFL);
		u1_printf("adc0:%f adc1:%f  \r\n", adc_Volt_1, adc_Volt_2);
		groupConvDone = false;
	 }
	/*LED��˸*/
   	PINS_DRV_TogglePins(PTD, 1 << 0);
   	PINS_DRV_TogglePins(PTD, 1 << 1);
   	PINS_DRV_TogglePins(PTD, 1 << 15);
   	PINS_DRV_TogglePins(PTD, 1 << 16);

   	delay_ms(100);
	/*OLED��ѹ��ֵˢ��*/
	OLED_write_number(45,3, adc_Volt_1,16,0);
	OLED_write_number(45,5, adc_Volt_2,16,0);

    }
  /*** Don't write any code pass th5is line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
