Sources/uart.o: ../Sources/uart.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/cpu.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/status.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_swtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/lpuart_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/callbacks.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/i2c_pal.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/i2c_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/i2c_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/lpi2c_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/adc_pal.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/adc_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/adc_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/adc_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/src/adc/adc_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/trgmux_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/pdb_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/pin_mux.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/clockMan1.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/Cpu.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/dmaController1.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/lpuart1.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/i2c1.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/adc_pal1.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/include/uart.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/cpu.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/status.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_swtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/lpuart_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/callbacks.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/i2c_pal.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/i2c_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/i2c_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/lpi2c_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/adc_pal.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/adc_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/pal/inc/adc_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/adc_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/src/adc/adc_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/trgmux_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/pdb_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/clock.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/devices/S32K144/startup/system_S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/pin_mux.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/clockMan1.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/Cpu.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/dmaController1.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/lpuart1.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/i2c1.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/Generated_Code/adc_pal1.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Swtrg/include/uart.h:
