/*
 * sys_cfg.h
 *
 *  Created on: 2020��11��18��
 *      Author: Administrator
 */

#ifndef SYS_CFG_H_
#define SYS_CFG_H_

extern const pdb_adc_pretrigger_config_t pdb1_AdcTrigInitConfig0;

/*! @brief PDB timer init config declaration */
extern const pdb_timer_config_t pdb1_InitConfig0;

/* @brief: Calculate the values to be used by pdb to generate
 *        a interrupt at a specific timeout.
 * @param pdbConfig: pointer to the PDB configuration struct
 * @param type:      pdb_timer_config_t *
 * @param uSec:      interval for pdb interrupt in microseconds
 * @param type:      uint32_t
 * @param intVal:    pointer to the storage element where to set the calculated value
 * @param type:      uint16_t
 * @return:          Returns true if the interrupt period can be achieved, false if not
 * @return type:     bool
 */
bool calculateIntValue(const pdb_timer_config_t *pdbConfig, uint32_t uSec, uint16_t *intValue);


#endif /* SYS_CFG_H_ */
