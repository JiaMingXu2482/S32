SDK/platform/drivers/src/lpi2c/lpi2c_irq.o: \
 ../SDK/platform/drivers/src/lpi2c/lpi2c_irq.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpi2c_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/rtos/osif/osif.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/callbacks.h \
 ../SDK/platform/drivers/src/lpi2c/lpi2c_irq.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpi2c_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/rtos/osif/osif.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/callbacks.h:

../SDK/platform/drivers/src/lpi2c/lpi2c_irq.h:
