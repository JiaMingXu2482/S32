SDK/platform/drivers/src/pdb/pdb_driver.o: \
 ../SDK/platform/drivers/src/pdb/pdb_driver.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pdb_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_pdb_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 ../SDK/platform/drivers/src/pdb/pdb_hw_access.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pdb_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_pdb_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

../SDK/platform/drivers/src/pdb/pdb_hw_access.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h:
