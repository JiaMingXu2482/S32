Sources/font.o: ../Sources/font.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/include/font.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/include/font.h:
