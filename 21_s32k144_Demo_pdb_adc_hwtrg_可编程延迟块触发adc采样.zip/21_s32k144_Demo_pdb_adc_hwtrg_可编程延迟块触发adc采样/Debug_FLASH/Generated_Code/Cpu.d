Generated_Code/Cpu.o: ../Generated_Code/Cpu.c ../Generated_Code/Cpu.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_pdb_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/rtos/osif/osif.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpuart_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/callbacks.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/pal/inc/i2c_pal.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/Generated_Code/i2c_pal_cfg.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/pal/inc/i2c_pal_mapping.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpi2c_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pdb_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/adc_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 ../Generated_Code/pin_mux.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pins_driver.h \
 ../Generated_Code/clockMan1.h ../Generated_Code/dmaController1.h \
 ../Generated_Code/lpuart1.h ../Generated_Code/i2c1.h \
 ../Generated_Code/pdb1.h ../Generated_Code/adConv1.h

../Generated_Code/Cpu.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_pdb_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/rtos/osif/osif.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpuart_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/edma_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/callbacks.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/pal/inc/i2c_pal.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/Generated_Code/i2c_pal_cfg.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/pal/inc/i2c_pal_mapping.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/lpi2c_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pdb_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/clock.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/adc_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/startup/system_S32K144.h:

../Generated_Code/pin_mux.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pins_driver.h:

../Generated_Code/clockMan1.h:

../Generated_Code/dmaController1.h:

../Generated_Code/lpuart1.h:

../Generated_Code/i2c1.h:

../Generated_Code/pdb1.h:

../Generated_Code/adConv1.h:
