Generated_Code/pin_mux.o: ../Generated_Code/pin_mux.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h \
 ../Generated_Code/pin_mux.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pins_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/devassert.h:

../Generated_Code/pin_mux.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/drivers/inc/pins_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_pdb_adc_hwtrg/SDK/platform/devices/status.h:
