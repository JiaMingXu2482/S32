/*
 * Ʒ�ǿƼ�S32K144������
 *
 * PDB - adcʵ��
 * ��ʾ����:
 * ����PDB0(�ɱ���ӳٿ�)����adc0-ch2����,���1�롣
 *
 * IO����
 * ADC0_CH2 PTA6
 *
 * LED1 PTD16 FTM0_CH1
 * LED2 PTD15 FTM0_CH0
 * LED3 PTD1 FTM0_CH3
 * LED4 PTD0 FTM0_CH2
 *
*/
#include "Cpu.h"
#include "delay.h"
#include "uart.h"
#include"key.h"
#include"sys_cfg.h"
#include"oled.h"
  volatile int exit_code = 0;

#define PDB_INSTANCE    0UL
#define ADC_INSTANCE    0UL
/*MCU�ο���ѹѡ�� �����������ñѡ��3.3V ����3.3V ���ʹ��5V����,����5V*/
//#define ADC_VREFH       5.0f
#define ADC_VREFH       3.3f
#define ADC_VREFL       0.0f


#define PDLY_TIMEOUT    1000000UL //PDB��ʱ��� ��λ΢��

#define LED1(x)  PINS_DRV_WritePin(PTD,16,!x);
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!x);
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!x);
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!x);

  volatile bool adcConvDone  = false;
  volatile uint16_t adcRawValue1;





  void ADC_IRQHandler(void)
  {

      ADC_DRV_GetChanResult(ADC_INSTANCE, 0U, (uint16_t *)&adcRawValue1); //��ȡadcֵ
      PINS_DRV_TogglePins(PTD, 1 << 16);//led��˸
      adcConvDone = true;//��ȡ��,���ñ�־λ
  }



int main(void)
{
  /* Write your local variable definition here */
    uint16_t delayValue = 0;

    /* Variables in which we store data from ADC */
    uint16_t adcMax;
    float adcValue1;

	uint8_t pinstate;
	int MCU_Freq;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
	MCU_Freq = delay_init();//��ʼ��delay����
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr); //��ʼ��IO
	I2C_MasterInit(&i2c1_instance, &i2c1_MasterConfig0);//��ʼ��I2C����,����OLEDͨѶ
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0); //��ʼ������


    /* ѡ��adc�ֱ��� */
    if (adConv1_ConvConfig0.resolution == ADC_RESOLUTION_8BIT)
        adcMax = (uint16_t) (1 << 8);
    else if (adConv1_ConvConfig0.resolution == ADC_RESOLUTION_10BIT)
        adcMax = (uint16_t) (1 << 10);
    else
        adcMax = (uint16_t) (1 << 12);




    ADC_DRV_ConfigConverter(ADC_INSTANCE, &adConv1_ConvConfig0); //��ʼ��adc
    ADC_DRV_AutoCalibration(ADC_INSTANCE); //�Զ�У׼

	ADC_DRV_ConfigChan(ADC_INSTANCE, 0UL, &adConv1_ChnConfig0);//���ò���ͨ��

    INT_SYS_InstallHandler(ADC0_IRQn, &ADC_IRQHandler, (isr_t*) 0); //��װhandler

    calculateIntValue(&pdb1_InitConfig0, PDLY_TIMEOUT, &delayValue); //nxp�ṩ�Ĺ���,����ͨ���˺����Զ�����pdb���������

    PDB_DRV_Init(PDB_INSTANCE, &pdb1_InitConfig0);//��ʼ��PDB
    PDB_DRV_Enable(PDB_INSTANCE);//ʹ��PDB
    PDB_DRV_ConfigAdcPreTrigger(PDB_INSTANCE, 0UL, &pdb1_AdcTrigInitConfig0); //����Ԥ����
    PDB_DRV_SetTimerModulusValue(PDB_INSTANCE, (uint32_t) delayValue);//���ô������
    PDB_DRV_SetAdcPreTriggerDelayValue(PDB_INSTANCE, 0UL, 0UL,(uint32_t) delayValue);
    PDB_DRV_LoadValuesCmd(PDB_INSTANCE);
    PDB_DRV_SoftTriggerCmd(PDB_INSTANCE); //��ʼPDB

    INT_SYS_EnableIRQ(ADC0_IRQn);//ʹ��ADC0�ж�


	oled_init(); //OLED���ò�����ʼ��
	OLED_TITLE((uint8_t*)"S32K144",(uint8_t*)"PDB ADC");//OLED��ʾ����
	OLED_ShowString(0,3,(uint8_t*)"ADC1:",16,0);
	u1_printf("��ʼ�����,MCU����Ƶ��Ϊ %d Mhz \r\n",MCU_Freq);
    while(1)
    {
    	 if (adcConvDone == true)
    	        {
    	            /* Process the result to get the value in volts */
    	            adcValue1 = ((float) adcRawValue1 / adcMax) * (ADC_VREFH - ADC_VREFL);
    	            /* And convert it to string */
    	            u1_printf("adc1 value : %f v \r\n",adcValue1);
    	            /* Clear conversion done interrupt flag */
    	            adcConvDone = false;
    	            /* Trigger PDB timer */
    	            PDB_DRV_SoftTriggerCmd(PDB_INSTANCE);
    	            OLED_write_number(45,3, adcValue1,16,0);
    	        }
   	delay_ms(100);
   	PINS_DRV_TogglePins(PTD, 1 << 0);
    }
  /*** Don't write any code pass th5is line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
