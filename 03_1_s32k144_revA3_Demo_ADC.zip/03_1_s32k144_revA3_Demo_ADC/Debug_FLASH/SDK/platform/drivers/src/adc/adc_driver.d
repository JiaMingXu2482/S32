SDK/platform/drivers/src/adc/adc_driver.o: \
 ../SDK/platform/drivers/src/adc/adc_driver.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/adc_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/devassert.h \
 ../SDK/platform/drivers/src/adc/adc_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/clock.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/status.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_adc\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/adc_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/devassert.h:

../SDK/platform/drivers/src/adc/adc_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/drivers/inc/clock.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_ADC/SDK/platform/devices/status.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_reva3_demo_adc\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
