function [Envelope, r_ssmax] = func_Envelope(VehiclePara, Constraints,VehStateMeasured)
%FUNC_ENVELOPE  Stability and rollover envelope bounds used as MPC constraints.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

    a   = VehiclePara.lf;
    b   = VehiclePara.lr;
    lr  = VehiclePara.lr;
    M   = VehiclePara.m;
    g   = VehiclePara.g;
    tf  = VehiclePara.tf;
    Kt  = VehiclePara.Kt;
    CarHat = VehiclePara.CarHat;
    Vel    = VehStateMeasured.x_dot;

    Alphar_lim = Constraints.arlim;
    LTR_lim    = Constraints.LTR_lim;
    es         = Constraints.es;

    r_ssmax = -CarHat * Alphar_lim * (1 + b/a) / (M * Vel);

    LM_middle = 0;
    Yroad_L   = Constraints.Roadwidth/2;
    Eymin = LM_middle - Yroad_L;
    Eymax = Eymin + 2*Yroad_L;

    Envelope.Henv = [ 0 0 0 0  1 0;
                      0 0 0 0 -1 0 ];
    Envelope.Genv = [ Eymax - (tf/2 + es);
                     -Eymin - (tf/2 + es) ];

    if isfield(Constraints,'ZengRho_on') && Constraints.ZengRho_on
        Fzr_st  = M * g * a / (a + b);
        Cr_cur  = max(abs(VehiclePara.CbarR), 1e3);
        a_sat   = atan( VehiclePara.mu * Fzr_st / Cr_cur );
        a_sl    = atan( 3 * VehiclePara.mu * Fzr_st / abs(CarHat) );
        alpha_r_sat = min(a_sat, a_sl);
        Envelope.Hsh = [  0      1      0 0 0 0;
                          0     -1      0 0 0 0;
                          1/Vel -lr/Vel 0 0 0 0;
                         -1/Vel  lr/Vel 0 0 0 0 ];
        Envelope.Gsh = [ Constraints.Zeng_rmax; Constraints.Zeng_rmax;
                         alpha_r_sat;           alpha_r_sat ];
    else
        Envelope.Hsh = [  0      1      0 0 0 0;
                          0     -1      0 0 0 0;
                          1/Vel -lr/Vel 0 0 0 0;
                         -1/Vel  lr/Vel 0 0 0 0 ];
        Envelope.Gsh = [ r_ssmax; r_ssmax; Alphar_lim; Alphar_lim ];
    end

    ms      = VehiclePara.ms;
    h_TL    = VehiclePara.h_TL;
    h_S2R   = VehiclePara.h_S2R;
    delta_f = VehStateMeasured.delta_f;

    kappa_g = M*h_TL - ms*h_S2R;
    bta     = 2/(M*g*tf);

    CbF = VehiclePara.CbarF;  CbR = VehiclePara.CbarR;
    cd_f = cos(delta_f);
    c_ay = [ (CbF*cd_f + CbR)/(M*Vel), ...
             (CbF*a*cd_f - CbR*lr)/(M*Vel), 0, 0, 0, 0 ];
    d_ay = [ -CbF*cd_f/M, 0, 0 ];

    Hr_row = bta*( kappa_g*c_ay + [0 0 Kt 0 0 0] );
    Or_row = bta*( kappa_g*d_ay + [0 0 1] );

    Envelope.Hr = [ Hr_row; -Hr_row ];
    Envelope.Or = [ Or_row; -Or_row ];
    Envelope.Gr = [ LTR_lim; LTR_lim ];

end
