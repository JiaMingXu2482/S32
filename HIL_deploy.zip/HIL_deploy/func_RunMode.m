function [mode, zeng, dsname] = func_RunMode()
%FUNC_RUNMODE  Pick the controller from the CarSim dataset name. Desktop only.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
mode = 2;  zeng = 0;  dsname = '<unknown>';
try
    par = fullfile(func_CarSimResDir(), 'Run_all.par');
    ds  = regexp(fileread(par), 'FullDataName CarSim Run Control`([^`]+)`','tokens','once');
    dsname = ds{1};
catch
    return;
end
U = upper(dsname);
if     contains(U,'ZENG'), mode = 2;  zeng = 1;
elseif contains(U,'PMPC'), mode = 1;  zeng = 0;
else,                      mode = 2;  zeng = 0;
end
end
