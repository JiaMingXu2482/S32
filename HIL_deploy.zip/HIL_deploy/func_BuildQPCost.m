function [H, f] = func_BuildQPCost(MPCParameters, Constraints, Pred, Wts, ...
                                   zeta, AI, Ut, ref_Vy, ref_r, lambda_L1, ...
                                   gamma_prev, W_dgamma)
%FUNC_BUILDQPCOST  Assemble H and f of the upper-level MPC QP.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

Nu = MPCParameters.Nu;  Nc = MPCParameters.Nc;
Np = MPCParameters.Np;  Ne = MPCParameters.Ne;  Nr = MPCParameters.Nr;

PSI = Pred.PSI; THETA = Pred.THETA; PHI = Pred.PHI; GAMMA = Pred.GAMMA;
Q = Wts.Q; R = Wts.R; S = Wts.S; W = Wts.W; V = Wts.V;

n1 = Nc*Nu;  n2 = Ne;  n3 = Nr;
H = zeros(n1+n2+n3, n1+n2+n3);
H(1:n1, 1:n1)           = 2*(THETA'*Q*THETA + R + AI'*S*AI);
H(n1+(1:n2), n1+(1:n2)) = 2*Np*W;
if nargin < 12 || isempty(W_dgamma), W_dgamma = zeros(Nr); end
if nargin < 11 || isempty(gamma_prev), gamma_prev = zeros(Nr,1); end
if Nr > 0
    eta_g = 1e-3;
    if isfield(Constraints,'gamma_reg') && ~isempty(Constraints.gamma_reg)
        eta_g = Constraints.gamma_reg;
    end
    H(n1+n2+(1:n3), n1+n2+(1:n3)) = 2*(W_dgamma + eta_g*Nc*V);
end
H = (H+H')/2 + 1e-8*eye(size(H));

Yr_blk = [ref_Vy(:)'; ref_r(:)'; zeros(4, Np)];
Yr     = Yr_blk(:);

a    = PSI*zeta + PHI*GAMMA;
f_DU = 2*(THETA'*(Q*(a - Yr)) + AI'*(S*Ut));

eps_scale = [Constraints.epsilon_r*ones(2,1);   Constraints.epsilon_alpha*ones(2,1);
             Constraints.epsilon_LTR*ones(2,1); Constraints.epsilon_e*ones(2,1)];

w_L1 = lambda_L1 * Np * diag(W) .* eps_scale;

if Nr > 0
    f_gamma = Nc*diag(V) - 2 * W_dgamma * gamma_prev(:);
else
    f_gamma = zeros(Nr,1);
end

f = [ f_DU; w_L1; f_gamma ];

end
