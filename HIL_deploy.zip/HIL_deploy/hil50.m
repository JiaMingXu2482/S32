function hil50(mdl)
%HIL50  In-place conversion of an older pmpc_hil: replaces the 62-input scatter Mux with a plain 50-input Mux. Only needed once, on a model whose Inports were already replaced by NI In blocks.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   Run this ONLY on a pmpc_hil built before 2026-09-18, i.e. one whose
%   Mux feeding PMPC_MF has 62 inputs. It finds the NI In blocks by following
%   the wiring, not by name, so renamed blocks are fine. It is idempotent:
%   on an already-converted model it reports and does nothing.

if nargin < 1 || isempty(mdl), mdl = 'pmpc_hil'; end
SLOTS = [1:4, 17:62];
load_system(mdl);

ph = get_param([mdl '/PMPC_MF'], 'PortHandles');
ln = get_param(ph.Inport(1), 'Line');
assert(ln > 0, 'hil50:NoLine', 'PMPC_MF ������û�Ӷ���');
mux = get_param(get_param(ln,'SrcPortHandle'), 'Parent');
assert(strcmp(get_param(mux,'BlockType'),'Mux'), 'hil50:NotMux', ...
       'PMPC_MF ������ %s, ���� Mux ���� ���ģ�Ͳ���Ԥ�ڵĽṹ', get_param(mux,'BlockType'));

nIn = numel(get_param(mux,'PortHandles').Inport);
if nIn == numel(SLOTS)
    fprintf('  %s �Ѿ��� Mux(%d) ��, ����Ķ�\n', mdl, nIn);
    close_system(mdl, 0);
    return
end
assert(nIn == 62, 'hil50:BadWidth', '���� Mux �� %d ��, Ԥ�� 62 �� 50', nIn);

mph = get_param(mux,'PortHandles');
src = cell(62,2);
for s = 1:62
    l = get_param(mph.Inport(s), 'Line');
    assert(l > 0, 'hil50:Dangling', '�� %d ��û����', s);
    p = get_param(l,'LineParent');
    while p > 0, l = p; p = get_param(l,'LineParent'); end
    sp = get_param(l,'SrcPortHandle');
    src{s,1} = get_param(get_param(sp,'Parent'),'Name');
    src{s,2} = get_param(sp,'PortNumber');
end

zname = src{5,1};
for s = 5:16
    assert(strcmp(src{s,1}, zname), 'hil50:ZeroFill', ...
           '�� %d ������ %s, ��� 5 �۵� %s ��ͬ ���� 5-16 ��Ӧ�����Ǹ����� 0', ...
           s, src{s,1}, zname);
end
zb = [mdl '/' zname];
assert(strcmp(get_param(zb,'BlockType'),'Constant') && ...
       str2double(get_param(zb,'Value')) == 0, 'hil50:NotZero', ...
       '%s ����һ��ֵΪ 0 �� Constant, ����ɾ', zname);
fprintf('  5-16 �۵�����: %s (Constant 0)\n', zname);

pos = get_param(mux,'Position');
local_kill(mux);
local_kill(zb);
NEW = [mdl '/pack50'];
add_block('simulink/Signal Routing/Mux', NEW, 'Inputs', num2str(numel(SLOTS)), ...
          'Position', pos);
for i = 1:numel(SLOTS)
    s = SLOTS(i);
    add_line(mdl, sprintf('%s/%d', src{s,1}, src{s,2}), ...
                  sprintf('pack50/%d', i), 'autorouting','on');
end
add_line(mdl, 'pack50/1', 'PMPC_MF/1', 'autorouting','on');

save_system(mdl);
fprintf('  %s: Mux(62)+%s -> Mux(50), ���� %d ����һ��û��\n', ...
        mdl, zname, numel(SLOTS));
fprintf('  �������ճ����ɴ��뼴�ɡ�\n');
end

function local_kill(blk)
ph = get_param(blk,'PortHandles');
hs = [ph.Inport, ph.Outport];
for k = 1:numel(hs)
    for guard = 1:500
        l = get_param(hs(k),'Line');
        if l <= 0, break; end
        delete_line(l);
    end
end
delete_block(blk);
end
