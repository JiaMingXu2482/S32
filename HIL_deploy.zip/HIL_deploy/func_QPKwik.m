function [x, status, nAct] = func_QPKwik(H, f, A, b, lb, ub, maxiter, usews)
%FUNC_QPKWIK  Wrapper around mpcqpsolver (KWIK active-set QP), written against the R2018a API.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   mpcqpsolver uses the convention A*x >= b, not A*x <= b.
%   The active set is warm started through a persistent variable, so two
%   copies of the controller running in parallel would corrupt each other.

n = numel(f);
BIG = 1e12;
ubf = ub; lbf = lb;
ubf(~isfinite(ubf)) =  BIG;
lbf(~isfinite(lbf)) = -BIG;

Am = [ -A ; eye(n) ; -eye(n) ];
bm = [ -b ; lbf    ; -ubf    ];
m  = numel(bm);

if nargin < 8, usews = true; end
if usews
    iA0 = local_warmstart(m, false(m,1), false);
else
    iA0 = false(m,1);
end

[L, p] = chol(H, 'lower');
if p ~= 0
    x = zeros(n,1);  status = -2;  nAct = 0;  return
end
Linv = L \ eye(n);

opt = mpcqpsolverOptions;
opt.MaxIter         = maxiter;
opt.FeasibilityTol  = 1e-6;
opt.IntegrityChecks = false;

[x, st_, iA_out] = mpcqpsolver(Linv, f, Am, bm, zeros(0,n), zeros(0,1), iA0, opt);
status = double(st_);
if usews, local_warmstart(m, iA_out, true); end
nAct = double(sum(iA_out));
end

function iA = local_warmstart(m, iA_new, doSet)
persistent iA_ws
if isempty(iA_ws)
    iA_ws = false(m,1);
end
if numel(iA_ws) ~= m
    iA_ws = false(m,1);
end
if doSet
    iA_ws = iA_new;
end
iA = iA_ws;
end
