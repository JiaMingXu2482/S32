function [A, B] = func_TireTable(mode, varargin)
%FUNC_TIRETABLE  Measured tire carpet lookup.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

switch lower(mode)

    case 'build'
        C0 = varargin{1};  mu = varargin{2};
        T.C0 = C0;  T.mu = mu;
        T.alpha = linspace(-0.35, 0.35, 141).';
        T.Fz    = linspace(200, 14000, 70);
        [AA, FF] = ndgrid(T.alpha, T.Fz);
        [T.Fbar, T.Cbar] = fiala_exact(C0, mu, AA, FF);
        A = T;  B = [];

    case 'carsim'
        mu_road = varargin{1};
        if numel(varargin) >= 2, nW = varargin{2}; else, nW = 2; end
        C = load('TireCarpet_265_75R16.mat');
        alc = C.AL(:);  fzc = C.FZ(:);  FYc = C.FY;
        T.src = 'CarSim FY_TIRE_CARPET 265/75 R16';
        T.mu  = mu_road;  T.nW = nW;
        T.alpha = linspace(-0.35, 0.35, 141).';
        T.Fz    = linspace(200, 14000, 70);
        T.Fbar  = zeros(numel(T.alpha), numel(T.Fz));
        adeg    = rad2deg(abs(T.alpha));
        for j = 1:numel(T.Fz)
            fzw = T.Fz(j)/nW;
            if fzw >= fzc(1)
                col = interp1(fzc, FYc.', min(fzw, fzc(end)), 'linear').';
            else
                col = FYc(:,1) * (fzw/fzc(1));
            end
            fy1 = interp1(alc, col, min(adeg, alc(end)), 'pchip');
            T.Fbar(:,j) = -sign(T.alpha) .* (nW*mu_road/C.MU_REF) .* fy1;
        end
        T.Cbar = zeros(size(T.Fbar));
        da = T.alpha(2)-T.alpha(1);
        T.Cbar(2:end-1,:) = (T.Fbar(3:end,:)-T.Fbar(1:end-2,:))/(2*da);
        T.Cbar(1,:)   = (T.Fbar(2,:)-T.Fbar(1,:))/da;
        T.Cbar(end,:) = (T.Fbar(end,:)-T.Fbar(end-1,:))/da;
        T.C0 = max(abs(T.Cbar(:)));
        A = T;  B = [];

    case 'eval'
        T = varargin{1};  alpha = varargin{2};  Fz = varargin{3};
        a = min(max(alpha, T.alpha(1)), T.alpha(end));
        z = min(max(Fz,    T.Fz(1)),    T.Fz(end));
        da = T.alpha(2) - T.alpha(1);   na = numel(T.alpha);
        dz = T.Fz(2)    - T.Fz(1);      nz = numel(T.Fz);
        ia = min(max(floor((a - T.alpha(1))/da) + 1, 1), na-1);
        iz = min(max(floor((z - T.Fz(1))   /dz) + 1, 1), nz-1);
        ta = (a - T.alpha(ia))/da;      tz = (z - T.Fz(iz))/dz;
        w11 = (1-ta)*(1-tz);  w21 = ta*(1-tz);
        w12 = (1-ta)*tz;      w22 = ta*tz;
        A = w11*T.Fbar(ia,iz) + w21*T.Fbar(ia+1,iz) + ...
            w12*T.Fbar(ia,iz+1) + w22*T.Fbar(ia+1,iz+1);
        B = w11*T.Cbar(ia,iz) + w21*T.Cbar(ia+1,iz) + ...
            w12*T.Cbar(ia,iz+1) + w22*T.Cbar(ia+1,iz+1);
        if ~isfinite(A), A = 0;      end
        if ~isfinite(B), B = -T.C0;  end

    case 'exact'
        C0 = varargin{1};  mu = varargin{2};
        [A, B] = fiala_exact(C0, mu, varargin{3}, varargin{4});

    otherwise
        error('func_TireTable: mode must be build / eval / exact');
end
end

function [Fy, dFy] = fiala_exact(C, mu, alpha, Fz)
muFz = max(mu .* Fz, 1e-6);
t    = tan(alpha);
tsl  = 3 .* muFz ./ C;

Fy_u  = -C.*t + (C.^2 ./ (3.*muFz)).*abs(t).*t - (C.^3 ./ (27.*muFz.^2)).*t.^3;
dFt_u = -C + (2*C.^2 ./ (3.*muFz)).*abs(t) - (C.^3 ./ (9.*muFz.^2)).*t.^2;

sat = abs(t) >= tsl;
Fy  = Fy_u;              Fy(sat)  = -muFz(sat) .* sign(alpha(sat));
dFy = dFt_u .* (1+t.^2); dFy(sat) = 0;
end
