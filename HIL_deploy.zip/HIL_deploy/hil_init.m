function hil_init()
%HIL_INIT  One-shot initialization on the deployment machine. Run this before opening the model.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   Do NOT call setup_pmpc directly on the deployment machine.
%   setup_pmpc picks the controller from the CarSim dataset name; with no
%   CarSim present it silently falls back to the baseline MPC, not PMPC.
assignin('base', 'PMPC_MODE',    1);
assignin('base', 'PMPC_ZENGRHO', 0);
assignin('base', 'PMPC_VERBOSE', 0);
evalin('base', 'setup_pmpc;');

P = evalin('base','PMPC_P');
fprintf('\n===== check before generating code =====\n');
if P.Pm.ContrlMode == 1
    fprintf('  controller   PMPC  (Nr=%d)      [ok]\n', P.Pm.MPCParameters.Nr);
else
    fprintf(2, '  controller   NOT PMPC!  ContrlMode=%d\n', P.Pm.ContrlMode);
end
if P.Pm.MPCParameters.Verbose == 0
    fprintf('  per-step log off                 [ok]\n');
else
    fprintf(2, '  per-step log STILL ON - fprintf will end up in the code\n');
end
fprintf('  PMPC_P       Pm %d fields / S0 %d fields\n', ...
        numel(fieldnames(P.Pm)), numel(fieldnames(P.S0)));
fprintf('\n  next: open pmpc_hil, swap in NI In/Out, set NIVeriStand.tlc + C++\n');
fprintf('  see README_deploy.md\n\n');
end
