function RES = func_CarSimResDir()
%FUNC_CARSIMRESDIR  Resolve the CarSim results directory from simfile.sim. Desktop only; unused on the HIL target.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
sf = fileread('simfile.sim');
rn = regexp(sf,'ROOT_FILE_NAME\)\$\s+(\S+)','tokens','once');
wd = regexp(sf,'WORK_DIR\)\$\s+([^\r\n]+)','tokens','once');
if isempty(rn) || isempty(wd)
    error('func_CarSimResDir:Parse','simfile.sim ���Ҳ��� ROOT_FILE_NAME / WORK_DIR');
end
RES = fullfile(strtrim(wd{1}), 'Results', rn{1});
if ~exist(RES,'dir')
    error('func_CarSimResDir:Missing','CarSim ���Ŀ¼������: %s', RES);
end
end
