function [y, Bout] = func_RLSFilter_Calpha_r(f, d, FIR_Num, delta_n )
%FUNC_RLSFILTER_CALPHA_R  Recursive least squares estimate of rear-axle cornering stiffness.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    persistent F_r B_r lambda_r  Num_r  Rinv_r
    if (ischar(f) && strcmp(f,'initial'))
        lambda_r = d;
        Num_r = FIR_Num;
        Rinv_r = delta_n*eye(Num_r);
        F_r = zeros(Num_r,1);
        B_r = zeros(Num_r,1);
        y = 0;
        Bout = 0;
    else
        for J = Num_r:-1:2
            F_r(J) = F_r(J-1);
        end;
        F_r(1) = f;
        y= F_r'*B_r;
        error=d-y;
        K = Rinv_r*F_r/(lambda_r + F_r'*Rinv_r*F_r);
        Rinvn = (Rinv_r - K*F_r'*Rinv_r)/lambda_r;
        B_r = B_r + K*error;
        Bout = B_r;
        Rinv_r = Rinvn;
    end
end
