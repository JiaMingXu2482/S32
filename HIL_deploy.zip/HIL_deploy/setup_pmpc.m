function P = setup_pmpc()
%SETUP_PMPC  Build every controller parameter and initial state; writes PMPC_P to the base workspace.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   PMPC_MODE / PMPC_ZENGRHO / PMPC_VERBOSE in the base workspace override
%   the dataset-based selection. On the deployment machine they MUST be set
%   (hil_init does this). PMPC_VERBOSE = 0 is required before code generation.

[~, ~] = func_RLSFilter_Calpha_f('initial', 0.99, 10, 50);
[~, ~] = func_RLSFilter_Calpha_r('initial', 0.99, 10, 50);

[InitialParams] = func_InitialParams;

InitialParams.BaselineMode    = wsget('PMPC_BASELINE',   0);
InitialParams.BaselineCurrent = wsget('PMPC_BASELINE_I', 2.0);
InitialParams.FishhookMode    = wsget('PMPC_FISHHOOK',   0);
[Reftraj] = func_WayPoints(1);
C_table = func_tire_init_Calpha(1,8);

Cf0=func_Fz_Calpha(4740);
Cr0=func_Fz_Calpha(4380);
PMPC_cargo = wsget('PMPC_CARGO', 0);
[VehiclePara] = func_VehicleParams(PMPC_cargo);
VehiclePara.mu = 0.5;
VehiclePara.mu_eff = 0.4275;

TireF = func_TireTable('carsim', VehiclePara.mu, 2);
TireR = func_TireTable('carsim', VehiclePara.mu, 2);

modeStr = {'PMPC Э������','Baseline �޿���'};
manvStr = {'DLC ·������','�㹳 �����෭'};
disp(' ');
disp(['======== ' modeStr{InitialParams.BaselineMode+1} ...
      '  |  '    manvStr{InitialParams.FishhookMode+1} ' ========']);
disp(['  �غ� '  num2str(PMPC_cargo) ' kg' ...
      ' | mu '  num2str(VehiclePara.mu) ...
      ' | m '   num2str(VehiclePara.m) ...
      ' | lf '  num2str(VehiclePara.lf) ...
      ' | Ix '  num2str(VehiclePara.Ix) ...
      ' | h_S2R ' num2str(VehiclePara.h_S2R)]);
if InitialParams.BaselineMode
    disp(['  MR ��Ƶ��� ' num2str(InitialParams.BaselineCurrent) ' A, AFS/DB ������']);
end
Constraints.Roadwidth  = 3.5;
Constraints.SW_rate_max_deg = 720;
Constraints.dlt_rate_max = deg2rad(Constraints.SW_rate_max_deg / VehiclePara.isw);
Constraints.SW_max     =deg2rad(240);
Constraints.AFS_max_deg = 5.73;
Constraints.AFS_max    = deg2rad(Constraints.AFS_max_deg);
Constraints.tau_MR = 0.015;
Constraints.I_nom = InitialParams.BaselineCurrent;
Constraints.ZengRho_on = 0;
Constraints.ZengLong_on  = 1;
Constraints.Zg_rfloor    = 0.05;
Constraints.Zg_Vmin      = 30/3.6;
Constraints.Zg_tau       = 2.5;
Constraints.Zg_tpid      = 0.3;
Constraints.Zg_cmax      = 3;
Constraints.Zg_ayfull    = 0;
Constraints.Zg_kovs      = 1.3;
Constraints.Zg_Npv       = 12;
Constraints.Zg_apv       = 0;
Constraints.Zg_dVdb      = 0.3;
Constraints.QPA_lamd     = 0.003;
Constraints.Gov_lamx     = 0.1;

Constraints.gamma_reg = 1e-4;

Constraints.Vel_ref = 25;
Constraints.Vd_ref  = 0.5;
Constraints.Ctan_floor_frac = 0;
MPCParameters.Zg_Npv       = Constraints.Zg_Npv;
MPCParameters.Zg_ayfull    = Constraints.Zg_ayfull;
MPCParameters.FishhookMode = InitialParams.FishhookMode;
MPCParameters.sigma_budget = 0;
MPCParameters.fx_couple    = 0;
Constraints.Tb_max = 3000;
Constraints.dTb_rate_max = 2e4;
Constraints.Vymax   = 2;
Constraints.arlim   = deg2rad(5);
Constraints.phimax  = deg2rad(4);
Constraints.dphimax = deg2rad(50);
Constraints.epsimax = deg2rad(8);
Constraints.epsilon_r = 10*deg2rad(5);
Constraints.epsilon_alpha = 10*deg2rad(5);
Constraints.epsilon_LTR = 3;
Constraints.epsilon_e   = 8;
Constraints.eps_ub_scale = 10;

MPCParameters.Nu = 3;
MPCParameters.Ne = 8;
MPCParameters.Nx = 6;
MPCParameters.Ny = 6;
MPCParameters.Ts = 0.05;
MPCParameters.Ns = 12;
MPCParameters.Np = MPCParameters.Ns;
MPCParameters.Nc = 6;
MPCParameters.LTV_on = 0;
MPCParameters.QPSolver = wsget('PMPC_QPSOLVER', 1);
MPCParameters.Ts_exec = 0.01;
MPCParameters.Ncons_sh  = MPCParameters.Nc;
MPCParameters.Ncons_r   = MPCParameters.Nc;
MPCParameters.Ncons_env = MPCParameters.Np;

MPCParameters.Verbose = wsget('PMPC_VERBOSE', 1);

DiscreteModle = 2;
[md_auto, zg_auto, ds_auto] = func_RunMode();
ContrlMode    = wsget('PMPC_MODE', md_auto);
Constraints.ZengRho_on = wsget('PMPC_ZENGRHO', zg_auto);
ctlStr = {'�� �̶�Ȩ�� MPC (�� sigma/gamma)','�� Zeng rho ��Ȩ','�� ���� PMPC'};
if ContrlMode==1, ic=3; elseif Constraints.ZengRho_on, ic=2; else ic=1; end
disp(['  ���ݼ� ' ds_auto '   ->   ������ ' ctlStr{ic}]);
if strcmp(ds_auto, '<unknown>') && ~evalin('base','exist(''PMPC_MODE'',''var'')')
    warning('setup_pmpc:NoDataset', ...
        ['������ CarSim ���ݼ���(û�� simfile.sim?), ���˻�Ĭ�Ͽ����� "%s"��\n' ...
         '�����ǲ����, �����ڹ�������ʽָ��, ���籾�� PMPC:\n' ...
         '    PMPC_MODE = 1; PMPC_ZENGRHO = 0;   Ȼ������ setup_pmpc'], ctlStr{ic});
end

if ContrlMode == 1 || ContrlMode == 2
    MPCParameters.Nr = 3*(ContrlMode == 1);
    VehiclePara.CafHat = -57772.51*2;VehiclePara.CarHat = -53484.51*2;
    Constraints.es = 0.43; Constraints.emax= 0.5*(Constraints.Roadwidth-VehiclePara.tf)-Constraints.es;
    Constraints.LTR_lim = 0.8;
    CostWeights.Q1=0; CostWeights.Q2=0;
    CostWeights.Q3=1e2; CostWeights.Q4=0;
    CostWeights.Q5=2e4; CostWeights.Q6=2e2;
    if InitialParams.FishhookMode
        CostWeights.Q1=0;    CostWeights.Q2=0;
        CostWeights.Q3=5e6;  CostWeights.Q4=2e3;
        CostWeights.Q5=0;    CostWeights.Q6=0;
    end
    CostWeights.R1=1e0; CostWeights.R2=1e1; CostWeights.R3=5;
    CostWeights.S1=0; CostWeights.S2=0; CostWeights.S3=0;
    CostWeights.Qf_scale = 1;
    CostWeights.V1=100; CostWeights.V2=8e4;CostWeights.V3=1;
    CostWeights.tau_gamma = 0;
    CostWeights.Wdg=[0 0 0];
    CostWeights.W1=5e4; CostWeights.W2=5e4;
    CostWeights.W3=5e6; CostWeights.W4=5e6;
else
    error('Invalid ContrlMode');
end

WarmStart = zeros(MPCParameters.Nc*MPCParameters.Nu + MPCParameters.Ne + MPCParameters.Nr, 1);
DotPHI = zeros(MPCParameters.Np,1);
rho = diag([1 1 1]);
if ~isfield(Constraints,'Zeng_bL'),   Constraints.Zeng_bL   = 0; end
if ~isfield(Constraints,'Zeng_bR'),   Constraints.Zeng_bR   = 0; end
if ~isfield(Constraints,'Zeng_rmax'), Constraints.Zeng_rmax = 0; end

P = struct();
P.InitialParams = InitialParams;
P.Reftraj = Reftraj;
P.VehiclePara = VehiclePara;
P.Constraints = Constraints;
P.MPCParameters = MPCParameters;
P.DiscreteModle = DiscreteModle;
P.ContrlMode = ContrlMode;
P.WarmStart = WarmStart;
P.DotPHI = DotPHI;
P.rho = rho;
P.CostWeights = CostWeights;
P.C_table = C_table;
P.Cf0 = Cf0;
P.Cr0 = Cr0;
P.TireF = TireF;
P.TireR = TireR;

P.Pm = struct('MPCParameters',MPCParameters, 'CostWeights',CostWeights, ...
              'DiscreteModle',DiscreteModle, 'ContrlMode',ContrlMode, ...
              'Reftraj',Reftraj, 'Cf0',Cf0, 'Cr0',Cr0, 'C_table',C_table, ...
              'TireF',TireF, 'TireR',TireR);
P.S0 = struct('InitialParams',InitialParams, 'WarmStart',WarmStart, 'rho',rho, ...
              'VehiclePara',VehiclePara, 'Constraints',Constraints);

if nargout == 0
    assignin('base','PMPC_P',P);
    fprintf('  PMPC_P ��д�빤���� (%d ���ֶ�)\n', numel(fieldnames(P)));
    clear P
end
end
