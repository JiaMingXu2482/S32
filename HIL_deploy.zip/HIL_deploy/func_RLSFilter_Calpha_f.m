function [y, Bout] = func_RLSFilter_Calpha_f(f, d, FIR_Num, delta_n )
%FUNC_RLSFILTER_CALPHA_F  Recursive least squares estimate of front-axle cornering stiffness.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    persistent F_f B_f lambda_f  Num_f  Rinv_f
    if (ischar(f) && strcmp(f,'initial'))
        lambda_f = d;
        Num_f = FIR_Num;
        Rinv_f = delta_n*eye(Num_f);
        F_f = zeros(Num_f,1);
        B_f = zeros(Num_f,1);
        y = 0;
        Bout = 0;
    else
        for J = Num_f:-1:2
            F_f(J) = F_f(J-1);
        end
        F_f(1) = f;
        y= F_f'*B_f;
        error=d-y;
        K = Rinv_f*F_f/(lambda_f + F_f'*Rinv_f*F_f);
        Rinvn = (Rinv_f - K*F_f'*Rinv_f)/lambda_f;
        B_f = B_f + K*error;
        Bout = B_f;
        Rinv_f = Rinvn;
    end
end
