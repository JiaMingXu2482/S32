function new_WarmStart = func_WarmStart_shiftHorizon(U,MPCParameters)
%FUNC_WARMSTART_SHIFTHORIZON  Shift the previous QP solution one step for warm starting.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    Nc  = MPCParameters.Nc;
    Nu  = MPCParameters.Nu;

    if Nc <= 1
        new_WarmStart = zeros(size(U));
    else
        new_WarmStart = [U(Nu+1:Nc*Nu); zeros(Nu,1); U(Nc*Nu+1:end)];
    end
end
