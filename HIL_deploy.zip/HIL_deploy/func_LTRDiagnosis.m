function [LTR_real, LTR_calc, LTR_Npdc] = func_LTRDiagnosis( ...
        VehiclePara, MPCParameters, VehStateMeasured, ParaHAT, ...
        Y, x_opt, exitflag, AI, Ut, Md_next, Npdc)
%FUNC_LTRDIAGNOSIS  Load transfer ratio (LTR) computation and diagnosis.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

m  = VehiclePara.m;   ms = VehiclePara.ms;  g = VehiclePara.g;
tf = VehiclePara.tf;  Kt = VehiclePara.Kt;
h_TL   = VehiclePara.h_TL;   h_S2R = VehiclePara.h_S2R;
CbF = VehiclePara.CbarF;  CbR = VehiclePara.CbarR;
lf_v = VehiclePara.lf;
lr_v   = VehiclePara.lr;

Nu = MPCParameters.Nu;  Nc = MPCParameters.Nc;
Np = MPCParameters.Np;  Nx = MPCParameters.Nx;  Ny = MPCParameters.Ny;

Vel     = VehStateMeasured.x_dot;
delta_f = VehStateMeasured.delta_f;
Roll    = ParaHAT.Roll;

kappa_g = m*h_TL - ms*h_S2R;
bta     = 2/(m*g*tf);

cd_f = cos(delta_f);
c_ay = [ (CbF*cd_f + CbR)/(m*Vel), ...
         (CbF*lf_v*cd_f - CbR*lr_v)/(m*Vel), 0, 0, 0, 0 ];
d_ay = [ -CbF*cd_f/m, 0, 0 ];

Fz_sum   = ParaHAT.Fz_l1 + ParaHAT.Fz_l2 + ParaHAT.Fz_r1 + ParaHAT.Fz_r2;
LTR_real = ( (ParaHAT.Fz_r1 + ParaHAT.Fz_r2) - (ParaHAT.Fz_l1 + ParaHAT.Fz_l2) ) / max(Fz_sum, 1);

ay_meas  = ( (ParaHAT.Fy_l1 + ParaHAT.Fy_r1)*cos(delta_f) ...
           +  ParaHAT.Fy_l2 + ParaHAT.Fy_r2 ) / m;
LTR_calc = bta*( kappa_g*ay_meas + Kt*Roll + Md_next );

if nargin < 11 || isempty(Npdc), Npdc = 4; end
Npdc   = max(1, round(Npdc));
Npdc_y = min(Npdc, Np);
Npdc_u = min(Npdc, Nc);

if exitflag == 1
    U_pred_Nc = Ut + AI * x_opt(1:Nu*Nc);
else
    U_pred_Nc = Ut;
end

by       = Ny*(Npdc_y-1);
xi_Npdc  = Y(by+1 : by+Nx);
phi_Npdc = xi_Npdc(3);

bu       = (Npdc_u-1)*Nu;
u_Npdc   = U_pred_Nc(bu+1 : bu+Nu);
Md_Npdc  = u_Npdc(3);

ay_Npdc  = c_ay*xi_Npdc + d_ay*u_Npdc;
LTR_Npdc = bta*( kappa_g*ay_Npdc + Kt*phi_Npdc + Md_Npdc );

end
