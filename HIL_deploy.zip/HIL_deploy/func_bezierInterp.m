function Q=func_bezierInterp(P0,P1,P2,P3,t)
%FUNC_BEZIERINTERP  Bezier interpolation.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
if nargin < 5, t = linspace(0,1,101); end
M=[-1  3 -3 1;
    3 -6  3 0;
   -3  3  0 0;
    1  0  0 0];
Q = zeros(length(t), size(P0,2));
for k=1:length(t)
    Q(k,:)=[t(k)^3 t(k)^2 t(k) 1]*M*[P0;P1;P2;P3];
end
