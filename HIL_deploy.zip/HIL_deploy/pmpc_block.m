function sys = pmpc_block(u, PMPC_P) %#codegen
%PMPC_BLOCK  Body of the PMPC_MF MATLAB Function block. Cross-step state lives in a persistent.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   PMPC_P is declared Scope = Parameter and Tunable = false in the block.
%   Tunable = false is the block-level coder.Constant: without it the array
%   sizes derived from PMPC_P stop being compile-time constants and the block
%   reports that it cannot determine the output size.

uc = u(:);

persistent St
if isempty(St)
    St = PMPC_P.S0;
end
[sys, St] = pmpc_step(uc, PMPC_P.Pm, St);
end
