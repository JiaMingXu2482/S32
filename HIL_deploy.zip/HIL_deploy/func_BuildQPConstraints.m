function [A_cons, b_cons, lb, ub, umax, umin] = func_BuildQPConstraints( ...
        MPCParameters, Envelope, Pred, AI, Ut, zeta, Lim)
%FUNC_BUILDQPCONSTRAINTS  Assemble the inequality constraints of the upper-level MPC QP.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

Nu = MPCParameters.Nu;  Nc = MPCParameters.Nc;
Np = MPCParameters.Np;  Ne = MPCParameters.Ne;  Nr = MPCParameters.Nr;
Ny = MPCParameters.Ny;

N_sh  = min(max(1, round(MPCParameters.Ncons_sh )), Np);
N_r   = min(max(1, round(MPCParameters.Ncons_r  )), Np);
N_env = min(max(1, round(MPCParameters.Ncons_env)), Np);

PSI = Pred.PSI; THETA = Pred.THETA; PHI = Pred.PHI; GAMMA = Pred.GAMMA;
xi0 = PSI*zeta + PHI*GAMMA;

Md_up    = max(Lim.Mdmax, Lim.Mdmin);
Md_low   = min(Lim.Mdmax, Lim.Mdmin);
Md_up_s  = min( (Md_up >=0)*0.9*Md_up  + (Md_up <0)*1.1*Md_up , Md_up  );
Md_low_s = max( (Md_low<=0)*0.9*Md_low + (Md_low>0)*1.1*Md_low, Md_low );

if isfield(Lim,'dlt_ub') && ~isempty(Lim.dlt_ub)
    afs_ub = Lim.dlt_ub;  afs_lb = Lim.dlt_lb;
else
    afs_ub = 0.95*Lim.Fyfmax;  afs_lb = -0.95*Lim.Fyfmax;
end
umax = [ afs_ub;  0.95*Lim.MFxmax;  Md_up_s  ];
umin = [ afs_lb; -0.95*Lim.MFxmax;  Md_low_s ];

u_prev  = zeta(7:9);
du_v    = [Lim.dFyfmax; Lim.dMFxmax; Lim.dMdmax];
umax = max(umax, u_prev - du_v);
umin = min(umin, u_prev + du_v);

Umin = kron(ones(Nc,1), umin);
Umax = kron(ones(Nc,1), umax);

Hsh = Envelope.Hsh;  Gsh  = Envelope.Gsh;
Henv= Envelope.Henv; Genv = Envelope.Genv;
Hr  = Envelope.Hr;   Gr   = Envelope.Gr;   Or = Envelope.Or;

sel   = @(n) [eye(n*Ny), zeros(n*Ny, (Np-n)*Ny)];
A_sh  = kron(eye(N_sh ),Hsh)  * sel(N_sh );   b_sh  = kron(ones(N_sh ,1),Gsh);
A_env = kron(eye(N_env),Henv) * sel(N_env);   b_env = kron(ones(N_env,1),Genv);
A_r   = kron(eye(N_r  ),Hr)   * sel(N_r  );   b_r   = kron(ones(N_r  ,1),Gr);

if N_r <= Nc
    E_r = [eye(2*N_r), zeros(2*N_r, 2*(Nc-N_r))];
else
    E_r = [ eye(2*Nc);
            repmat([zeros(2, 2*(Nc-1)), eye(2)], N_r-Nc, 1) ];
end
O_r = kron(eye(Nc),Or);

A_cons_sh = [A_sh*THETA, -1*kron(ones(N_sh,1),[eye(4),zeros(4,4)]), zeros(length(Gsh)*N_sh,Nr)];
b_cons_sh = b_sh - A_sh*xi0;

A_cons_env= [A_env*THETA, -1*kron(ones(N_env,1),[zeros(2,6),eye(2)]), zeros(length(Genv)*N_env,Nr)];
b_cons_env= b_env - A_env*xi0;

A_cons_r  = [A_r*THETA + E_r*O_r*AI, -1*kron(ones(N_r,1),[zeros(2,4),eye(2),zeros(2,2)]), zeros(length(Gr)*N_r,Nr)];
b_cons_r  = b_r - A_r*xi0 - E_r*O_r*Ut;

if Nr > 0
    if isfield(Lim,'Mdnom') && ~isempty(Lim.Mdnom)
        uc = [0; 0; Lim.Mdnom];
    else
        uc = zeros(3,1);
    end
    uc(3) = min(max(uc(3), min(umin(3),umax(3))), max(umin(3),umax(3)));

    A_high = zeros(3*Nc, Nu*Nc + Ne + Nr);
    A_low  = zeros(3*Nc, Nu*Nc + Ne + Nr);
    b_high = zeros(3*Nc, 1);
    b_low  = zeros(3*Nc, 1);

    for i = 1:Nc
        AI_i = AI((i-1)*Nu+1:i*Nu, :);
        Ut_i = Ut((i-1)*Nu+1:i*Nu);
        for k = 1:3
            row = 3*(i-1) + k;
            A_high(row, 1:Nu*Nc)        =  AI_i(k, :);
            A_high(row, Nu*Nc + Ne + k) = -(umax(k) - uc(k));
            b_high(row)                 =  uc(k) - Ut_i(k);
            A_low(row, 1:Nu*Nc)         = -AI_i(k, :);
            A_low(row, Nu*Nc + Ne + k)  =  umin(k) - uc(k);
            b_low(row)                  =  Ut_i(k) - uc(k);
        end
    end
    A_input = [A_high; A_low];
    b_input = [b_high; b_low];

    if MPCParameters.fx_couple ~= 0
        kap  = Lim.kappa_fx;   uop = Lim.u_op;
        A_fx = zeros(4*Nc, Nu*Nc + Ne + Nr);
        b_fx = zeros(4*Nc, 1);
        for i = 1:Nc
            AI_i = AI((i-1)*Nu+1:i*Nu, :);
            Ut_i = Ut((i-1)*Nu+1:i*Nu);
            aA = AI_i(1,:);   aD = AI_i(2,:);
            for sD = [1 -1]
                for sA = [1 -1]
                    r = 4*(i-1) + (sD<0)*2 + (sA<0) + 1;
                    A_fx(r, 1:Nu*Nc) = sD*aD + kap*sA*aA;
                    b_fx(r) = 0.95*Lim.MFxmax - sD*Ut_i(2) - kap*sA*(Ut_i(1) - uop);
                end
            end
        end
        A_input = [A_input; A_fx];
        b_input = [b_input; b_fx];
    end

    if MPCParameters.sigma_budget > 0
        Bb = MPCParameters.sigma_budget;
        s_prev = 2;
        if isfield(Lim,'gamma_prev') && ~isempty(Lim.gamma_prev)
            s_prev = sum(Lim.gamma_prev(1:2));
        end
        dB   = 0.1;
        Beff = max(Bb, s_prev - dB);
        A_input = [A_input; zeros(1, Nu*Nc + Ne), 1, 1, 0];
        b_input = [b_input; Beff];
    end
else
    A_input = [ AI, zeros(Nu*Nc, Ne);
               -AI, zeros(Nu*Nc, Ne) ];
    b_input = [ Umax - Ut;
                Ut - Umin ];
end

nvars_ = Nu*Nc + Ne + Nr;
n_in_  = size(A_input,1);
n_sh_  = size(A_cons_sh,1);
n_r_   = size(A_cons_r,1);
n_env_ = size(A_cons_env,1);
A_cons = zeros(n_in_ + n_sh_ + n_r_ + n_env_, nvars_);
b_cons = zeros(n_in_ + n_sh_ + n_r_ + n_env_, 1);
k_ = 0;
A_cons(k_+1:k_+n_in_,  :) = A_input;    b_cons(k_+1:k_+n_in_)  = b_input;    k_ = k_ + n_in_;
A_cons(k_+1:k_+n_sh_,  :) = A_cons_sh;  b_cons(k_+1:k_+n_sh_)  = b_cons_sh;  k_ = k_ + n_sh_;
A_cons(k_+1:k_+n_r_,   :) = A_cons_r;   b_cons(k_+1:k_+n_r_)   = b_cons_r;   k_ = k_ + n_r_;
A_cons(k_+1:k_+n_env_, :) = A_cons_env; b_cons(k_+1:k_+n_env_) = b_cons_env;

dumax = [Lim.dFyfmax; Lim.dMFxmax; Lim.dMdmax];
dUmin = kron(ones(Nc,1), -dumax);
dUmax = kron(ones(Nc,1),  dumax);

eps_min = zeros(Ne,1);
if isfield(Lim,'eps_ub') && ~isempty(Lim.eps_ub)
    eps_ub = Lim.eps_ub(:);
else
    eps_ub = inf(Ne,1);
end

if Nr > 0
    rho_min = [0; 0; 0];
    rho_max = [1; 1; 1];
    lb = [dUmin; eps_min; rho_min];
    ub = [dUmax; eps_ub;  rho_max];
else
    lb = [dUmin; eps_min];
    ub = [dUmax; eps_ub];
end

end
