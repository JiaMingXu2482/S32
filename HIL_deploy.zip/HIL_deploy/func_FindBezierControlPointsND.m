function [P0, P1, P2, P3, tout]= func_FindBezierControlPointsND(p, ptype)
%FUNC_FINDBEZIERCONTROLPOINTSND  Bezier control points for local path smoothing.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
if nargin < 2, ptype = ''; end

n=size(p,1);

if (strcmpi(ptype,'u') || strcmpi(ptype,'uniform') )
    [t]=linspace(0,1,n);
else
    [t]=ChordLengthNormND(p);
end

P0=p(1,:);
P3=p(n,:);

if (n==1)
   P1=P0;
   P2=P0;

elseif (n==2)
   P1=P0;
   P2=P3;

elseif (n==3)
   P1=p(2,:);
   P2=p(2,:);

else

   A1=0;	A2=0;	A12=0;
   C1=zeros(1,size(p,2));	C2=zeros(1,size(p,2));
    for i=2:n-1
      B0 = (1-t(i))^3            ;
      B1 = ( 3*t(i)*(1-t(i))^2 ) ;
      B2 = ( 3*t(i)^2*(1-t(i)) ) ;
      B3 = t(i)^3                ;

      A1  = A1 +  B1^2;
      A2  = A2 +  B2^2;
      A12 = A12 + B1*B2;
      C1 = C1 + B1*( p(i,:) - B0*P0 - B3*P3 );
      C2 = C2 + B2*( p(i,:) - B0*P0 - B3*P3 );

   end

   DENOM=(A1*A2-A12*A12);
   if(DENOM==0)
       P1=P0;
       P2=P3;
   else
       P1=(A2*C1-A12*C2)/DENOM;
       P2=(A1*C2-A12*C1)/DENOM;
   end

end

if(nargout==5)
    tout=t;
end
