/*
 * pmpc_hil1.h
 *
 * Code generation for model "pmpc_hil1".
 *
 * Model version              : 1.1
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C++ source code generated on : Sat Sep 19 13:53:59 2026
 *
 * Target selection: NIVeriStand.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pmpc_hil1_h_
#define RTW_HEADER_pmpc_hil1_h_
#include <cmath>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#ifndef pmpc_hil1_COMMON_INCLUDES_
# define pmpc_hil1_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#endif                                 /* pmpc_hil1_COMMON_INCLUDES_ */

#include "pmpc_hil1_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetCtrlRateMdlRefTiming
# define rtmGetCtrlRateMdlRefTiming(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTiming
# define rtmSetCtrlRateMdlRefTiming(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateMdlRefTimingPtr
# define rtmGetCtrlRateMdlRefTimingPtr(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTimingPtr
# define rtmSetCtrlRateMdlRefTimingPtr(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateNumTicksToNextHit
# define rtmGetCtrlRateNumTicksToNextHit(rtm) ()
#endif

#ifndef rtmSetCtrlRateNumTicksToNextHit
# define rtmSetCtrlRateNumTicksToNextHit(rtm, val) ()
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ()
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ()
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ()
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ()
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumPeriodicContStates
# define rtmGetNumPeriodicContStates(rtm) ((rtm)->Sizes.numPeriodicContStates)
#endif

#ifndef rtmSetNumPeriodicContStates
# define rtmSetNumPeriodicContStates(rtm, val) ((rtm)->Sizes.numPeriodicContStates = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ()
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ()
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ()
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ()
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSelf
# define rtmGetSelf(rtm)               ()
#endif

#ifndef rtmSetSelf
# define rtmSetSelf(rtm, val)          ()
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ((rtm)->Timing.TaskCounters)
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ((rtm)->Timing.TaskCounters = (val))
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGettimingBridge
# define rtmGettimingBridge(rtm)       ()
#endif

#ifndef rtmSettimingBridge
# define rtmSettimingBridge(rtm, val)  ()
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) == 0)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) ((rtmIsMajorTimeStep((rtm)) && (rtm)->Timing.sampleHits[(rtm)->Timing.sampleTimeTaskIDPtr[sti]]))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)

/* Definition for use in the target main file */
#define pmpc_hil1_rtModel              RT_MODEL_pmpc_hil1_T

/* Block signals (default storage) */
typedef struct {
  sCbhmMeZ4DAZChEA352SZoG_pmpc__T InitialParams;
  real_T Q[5184];
  real_T A[3848];
  real_T PHI[2592];
  real_T A_cons[2496];
  real_T dv0[2496];
  real_T A_sh[1728];
  real_T A_env[1728];
  real_T dv1[1728];
  real_T pp_coefs_data[1600];
  real_T e_coefs_data[1600];
  real_T interp_idx[1500];
  real_T X_interp_data[1500];
  real_T Y_interp_data[1500];
  real_T interp_dists_data[1500];
  real_T X_interp_data_m[1500];
  real_T tmp_data[1500];
  real_T Y_interp_data_c[1500];
  real_T THETA[1296];
  real_T Pred_THETA[1296];
  real_T assign_temp_A_aug[972];
  real_T Aprod[972];
  real_T A_r[864];
  real_T dv2[864];
  real_T H[676];
  real_T B_data[676];
  real_T B_data_k[676];
  real_T H_c[676];
  real_T Linv_data[676];
  real_T B_data_b[676];
  real_T b_A_data[676];
  real_T b[676];
  real_T b_A_data_p[676];
  real_T b_A_data_c[676];
  real_T B[676];
  real_T Hinv[676];
  real_T a_data[676];
  real_T b_A_data_f[676];
  real_T Hs[676];
  real_T sc[676];
  real_T b_A_data_g[676];
  real_T QQ_data[676];
  real_T RLinv_data[676];
  real_T D_data[676];
  real_T H_data[676];
  real_T U_data[676];
  real_T TL_data[676];
  real_T QQ_data_g[676];
  real_T RR_data[676];
  real_T PSI[648];
  real_T NIVeriStandIn1;               /* '<S4>/NIVeriStand In1' */
  real_T NIVeriStandIn2;               /* '<S4>/NIVeriStand In2' */
  real_T NIVeriStandIn3;               /* '<S4>/NIVeriStand In3' */
  real_T NIVeriStandIn4;               /* '<S4>/NIVeriStand In4' */
  real_T NIVeriStandIn5;               /* '<S4>/NIVeriStand In5' */
  real_T NIVeriStandIn6;               /* '<S4>/NIVeriStand In6' */
  real_T NIVeriStandIn7;               /* '<S4>/NIVeriStand In7' */
  real_T NIVeriStandIn8;               /* '<S4>/NIVeriStand In8' */
  real_T NIVeriStandIn9;               /* '<S4>/NIVeriStand In9' */
  real_T NIVeriStandIn10;              /* '<S4>/NIVeriStand In10' */
  real_T NIVeriStandIn11;              /* '<S4>/NIVeriStand In11' */
  real_T NIVeriStandIn12;              /* '<S4>/NIVeriStand In12' */
  real_T NIVeriStandIn13;              /* '<S4>/NIVeriStand In13' */
  real_T NIVeriStandIn14;              /* '<S4>/NIVeriStand In14' */
  real_T NIVeriStandIn15;              /* '<S4>/NIVeriStand In15' */
  real_T NIVeriStandIn16;              /* '<S4>/NIVeriStand In16' */
  real_T NIVeriStandIn17;              /* '<S4>/NIVeriStand In17' */
  real_T NIVeriStandIn18;              /* '<S4>/NIVeriStand In18' */
  real_T NIVeriStandIn19;              /* '<S4>/NIVeriStand In19' */
  real_T NIVeriStandIn20;              /* '<S4>/NIVeriStand In20' */
  real_T NIVeriStandIn21;              /* '<S4>/NIVeriStand In21' */
  real_T NIVeriStandIn22;              /* '<S4>/NIVeriStand In22' */
  real_T NIVeriStandIn23;              /* '<S4>/NIVeriStand In23' */
  real_T NIVeriStandIn24;              /* '<S4>/NIVeriStand In24' */
  real_T NIVeriStandIn25;              /* '<S4>/NIVeriStand In25' */
  real_T NIVeriStandIn26;              /* '<S4>/NIVeriStand In26' */
  real_T NIVeriStandIn27;              /* '<S4>/NIVeriStand In27' */
  real_T NIVeriStandIn28;              /* '<S4>/NIVeriStand In28' */
  real_T NIVeriStandIn29;              /* '<S4>/NIVeriStand In29' */
  real_T NIVeriStandIn30;              /* '<S4>/NIVeriStand In30' */
  real_T NIVeriStandIn31;              /* '<S4>/NIVeriStand In31' */
  real_T NIVeriStandIn32;              /* '<S4>/NIVeriStand In32' */
  real_T NIVeriStandIn33;              /* '<S4>/NIVeriStand In33' */
  real_T NIVeriStandIn34;              /* '<S4>/NIVeriStand In34' */
  real_T NIVeriStandIn35;              /* '<S4>/NIVeriStand In35' */
  real_T NIVeriStandIn36;              /* '<S4>/NIVeriStand In36' */
  real_T NIVeriStandIn37;              /* '<S4>/NIVeriStand In37' */
  real_T NIVeriStandIn38;              /* '<S4>/NIVeriStand In38' */
  real_T NIVeriStandIn39;              /* '<S4>/NIVeriStand In39' */
  real_T NIVeriStandIn40;              /* '<S4>/NIVeriStand In40' */
  real_T NIVeriStandIn41;              /* '<S4>/NIVeriStand In41' */
  real_T NIVeriStandIn42;              /* '<S4>/NIVeriStand In42' */
  real_T NIVeriStandIn43;              /* '<S4>/NIVeriStand In43' */
  real_T NIVeriStandIn44;              /* '<S4>/NIVeriStand In44' */
  real_T NIVeriStandIn45;              /* '<S4>/NIVeriStand In45' */
  real_T NIVeriStandIn46;              /* '<S4>/NIVeriStand In46' */
  real_T NIVeriStandIn47;              /* '<S4>/NIVeriStand In47' */
  real_T NIVeriStandIn48;              /* '<S4>/NIVeriStand In48' */
  real_T NIVeriStandIn49;              /* '<S4>/NIVeriStand In49' */
  real_T NIVeriStandIn50;              /* '<S4>/NIVeriStand In50' */
  real_T Gain_P;                       /* '<S1>/Gain_P' */
  real_T Saturation;                   /* '<S1>/Saturation' */
  real_T Switch_I;                     /* '<S1>/Switch_I' */
  real_T sys[54];                      /* '<Root>/PMPC_MF' */
  real_T Fig;                          /* '<S1>/Chart' */
  uint8_T Compare;                     /* '<S6>/Compare' */
} B_pmpc_hil1_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T St;  /* '<Root>/PMPC_MF' */
  emxArray_boolean_T_148_pmpc_h_T iA_ws;/* '<Root>/PMPC_MF' */
  real_T NIVeriStandIn1_DWORK1;        /* '<S4>/NIVeriStand In1' */
  real_T NIVeriStandIn2_DWORK1;        /* '<S4>/NIVeriStand In2' */
  real_T NIVeriStandIn3_DWORK1;        /* '<S4>/NIVeriStand In3' */
  real_T NIVeriStandIn4_DWORK1;        /* '<S4>/NIVeriStand In4' */
  real_T NIVeriStandIn5_DWORK1;        /* '<S4>/NIVeriStand In5' */
  real_T NIVeriStandIn6_DWORK1;        /* '<S4>/NIVeriStand In6' */
  real_T NIVeriStandIn7_DWORK1;        /* '<S4>/NIVeriStand In7' */
  real_T NIVeriStandIn8_DWORK1;        /* '<S4>/NIVeriStand In8' */
  real_T NIVeriStandIn9_DWORK1;        /* '<S4>/NIVeriStand In9' */
  real_T NIVeriStandIn10_DWORK1;       /* '<S4>/NIVeriStand In10' */
  real_T NIVeriStandIn11_DWORK1;       /* '<S4>/NIVeriStand In11' */
  real_T NIVeriStandIn12_DWORK1;       /* '<S4>/NIVeriStand In12' */
  real_T NIVeriStandIn13_DWORK1;       /* '<S4>/NIVeriStand In13' */
  real_T NIVeriStandIn14_DWORK1;       /* '<S4>/NIVeriStand In14' */
  real_T NIVeriStandIn15_DWORK1;       /* '<S4>/NIVeriStand In15' */
  real_T NIVeriStandIn16_DWORK1;       /* '<S4>/NIVeriStand In16' */
  real_T NIVeriStandIn17_DWORK1;       /* '<S4>/NIVeriStand In17' */
  real_T NIVeriStandIn18_DWORK1;       /* '<S4>/NIVeriStand In18' */
  real_T NIVeriStandIn19_DWORK1;       /* '<S4>/NIVeriStand In19' */
  real_T NIVeriStandIn20_DWORK1;       /* '<S4>/NIVeriStand In20' */
  real_T NIVeriStandIn21_DWORK1;       /* '<S4>/NIVeriStand In21' */
  real_T NIVeriStandIn22_DWORK1;       /* '<S4>/NIVeriStand In22' */
  real_T NIVeriStandIn23_DWORK1;       /* '<S4>/NIVeriStand In23' */
  real_T NIVeriStandIn24_DWORK1;       /* '<S4>/NIVeriStand In24' */
  real_T NIVeriStandIn25_DWORK1;       /* '<S4>/NIVeriStand In25' */
  real_T NIVeriStandIn26_DWORK1;       /* '<S4>/NIVeriStand In26' */
  real_T NIVeriStandIn27_DWORK1;       /* '<S4>/NIVeriStand In27' */
  real_T NIVeriStandIn28_DWORK1;       /* '<S4>/NIVeriStand In28' */
  real_T NIVeriStandIn29_DWORK1;       /* '<S4>/NIVeriStand In29' */
  real_T NIVeriStandIn30_DWORK1;       /* '<S4>/NIVeriStand In30' */
  real_T NIVeriStandIn31_DWORK1;       /* '<S4>/NIVeriStand In31' */
  real_T NIVeriStandIn32_DWORK1;       /* '<S4>/NIVeriStand In32' */
  real_T NIVeriStandIn33_DWORK1;       /* '<S4>/NIVeriStand In33' */
  real_T NIVeriStandIn34_DWORK1;       /* '<S4>/NIVeriStand In34' */
  real_T NIVeriStandIn35_DWORK1;       /* '<S4>/NIVeriStand In35' */
  real_T NIVeriStandIn36_DWORK1;       /* '<S4>/NIVeriStand In36' */
  real_T NIVeriStandIn37_DWORK1;       /* '<S4>/NIVeriStand In37' */
  real_T NIVeriStandIn38_DWORK1;       /* '<S4>/NIVeriStand In38' */
  real_T NIVeriStandIn39_DWORK1;       /* '<S4>/NIVeriStand In39' */
  real_T NIVeriStandIn40_DWORK1;       /* '<S4>/NIVeriStand In40' */
  real_T NIVeriStandIn41_DWORK1;       /* '<S4>/NIVeriStand In41' */
  real_T NIVeriStandIn42_DWORK1;       /* '<S4>/NIVeriStand In42' */
  real_T NIVeriStandIn43_DWORK1;       /* '<S4>/NIVeriStand In43' */
  real_T NIVeriStandIn44_DWORK1;       /* '<S4>/NIVeriStand In44' */
  real_T NIVeriStandIn45_DWORK1;       /* '<S4>/NIVeriStand In45' */
  real_T NIVeriStandIn46_DWORK1;       /* '<S4>/NIVeriStand In46' */
  real_T NIVeriStandIn47_DWORK1;       /* '<S4>/NIVeriStand In47' */
  real_T NIVeriStandIn48_DWORK1;       /* '<S4>/NIVeriStand In48' */
  real_T NIVeriStandIn49_DWORK1;       /* '<S4>/NIVeriStand In49' */
  real_T NIVeriStandIn50_DWORK1;       /* '<S4>/NIVeriStand In50' */
  real_T NIVeriStandOut1_DWORK1;       /* '<S3>/NIVeriStand Out1' */
  real_T NIVeriStandOut2_DWORK1;       /* '<S3>/NIVeriStand Out2' */
  real_T NIVeriStandOut3_DWORK1;       /* '<S3>/NIVeriStand Out3' */
  real_T NIVeriStandOut4_DWORK1;       /* '<S3>/NIVeriStand Out4' */
  real_T NIVeriStandOut5_DWORK1;       /* '<S3>/NIVeriStand Out5' */
  real_T NIVeriStandOut6_DWORK1;       /* '<S3>/NIVeriStand Out6' */
  real_T NIVeriStandOut7_DWORK1;       /* '<S3>/NIVeriStand Out7' */
  real_T NIVeriStandOut8_DWORK1;       /* '<S3>/NIVeriStand Out8' */
  real_T NIVeriStandOut9_DWORK1;       /* '<S3>/NIVeriStand Out9' */
  real_T NIVeriStandOut10_DWORK1;      /* '<S3>/NIVeriStand Out10' */
  real_T NIVeriStandOut11_DWORK1;      /* '<S3>/NIVeriStand Out11' */
  real_T VG[21];                       /* '<Root>/PMPC_MF' */
  real_T IG[5];                        /* '<Root>/PMPC_MF' */
  real_T FT[105];                      /* '<Root>/PMPC_MF' */
  uint8_T DB_delay_DSTATE;             /* '<S1>/DB_delay' */
  uint8_T NIVeriStandIn1_DWORK2[10];   /* '<S4>/NIVeriStand In1' */
  uint8_T NIVeriStandIn2_DWORK2[10];   /* '<S4>/NIVeriStand In2' */
  uint8_T NIVeriStandIn3_DWORK2[10];   /* '<S4>/NIVeriStand In3' */
  uint8_T NIVeriStandIn4_DWORK2[10];   /* '<S4>/NIVeriStand In4' */
  uint8_T NIVeriStandIn5_DWORK2[10];   /* '<S4>/NIVeriStand In5' */
  uint8_T NIVeriStandIn6_DWORK2[10];   /* '<S4>/NIVeriStand In6' */
  uint8_T NIVeriStandIn7_DWORK2[10];   /* '<S4>/NIVeriStand In7' */
  uint8_T NIVeriStandIn8_DWORK2[10];   /* '<S4>/NIVeriStand In8' */
  uint8_T NIVeriStandIn9_DWORK2[10];   /* '<S4>/NIVeriStand In9' */
  uint8_T NIVeriStandIn10_DWORK2[10];  /* '<S4>/NIVeriStand In10' */
  uint8_T NIVeriStandIn11_DWORK2[10];  /* '<S4>/NIVeriStand In11' */
  uint8_T NIVeriStandIn12_DWORK2[10];  /* '<S4>/NIVeriStand In12' */
  uint8_T NIVeriStandIn13_DWORK2[10];  /* '<S4>/NIVeriStand In13' */
  uint8_T NIVeriStandIn14_DWORK2[10];  /* '<S4>/NIVeriStand In14' */
  uint8_T NIVeriStandIn15_DWORK2[10];  /* '<S4>/NIVeriStand In15' */
  uint8_T NIVeriStandIn16_DWORK2[10];  /* '<S4>/NIVeriStand In16' */
  uint8_T NIVeriStandIn17_DWORK2[10];  /* '<S4>/NIVeriStand In17' */
  uint8_T NIVeriStandIn18_DWORK2[10];  /* '<S4>/NIVeriStand In18' */
  uint8_T NIVeriStandIn19_DWORK2[10];  /* '<S4>/NIVeriStand In19' */
  uint8_T NIVeriStandIn20_DWORK2[10];  /* '<S4>/NIVeriStand In20' */
  uint8_T NIVeriStandIn21_DWORK2[10];  /* '<S4>/NIVeriStand In21' */
  uint8_T NIVeriStandIn22_DWORK2[10];  /* '<S4>/NIVeriStand In22' */
  uint8_T NIVeriStandIn23_DWORK2[10];  /* '<S4>/NIVeriStand In23' */
  uint8_T NIVeriStandIn24_DWORK2[10];  /* '<S4>/NIVeriStand In24' */
  uint8_T NIVeriStandIn25_DWORK2[10];  /* '<S4>/NIVeriStand In25' */
  uint8_T NIVeriStandIn26_DWORK2[10];  /* '<S4>/NIVeriStand In26' */
  uint8_T NIVeriStandIn27_DWORK2[10];  /* '<S4>/NIVeriStand In27' */
  uint8_T NIVeriStandIn28_DWORK2[10];  /* '<S4>/NIVeriStand In28' */
  uint8_T NIVeriStandIn29_DWORK2[10];  /* '<S4>/NIVeriStand In29' */
  uint8_T NIVeriStandIn30_DWORK2[10];  /* '<S4>/NIVeriStand In30' */
  uint8_T NIVeriStandIn31_DWORK2[10];  /* '<S4>/NIVeriStand In31' */
  uint8_T NIVeriStandIn32_DWORK2[10];  /* '<S4>/NIVeriStand In32' */
  uint8_T NIVeriStandIn33_DWORK2[10];  /* '<S4>/NIVeriStand In33' */
  uint8_T NIVeriStandIn34_DWORK2[10];  /* '<S4>/NIVeriStand In34' */
  uint8_T NIVeriStandIn35_DWORK2[10];  /* '<S4>/NIVeriStand In35' */
  uint8_T NIVeriStandIn36_DWORK2[10];  /* '<S4>/NIVeriStand In36' */
  uint8_T NIVeriStandIn37_DWORK2[10];  /* '<S4>/NIVeriStand In37' */
  uint8_T NIVeriStandIn38_DWORK2[10];  /* '<S4>/NIVeriStand In38' */
  uint8_T NIVeriStandIn39_DWORK2[10];  /* '<S4>/NIVeriStand In39' */
  uint8_T NIVeriStandIn40_DWORK2[10];  /* '<S4>/NIVeriStand In40' */
  uint8_T NIVeriStandIn41_DWORK2[10];  /* '<S4>/NIVeriStand In41' */
  uint8_T NIVeriStandIn42_DWORK2[10];  /* '<S4>/NIVeriStand In42' */
  uint8_T NIVeriStandIn43_DWORK2[10];  /* '<S4>/NIVeriStand In43' */
  uint8_T NIVeriStandIn44_DWORK2[10];  /* '<S4>/NIVeriStand In44' */
  uint8_T NIVeriStandIn45_DWORK2[10];  /* '<S4>/NIVeriStand In45' */
  uint8_T NIVeriStandIn46_DWORK2[10];  /* '<S4>/NIVeriStand In46' */
  uint8_T NIVeriStandIn47_DWORK2[10];  /* '<S4>/NIVeriStand In47' */
  uint8_T NIVeriStandIn48_DWORK2[10];  /* '<S4>/NIVeriStand In48' */
  uint8_T NIVeriStandIn49_DWORK2[10];  /* '<S4>/NIVeriStand In49' */
  uint8_T NIVeriStandIn50_DWORK2[10];  /* '<S4>/NIVeriStand In50' */
  uint8_T NIVeriStandOut1_DWORK2[10];  /* '<S3>/NIVeriStand Out1' */
  uint8_T NIVeriStandOut2_DWORK2[10];  /* '<S3>/NIVeriStand Out2' */
  uint8_T NIVeriStandOut3_DWORK2[10];  /* '<S3>/NIVeriStand Out3' */
  uint8_T NIVeriStandOut4_DWORK2[10];  /* '<S3>/NIVeriStand Out4' */
  uint8_T NIVeriStandOut5_DWORK2[10];  /* '<S3>/NIVeriStand Out5' */
  uint8_T NIVeriStandOut6_DWORK2[10];  /* '<S3>/NIVeriStand Out6' */
  uint8_T NIVeriStandOut7_DWORK2[10];  /* '<S3>/NIVeriStand Out7' */
  uint8_T NIVeriStandOut8_DWORK2[10];  /* '<S3>/NIVeriStand Out8' */
  uint8_T NIVeriStandOut9_DWORK2[10];  /* '<S3>/NIVeriStand Out9' */
  uint8_T NIVeriStandOut10_DWORK2[10]; /* '<S3>/NIVeriStand Out10' */
  uint8_T NIVeriStandOut11_DWORK2[10]; /* '<S3>/NIVeriStand Out11' */
  boolean_T iA_ws_not_empty;           /* '<Root>/PMPC_MF' */
} DW_pmpc_hil1_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Int_I_CSTATE;                 /* '<S1>/Int_I' */
} X_pmpc_hil1_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Int_I_CSTATE;                 /* '<S1>/Int_I' */
} XDot_pmpc_hil1_T;

/* State disabled  */
typedef struct {
  boolean_T Int_I_CSTATE;              /* '<S1>/Int_I' */
} XDis_pmpc_hil1_T;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* Backward compatible GRT Identifiers */
#define rtB                            pmpc_hil1_B
#define BlockIO                        B_pmpc_hil1_T
#define rtX                            pmpc_hil1_X
#define ContinuousStates               X_pmpc_hil1_T
#define rtXdot                         pmpc_hil1_XDot
#define StateDerivatives               XDot_pmpc_hil1_T
#define tXdis                          pmpc_hil1_XDis
#define StateDisabled                  XDis_pmpc_hil1_T
#define rtP                            pmpc_hil1_P
#define Parameters                     P_pmpc_hil1_T
#define rtDWork                        pmpc_hil1_DW
#define D_Work                         DW_pmpc_hil1_T

/* Parameters (default storage) */
struct P_pmpc_hil1_T_ {
  real_T DB_on_const;                  /* Mask Parameter: DB_on_const
                                        * Referenced by: '<S6>/Constant'
                                        */
  real_T Gain_I_Gain;                  /* Expression: 0.005
                                        * Referenced by: '<S1>/Gain_I'
                                        */
  real_T Zero_I_Value;                 /* Expression: 0
                                        * Referenced by: '<S1>/Zero_I'
                                        */
  real_T NIVeriStandIn1_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn1_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn1_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn1_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn1_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn1_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In1'
                                        */
  real_T NIVeriStandIn2_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn2_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn2_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn2_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn2_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn2_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In2'
                                        */
  real_T NIVeriStandIn3_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn3_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn3_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn3_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn3_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn3_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In3'
                                        */
  real_T NIVeriStandIn4_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn4_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn4_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn4_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn4_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn4_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In4'
                                        */
  real_T NIVeriStandIn5_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn5_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn5_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn5_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn5_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn5_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In5'
                                        */
  real_T NIVeriStandIn6_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn6_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn6_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn6_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn6_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn6_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In6'
                                        */
  real_T NIVeriStandIn7_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn7_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn7_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn7_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn7_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn7_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In7'
                                        */
  real_T NIVeriStandIn8_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn8_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn8_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn8_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn8_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn8_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In8'
                                        */
  real_T NIVeriStandIn9_P1;            /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn9_P2;            /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn9_P3;            /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn9_P4;            /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn9_P5;            /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn9_P6;            /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In9'
                                        */
  real_T NIVeriStandIn10_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn10_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn10_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn10_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn10_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn10_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In10'
                                        */
  real_T NIVeriStandIn11_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn11_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn11_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn11_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn11_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn11_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In11'
                                        */
  real_T NIVeriStandIn12_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn12_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn12_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn12_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn12_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn12_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In12'
                                        */
  real_T NIVeriStandIn13_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn13_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn13_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn13_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn13_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn13_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In13'
                                        */
  real_T NIVeriStandIn14_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn14_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn14_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn14_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn14_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn14_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In14'
                                        */
  real_T NIVeriStandIn15_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn15_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn15_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn15_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn15_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn15_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In15'
                                        */
  real_T NIVeriStandIn16_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn16_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn16_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn16_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn16_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn16_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In16'
                                        */
  real_T NIVeriStandIn17_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn17_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn17_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn17_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn17_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn17_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In17'
                                        */
  real_T NIVeriStandIn18_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn18_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn18_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn18_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn18_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn18_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In18'
                                        */
  real_T NIVeriStandIn19_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn19_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn19_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn19_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn19_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn19_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In19'
                                        */
  real_T NIVeriStandIn20_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn20_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn20_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn20_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn20_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn20_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In20'
                                        */
  real_T NIVeriStandIn21_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn21_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn21_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn21_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn21_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn21_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In21'
                                        */
  real_T NIVeriStandIn22_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn22_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn22_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn22_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn22_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn22_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In22'
                                        */
  real_T NIVeriStandIn23_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn23_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn23_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn23_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn23_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn23_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In23'
                                        */
  real_T NIVeriStandIn24_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn24_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn24_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn24_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn24_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn24_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In24'
                                        */
  real_T NIVeriStandIn25_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn25_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn25_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn25_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn25_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn25_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In25'
                                        */
  real_T NIVeriStandIn26_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn26_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn26_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn26_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn26_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn26_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In26'
                                        */
  real_T NIVeriStandIn27_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn27_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn27_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn27_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn27_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn27_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In27'
                                        */
  real_T NIVeriStandIn28_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn28_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn28_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn28_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn28_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn28_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In28'
                                        */
  real_T NIVeriStandIn29_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn29_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn29_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn29_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn29_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn29_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In29'
                                        */
  real_T NIVeriStandIn30_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn30_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn30_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn30_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn30_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn30_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In30'
                                        */
  real_T NIVeriStandIn31_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn31_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn31_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn31_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn31_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn31_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In31'
                                        */
  real_T NIVeriStandIn32_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn32_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn32_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn32_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn32_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn32_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In32'
                                        */
  real_T NIVeriStandIn33_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn33_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn33_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn33_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn33_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn33_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In33'
                                        */
  real_T NIVeriStandIn34_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn34_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn34_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn34_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn34_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn34_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In34'
                                        */
  real_T NIVeriStandIn35_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn35_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn35_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn35_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn35_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn35_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In35'
                                        */
  real_T NIVeriStandIn36_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn36_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn36_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn36_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn36_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn36_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In36'
                                        */
  real_T NIVeriStandIn37_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn37_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn37_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn37_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn37_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn37_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In37'
                                        */
  real_T NIVeriStandIn38_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn38_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn38_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn38_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn38_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn38_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In38'
                                        */
  real_T NIVeriStandIn39_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn39_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn39_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn39_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn39_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn39_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In39'
                                        */
  real_T NIVeriStandIn40_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn40_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn40_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn40_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn40_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn40_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In40'
                                        */
  real_T NIVeriStandIn41_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn41_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn41_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn41_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn41_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn41_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In41'
                                        */
  real_T NIVeriStandIn42_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn42_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn42_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn42_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn42_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn42_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In42'
                                        */
  real_T NIVeriStandIn43_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn43_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn43_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn43_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn43_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn43_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In43'
                                        */
  real_T NIVeriStandIn44_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn44_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn44_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn44_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn44_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn44_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In44'
                                        */
  real_T NIVeriStandIn45_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn45_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn45_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn45_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn45_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn45_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In45'
                                        */
  real_T NIVeriStandIn46_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn46_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn46_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn46_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn46_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn46_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In46'
                                        */
  real_T NIVeriStandIn47_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn47_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn47_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn47_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn47_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn47_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In47'
                                        */
  real_T NIVeriStandIn48_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn48_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn48_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn48_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn48_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn48_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In48'
                                        */
  real_T NIVeriStandIn49_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn49_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn49_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn49_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn49_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn49_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In49'
                                        */
  real_T NIVeriStandIn50_P1;           /* Expression: width
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandIn50_P2;           /* Expression: dtype
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandIn50_P3;           /* Expression: portnum
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandIn50_P4;           /* Expression: stime
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandIn50_P5;           /* Expression: stype
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandIn50_P6;           /* Expression: btype
                                        * Referenced by: '<S4>/NIVeriStand In50'
                                        */
  real_T NIVeriStandOut1_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut1_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut1_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut1_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut1_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut1_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out1'
                                        */
  real_T NIVeriStandOut2_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut2_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut2_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut2_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut2_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut2_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out2'
                                        */
  real_T NIVeriStandOut3_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut3_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut3_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut3_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut3_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut3_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out3'
                                        */
  real_T NIVeriStandOut4_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut4_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut4_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut4_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut4_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut4_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out4'
                                        */
  real_T NIVeriStandOut5_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut5_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut5_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut5_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut5_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut5_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out5'
                                        */
  real_T NIVeriStandOut6_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut6_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut6_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut6_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut6_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut6_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out6'
                                        */
  real_T NIVeriStandOut7_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut7_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut7_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut7_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut7_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut7_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out7'
                                        */
  real_T NIVeriStandOut8_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut8_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut8_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut8_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut8_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut8_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out8'
                                        */
  real_T NIVeriStandOut9_P1;           /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T NIVeriStandOut9_P2;           /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T NIVeriStandOut9_P3;           /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T NIVeriStandOut9_P4;           /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T NIVeriStandOut9_P5;           /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T NIVeriStandOut9_P6;           /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out9'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real_T Gain_P_Gain;                  /* Expression: 0.1
                                        * Referenced by: '<S1>/Gain_P'
                                        */
  real_T Int_I_IC;                     /* Expression: 0
                                        * Referenced by: '<S1>/Int_I'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S1>/Switch'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 1
                                        * Referenced by: '<S1>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<S1>/Saturation'
                                        */
  real_T NIVeriStandOut10_P1;          /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T NIVeriStandOut10_P2;          /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T NIVeriStandOut10_P3;          /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T NIVeriStandOut10_P4;          /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T NIVeriStandOut10_P5;          /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T NIVeriStandOut10_P6;          /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out10'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant2'
                                        */
  real_T NIVeriStandOut11_P1;          /* Expression: width
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  real_T NIVeriStandOut11_P2;          /* Expression: dtype
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  real_T NIVeriStandOut11_P3;          /* Expression: portnum
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  real_T NIVeriStandOut11_P4;          /* Expression: stime
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  real_T NIVeriStandOut11_P5;          /* Expression: stype
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  real_T NIVeriStandOut11_P6;          /* Expression: btype
                                        * Referenced by: '<S3>/NIVeriStand Out11'
                                        */
  uint8_T DB_delay_InitialCondition;   /* Computed Parameter: DB_delay_InitialCondition
                                        * Referenced by: '<S1>/DB_delay'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_pmpc_hil1_T {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;
  void *blockIO;
  const void *constBlockIO;
  void *defaultParam;
  ZCSigState *prevZCSigState;
  real_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  void *zcSignalValues;
  void *inputs;
  void *outputs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][1];
  ODE1_IntgData intgData;
  void *dwork;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    struct {
      uint8_T TID[3];
    } TaskCounters;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[3];
    time_T offsetTimesArray[3];
    int_T sampleTimeTaskIDArray[3];
    int_T sampleHitArray[3];
    int_T perTaskSampleHitsArray[9];
    time_T tArray[3];
  } Timing;
};

/* Block parameters (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern P_pmpc_hil1_T pmpc_hil1_P;

#ifdef __cplusplus

}
#endif

/* Block signals (default storage) */
extern B_pmpc_hil1_T pmpc_hil1_B;

/* Continuous states (default storage) */
extern X_pmpc_hil1_T pmpc_hil1_X;

/* Block states (default storage) */
extern DW_pmpc_hil1_T pmpc_hil1_DW;

#ifdef __cplusplus

extern "C" {

#endif

  /* Model entry point functions */
  extern void pmpc_hil1_initialize(void);
  extern void pmpc_hil1_output(void);
  extern void pmpc_hil1_update(void);
  extern void pmpc_hil1_terminate(void);

#ifdef __cplusplus

}
#endif

/*====================*
 * External functions *
 *====================*/
#ifdef __cplusplus

extern "C" {

#endif

  extern pmpc_hil1_rtModel *pmpc_hil1(void);
  extern void MdlInitializeSizes(void);
  extern void MdlInitializeSampleTimes(void);
  extern void MdlInitialize(void);
  extern void MdlStart(void);
  extern void MdlOutputs(int_T tid);
  extern void MdlUpdate(int_T tid);
  extern void MdlTerminate(void);

#ifdef __cplusplus

}
#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_pmpc_hil1_T *const pmpc_hil1_M;

#ifdef __cplusplus

}
#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pmpc_hil1'
 * '<S1>'   : 'pmpc_hil1/PID velocity control'
 * '<S2>'   : 'pmpc_hil1/PMPC_MF'
 * '<S3>'   : 'pmpc_hil1/Subsystem'
 * '<S4>'   : 'pmpc_hil1/Subsystem1'
 * '<S5>'   : 'pmpc_hil1/PID velocity control/Chart'
 * '<S6>'   : 'pmpc_hil1/PID velocity control/DB_on'
 */
#endif                                 /* RTW_HEADER_pmpc_hil1_h_ */

/*========================================================================*
 * VeriStand Model Framework code generation
 *
 * Model : pmpc_hil1
 * Model version : 1.1
 * VeriStand Model Framework version : 2020.4.0.0 (2020 R4)
 * Source generated on : Sat Sep 19 13:53:59 2026
 *========================================================================*/
#if !defined(NI_HEADER_pmpc_hil1_h_)
#define NI_HEADER_pmpc_hil1_h_
#ifdef NI_ROOTMODEL_pmpc_hil1

/* main model definitions enabled by makefile */
#include "ni_pglobals.h"
#ifndef NI_VERISTAND_MODELDATAFILE
#ifdef NI_VERISTAND_MAINMODELFILE

/* pmpc_hil1.cpp definitions */
int READSIDE = 0;
int tid = 0;

#ifdef MULTITASKING

/* multi-rate model */
P_pmpc_hil1_T rtParameter[NUMST+!TID01EQ];
P_pmpc_hil1_T *param_lookup[NUMST][2] = {
  { &rtParameter[0], &rtParameter[1] },

  { &rtParameter[0], &rtParameter[1] },

  { &rtParameter[2], &rtParameter[2] },
};

#else

/* single-rate model */
P_pmpc_hil1_T rtParameter[2];

#endif

#else

extern int READSIDE;

#ifdef MULTITASKING

/* multi-rate model */
extern int tid;
extern P_pmpc_hil1_T* param_lookup[NUMST][2];

#else

/* single-rate model */
extern P_pmpc_hil1_T rtParameter[];

#endif
#endif

/* Declare parameter macros */
#define _NI_DEFINE_PARAMS_DBL_BUFFER_
#include "ni_pglobals.h"
#endif
#endif
#endif                                 /* NI_HEADER_pmpc_hil1_h_ */
