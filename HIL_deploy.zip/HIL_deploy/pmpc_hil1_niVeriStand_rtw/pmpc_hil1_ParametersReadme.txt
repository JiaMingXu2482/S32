<parameterlist>
<parameter> Id = "0" Inline = "0" Name = "pmpc_hil1/PID velocity control/DB_on/Constant/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "1" Inline = "0" Name = "pmpc_hil1/PID velocity control/Gain_I/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "2" Inline = "0" Name = "pmpc_hil1/PID velocity control/Zero_I/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "3" Inline = "0" Name = "pmpc_hil1/PID velocity control/Constant1/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "4" Inline = "0" Name = "pmpc_hil1/PID velocity control/Gain_P/Gain" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "5" Inline = "0" Name = "pmpc_hil1/PID velocity control/Int_I/InitialCondition" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "6" Inline = "0" Name = "pmpc_hil1/PID velocity control/Switch/Threshold" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "7" Inline = "0" Name = "pmpc_hil1/PID velocity control/Saturation/UpperLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "8" Inline = "0" Name = "pmpc_hil1/PID velocity control/Saturation/LowerLimit" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "9" Inline = "0" Name = "pmpc_hil1/PID velocity control/Constant2/Value" Width = "1" DataType = "real_T" </parameter>
<parameter> Id = "10" Inline = "0" Name = "pmpc_hil1/PID velocity control/DB_delay/InitialCondition" Width = "1" DataType = "uint8_T" </parameter>
</parameterlist>
