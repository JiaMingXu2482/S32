#define NI_VERISTAND_MODELDATAFILE
#include "ni_modelframework.h"
#if defined VXWORKS || defined kNIOSLinux
#define pmpc_hil1_P                    pmpc_hil1_P DataSection(".NIVS.defaultparams")
#endif

/*
 * pmpc_hil1_data.cpp
 *
 * Code generation for model "pmpc_hil1".
 *
 * Model version              : 1.1
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C++ source code generated on : Sat Sep 19 13:53:59 2026
 *
 * Target selection: NIVeriStand.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "pmpc_hil1.h"
#include "pmpc_hil1_private.h"

/* Block parameters (default storage) */
P_pmpc_hil1_T pmpc_hil1_P = {
  /* Mask Parameter: DB_on_const
   * Referenced by: '<S6>/Constant'
   */
  50.0,

  /* Expression: 0.005
   * Referenced by: '<S1>/Gain_I'
   */
  0.005,

  /* Expression: 0
   * Referenced by: '<S1>/Zero_I'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  1.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In1'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  2.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In2'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  3.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In3'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  4.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In4'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  5.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In5'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  6.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In6'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  7.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In7'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  8.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In8'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  9.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In9'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  10.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In10'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  11.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In11'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  12.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In12'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  13.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In13'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  14.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In14'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  15.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In15'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  16.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In16'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  17.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In17'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  18.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In18'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  19.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In19'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  20.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In20'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  21.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In21'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  22.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In22'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  23.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In23'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  24.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In24'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  25.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In25'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  26.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In26'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  27.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In27'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  28.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In28'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  29.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In29'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  30.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In30'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  31.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In31'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  32.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In32'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  33.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In33'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  34.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In34'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  35.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In35'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  36.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In36'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  37.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In37'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  38.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In38'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  39.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In39'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  40.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In40'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  41.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In41'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  42.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In42'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  43.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In43'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  44.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In44'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  45.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In45'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  46.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In46'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  47.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In47'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  48.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In48'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  49.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In49'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  50.0,

  /* Expression: stime
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S4>/NIVeriStand In50'
   */
  1.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  1.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out1'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  2.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out2'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  3.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out3'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  4.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out4'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  5.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out5'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  6.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out6'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  7.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out7'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  8.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out8'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  9.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out9'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Constant1'
   */
  0.0,

  /* Expression: 0.1
   * Referenced by: '<S1>/Gain_P'
   */
  0.1,

  /* Expression: 0
   * Referenced by: '<S1>/Int_I'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Switch'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S1>/Saturation'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S1>/Saturation'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  10.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out10'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Constant2'
   */
  0.0,

  /* Expression: width
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  -1.0,

  /* Expression: dtype
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  1.0,

  /* Expression: portnum
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  11.0,

  /* Expression: stime
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  -1.0,

  /* Expression: stype
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  1.0,

  /* Expression: btype
   * Referenced by: '<S3>/NIVeriStand Out11'
   */
  0.0,

  /* Computed Parameter: DB_delay_InitialCondition
   * Referenced by: '<S1>/DB_delay'
   */
  0U
};

/*========================================================================*
 * VeriStand Model Framework code generation
 *
 * Model : pmpc_hil1
 * Model version : 1.1
 * VeriStand Model Framework version : 2020.4.0.0 (2020 R4)
 * Source generated on : Sat Sep 19 13:53:59 2026
 *========================================================================*/
#if defined VXWORKS || defined kNIOSLinux

typedef struct {
  int32_t size;
  int32_t width;
  int32_t basetype;
} NI_ParamSizeWidth;

NI_ParamSizeWidth P_pmpc_hil1_T_sizes[] DataSection(".NIVS.defaultparamsizes") =
{
  { sizeof(P_pmpc_hil1_T), 1 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(real_T), 1, 0 },

  { sizeof(uint8_T), 1, 3 },
};

#endif
