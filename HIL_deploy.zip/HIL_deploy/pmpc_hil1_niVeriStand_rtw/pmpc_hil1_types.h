/*
 * pmpc_hil1_types.h
 *
 * Code generation for model "pmpc_hil1".
 *
 * Model version              : 1.1
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C++ source code generated on : Sat Sep 19 13:53:59 2026
 *
 * Target selection: NIVeriStand.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pmpc_hil1_types_h_
#define RTW_HEADER_pmpc_hil1_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Custom Type definition for MATLAB Function: '<Root>/PMPC_MF' */
#ifndef struct_tag_sVXb2BidddHRLBtc2GzZiBG
#define struct_tag_sVXb2BidddHRLBtc2GzZiBG

struct tag_sVXb2BidddHRLBtc2GzZiBG
{
  real_T y;
  real_T psi;
};

#endif                                 /*struct_tag_sVXb2BidddHRLBtc2GzZiBG*/

#ifndef typedef_sVXb2BidddHRLBtc2GzZiBG_pmpc__T
#define typedef_sVXb2BidddHRLBtc2GzZiBG_pmpc__T

typedef struct tag_sVXb2BidddHRLBtc2GzZiBG sVXb2BidddHRLBtc2GzZiBG_pmpc__T;

#endif                                 /*typedef_sVXb2BidddHRLBtc2GzZiBG_pmpc__T*/

#ifndef struct_tag_s4H9mukNN3ugNJ0MwoCbpqE
#define struct_tag_s4H9mukNN3ugNJ0MwoCbpqE

struct tag_s4H9mukNN3ugNJ0MwoCbpqE
{
  real_T m;
  real_T ms;
  real_T Iz;
  real_T Ix;
  real_T h_TL;
  real_T h_SL;
  real_T lf;
  real_T L;
  real_T lr;
  real_T BodyLength;
  real_T BodyWigdth;
  real_T Bodydiagonal;
  real_T h_RC;
  real_T h_S2R;
  real_T tf;
  real_T tr;
  real_T lsf;
  real_T lsr;
  real_T ldf;
  real_T ldr;
  real_T If;
  real_T Ir;
  real_T rt;
  real_T isw;
  real_T kf;
  real_T kr;
  real_T cf;
  real_T cr;
  real_T Ct;
  real_T kw;
  real_T Kaux_f;
  real_T Kaux_r;
  real_T Kt;
  real_T g;
  real_T mu;
  real_T kd;
  real_T k1;
  real_T k2;
  real_T b;
  real_T k3;
  real_T v0;
  real_T CbarF;
  real_T CbarR;
  real_T CafTan;
  real_T CarTan;
  real_T mu_eff;
  real_T CafHat;
  real_T CarHat;
};

#endif                                 /*struct_tag_s4H9mukNN3ugNJ0MwoCbpqE*/

#ifndef typedef_s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T
#define typedef_s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T

typedef struct tag_s4H9mukNN3ugNJ0MwoCbpqE s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T;

#endif                                 /*typedef_s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T*/

#ifndef struct_tag_seSWzzkDqqnmIb9KZFsj0XH
#define struct_tag_seSWzzkDqqnmIb9KZFsj0XH

struct tag_seSWzzkDqqnmIb9KZFsj0XH
{
  real_T Roadwidth;
  real_T SW_rate_max_deg;
  real_T dlt_rate_max;
  real_T SW_max;
  real_T AFS_max_deg;
  real_T AFS_max;
  real_T tau_MR;
  real_T I_nom;
  real_T ZengRho_on;
  real_T ZengLong_on;
  real_T Zg_rfloor;
  real_T Zg_Vmin;
  real_T Zg_tau;
  real_T Zg_tpid;
  real_T Zg_cmax;
  real_T Zg_ayfull;
  real_T Zg_kovs;
  real_T Zg_Npv;
  real_T Zg_apv;
  real_T Zg_dVdb;
  real_T QPA_lamd;
  real_T Gov_lamx;
  real_T gamma_reg;
  real_T Vel_ref;
  real_T Vd_ref;
  real_T Ctan_floor_frac;
  real_T Tb_max;
  real_T dTb_rate_max;
  real_T Vymax;
  real_T arlim;
  real_T phimax;
  real_T dphimax;
  real_T epsimax;
  real_T epsilon_r;
  real_T epsilon_alpha;
  real_T epsilon_LTR;
  real_T epsilon_e;
  real_T eps_ub_scale;
  real_T es;
  real_T emax;
  real_T LTR_lim;
  real_T Zeng_bL;
  real_T Zeng_bR;
  real_T Zeng_rmax;
};

#endif                                 /*struct_tag_seSWzzkDqqnmIb9KZFsj0XH*/

#ifndef typedef_seSWzzkDqqnmIb9KZFsj0XH_pmpc__T
#define typedef_seSWzzkDqqnmIb9KZFsj0XH_pmpc__T

typedef struct tag_seSWzzkDqqnmIb9KZFsj0XH seSWzzkDqqnmIb9KZFsj0XH_pmpc__T;

#endif                                 /*typedef_seSWzzkDqqnmIb9KZFsj0XH_pmpc__T*/

#ifndef struct_tag_siQ02pX79ClhDlbeDEKhaoB
#define struct_tag_siQ02pX79ClhDlbeDEKhaoB

struct tag_siQ02pX79ClhDlbeDEKhaoB
{
  real_T Zg_Npv;
  real_T Zg_ayfull;
  real_T FishhookMode;
  real_T sigma_budget;
  real_T fx_couple;
  real_T Nu;
  real_T Ne;
  real_T Nx;
  real_T Ny;
  real_T Ts;
  real_T Ns;
  real_T Np;
  real_T Nc;
  real_T LTV_on;
  real_T QPSolver;
  real_T Ts_exec;
  real_T Ncons_sh;
  real_T Ncons_r;
  real_T Ncons_env;
  real_T Verbose;
  real_T Nr;
};

#endif                                 /*struct_tag_siQ02pX79ClhDlbeDEKhaoB*/

#ifndef typedef_siQ02pX79ClhDlbeDEKhaoB_pmpc__T
#define typedef_siQ02pX79ClhDlbeDEKhaoB_pmpc__T

typedef struct tag_siQ02pX79ClhDlbeDEKhaoB siQ02pX79ClhDlbeDEKhaoB_pmpc__T;

#endif                                 /*typedef_siQ02pX79ClhDlbeDEKhaoB_pmpc__T*/

#ifndef struct_tag_sbvkBze56SjuXgPM3czyE9E
#define struct_tag_sbvkBze56SjuXgPM3czyE9E

struct tag_sbvkBze56SjuXgPM3czyE9E
{
  real_T V_l1;
  real_T V_l2;
  real_T V_r1;
  real_T V_r2;
  real_T X;
  real_T Y;
  real_T x_dot;
  real_T y_dot;
  real_T Yaw;
  real_T Yawrate;
  real_T Yawaccel;
  real_T beta;
  real_T delta_l;
  real_T delta_r;
  real_T Steer_SW;
  real_T Ax;
  real_T Ay;
  real_T omega_L1;
  real_T omega_L2;
  real_T omega_R1;
  real_T omega_R2;
  real_T VxTarget;
  real_T delta_f;
};

#endif                                 /*struct_tag_sbvkBze56SjuXgPM3czyE9E*/

#ifndef typedef_sbvkBze56SjuXgPM3czyE9E_pmpc__T
#define typedef_sbvkBze56SjuXgPM3czyE9E_pmpc__T

typedef struct tag_sbvkBze56SjuXgPM3czyE9E sbvkBze56SjuXgPM3czyE9E_pmpc__T;

#endif                                 /*typedef_sbvkBze56SjuXgPM3czyE9E_pmpc__T*/

#ifndef struct_tag_stqsoKSc3kjr3PcXZyE6mmG
#define struct_tag_stqsoKSc3kjr3PcXZyE6mmG

struct tag_stqsoKSc3kjr3PcXZyE6mmG
{
  real_T Roll;
  real_T Rollrate;
  real_T Rollaccel;
  real_T alpha_l1;
  real_T alpha_l2;
  real_T alpha_r1;
  real_T alpha_r2;
  real_T Fx_l1;
  real_T Fx_l2;
  real_T Fx_r1;
  real_T Fx_r2;
  real_T Fy_l1;
  real_T Fy_l2;
  real_T Fy_r1;
  real_T Fy_r2;
  real_T Fz_l1;
  real_T Fz_l2;
  real_T Fz_r1;
  real_T Fz_r2;
  real_T Fd_L1;
  real_T Fd_L2;
  real_T Fd_R1;
  real_T Fd_R2;
  real_T Td_L1;
  real_T Td_L2;
  real_T Td_R1;
  real_T Td_R2;
  real_T LTR;
  real_T MFx;
  real_T Fyf;
  real_T Fyr;
  real_T Md;
  real_T alphaf;
  real_T alphar;
  real_T Fzf;
  real_T Fzr;
  real_T Fxf;
  real_T Fxr;
};

#endif                                 /*struct_tag_stqsoKSc3kjr3PcXZyE6mmG*/

#ifndef typedef_stqsoKSc3kjr3PcXZyE6mmG_pmpc__T
#define typedef_stqsoKSc3kjr3PcXZyE6mmG_pmpc__T

typedef struct tag_stqsoKSc3kjr3PcXZyE6mmG stqsoKSc3kjr3PcXZyE6mmG_pmpc__T;

#endif                                 /*typedef_stqsoKSc3kjr3PcXZyE6mmG_pmpc__T*/

#ifndef struct_tag_s1YBrsQ6z6NwvX1uvcMMCjG
#define struct_tag_s1YBrsQ6z6NwvX1uvcMMCjG

struct tag_s1YBrsQ6z6NwvX1uvcMMCjG
{
  real_T Tb_L1;
  real_T Tb_R1;
  real_T Tb_L2;
  real_T Tb_R2;
};

#endif                                 /*struct_tag_s1YBrsQ6z6NwvX1uvcMMCjG*/

#ifndef typedef_s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T
#define typedef_s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T

typedef struct tag_s1YBrsQ6z6NwvX1uvcMMCjG s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T;

#endif                                 /*typedef_s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T*/

#ifndef struct_tag_sL6LJlPlxhdTxZzXh5NTaQC
#define struct_tag_sL6LJlPlxhdTxZzXh5NTaQC

struct tag_sL6LJlPlxhdTxZzXh5NTaQC
{
  int32_T intNumBits;
};

#endif                                 /*struct_tag_sL6LJlPlxhdTxZzXh5NTaQC*/

#ifndef typedef_sL6LJlPlxhdTxZzXh5NTaQC_pmpc__T
#define typedef_sL6LJlPlxhdTxZzXh5NTaQC_pmpc__T

typedef struct tag_sL6LJlPlxhdTxZzXh5NTaQC sL6LJlPlxhdTxZzXh5NTaQC_pmpc__T;

#endif                                 /*typedef_sL6LJlPlxhdTxZzXh5NTaQC_pmpc__T*/

#ifndef struct_tag_sOR35emZGbeB3VgGxZNI5JD
#define struct_tag_sOR35emZGbeB3VgGxZNI5JD

struct tag_sOR35emZGbeB3VgGxZNI5JD
{
  real_T solve;
  real_T conv;
  real_T unsolved;
  real_T NaN_or_Inf;
  real_T b_else;
};

#endif                                 /*struct_tag_sOR35emZGbeB3VgGxZNI5JD*/

#ifndef typedef_sOR35emZGbeB3VgGxZNI5JD_pmpc__T
#define typedef_sOR35emZGbeB3VgGxZNI5JD_pmpc__T

typedef struct tag_sOR35emZGbeB3VgGxZNI5JD sOR35emZGbeB3VgGxZNI5JD_pmpc__T;

#endif                                 /*typedef_sOR35emZGbeB3VgGxZNI5JD_pmpc__T*/

#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T_pmpc_hil1_T
#define typedef_emxArray_real_T_pmpc_hil1_T

typedef struct emxArray_real_T emxArray_real_T_pmpc_hil1_T;

#endif                                 /*typedef_emxArray_real_T_pmpc_hil1_T*/

#ifndef struct_emxArray_char_T_1x30
#define struct_emxArray_char_T_1x30

struct emxArray_char_T_1x30
{
  char_T data[30];
  int32_T size[2];
};

#endif                                 /*struct_emxArray_char_T_1x30*/

#ifndef typedef_emxArray_char_T_1x30_pmpc_hil_T
#define typedef_emxArray_char_T_1x30_pmpc_hil_T

typedef struct emxArray_char_T_1x30 emxArray_char_T_1x30_pmpc_hil_T;

#endif                                 /*typedef_emxArray_char_T_1x30_pmpc_hil_T*/

/* Custom Type definition for MATLAB Function: '<Root>/PMPC_MF' */
#ifndef struct_s6iR23uabA7lcRDqHatfpeB_tag
#define struct_s6iR23uabA7lcRDqHatfpeB_tag

struct s6iR23uabA7lcRDqHatfpeB_tag
{
  emxArray_char_T_1x30_pmpc_hil_T f1;
};

#endif                                 /*struct_s6iR23uabA7lcRDqHatfpeB_tag*/

#ifndef typedef_b_cell_wrap_2_pmpc_hil1_T
#define typedef_b_cell_wrap_2_pmpc_hil1_T

typedef struct s6iR23uabA7lcRDqHatfpeB_tag b_cell_wrap_2_pmpc_hil1_T;

#endif                                 /*typedef_b_cell_wrap_2_pmpc_hil1_T*/

#ifndef struct_tag_sjuLL9cCC5HJJHyNGiYxFqB
#define struct_tag_sjuLL9cCC5HJJHyNGiYxFqB

struct tag_sjuLL9cCC5HJJHyNGiYxFqB
{
  real_T sw;
  real_T Fyf;
  real_T MFx;
  real_T Md;
  real_T ey;
  real_T epsi;
  real_T Tb[4];
  real_T Fd[4];
  real_T Vd[4];
  real_T b_gamma[3];
  real_T Vpid;
};

#endif                                 /*struct_tag_sjuLL9cCC5HJJHyNGiYxFqB*/

#ifndef typedef_sjuLL9cCC5HJJHyNGiYxFqB_pmpc__T
#define typedef_sjuLL9cCC5HJJHyNGiYxFqB_pmpc__T

typedef struct tag_sjuLL9cCC5HJJHyNGiYxFqB sjuLL9cCC5HJJHyNGiYxFqB_pmpc__T;

#endif                                 /*typedef_sjuLL9cCC5HJJHyNGiYxFqB_pmpc__T*/

#ifndef struct_tag_s9vR7NXdUIaS6ArqrqJ3uSB
#define struct_tag_s9vR7NXdUIaS6ArqrqJ3uSB

struct tag_s9vR7NXdUIaS6ArqrqJ3uSB
{
  real_T Q1;
  real_T Q2;
  real_T Q3;
  real_T Q4;
  real_T Q5;
  real_T Q6;
  real_T R1;
  real_T R2;
  real_T R3;
  real_T S1;
  real_T S2;
  real_T S3;
  real_T Qf_scale;
  real_T V1;
  real_T V2;
  real_T V3;
  real_T tau_gamma;
  real_T Wdg[3];
  real_T W1;
  real_T W2;
  real_T W3;
  real_T W4;
};

#endif                                 /*struct_tag_s9vR7NXdUIaS6ArqrqJ3uSB*/

#ifndef typedef_s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T
#define typedef_s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T

typedef struct tag_s9vR7NXdUIaS6ArqrqJ3uSB s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T;

#endif                                 /*typedef_s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T*/

#ifndef struct_tag_slSgDykzvLWgqZNBtieIyjF
#define struct_tag_slSgDykzvLWgqZNBtieIyjF

struct tag_slSgDykzvLWgqZNBtieIyjF
{
  char_T src[32];
  real_T mu;
  real_T nW;
  real_T alpha[141];
  real_T Fz[70];
  real_T Fbar[9870];
  real_T Cbar[9870];
  real_T C0;
};

#endif                                 /*struct_tag_slSgDykzvLWgqZNBtieIyjF*/

#ifndef typedef_slSgDykzvLWgqZNBtieIyjF_pmpc__T
#define typedef_slSgDykzvLWgqZNBtieIyjF_pmpc__T

typedef struct tag_slSgDykzvLWgqZNBtieIyjF slSgDykzvLWgqZNBtieIyjF_pmpc__T;

#endif                                 /*typedef_slSgDykzvLWgqZNBtieIyjF_pmpc__T*/

#ifndef struct_tag_sp9kPoz8g5ktlnFGoQORmNE
#define struct_tag_sp9kPoz8g5ktlnFGoQORmNE

struct tag_sp9kPoz8g5ktlnFGoQORmNE
{
  siQ02pX79ClhDlbeDEKhaoB_pmpc__T MPCParameters;
  s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T CostWeights;
  real_T DiscreteModle;
  real_T ContrlMode;
  real_T Reftraj[3609];
  real_T Cf0;
  real_T Cr0;
  real_T C_table[4];
  slSgDykzvLWgqZNBtieIyjF_pmpc__T TireF;
  slSgDykzvLWgqZNBtieIyjF_pmpc__T TireR;
};

#endif                                 /*struct_tag_sp9kPoz8g5ktlnFGoQORmNE*/

#ifndef typedef_sp9kPoz8g5ktlnFGoQORmNE_pmpc__T
#define typedef_sp9kPoz8g5ktlnFGoQORmNE_pmpc__T

typedef struct tag_sp9kPoz8g5ktlnFGoQORmNE sp9kPoz8g5ktlnFGoQORmNE_pmpc__T;

#endif                                 /*typedef_sp9kPoz8g5ktlnFGoQORmNE_pmpc__T*/

#ifndef struct_tag_sG3kQTpcw2cs3awv6Sx9ZZH
#define struct_tag_sG3kQTpcw2cs3awv6Sx9ZZH

struct tag_sG3kQTpcw2cs3awv6Sx9ZZH
{
  real_T mu_grid[5];
  real_T V_grid_kmh[5];
  real_T delta_grid_deg[8];
  real_T betaL[200];
  real_T betaR[200];
  real_T ok[200];
};

#endif                                 /*struct_tag_sG3kQTpcw2cs3awv6Sx9ZZH*/

#ifndef typedef_sG3kQTpcw2cs3awv6Sx9ZZH_pmpc__T
#define typedef_sG3kQTpcw2cs3awv6Sx9ZZH_pmpc__T

typedef struct tag_sG3kQTpcw2cs3awv6Sx9ZZH sG3kQTpcw2cs3awv6Sx9ZZH_pmpc__T;

#endif                                 /*typedef_sG3kQTpcw2cs3awv6Sx9ZZH_pmpc__T*/

#ifndef struct_tag_scZlGNcmSdXsfgNftx2nQBF
#define struct_tag_scZlGNcmSdXsfgNftx2nQBF

struct tag_scZlGNcmSdXsfgNftx2nQBF
{
  char_T DataType[6];
  real_T MaxIter;
  real_T FeasibilityTol;
  boolean_T IntegrityChecks;
};

#endif                                 /*struct_tag_scZlGNcmSdXsfgNftx2nQBF*/

#ifndef typedef_scZlGNcmSdXsfgNftx2nQBF_pmpc__T
#define typedef_scZlGNcmSdXsfgNftx2nQBF_pmpc__T

typedef struct tag_scZlGNcmSdXsfgNftx2nQBF scZlGNcmSdXsfgNftx2nQBF_pmpc__T;

#endif                                 /*typedef_scZlGNcmSdXsfgNftx2nQBF_pmpc__T*/

#ifndef struct_tag_sCbhmMeZ4DAZChEA352SZoG
#define struct_tag_sCbhmMeZ4DAZChEA352SZoG

struct tag_sCbhmMeZ4DAZChEA352SZoG
{
  real_T InitialGapflag;
  real_T WayPoints_IndexPre;
  sOR35emZGbeB3VgGxZNI5JD_pmpc__T failed_num;
  sVXb2BidddHRLBtc2GzZiBG_pmpc__T emax;
  real_T U[3];
  sjuLL9cCC5HJJHyNGiYxFqB_pmpc__T prevstate;
  real_T dr_prev;
  real_T dr_rate;
  real_T t_solve[20000];
  real_T n_solve;
  real_T ey_hist[20000];
  real_T epsi_hist[20000];
  real_T BaselineMode;
  real_T BaselineCurrent;
  real_T FishhookMode;
};

#endif                                 /*struct_tag_sCbhmMeZ4DAZChEA352SZoG*/

#ifndef typedef_sCbhmMeZ4DAZChEA352SZoG_pmpc__T
#define typedef_sCbhmMeZ4DAZChEA352SZoG_pmpc__T

typedef struct tag_sCbhmMeZ4DAZChEA352SZoG sCbhmMeZ4DAZChEA352SZoG_pmpc__T;

#endif                                 /*typedef_sCbhmMeZ4DAZChEA352SZoG_pmpc__T*/

#ifndef struct_tag_s1bqF0CUvhfxI4SgSy4sO1C
#define struct_tag_s1bqF0CUvhfxI4SgSy4sO1C

struct tag_s1bqF0CUvhfxI4SgSy4sO1C
{
  sCbhmMeZ4DAZChEA352SZoG_pmpc__T InitialParams;
  real_T WarmStart[26];
  real_T rho[9];
  s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T VehiclePara;
  seSWzzkDqqnmIb9KZFsj0XH_pmpc__T Constraints;
};

#endif                                 /*struct_tag_s1bqF0CUvhfxI4SgSy4sO1C*/

#ifndef typedef_s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T
#define typedef_s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T

typedef struct tag_s1bqF0CUvhfxI4SgSy4sO1C s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T;

#endif                                 /*typedef_s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T*/

#ifndef struct_tag_ser4JjaYDiHULTlI5DaIvXB
#define struct_tag_ser4JjaYDiHULTlI5DaIvXB

struct tag_ser4JjaYDiHULTlI5DaIvXB
{
  sCbhmMeZ4DAZChEA352SZoG_pmpc__T InitialParams;
  real_T Reftraj[3609];
  s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T VehiclePara;
  seSWzzkDqqnmIb9KZFsj0XH_pmpc__T Constraints;
  siQ02pX79ClhDlbeDEKhaoB_pmpc__T MPCParameters;
  real_T DiscreteModle;
  real_T ContrlMode;
  real_T WarmStart[26];
  real_T DotPHI[12];
  real_T rho[9];
  s9vR7NXdUIaS6ArqrqJ3uSB_pmpc__T CostWeights;
  real_T C_table[4];
  real_T Cf0;
  real_T Cr0;
  slSgDykzvLWgqZNBtieIyjF_pmpc__T TireF;
  slSgDykzvLWgqZNBtieIyjF_pmpc__T TireR;
  sp9kPoz8g5ktlnFGoQORmNE_pmpc__T Pm;
  s1bqF0CUvhfxI4SgSy4sO1C_pmpc__T S0;
};

#endif                                 /*struct_tag_ser4JjaYDiHULTlI5DaIvXB*/

#ifndef typedef_ser4JjaYDiHULTlI5DaIvXB_pmpc__T
#define typedef_ser4JjaYDiHULTlI5DaIvXB_pmpc__T

typedef struct tag_ser4JjaYDiHULTlI5DaIvXB ser4JjaYDiHULTlI5DaIvXB_pmpc__T;

#endif                                 /*typedef_ser4JjaYDiHULTlI5DaIvXB_pmpc__T*/

#ifndef struct_emxArray_boolean_T_148
#define struct_emxArray_boolean_T_148

struct emxArray_boolean_T_148
{
  boolean_T data[148];
  int32_T size;
};

#endif                                 /*struct_emxArray_boolean_T_148*/

#ifndef typedef_emxArray_boolean_T_148_pmpc_h_T
#define typedef_emxArray_boolean_T_148_pmpc_h_T

typedef struct emxArray_boolean_T_148 emxArray_boolean_T_148_pmpc_h_T;

#endif                                 /*typedef_emxArray_boolean_T_148_pmpc_h_T*/

/* Parameters (default storage) */
typedef struct P_pmpc_hil1_T_ P_pmpc_hil1_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_pmpc_hil1_T RT_MODEL_pmpc_hil1_T;

#endif                                 /* RTW_HEADER_pmpc_hil1_types_h_ */
