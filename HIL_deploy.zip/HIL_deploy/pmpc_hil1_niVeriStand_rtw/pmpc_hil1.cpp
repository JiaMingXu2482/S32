#define NI_VERISTAND_MAINMODELFILE

/*
 *
 * Code generation for model "pmpc_hil1".
 *
 * Model version              : 1.1
 * Simulink Coder version : 8.14 (R2018a) 06-Feb-2018
 * C++ source code generated on : Sat Sep 19 13:53:59 2026
 *
 * Target selection: NIVeriStand.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "pmpc_hil1.h"
#include "pmpc_hil1_private.h"

/* Block signals (default storage) */
B_pmpc_hil1_T pmpc_hil1_B;

/* Continuous states */
X_pmpc_hil1_T pmpc_hil1_X;

/* Block states (default storage) */
DW_pmpc_hil1_T pmpc_hil1_DW;

/* Real-time model */
RT_MODEL_pmpc_hil1_T pmpc_hil1_M_;
RT_MODEL_pmpc_hil1_T *const pmpc_hil1_M = &pmpc_hil1_M_;

/* Forward declaration for local functions */
static void pmpc_hil1_func_StateEstimation(const real_T ModelInput[50],
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStatemeasured,
  stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *HATParameter);
static void pmpc_hil1_func_TireTable(const real_T varargin_1_alpha[141], const
  real_T varargin_1_Fz[70], const real_T varargin_1_Fbar[9870], const real_T
  varargin_1_Cbar[9870], real_T varargin_2, real_T varargin_3, real_T *A, real_T
  *B);
static void pmpc_hil1_power(const real_T a[401], real_T y[401]);
static void pmpc_hil1_sqrt(real_T x[401]);
static void pmpc_hil1_linspace(real_T d2, real_T y[1500]);
static void pmpc_hil1_pwchcore_n(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], int32_T yoffset, const real_T s_data[], const real_T
  dx_data[], const real_T divdif_data[], real_T pp_breaks_data[], int32_T
  pp_breaks_size[2], real_T pp_coefs_data[], int32_T pp_coefs_size[3]);
static void pmpc_hil1_pwchcore(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const real_T s[2], real_T pp_breaks_data[], int32_T
  pp_breaks_size[2], real_T pp_coefs[4]);
static void pmpc_hil1_splinepp(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const int32_T y_size[2], real_T pp_breaks_data[],
  int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T pp_coefs_size[3]);
static void pmpc_hil1_spline(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const int32_T *y_size, const real_T xx[1500], real_T
  output_data[], int32_T output_size[2]);
static void pmpc_hil1_power_b(const real_T a_data[], real_T y_data[], int32_T
  y_size[2]);
static void pmpc_hil1_sqrt_f(real_T x_data[]);
static void pmpc_hil1_local_wrapToPi(real_T *ang);
static void pmpc_hil1_func_error(real_T PosX, real_T PosY, real_T PosPsi, real_T
  *PPx, real_T *PPy, real_T *Psi0, real_T *e_y, real_T *e_psi);
static void pmpc_hil1_emxInit_real_T(emxArray_real_T_pmpc_hil1_T **pEmxArray,
  int32_T numDimensions);
static void pmpc_h_emxEnsureCapacity_real_T(emxArray_real_T_pmpc_hil1_T
  *emxArray, int32_T oldNumel);
static void pmpc_hil1_emxFree_real_T(emxArray_real_T_pmpc_hil1_T **pEmxArray);
static void pmpc_hil1_linspace_k(real_T n1, emxArray_real_T_pmpc_hil1_T *y);
static void pmpc_func_RefTraj_LocalPlanning(real_T WayPoints_Index, const
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured, real_T *WPIndex, real_T
  RefU[36], real_T Bezier_K[12], real_T *PrjP_ey, real_T *PrjP_epsi, real_T
  *PrjP_Velr, real_T *PrjP_xr, real_T *PrjP_yr, real_T *PrjP_psir);
static void pmpc_hil1_func_Envelope(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  real_T Envelope_Henv[12], real_T Envelope_Genv[2], real_T Envelope_Hsh[24],
  real_T Envelope_Gsh[4], real_T Envelope_Hr[12], real_T Envelope_Or[6], real_T
  Envelope_Gr[2], real_T *r_ssmax);
static real_T pmpc_hil1_func_MRDamper(real_T v);
static void func_CostWeightingRegulation_Qu(const
  stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, const
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured, real_T Q[5184], real_T R
  [324], real_T S[324], real_T Wshl[64], real_T Wact[9], real_T *dFyfmax, real_T
  *dMFxmax, real_T *dMdmax, real_T *Fyfmax, real_T *MFxmax, real_T *Mdmax,
  real_T *Mdmin, s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T *Tb_u, real_T Fdu[4], real_T
  Fdl[4], real_T *Mdnom);
static void pmpc_hil1_func_DynamicalModel(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  real_T StateSpaceModel_C_aug[54], real_T StateSpaceModel_A_aug[972], real_T
  StateSpaceModel_B_aug[324], real_T StateSpaceModel_D_aug[324], real_T
  StateSpaceModel_off[24], boolean_T *StateSpaceModel_off_valid);
static void pmpc_hil1_eye(real_T I[81]);
static void pmpc_hil1_func_SystemFurture(const real_T StateSpaceModel_C_aug[54],
  const real_T StateSpaceModel_A_aug[972], const real_T StateSpaceModel_B_aug
  [324], const real_T StateSpaceModel_D_aug[324], const real_T Bezier_SK[12],
  const real_T dist_data[], real_T PSI[648], real_T THETA[1296], real_T GAMMA[36],
  real_T PHI[2592]);
static void pmpc_hil1_kron(const real_T B[3], real_T K[18]);
static void pmpc_hil1_diag_e(const real_T v[64], real_T d[8]);
static void pmpc_hil1_func_BuildQPCost(const real_T Pred_PSI[648], const real_T
  Pred_THETA[1296], const real_T Pred_PHI[2592], const real_T Pred_GAMMA[36],
  const real_T Wts_Q[5184], const real_T Wts_R[324], const real_T Wts_S[324],
  const real_T Wts_W[64], const real_T zeta[9], const real_T AI[324], const
  real_T Ut[18], const real_T ref_Vy[12], const real_T ref_r[12], real_T H[676],
  real_T f[26]);
static void pmpc_hil1_kron_k(const real_T A[36], const real_T B[24], real_T K
  [864]);
static void pmpc_hil1_kron_kaq(const real_T A[144], const real_T B[12], real_T
  K[1728]);
static void pmpc_hil1_kron_kaqb3(const real_T A[36], const real_T B[12], real_T
  K[432]);
static void pmpc_hil1_kron_kaqb31d(const real_T A[36], const real_T B[6], real_T
  K[216]);
static void pmpc_hil1_kron_ka(const real_T B[4], real_T K[24]);
static void pmpc_hil1_kron_kaqb31(const real_T B[2], real_T K[12]);
static void pmpc_hil1_kron_kaqb(const real_T B[2], real_T K[24]);
static void pmpc_hi_func_BuildQPConstraints(const real_T Envelope_Henv[12],
  const real_T Envelope_Genv[2], const real_T Envelope_Hsh[24], const real_T
  Envelope_Gsh[4], const real_T Envelope_Hr[12], const real_T Envelope_Or[6],
  const real_T Envelope_Gr[2], const real_T Pred_PSI[648], const real_T
  Pred_THETA[1296], const real_T Pred_PHI[2592], const real_T Pred_GAMMA[36],
  const real_T AI[324], const real_T Ut[18], const real_T zeta[9], real_T
  Lim_MFxmax, real_T Lim_Mdmax, real_T Lim_Mdmin, const real_T Lim_eps_ub[8],
  real_T Lim_dMFxmax, real_T Lim_dMdmax, real_T Lim_dlt_ub, real_T Lim_dlt_lb,
  real_T A_cons[2496], real_T b_cons[96], real_T lb[26], real_T ub[26], real_T
  umax[3], real_T umin[3]);
static void pmpc_hil1_isfinite_c(const real_T x[26], boolean_T b[26]);
static boolean_T pmpc_hil1_all(const boolean_T x[26]);
static void pmpc_hil1_isfinite_cn5(const real_T x[676], boolean_T b[676]);
static boolean_T pmpc_hil1_all_n(const boolean_T x[676]);
static void pmpc_hil1_isfinite_cn5c(const real_T x[2496], boolean_T b[2496]);
static boolean_T pmpc_hil1_all_ns(const boolean_T x[2496]);
static void pmpc_hil1_isfinite_cn5ck(const real_T x[96], boolean_T b[96]);
static boolean_T pmpc_hil1_all_ns5(const boolean_T x[96]);
static boolean_T pmpc_hil1_any(const boolean_T x[26]);
static boolean_T pmpc_hil1_isfinite(real_T x);
static void pmpc_hil1_diag_eek(const real_T v[676], real_T d[26]);
static void pmpc_hil1_sqrt_fk(real_T x[26]);
static void pmpc_hil1_bsxfun(const real_T a[2496], const real_T b[26], real_T c
  [2496]);
static void pmpc_hil1_local_warmstart(boolean_T iA_data[], int32_T *iA_size);
static int32_T pmpc_hil1_xpotrf(real_T A_data[], int32_T A_size[2], int32_T lda);
static int32_T pmpc_hil1_cholesky(real_T A_data[], int32_T A_size[2]);
static int32_T pmpc_hil1_ixamax_n(int32_T n, const real_T x_data[], int32_T ix0);
static void pmpc_hil1_xswap(int32_T n, real_T x_data[], int32_T ix0, int32_T iy0);
static real_T pmpc_hil1_xnrm2(int32_T n, const real_T x_data[], int32_T ix0);
static real_T pmpc_hil1_xzlarfg(int32_T n, real_T *alpha1, real_T x_data[],
  int32_T ix0);
static int32_T pmpc_hil1_ilazlc(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda);
static void pmpc_hil1_xgemv(int32_T m, int32_T n, const real_T A_data[], int32_T
  ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y_data[]);
static void pmpc_hil1_xger(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y_data[], real_T A_data[], int32_T ia0, int32_T lda);
static void pmpc_hil1_xzlarf(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C_data[], int32_T ic0, int32_T ldc, real_T work_data[]);
static void pmpc_hil1_xgeqp3(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size, int32_T jpvt_data[], int32_T jpvt_size[2]);
static int32_T pmpc_hil1_rankFromQR(const real_T A_data[], const int32_T A_size
  [2]);
static void pmpc_hil1_xunormqr(const real_T Q_data[], const int32_T Q_size[2],
  real_T C[676], const real_T tau_data[]);
static void pmpc_hil1_LSQFromQR_j(const real_T A_data[], const int32_T A_size[2],
  const real_T tau_data[], const int32_T jpvt_data[], int32_T rankA, real_T
  Y_data[], int32_T Y_size[2]);
static void pmpc_hil1_qrsolve_i(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2]);
static int32_T pmpc_hil1_ixamax(int32_T n, const real_T x_data[], int32_T ix0);
static void pmpc_hil1_xswap_h(real_T x_data[], int32_T ix0, int32_T iy0);
static void pmpc_hil1_xgetrf(real_T A_data[], int32_T A_size[2], int32_T ipiv[26],
  int32_T *info);
static void pmpc_hil1_xtrsm(const real_T A_data[], real_T B[676]);
static void pmpc_hil1_xtrsm_l(const real_T A_data[], real_T B[676]);
static void pmpc_hil1_lusolve(const real_T A_data[], const int32_T A_size[2],
  real_T X[676]);
static void pmpc_hil1_mldivide_j(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2]);
static void pmpc_hil1_Unconstrained_p(const real_T Hinv[676], const real_T f[26],
  real_T x_data[], int16_T n);
static real_T pmpc_hil1_norm(const real_T x_data[], const int32_T *x_size);
static void pmpc_hil1_abs_jm(const real_T x[26], real_T y[26]);
static void pmpc_hil1_abs_jm4(const real_T x[148], real_T y[148]);
static real_T pmpc_hil1_xzlarfg_h(int32_T n, real_T *alpha1, real_T x_data[],
  int32_T ix0);
static void pmpc_hil1_xgemv_kx(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y[26]);
static void pmpc_hil1_xger_ky(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[26], real_T A_data[], int32_T ia0, int32_T lda);
static void pmpc_hil1_xzlarf_cu(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C_data[], int32_T ic0, int32_T ldc, real_T work[26]);
static void pmpc_hil1_xgeqrf_ft(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size);
static void pmpc_hil1_xscal_i(int32_T n, real_T a, real_T x_data[], int32_T ix0);
static void pmpc_hil1_qr_e(const real_T A_data[], const int32_T A_size[2],
  real_T Q_data[], int32_T Q_size[2], real_T R_data[], int32_T R_size[2]);
static real_T pmpc_hil1_KWIKfactor_p(const real_T Ac[3848], const int16_T iC[148],
  int16_T nA, const real_T Linv_data[], const int32_T Linv_size[2], real_T
  RLinv_data[], int32_T RLinv_size[2], real_T D_data[], int32_T D_size[2],
  real_T H_data[], int32_T H_size[2], int16_T n);
static void pmpc_hil1_DropConstraint_a(int16_T kDrop, int16_T iA_data[], int16_T
  *nA, int16_T iC[148]);
static void pmpc_hil1_qpkwik_o(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T Hinv[676], const real_T f[26], const real_T Ac[3848],
  const real_T b[148], int16_T iA_data[], int32_T *iA_size, int16_T n, real_T
  x_data[], int32_T *x_size, real_T lambda[148], real_T *status);
static void pmpc_hil1_mpcqpsolver_h(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T f[26], const real_T A[3848], const real_T b[148],
  const boolean_T iA0_data[], real_T x_data[], int32_T *x_size, real_T *status,
  boolean_T iA[148]);
static void pmpc_hil1_local_warmstart_i(const boolean_T iA_new[148]);
static real_T pmpc_hil1_sum(const boolean_T x[148]);
static void pmpc_hil1_func_QPKwik_cz(const real_T H[676], const real_T f[26],
  const real_T A[2496], const real_T b[96], const real_T lb[26], const real_T
  ub[26], real_T x_data[], int32_T *x_size, real_T *status, real_T *nAct);
static void pmpc_hil1_func_SolveMPCQP(const real_T H[676], const real_T f[26],
  const real_T A_cons[2496], const real_T b_cons[96], const real_T lb[26], const
  real_T ub[26], real_T WarmStart[26], real_T x_opt[26], real_T *exitflag,
  real_T delta_U_first[3], real_T rho_val[3], real_T epsilon_val[8]);
static void pmpc_hil1_diag(const real_T v[3], real_T d[9]);
static void pmpc_hil1_isfinite_cn(const real_T x[4], boolean_T b[4]);
static void pmpc_hil1_LSQFromQR(const real_T A_data[], const int32_T A_size[2],
  const real_T tau_data[], const int32_T jpvt_data[], int32_T rankA, real_T
  Y_data[], int32_T Y_size[2]);
static void pmpc_hil1_qrsolve(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2]);
static void pmpc_hil1_mldivide(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2]);
static void pmpc_hil1_Unconstrained(const real_T Hinv[16], const real_T f[4],
  real_T x_data[], int16_T n);
static void pmpc_hil1_abs(const real_T x[4], real_T y[4]);
static void pmpc_hil1_abs_j(const real_T x[8], real_T y[8]);
static void pmpc_hil1_xgemv_k(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y[4]);
static void pmpc_hil1_xger_k(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[4], real_T A_data[], int32_T ia0, int32_T lda);
static void pmpc_hil1_xgeqrf_f(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size);
static void pmpc_hil1_xgeqrf(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size);
static void pmpc_hil1_xscal(int32_T n, real_T a, real_T x_data[], int32_T ix0);
static void pmpc_hil1_qr(const real_T A_data[], const int32_T A_size[2], real_T
  Q_data[], int32_T Q_size[2], real_T R_data[], int32_T R_size[2]);
static real_T pmpc_hil1_KWIKfactor(const int16_T iC[8], int16_T nA, const real_T
  Linv_data[], const int32_T Linv_size[2], real_T RLinv_data[], int32_T
  RLinv_size[2], real_T D_data[], int32_T D_size[2], real_T H_data[], int32_T
  H_size[2], int16_T n);
static void pmpc_hil1_DropConstraint(int16_T kDrop, int16_T iA[8], int16_T *nA,
  int16_T iC[8]);
static void pmpc_hil1_qpkwik(const real_T Linv_data[], const int32_T Linv_size[2],
  const real_T Hinv[16], const real_T f[4], const real_T b[8], int16_T n, real_T
  x_data[], int32_T *x_size, real_T lambda[8], real_T *status, int16_T iA[8]);
static void pmpc_hil1_mpcqpsolver(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T f[4], const real_T b[8], real_T x_data[], int32_T
  *x_size, real_T *status, boolean_T iA[8]);
static void pmpc_hil1_func_QPKwik(const real_T H[16], const real_T f[4], const
  real_T ub[4], real_T x_data[], int32_T *x_size, real_T *status, real_T *nAct);
static void pmpc_hil1_func_QPA_DB(const real_T InitialParams_prevstate_Tb[4],
  const stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, real_T MFx, real_T delta_wheel,
  const s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T Tb_u, real_T Fx_dem, real_T *Tb_L1,
  real_T *Tb_L2, real_T *Tb_R1, real_T *Tb_R2);
static void pmpc_hil1_func_QPKwik_c(const real_T H[16], const real_T f[4], const
  real_T lb[4], const real_T ub[4], real_T x_data[], int32_T *x_size, real_T
  *status, real_T *nAct);
static void pmpc_hil1_func_QPA_CDC(const real_T InitialParams_prevstate_Fd[4],
  real_T MFd, const real_T Fdu[4], const real_T Fdl[4], real_T *Fd_L1, real_T
  *Fd_L2, real_T *Fd_R1, real_T *Fd_R2, real_T *Md_real, real_T *exitflag_Fd);
static void pmpc_hil1_func_ReportStatus(sCbhmMeZ4DAZChEA352SZoG_pmpc__T
  *InitialParams, real_T exitflag, real_T PrjP_ey, real_T PrjP_epsi, real_T Vel);
static void pmpc_hil1_func_LTRDiagnosis(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  const stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, const real_T Y[72], const
  real_T x_opt[26], real_T exitflag, const real_T AI[324], const real_T Ut[18],
  real_T Md_next, real_T *LTR_real, real_T *LTR_calc, real_T *LTR_Npdc);
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (pmpc_hil1_M->Timing.TaskCounters.TID[2])++;
  if ((pmpc_hil1_M->Timing.TaskCounters.TID[2]) > 9) {/* Sample time: [0.01s, 0.0s] */
    pmpc_hil1_M->Timing.TaskCounters.TID[2] = 0;
  }

  pmpc_hil1_M->Timing.sampleHits[2] = (pmpc_hil1_M->Timing.TaskCounters.TID[2] ==
    0);
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  pmpc_hil1_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_StateEstimation(const real_T ModelInput[50],
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStatemeasured,
  stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *HATParameter)
{
  real_T A;
  real_T b_A;
  real_T c_A;
  real_T d_A;
  real_T x;
  real_T y;
  real_T b_x;
  real_T c_x;
  real_T d_x;
  real_T f_x;
  real_T g_x;
  real_T h_x;
  real_T i_x;
  real_T j_x;
  real_T k_x;
  real_T l_x;
  real_T m_x;
  real_T n_x;
  real_T o_x;
  real_T p_x;
  VehStatemeasured->V_l1 = ModelInput[0] / 1000.0;
  VehStatemeasured->V_l2 = ModelInput[1] / 1000.0;
  VehStatemeasured->V_r1 = ModelInput[2] / 1000.0;
  VehStatemeasured->V_r2 = ModelInput[3] / 1000.0;
  VehStatemeasured->X = ModelInput[39];
  VehStatemeasured->Y = ModelInput[40];
  VehStatemeasured->x_dot = ModelInput[41] / 3.6;
  VehStatemeasured->y_dot = ModelInput[42] / 3.6;
  VehStatemeasured->Yaw = ModelInput[38] * 3.1415926535897931 / 180.0;
  VehStatemeasured->Yawrate = ModelInput[33] * 3.1415926535897931 / 180.0;
  VehStatemeasured->Yawaccel = ModelInput[44];
  HATParameter->Roll = ModelInput[37] * 3.1415926535897931 / 180.0;
  HATParameter->Rollrate = ModelInput[32] * 3.1415926535897931 / 180.0;
  HATParameter->Rollaccel = ModelInput[43];
  VehStatemeasured->beta = ModelInput[36] * 3.1415926535897931 / 180.0;
  VehStatemeasured->delta_l = ModelInput[45] * 3.1415926535897931 / 180.0;
  VehStatemeasured->delta_r = ModelInput[46] * 3.1415926535897931 / 180.0;
  VehStatemeasured->Steer_SW = ModelInput[47];
  VehStatemeasured->Ax = 9.81 * ModelInput[34];
  VehStatemeasured->Ay = 9.81 * ModelInput[35];
  A = ModelInput[4] * 3.1415926535897931;
  HATParameter->alpha_l1 = A / 180.0;
  b_A = ModelInput[5] * 3.1415926535897931;
  HATParameter->alpha_l2 = b_A / 180.0;
  c_A = ModelInput[6] * 3.1415926535897931;
  HATParameter->alpha_r1 = c_A / 180.0;
  d_A = ModelInput[7] * 3.1415926535897931;
  HATParameter->alpha_r2 = d_A / 180.0;
  x = rt_roundd_snf(1000.0 * ModelInput[8]);
  y = x / 1000.0;
  HATParameter->Fx_l1 = x / 1000.0;
  b_x = rt_roundd_snf(1000.0 * ModelInput[9]);
  x = b_x / 1000.0;
  HATParameter->Fx_l2 = b_x / 1000.0;
  c_x = rt_roundd_snf(1000.0 * ModelInput[10]);
  b_x = c_x / 1000.0;
  HATParameter->Fx_r1 = c_x / 1000.0;
  d_x = rt_roundd_snf(1000.0 * ModelInput[11]);
  c_x = d_x / 1000.0;
  HATParameter->Fx_r2 = d_x / 1000.0;
  d_x = rt_roundd_snf(1000.0 * ModelInput[12]);
  HATParameter->Fy_l1 = d_x / 1000.0;
  f_x = rt_roundd_snf(1000.0 * ModelInput[13]);
  HATParameter->Fy_l2 = f_x / 1000.0;
  g_x = rt_roundd_snf(1000.0 * ModelInput[14]);
  HATParameter->Fy_r1 = g_x / 1000.0;
  h_x = rt_roundd_snf(1000.0 * ModelInput[15]);
  HATParameter->Fy_r2 = h_x / 1000.0;
  i_x = rt_roundd_snf(1000.0 * ModelInput[16]);
  HATParameter->Fz_l1 = i_x / 1000.0;
  j_x = rt_roundd_snf(1000.0 * ModelInput[17]);
  HATParameter->Fz_l2 = j_x / 1000.0;
  k_x = rt_roundd_snf(1000.0 * ModelInput[18]);
  HATParameter->Fz_r1 = k_x / 1000.0;
  l_x = rt_roundd_snf(1000.0 * ModelInput[19]);
  HATParameter->Fz_r2 = l_x / 1000.0;
  m_x = rt_roundd_snf(1000.0 * ModelInput[20]);
  HATParameter->Fd_L1 = m_x / 1000.0;
  n_x = rt_roundd_snf(1000.0 * ModelInput[21]);
  HATParameter->Fd_L2 = n_x / 1000.0;
  o_x = rt_roundd_snf(1000.0 * ModelInput[22]);
  HATParameter->Fd_R1 = o_x / 1000.0;
  p_x = rt_roundd_snf(1000.0 * ModelInput[23]);
  HATParameter->Fd_R2 = p_x / 1000.0;
  HATParameter->Td_L1 = ModelInput[28];
  HATParameter->Td_L2 = ModelInput[29];
  HATParameter->Td_R1 = ModelInput[30];
  HATParameter->Td_R2 = ModelInput[31];
  VehStatemeasured->omega_L1 = ModelInput[24] * 3.1415926535897931 / 30.0;
  VehStatemeasured->omega_L2 = ModelInput[25] * 3.1415926535897931 / 30.0;
  VehStatemeasured->omega_R1 = ModelInput[26] * 3.1415926535897931 / 30.0;
  VehStatemeasured->omega_R2 = ModelInput[27] * 3.1415926535897931 / 30.0;
  VehStatemeasured->VxTarget = ModelInput[48];
  HATParameter->LTR = ModelInput[49];
  VehStatemeasured->delta_f = (ModelInput[45] + ModelInput[46]) * 0.5 *
    3.1415926535897931 / 180.0;
  HATParameter->MFx = ((b_x + c_x) - y) - x;
  HATParameter->Fyf = d_x / 1000.0 + g_x / 1000.0;
  HATParameter->Fyr = f_x / 1000.0 + h_x / 1000.0;
  HATParameter->Md = (o_x / 1000.0 - m_x / 1000.0) * 1.1 + (p_x / 1000.0 - n_x /
    1000.0) * 1.1;
  HATParameter->alphaf = (A / 180.0 + c_A / 180.0) / 2.0;
  HATParameter->alphar = (b_A / 180.0 + d_A / 180.0) / 2.0;
  HATParameter->Fzf = i_x / 1000.0 + k_x / 1000.0;
  HATParameter->Fzr = j_x / 1000.0 + l_x / 1000.0;
  HATParameter->Fxf = y + b_x;
  HATParameter->Fxr = x + c_x;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_TireTable(const real_T varargin_1_alpha[141], const
  real_T varargin_1_Fz[70], const real_T varargin_1_Fbar[9870], const real_T
  varargin_1_Cbar[9870], real_T varargin_2, real_T varargin_3, real_T *A, real_T
  *B)
{
  real_T a;
  real_T z;
  real_T dz;
  real_T tz;
  real_T da;
  real_T u0;
  real_T u0_0;
  int32_T tz_tmp;
  int32_T A_tmp;
  int32_T A_tmp_0;
  int32_T A_tmp_1;
  if ((varargin_2 > varargin_1_alpha[0]) || rtIsNaN(varargin_1_alpha[0])) {
    a = varargin_2;
  } else {
    a = varargin_1_alpha[0];
  }

  if (!((a < varargin_1_alpha[140]) || rtIsNaN(varargin_1_alpha[140]))) {
    a = varargin_1_alpha[140];
  }

  if ((varargin_3 > varargin_1_Fz[0]) || rtIsNaN(varargin_1_Fz[0])) {
    z = varargin_3;
  } else {
    z = varargin_1_Fz[0];
  }

  if (!((z < varargin_1_Fz[69]) || rtIsNaN(varargin_1_Fz[69]))) {
    z = varargin_1_Fz[69];
  }

  da = varargin_1_alpha[1] - varargin_1_alpha[0];
  dz = varargin_1_Fz[1] - varargin_1_Fz[0];
  u0 = std::floor((a - varargin_1_alpha[0]) / da) + 1.0;
  if (!(u0 > 1.0)) {
    u0 = 1.0;
  }

  if (!(u0 < 140.0)) {
    u0 = 140.0;
  }

  u0_0 = std::floor((z - varargin_1_Fz[0]) / dz) + 1.0;
  if (!(u0_0 > 1.0)) {
    u0_0 = 1.0;
  }

  if (!(u0_0 < 69.0)) {
    u0_0 = 69.0;
  }

  a = (a - varargin_1_alpha[(int32_T)u0 - 1]) / da;
  tz_tmp = (int32_T)u0_0 - 1;
  tz = (z - varargin_1_Fz[tz_tmp]) / dz;
  z = (1.0 - a) * (1.0 - tz);
  dz = (1.0 - tz) * a;
  da = (1.0 - a) * tz;
  a *= tz;
  tz_tmp = tz_tmp * 141 + (int32_T)u0;
  A_tmp = 141 * (int32_T)u0_0 + (int32_T)u0;
  A_tmp_0 = tz_tmp - 1;
  A_tmp_1 = A_tmp - 1;
  *A = ((varargin_1_Fbar[A_tmp_0] * z + varargin_1_Fbar[tz_tmp] * dz) +
        varargin_1_Fbar[A_tmp_1] * da) + varargin_1_Fbar[A_tmp] * a;
  *B = ((varargin_1_Cbar[A_tmp_0] * z + varargin_1_Cbar[tz_tmp] * dz) +
        varargin_1_Cbar[A_tmp_1] * da) + varargin_1_Cbar[A_tmp] * a;
  if (!((!rtIsInf(*A)) && (!rtIsNaN(*A)))) {
    *A = 0.0;
  }

  if (!((!rtIsInf(*B)) && (!rtIsNaN(*B)))) {
    *B = -87800.360613855533;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_power(const real_T a[401], real_T y[401])
{
  int32_T k;
  for (k = 0; k < 401; k++) {
    y[k] = a[k] * a[k];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_sqrt(real_T x[401])
{
  int32_T k;
  for (k = 0; k < 401; k++) {
    x[k] = std::sqrt(x[k]);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_linspace(real_T d2, real_T y[1500])
{
  real_T delta1;
  int32_T k;
  y[1499] = d2;
  y[0] = 1.0;
  delta1 = (d2 - 1.0) / 1499.0;
  for (k = 0; k < 1498; k++) {
    y[k + 1] = (1.0 + (real_T)k) * delta1 + 1.0;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_pwchcore_n(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], int32_T yoffset, const real_T s_data[], const real_T
  dx_data[], const real_T divdif_data[], real_T pp_breaks_data[], int32_T
  pp_breaks_size[2], real_T pp_coefs_data[], int32_T pp_coefs_size[3])
{
  int32_T nx;
  int32_T nxm1;
  real_T dzzdx;
  real_T dzdxdx;
  int32_T loop_ub;
  nx = x_size[1] - 1;
  nxm1 = x_size[1] - 1;
  pp_breaks_size[0] = 1;
  pp_breaks_size[1] = x_size[1];
  loop_ub = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&pp_breaks_data[0], &x_data[0], loop_ub * sizeof(real_T));
  }

  pp_coefs_size[0] = 1;
  pp_coefs_size[1] = (int16_T)(x_size[1] - 1);
  pp_coefs_size[2] = 4;
  for (loop_ub = 0; loop_ub < nx; loop_ub++) {
    dzzdx = (divdif_data[loop_ub] - s_data[loop_ub]) / dx_data[loop_ub];
    dzdxdx = (s_data[loop_ub + 1] - divdif_data[loop_ub]) / dx_data[loop_ub];
    pp_coefs_data[loop_ub] = (dzdxdx - dzzdx) / dx_data[loop_ub];
    pp_coefs_data[nx + loop_ub] = 2.0 * dzzdx - dzdxdx;
    pp_coefs_data[(nxm1 << 1) + loop_ub] = s_data[loop_ub];
    pp_coefs_data[3 * nxm1 + loop_ub] = y_data[yoffset + loop_ub];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_pwchcore(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const real_T s[2], real_T pp_breaks_data[], int32_T
  pp_breaks_size[2], real_T pp_coefs[4])
{
  real_T dxj;
  real_T divdifij;
  real_T dzzdx;
  int32_T loop_ub;
  pp_breaks_size[0] = 1;
  pp_breaks_size[1] = x_size[1];
  loop_ub = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&pp_breaks_data[0], &x_data[0], loop_ub * sizeof(real_T));
  }

  for (loop_ub = 1; loop_ub < x_size[1]; loop_ub++) {
    dxj = x_data[loop_ub] - x_data[loop_ub - 1];
    divdifij = (y_data[loop_ub + 1] - y_data[loop_ub]) / dxj;
    dzzdx = (divdifij - s[loop_ub - 1]) / dxj;
    divdifij = (s[1] - divdifij) / dxj;
    pp_coefs[loop_ub - 1] = (divdifij - dzzdx) / dxj;
    pp_coefs[loop_ub] = 2.0 * dzzdx - divdifij;
    pp_coefs[loop_ub + 1] = s[loop_ub - 1];
    pp_coefs[3] = y_data[loop_ub];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_splinepp(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const int32_T y_size[2], real_T pp_breaks_data[],
  int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T pp_coefs_size[3])
{
  int32_T nx;
  boolean_T has_endslopes;
  real_T c_data[3];
  real_T dx_data[400];
  real_T d31;
  int32_T yoffset;
  real_T dvdf_data[400];
  real_T s_data[401];
  real_T dnnm2;
  real_T md_data[401];
  real_T r;
  real_T b_c_data[2];
  int32_T k;
  real_T b_coefs[4];
  int32_T e_coefs_size[3];
  int32_T dvdf_data_tmp;
  nx = x_size[1] - 1;
  has_endslopes = (x_size[1] + 2 == y_size[1]);
  if (x_size[1] <= 2) {
    if (has_endslopes) {
      b_c_data[0] = y_data[0];
      b_c_data[1] = y_data[y_size[1] - 1];
      pmpc_hil1_pwchcore(x_data, x_size, y_data, b_c_data, pp_breaks_data,
                         pp_breaks_size, b_coefs);
      pp_coefs_size[0] = 1;
      pp_coefs_size[1] = 4;
      pp_coefs_size[2] = 1;
      pp_coefs_data[0] = b_coefs[0];
      pp_coefs_data[1] = b_coefs[1];
      pp_coefs_data[2] = b_coefs[2];
      pp_coefs_data[3] = b_coefs[3];
    } else {
      b_c_data[0] = (y_data[1] - y_data[0]) / (x_data[1] - x_data[0]);
      b_c_data[1] = y_data[0];
      pp_breaks_size[0] = 1;
      pp_breaks_size[1] = x_size[1];
      nx = x_size[1];
      if (0 <= nx - 1) {
        memcpy(&pp_breaks_data[0], &x_data[0], nx * sizeof(real_T));
      }

      pp_coefs_size[0] = 1;
      pp_coefs_size[1] = 1;
      pp_coefs_size[2] = 2;
      for (nx = 0; nx < 2; nx++) {
        pp_coefs_data[nx] = b_c_data[nx];
      }
    }
  } else if ((x_size[1] == 3) && (!has_endslopes)) {
    d31 = x_data[1] - x_data[0];
    dnnm2 = (y_data[1] - y_data[0]) / d31;
    c_data[0] = ((y_data[2] - y_data[1]) / (x_data[2] - x_data[1]) - dnnm2) /
      (x_data[2] - x_data[0]);
    c_data[1] = dnnm2 - c_data[0] * d31;
    c_data[2] = y_data[0];
    pp_breaks_size[0] = 1;
    pp_breaks_size[1] = 2;
    pp_breaks_data[0] = x_data[0];
    pp_breaks_data[1] = x_data[2];
    pp_coefs_size[0] = 1;
    pp_coefs_size[1] = 1;
    pp_coefs_size[2] = 3;
    for (nx = 0; nx < 3; nx++) {
      pp_coefs_data[nx] = c_data[nx];
    }
  } else {
    if (has_endslopes) {
      yoffset = 1;
    } else {
      yoffset = 0;
    }

    for (k = 0; k < nx; k++) {
      dx_data[k] = x_data[k + 1] - x_data[k];
      dvdf_data_tmp = yoffset + k;
      dvdf_data[k] = (y_data[dvdf_data_tmp + 1] - y_data[dvdf_data_tmp]) /
        dx_data[k];
    }

    for (k = 1; k < nx; k++) {
      s_data[k] = (dvdf_data[k - 1] * dx_data[k] + dx_data[k - 1] * dvdf_data[k])
        * 3.0;
    }

    if (has_endslopes) {
      d31 = 0.0;
      dnnm2 = 0.0;
      s_data[0] = dx_data[1] * y_data[0];
      s_data[x_size[1] - 1] = dx_data[x_size[1] - 3] * y_data[x_size[1] + 1];
    } else {
      d31 = x_data[2] - x_data[0];
      dnnm2 = x_data[x_size[1] - 1] - x_data[x_size[1] - 3];
      s_data[0] = ((2.0 * d31 + dx_data[0]) * dx_data[1] * dvdf_data[0] +
                   dx_data[0] * dx_data[0] * dvdf_data[1]) / d31;
      s_data[x_size[1] - 1] = ((dx_data[x_size[1] - 2] + 2.0 * dnnm2) *
        dx_data[x_size[1] - 3] * dvdf_data[x_size[1] - 2] + dx_data[x_size[1] -
        2] * dx_data[x_size[1] - 2] * dvdf_data[x_size[1] - 3]) / dnnm2;
    }

    md_data[0] = dx_data[1];
    md_data[x_size[1] - 1] = dx_data[x_size[1] - 3];
    for (k = 1; k < nx; k++) {
      md_data[k] = (dx_data[k - 1] + dx_data[k]) * 2.0;
    }

    r = dx_data[1] / md_data[0];
    md_data[1] -= r * d31;
    s_data[1] -= r * s_data[0];
    for (k = 2; k < nx; k++) {
      r = dx_data[k] / md_data[k - 1];
      md_data[k] -= dx_data[k - 2] * r;
      s_data[k] -= s_data[k - 1] * r;
    }

    r = dnnm2 / md_data[x_size[1] - 2];
    md_data[x_size[1] - 1] -= dx_data[x_size[1] - 3] * r;
    s_data[x_size[1] - 1] -= s_data[x_size[1] - 2] * r;
    s_data[x_size[1] - 1] /= md_data[x_size[1] - 1];
    for (nx = x_size[1] - 2; nx + 1 > 1; nx--) {
      s_data[nx] = (s_data[nx] - dx_data[nx - 1] * s_data[nx + 1]) / md_data[nx];
    }

    s_data[0] = (s_data[0] - d31 * s_data[1]) / md_data[0];
    pmpc_hil1_pwchcore_n(x_data, x_size, y_data, yoffset, s_data, dx_data,
                         dvdf_data, pp_breaks_data, pp_breaks_size,
                         pmpc_hil1_B.e_coefs_data, e_coefs_size);
    pp_coefs_size[0] = 1;
    pp_coefs_size[1] = e_coefs_size[1];
    pp_coefs_size[2] = 4;
    nx = e_coefs_size[0] * e_coefs_size[1] * e_coefs_size[2] - 1;
    if (0 <= nx) {
      memcpy(&pp_coefs_data[0], &pmpc_hil1_B.e_coefs_data[0], (nx + 1) * sizeof
             (real_T));
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_spline(const real_T x_data[], const int32_T x_size[2],
  const real_T y_data[], const int32_T *y_size, const real_T xx[1500], real_T
  output_data[], int32_T output_size[2])
{
  real_T pp_breaks_data[401];
  int32_T numTerms;
  int32_T ix;
  real_T v;
  real_T xloc;
  int32_T low_i;
  int32_T low_ip1;
  int32_T high_i;
  int32_T mid_i;
  real_T y_data_0[401];
  int32_T pp_breaks_size[2];
  int32_T pp_coefs_size[3];
  int32_T y_size_0[2];
  y_size_0[0] = 1;
  y_size_0[1] = *y_size;
  if (0 <= *y_size - 1) {
    memcpy(&y_data_0[0], &y_data[0], *y_size * sizeof(real_T));
  }

  pmpc_hil1_splinepp(x_data, x_size, y_data_0, y_size_0, pp_breaks_data,
                     pp_breaks_size, pmpc_hil1_B.pp_coefs_data, pp_coefs_size);
  numTerms = pp_coefs_size[2];
  output_size[0] = 1;
  output_size[1] = 1500;
  for (ix = 0; ix < 1500; ix++) {
    if ((numTerms > 1) && rtIsNaN(xx[ix])) {
      v = xx[ix];
    } else {
      low_i = 1;
      low_ip1 = 2;
      high_i = pp_breaks_size[1];
      while (high_i > low_ip1) {
        mid_i = (low_i >> 1) + (high_i >> 1);
        if (((low_i & 1) == 1) && ((high_i & 1) == 1)) {
          mid_i++;
        }

        if (xx[ix] >= pp_breaks_data[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }

      xloc = xx[ix] - pp_breaks_data[low_i - 1];
      v = pmpc_hil1_B.pp_coefs_data[low_i - 1];
      for (low_ip1 = 2; low_ip1 <= numTerms; low_ip1++) {
        v = pmpc_hil1_B.pp_coefs_data[((low_ip1 - 1) * (pp_breaks_size[1] - 1) +
          low_i) - 1] + xloc * v;
      }
    }

    output_data[ix] = v;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_power_b(const real_T a_data[], real_T y_data[], int32_T
  y_size[2])
{
  int32_T k;
  y_size[0] = 1;
  y_size[1] = 1500;
  for (k = 0; k < 1500; k++) {
    y_data[k] = a_data[k] * a_data[k];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_sqrt_f(real_T x_data[])
{
  int32_T k;
  for (k = 0; k < 1500; k++) {
    x_data[k] = std::sqrt(x_data[k]);
  }
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2((real_T)u0_0, (real_T)u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_local_wrapToPi(real_T *ang)
{
  real_T r;
  boolean_T rEQ0;
  real_T q;
  if ((*ang < -3.1415926535897931) || (*ang > 3.1415926535897931)) {
    if ((!rtIsInf(*ang + 3.1415926535897931)) && (!rtIsNaN(*ang +
          3.1415926535897931))) {
      if (*ang + 3.1415926535897931 == 0.0) {
        r = 0.0;
      } else {
        r = std::fmod(*ang + 3.1415926535897931, 6.2831853071795862);
        rEQ0 = (r == 0.0);
        if (!rEQ0) {
          q = std::abs((*ang + 3.1415926535897931) / 6.2831853071795862);
          rEQ0 = (std::abs(q - std::floor(q + 0.5)) <= 2.2204460492503131E-16 *
                  q);
        }

        if (rEQ0) {
          r = 0.0;
        } else {
          if (*ang + 3.1415926535897931 < 0.0) {
            r += 6.2831853071795862;
          }
        }
      }
    } else {
      r = (rtNaN);
    }

    *ang = r - 3.1415926535897931;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_error(real_T PosX, real_T PosY, real_T PosPsi, real_T
  *PPx, real_T *PPy, real_T *Psi0, real_T *e_y, real_T *e_psi)
{
  real_T dists[401];
  int32_T start_idx;
  int32_T end_idx;
  real_T dx;
  real_T dy;
  int32_T d;
  int32_T e;
  int32_T idx;
  int32_T k;
  real_T y_data[401];
  static const real_T Y_ref[401] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.3228606001226904E-7, 1.5271629291310949E-7,
    1.7630176656541295E-7, 2.0352977621994352E-7, 2.3496287366879493E-7,
    2.7125049194906196E-7, 3.1314236225907128E-7, 3.6150400362628236E-7,
    4.1733460614040918E-7, 4.8178767377534458E-7, 5.561948581707241E-7,
    6.4209346982518171E-7, 7.4125824120433318E-7, 8.5573799424889194E-7,
    9.8789796920547181E-7, 1.140468692920799E-6, 1.3166023936577437E-6,
    1.5199381278254111E-6, 1.7546769648556593E-6, 2.0256687841481708E-6,
    2.3385124766914839E-6, 2.6996716205580254E-6, 3.116608022258982E-6,
    3.5979358799941754E-6, 4.1535997577823537E-6, 4.79508004235572E-6,
    5.5356301311798057E-6, 6.390550249878671E-6, 7.3775035566370906E-6,
    8.5168810611976928E-6, 9.8322229012238221E-6, 1.1350704672345736E-5,
    1.3103698864311212E-5, 1.5127422993592607E-5, 1.746368782508337E-5,
    2.0160761131290458E-5, 2.3274364834152897E-5, 2.6868826115450469E-5,
    3.1018406271344034E-5, 3.5808834747812024E-5, 4.1339080029868432E-5,
    4.772339394309252E-5, 5.509367156659372E-5, 6.3602175461844143E-5,
    7.342468043635046E-5, 8.4764103718956875E-5, 9.7854695432163721E-5,
    0.00011296687577283843, 0.00013041281862655643, 0.00015055289668852958,
    0.00017380312086351206, 0.00020064372713956953, 0.00023162908765955831,
    0.00026739914984866839, 0.00030869263872514445, 0.0003563622935440203,
    0.00041139245141427289, 0.00047491933830792125, 0.00054825448285420624,
    0.00063291173156181048, 0.000730638416821457, 0.00084345131258324591,
    0.00097367810850778182, 0.0011240052433987909, 0.0012975330647785877,
    0.00149783942571698, 0.0017290529948972881, 0.0019959377439802456,
    0.0023039902905212296, 0.00265955201799473, 0.0030699381701609035,
    0.0035435864282808904, 0.0040902278298454234, 0.004721083279474729,
    0.0054490893389877127, 0.006289157465936503, 0.0072584713983140934,
    0.0083768279557369964, 0.0096670271390256954, 0.01115531805116869,
    0.012871907817273587, 0.014851541324794873, 0.017134160201938906,
    0.019765649949941424, 0.022798684471626283, 0.026293677295168155,
    0.030319848444790562, 0.034956414982043618, 0.040293911500841349,
    0.046435644008828242, 0.053499276290428978, 0.061618541556274553,
    0.070945063373987621, 0.081650257880923907, 0.093927273346502957,
    0.10799290247180471, 0.12408937659183612, 0.14248591851662218,
    0.16347989176389607, 0.18739733864609442, 0.21459264930552066,
    0.24544705105479983, 0.28036555707133648, 0.31977197313779249,
    0.364101541516229, 0.41379081650033378, 0.46926443409597079,
    0.53091857757266758, 0.59910116870045216, 0.67408914220472838,
    0.75606358590855915, 0.84508402777789693, 0.94106367260887425,
    1.0437478542281236, 1.152698267808127, 1.2672855664497911, 1.386692550104242,
    1.5099293988290852, 1.6358612447688898, 1.7632469742208312,
    1.8907867239725917, 2.0171743481008004, 2.141150423020056,
    2.2615512806530367, 2.3773501290570072, 2.4876874145399421,
    2.5918889742839446, 2.6894719595336092, 2.7801397404339707, 2.86376787623742,
    2.9403836879220884, 3.0101420315886145, 3.0732996276642957,
    3.1301898662115186, 3.1811994924544709, 3.22674806684294, 3.2672706486739411,
    3.3032038008828937, 3.3349747627571094, 3.3629934786062479,
    3.3876470874666542, 3.4092964527998375, 3.4282743239300775,
    3.4448847575490911, 3.4594034763753356, 3.4720788947412626,
    3.4831335921141484, 3.4927660621914525, 3.50115260572328, 3.5084492691636369,
    3.5147937588748897, 3.5203072825159367, 3.5250962862113533,
    3.5292540689388883, 3.5328622650568198, 3.5359921927084685,
    3.5387060705777156, 3.541058108615752, 3.5430954803117021,
    3.5448591851528475, 3.5463848103592541, 3.5477032009708043,
    3.548841047054017, 3.5498213962870269, 3.5506640995503886,
    3.5513861964537004, 3.5520022470010928, 3.5525246148674063, 3.55296370703674,
    3.553328173854172, 3.5536250728628311, 3.5538599991408883,
    3.5540371842126115, 3.5541595649779056, 3.5542288234777777,
    3.5542453976792991, 3.5542084628121189, 3.5541158821073435,
    3.553964125065677, 3.553748150600847, 3.5534612515515289, 3.5530948561141957,
    3.5526382807041186, 3.5520784275853732, 3.5513994193073737,
    3.5505821605308756, 3.5496038162104333, 3.5484371933189753,
    3.5470500113603998, 3.5454040448409, 3.5434541187067574, 3.5411469355890413,
    3.538419711658698, 3.535198596195853, 3.5313968489215251, 3.5269127491710148,
    3.5216272127300763, 3.5154010964693447, 3.5080721789643632,
    3.4994518186185974, 3.489321311401222, 3.4774280006537852,
    3.4634812344942749, 3.4471483255459661, 3.4280507465788395,
    3.4057608973159459, 3.3797999039187929, 3.3496370624372682,
    3.3146917045699169, 3.2743384340504447, 3.2279168287103555,
    3.1747467853084879, 3.1141506426936405, 3.0454829791593863,
    2.9681684602932457, 2.8817472447127424, 2.78592621123113, 2.6806327124134075,
    2.5660658738325131, 2.4427389819173739, 2.3115056946660459, 2.17356315317282,
    2.0304269132940358, 1.8838759711657593, 1.7358705759284698,
    1.5884501158739357, 1.443622010613038, 1.303254257391997, 1.1689835776965221,
    1.0421481915905177, 0.92374992107985765, 0.81444570047299925,
    0.71456467815091829, 0.62414458194355849, 0.54298006294306989,
    0.47067610366042256, 0.40670082776471128, 0.35043369434960869,
    0.30120670417124717, 0.2583376377900648, 0.22115537575118172,
    0.18901801318386457, 0.16132483080372051, 0.13752330079159591,
    0.11711226863730095, 0.09964232691595365, 0.084714232917115329,
    0.071976051379076811, 0.061119545247536156, 0.051876200679212836,
    0.044013160409407615, 0.037329251311114753, 0.031651224780145704,
    0.0268302790307291, 0.022738896979264123, 0.019268008952027849,
    0.016324473273849893, 0.013828857684227369, 0.011713498761338315,
    0.0099208137960427045, 0.0084018388636981634, 0.0071149674728929746,
    0.0060248656124159972, 0.0051015409103514209, 0.004319545715834483,
    0.0036572960512288866, 0.0030964904563615114, 0.002621614694719554,
    0.0022195200806733872, 0.0018790648028117474, 0.001590809059771825,
    0.001346756098124402, 0.0011401323577757694, 0.00096520090263307878,
    0.00081710315714467185, 0.00069172469709810613, 0.00058558146942599976,
    0.000495723353387767, 0.00041965243585950773, 0.00035525376704947931,
    0.0003007366987950455, 0.00025458519391641232, 0.000215515738849259,
    0.00018244169914316544, 0.00015444313365220452, 0.00013074123300649276,
    0.00011067667502784317, 9.3691297683662356E-5, 7.93125816191953E-5,
    6.71405119914148E-5, 5.6836455041509026E-5, 4.8113740677813155E-5,
    4.0729689549490189E-5, 3.4478863159659312E-5, 2.9187349482207026E-5,
    2.4707925277311915E-5, 2.0915960641243458E-5, 1.7705951944169129E-5,
    1.4988586751307764E-5, 1.2688259121595991E-5, 1.0740966181810307E-5,
    9.09252747849365E-6, 7.6970775797491342E-6, 6.5157900039913841E-6,
    5.5157969667263274E-6, 4.66927491737934E-6, 3.9526704065373508E-6,
    3.3460447537159155E-6, 2.83251929333872E-6, 2.3978057539508768E-6,
    2.029808704673286E-6, 1.7182890239553217E-6, 1.4545790043563045E-6,
    1.2313411921205386E-6, 1.0423642233803321E-6, 8.8239000728407291E-7,
    7.4696742435875763E-7, 6.3232847669070225E-7, 5.3528344956532692E-7,
    4.5313216201492423E-7, 3.83588836250226E-7, 3.2471849698012534E-7,
    2.7488313492085581E-7, 2.3269612992038446E-7, 1.9698366982012772E-7,
    1.6675209035810212E-7, 1.4116022706289755E-7, 1.1949601130822884E-7,
    1.0115665682874919E-7, 8.56318886910401E-8, 7.2489746649750941E-8,
    6.1364562320420646E-8, 5.194678731612612E-8, 4.3974382357703234E-8,
    3.7225522220296625E-8, 3.1512426890145662E-8, 2.6676134634584514E-8,
    2.2582080649868885E-8, 1.9116351168690926E-8, 1.6182516215934584E-8,
    1.3698944645312849E-8, 1.1596532178970165E-8, 9.81678294209587E-9,
    8.3101761028103738E-9, 7.0347918601498804E-9, 5.9551443776229007E-9,
    5.0411927965399173E-9, 4.2675085687449155E-9, 3.6125626934335742E-9,
    3.0581333021473256E-9, 2.5887940680036081E-9, 2.1914847714299412E-9,
    1.8551524760823668E-9, 1.5704371136848749E-9, 1.32941790909058E-9,
    1.1253886711415362E-9, 9.5267260746823013E-10, 8.0646334055245461E-10,
    6.8269301323198306E-10, 5.7791860186284794E-10 };

  static const real_T psi_ref[401] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 3.8127329605604831E-8, 4.4015706553143889E-8,
    5.0813483306833984E-8, 5.8661107103381909E-8, 6.7720715729118338E-8,
    7.8179488590276189E-8, 9.0253511677220148E-8, 1.0419224388133754E-7,
    1.2028367014906164E-7, 1.3886025203031401E-7, 1.6030579604983575E-7,
    1.8506338303360697E-7, 2.1364452442370698E-7, 2.4663972800113366E-7,
    2.8473069867189938E-7, 3.2870442445226E-7, 3.7946943490459393E-7,
    4.3807457119788766E-7, 5.057306563227166E-7, 5.8383551183575818E-7,
    6.7400283640975255E-7, 7.7809554556734113E-7, 8.9826425943590834E-7,
    1.036991735523E-6, 1.1971441623609729E-6, 1.3820303733965722E-6,
    1.595470207521597E-6, 1.841873425455202E-6, 2.126330811315817E-6,
    2.4547193445818009E-6, 2.833823611140458E-6, 3.2714759630757193E-6,
    3.7767183212289141E-6, 4.3599889607445313E-6, 5.0333381376553446E-6,
    5.8106770090041293E-6, 6.708064984059395E-6, 7.7440414370363336E-6,
    8.9400086321233813E-6, 1.0320673758157958E-5, 1.1914559194716712E-5,
    1.3754591535857883E-5, 1.5878781517417088E-5, 1.8331008867703509E-5,
    2.1161928253953771E-5, 2.4430014990953108E-5, 2.8202772046404097E-5,
    3.25581231828885E-5, 3.7586020897991781E-5, 4.3390302209725055E-5,
    5.0090830409145787E-5, 5.7825966731592614E-5, 6.6755422609938439E-5,
    7.7063550913031371E-5, 8.896314346065405E-5, 0.00010269981232806152,
    0.00011855704420843067, 0.00013686203058540264, 0.00015799239193930846,
    0.0001823839319449839, 0.00021053957791057881, 0.00024303968690101181,
    0.00028055392345469786, 0.00032385494494861788, 0.00037383416490349957,
    0.00043151990333434038, 0.00049809827707021951, 0.00057493723227489179,
    0.00066361417659949531, 0.00076594772985194115, 0.00088403417999034231,
    0.0010202893056472935, 0.0011774963069949541, 0.001358860672761873,
    0.0015680729012404542, 0.0018093800847736703, 0.0020876674568629538,
    0.002408551083270856, 0.0027784829454769551, 0.0032048697055944357,
    0.0036962064410814561, 0.0042622265744576586, 0.0049140690696619516,
    0.0056644636853015037, 0.0065279346166624043, 0.0075210221591415181,
    0.0086625210039536545, 0.009973732329430985, 0.011478724850315418,
    0.013204597278749019, 0.015181731053022235, 0.017444017499689175,
    0.020029037596229583, 0.022978164991310269, 0.026336553766303544,
    0.030152961552156816, 0.034479346237802064, 0.039370161176602941,
    0.044881260642105729, 0.05106831625167689, 0.057984639217846266,
    0.065678307008683823, 0.074188512167323639, 0.0835410927499672,
    0.093743275562056111, 0.10477777117836799, 0.11659650538212821,
    0.12911444863283733, 0.14220419445692059, 0.15569210497574665,
    0.1693569389056, 0.18293185006604534, 0.19611044808000058,
    0.20855723266611959, 0.21992218068627953, 0.22985866351820866,
    0.23804331812078425, 0.24419610519575669, 0.24809864141977558,
    0.2496090088537638, 0.2486715856254, 0.24532093880867745,
    0.23967940257479103, 0.23194857588587961, 0.2223955674648477,
    0.21133533854290129, 0.199110878148821, 0.18607311968603227,
    0.17256242339874944, 0.1588931114452555, 0.14534201697695839,
    0.13214140702048313, 0.11947608133398305, 0.10748402863622686,
    0.096259781895378635, 0.085859550628008763, 0.076307280891628762,
    0.06760094923515822, 0.059718584656673276, 0.05262369472884415,
    0.046269926037155219, 0.040604905843282461, 0.035573291634873536,
    0.031119103320675651, 0.027187436618987731, 0.023725662954969345,
    0.020684217121935543, 0.018017063822038132, 0.015681921332465109,
    0.013640307125989249, 0.011857457604295098, 0.010302162849151567,
    0.0089465477192804677, 0.007765822727947895, 0.00673802179689239,
    0.00584373900014998, 0.0050658725715663835, 0.0043893815441801744,
    0.00380105823103792, 0.0032893181844495544, 0.0028440081501235337,
    0.0024562317552079909, 0.0021181921482925229, 0.0018230504767249062,
    0.0015647988894856946, 0.0013381466519921848, 0.00113841792191095,
    0.00096145973938766948, 0.00080355881381115183, 0.0006613657296630597,
    0.00053182523657620967, 0.00041211132644995111, 0.00029956582805630908,
    0.00019163926282016522, 8.583270118272301E-5, -2.0360665655989352E-5,
    -0.00012951557123144151, -0.00024433774157943909, -0.00036773148992081826,
    -0.00050287347175895258, -0.00065329439371067106, -0.00082297066161624087,
    -0.0010164281787895353, -0.0012388607629532542, -0.0014962659378773111,
    -0.0017956011671553076, -0.0021449639223273353, -0.00255379929815229,
    -0.0030331391764818892, -0.0035958771549330936, -0.004257083534970816,
    -0.0050343645159305842, -0.00594826923849253, -0.0070227472833190585,
    -0.0082856574103190948, -0.00976932538569526, -0.011511144241132441,
    -0.013554203661377651, -0.015947925667538467, -0.018748670455975929,
    -0.022020258127058011, -0.0258343279876838, -0.030270426133853837,
    -0.035415673544746194, -0.041363821380219025, -0.048213449912573571,
    -0.056065018126080904, -0.065016433068377066, -0.075156799086466136,
    -0.086558053168171945, -0.099264327989743328, -0.11327914705017858,
    -0.12855097708836083, -0.14495824450278594, -0.16229561129332382,
    -0.18026396622604754, -0.19846699546808208, -0.21641708607699486,
    -0.23355247510670996, -0.24926596995453137, -0.26294350370728348,
    -0.27400877627984016, -0.28196884697643837, -0.28645515648729092,
    -0.28725506641943954, -0.28433030308321583, -0.27782029274717707,
    -0.26803003380303991, -0.25540380934732659, -0.24048768644581273,
    -0.22388521876794754, -0.20621172257578879, -0.18805255735654774,
    -0.16992985894917317, -0.152280364289366, -0.13544485265657949,
    -0.11966788733046993, -0.10510536780129602, -0.0918369971047741,
    -0.079880987511316823, -0.069208911837554676, -0.059759306209623109,
    -0.051449268403779939, -0.04418378772873835, -0.037862870129332586,
    -0.03238670750750524, -0.027659219977503573, -0.023590310670938575,
    -0.020097144549129423, -0.017104716526348287, -0.014545923386927961,
    -0.012361305980490076, -0.010498586544191784, -0.00891209184462165,
    -0.0075621259267933342, -0.0064143357341251732, -0.0054390976308043553,
    -0.0046109418348199531, -0.0039080239927669208, -0.0033116477912943547,
    -0.0028058389599202355, -0.0023769687746629294, -0.0020134238418139027,
    -0.0017053182434950684, -0.0014442438549676785, -0.0012230546496320063,
    -0.0010356809862065793, -0.00087697015086896774, -0.00074254975543204733,
    -0.00062871093806313172, -0.00053230865441034308, -0.00045067667148382097,
    -0.0003815551769751676, -0.00032302918939529579, -0.00027347619871728089,
    -0.00023152168358197455, -0.00019600134120044229, -0.00016592903204368142,
    -0.00014046958541438621, -0.00011891573650393497, -0.00010066857279300312,
    -8.5220959739477561E-5, -7.214349464808553E-5, -6.1072605121123661E-5,
    -5.1700466090608623E-5, -4.3766458596416424E-5, -3.7049935305877619E-5,
    -3.136409339836352E-5, -2.6550785686008618E-5, -2.2476126573901472E-5,
    -1.9026771311305631E-5, -1.610676549062599E-5, -1.363487751730889E-5,
    -1.1542340066770585E-5, -9.77093788203645E-6, -8.2713888407749363E-6,
    -7.0019733330283559E-6, -5.9273738898662774E-6, -5.0176928225310285E-6,
    -4.247620569471911E-6, -3.5957316430868432E-6, -3.0438886020517725E-6,
    -2.5767374744965638E-6, -2.1812806130193471E-6, -1.8465150866099452E-6,
    -1.5631265601877035E-6, -1.3232301636626524E-6, -1.1201511131981624E-6,
    -9.4823899976475449E-7, -8.0271058866526162E-7, -6.7951672999545052E-7,
    -5.7522970031691809E-7, -4.8694783183474453E-7, -4.1221478097594907E-7,
    -3.4895118483645151E-7, -2.9539679902156588E-7, -2.5006153059336547E-7,
    -2.1168397479342756E-7, -1.7919631467577611E-7, -1.5169461331509976E-7,
    -1.2841366503479818E-7, -1.0870570132936976E-7, -9.2022367059740608E-8,
    -7.7899465100727935E-8, -6.5944039562282249E-8, -5.5823442757230109E-8,
    -4.7256079049873245E-8, -4.0003570234148336E-8, -3.3864122617188728E-8,
    -2.8666910178998244E-8, -2.4267326370619454E-8, -2.0542959333624818E-8,
    -1.7390179962717408E-8, -1.4721265095829493E-8, -1.2461955467557573E-8,
    -1.0549387585712111E-8, -8.9303462402767764E-9, -7.5597834658935881E-9,
    -6.3995644339343016E-9, -5.4174065233780766E-9, -4.5859840369644189E-9,
    -3.88216170321698E-9, -3.286356076159791E-9, -2.7819910819459892E-9,
    -2.3550317251874731E-9, -1.9935990636099632E-9, -1.6876358088779853E-9,
    -1.4286301031063431E-9, -1.2093752665975899E-9, -1.0237686254299661E-9,
    -8.6664853071738435E-10, -7.3364159192124134E-10, -6.2104765774506632E-10,
    -5.2573456699178678E-10, -4.4504844254333875E-10, -3.7674530162234987E-10,
    -3.1892533058908157E-10, -2.6997959423624707E-10, -2.2854473868960667E-10,
    -2.0954882273827025E-10 };

  real_T tmp_data[401];
  int32_T i;
  int32_T loop_ub;
  int32_T X_interp_size[2];
  int32_T y_size[2];
  int32_T loop_ub_0;
  boolean_T exitg1;
  for (end_idx = 0; end_idx < 401; end_idx++) {
    y_data[end_idx] = 0.5 * (real_T)end_idx - PosX;
  }

  pmpc_hil1_power(y_data, tmp_data);
  for (end_idx = 0; end_idx < 401; end_idx++) {
    dists[end_idx] = Y_ref[end_idx] - PosY;
  }

  pmpc_hil1_power(dists, y_data);
  for (end_idx = 0; end_idx < 401; end_idx++) {
    dists[end_idx] = tmp_data[end_idx] + y_data[end_idx];
  }

  pmpc_hil1_sqrt(dists);
  if (!rtIsNaN(dists[0])) {
    idx = 1;
  } else {
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 402)) {
      if (!rtIsNaN(dists[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    idx = 1;
  } else {
    dx = dists[idx - 1];
    for (k = idx; k + 1 < 402; k++) {
      if (dx > dists[k]) {
        dx = dists[k];
        idx = k + 1;
      }
    }
  }

  if (1.0 > (real_T)idx - 7.0) {
    dx = 1.0;
    start_idx = 1;
  } else {
    dx = (real_T)idx - 7.0;
    start_idx = (int32_T)((real_T)idx - 7.0);
  }

  if (401.0 < (real_T)start_idx + 15.0) {
    dy = 401.0;
  } else {
    dy = (real_T)start_idx + 15.0;
  }

  if (401.0 < (real_T)(int32_T)dx + 15.0) {
    end_idx = 401;
  } else {
    end_idx = (int32_T)((real_T)(int32_T)dx + 15.0);
  }

  if ((int32_T)dy - (int32_T)dx < 5) {
    start_idx = (int32_T)dy - 5;
  }

  if (start_idx > (int32_T)dy) {
    start_idx = 1;
    end_idx = 0;
    e = 0;
    d = 0;
    idx = 0;
    k = 0;
  } else {
    e = start_idx - 1;
    d = (int32_T)dy;
    idx = start_idx - 1;
    k = (int32_T)dy;
  }

  pmpc_hil1_linspace((real_T)(end_idx - start_idx) + 1.0, pmpc_hil1_B.interp_idx);
  loop_ub_0 = end_idx - start_idx;
  end_idx = loop_ub_0 + 1;
  if (end_idx < 1) {
    y_size[0] = 1;
    y_size[1] = 0;
  } else {
    y_size[0] = 1;
    y_size[1] = end_idx;
    loop_ub = end_idx - 1;
    for (i = 0; i <= loop_ub; i++) {
      y_data[i] = 1.0 + (real_T)i;
    }
  }

  loop_ub = end_idx;
  for (end_idx = 0; end_idx <= loop_ub_0; end_idx++) {
    tmp_data[end_idx] = ((real_T)(start_idx + end_idx) - 1.0) * 0.5;
  }

  pmpc_hil1_spline(y_data, y_size, tmp_data, &loop_ub, pmpc_hil1_B.interp_idx,
                   pmpc_hil1_B.X_interp_data, X_interp_size);
  loop_ub_0 = d - e;
  if (loop_ub_0 < 1) {
    y_size[0] = 1;
    y_size[1] = 0;
  } else {
    y_size[0] = 1;
    y_size[1] = loop_ub_0;
    loop_ub = loop_ub_0 - 1;
    for (end_idx = 0; end_idx <= loop_ub; end_idx++) {
      y_data[end_idx] = 1.0 + (real_T)end_idx;
    }
  }

  for (end_idx = 0; end_idx < loop_ub_0; end_idx++) {
    tmp_data[end_idx] = Y_ref[e + end_idx];
  }

  pmpc_hil1_spline(y_data, y_size, tmp_data, &loop_ub_0, pmpc_hil1_B.interp_idx,
                   pmpc_hil1_B.Y_interp_data, X_interp_size);
  loop_ub_0 = k - idx;
  if (loop_ub_0 < 1) {
    y_size[0] = 1;
    y_size[1] = 0;
  } else {
    y_size[0] = 1;
    y_size[1] = loop_ub_0;
    loop_ub = loop_ub_0 - 1;
    for (end_idx = 0; end_idx <= loop_ub; end_idx++) {
      y_data[end_idx] = 1.0 + (real_T)end_idx;
    }
  }

  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.X_interp_data_m[end_idx] = pmpc_hil1_B.X_interp_data[end_idx] -
      PosX;
  }

  pmpc_hil1_power_b(pmpc_hil1_B.X_interp_data_m, pmpc_hil1_B.tmp_data,
                    X_interp_size);
  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.Y_interp_data_c[end_idx] = pmpc_hil1_B.Y_interp_data[end_idx] -
      PosY;
  }

  pmpc_hil1_power_b(pmpc_hil1_B.Y_interp_data_c, pmpc_hil1_B.X_interp_data_m,
                    X_interp_size);
  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.interp_dists_data[end_idx] = pmpc_hil1_B.tmp_data[end_idx] +
      pmpc_hil1_B.X_interp_data_m[end_idx];
  }

  pmpc_hil1_sqrt_f(pmpc_hil1_B.interp_dists_data);
  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.X_interp_data_m[end_idx] = pmpc_hil1_B.X_interp_data[end_idx] -
      PosX;
  }

  pmpc_hil1_power_b(pmpc_hil1_B.X_interp_data_m, pmpc_hil1_B.tmp_data,
                    X_interp_size);
  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.Y_interp_data_c[end_idx] = pmpc_hil1_B.Y_interp_data[end_idx] -
      PosY;
  }

  pmpc_hil1_power_b(pmpc_hil1_B.Y_interp_data_c, pmpc_hil1_B.X_interp_data_m,
                    X_interp_size);
  for (end_idx = 0; end_idx < 1500; end_idx++) {
    pmpc_hil1_B.Y_interp_data_c[end_idx] = pmpc_hil1_B.tmp_data[end_idx] +
      pmpc_hil1_B.X_interp_data_m[end_idx];
  }

  pmpc_hil1_sqrt_f(pmpc_hil1_B.Y_interp_data_c);
  if (!rtIsNaN(pmpc_hil1_B.Y_interp_data_c[0])) {
    start_idx = 0;
  } else {
    start_idx = -1;
    end_idx = 2;
    exitg1 = false;
    while ((!exitg1) && (end_idx <= 1500)) {
      if (!rtIsNaN(pmpc_hil1_B.Y_interp_data_c[end_idx - 1])) {
        start_idx = end_idx - 1;
        exitg1 = true;
      } else {
        end_idx++;
      }
    }
  }

  if (start_idx + 1 == 0) {
    start_idx = 0;
  } else {
    dx = pmpc_hil1_B.interp_dists_data[start_idx];
    for (end_idx = start_idx + 1; end_idx < 1500; end_idx++) {
      if (dx > pmpc_hil1_B.interp_dists_data[end_idx]) {
        dx = pmpc_hil1_B.interp_dists_data[end_idx];
        start_idx = end_idx;
      }
    }
  }

  *PPx = pmpc_hil1_B.X_interp_data[start_idx];
  *PPy = pmpc_hil1_B.Y_interp_data[start_idx];
  dx = pmpc_hil1_B.X_interp_data[start_idx] - PosX;
  dy = pmpc_hil1_B.Y_interp_data[start_idx] - PosY;
  *Psi0 = rt_atan2d_snf(dy, dx);
  *e_y = -dx * std::sin(PosPsi) + dy * std::cos(PosPsi);
  for (end_idx = 0; end_idx < loop_ub_0; end_idx++) {
    tmp_data[end_idx] = psi_ref[idx + end_idx];
  }

  pmpc_hil1_spline(y_data, y_size, tmp_data, &loop_ub_0, pmpc_hil1_B.interp_idx,
                   pmpc_hil1_B.tmp_data, X_interp_size);
  *e_psi = pmpc_hil1_B.tmp_data[start_idx] - PosPsi;
  pmpc_hil1_local_wrapToPi(e_psi);
}

static void pmpc_hil1_emxInit_real_T(emxArray_real_T_pmpc_hil1_T **pEmxArray,
  int32_T numDimensions)
{
  emxArray_real_T_pmpc_hil1_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_real_T_pmpc_hil1_T *)malloc(sizeof
    (emxArray_real_T_pmpc_hil1_T));
  emxArray = *pEmxArray;
  emxArray->data = (real_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void pmpc_h_emxEnsureCapacity_real_T(emxArray_real_T_pmpc_hil1_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(real_T));
    if (emxArray->data != NULL) {
      memcpy(newData, (void *)emxArray->data, sizeof(real_T) * oldNumel);
      if (emxArray->canFreeData) {
        free((void *)emxArray->data);
      }
    }

    emxArray->data = (real_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

static void pmpc_hil1_emxFree_real_T(emxArray_real_T_pmpc_hil1_T **pEmxArray)
{
  if (*pEmxArray != (emxArray_real_T_pmpc_hil1_T *)NULL) {
    if (((*pEmxArray)->data != (real_T *)NULL) && (*pEmxArray)->canFreeData) {
      free((void *)(*pEmxArray)->data);
    }

    free((void *)(*pEmxArray)->size);
    free((void *)*pEmxArray);
    *pEmxArray = (emxArray_real_T_pmpc_hil1_T *)NULL;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_linspace_k(real_T n1, emxArray_real_T_pmpc_hil1_T *y)
{
  real_T delta1;
  int32_T b;
  int32_T k;
  b = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int32_T)std::floor(n1);
  pmpc_h_emxEnsureCapacity_real_T(y, b);
  if (y->size[1] >= 1) {
    y->data[y->size[1] - 1] = 1.0;
    if (y->size[1] >= 2) {
      y->data[0] = 0.0;
      if (y->size[1] >= 3) {
        delta1 = 1.0 / ((real_T)y->size[1] - 1.0);
        b = y->size[1];
        for (k = 0; k <= b - 3; k++) {
          y->data[k + 1] = (1.0 + (real_T)k) * delta1;
        }
      }
    }
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  real_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    tmp = std::abs(u0);
    tmp_0 = std::abs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_func_RefTraj_LocalPlanning(real_T WayPoints_Index, const
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured, real_T *WPIndex, real_T
  RefU[36], real_T Bezier_K[12], real_T *PrjP_ey, real_T *PrjP_epsi, real_T
  *PrjP_Velr, real_T *PrjP_xr, real_T *PrjP_yr, real_T *PrjP_psir)
{
  real_T Vel;
  real_T PosX;
  real_T PosY;
  real_T PosPsi;
  real_T Dist_MIN;
  real_T tempDx;
  real_T tempDy;
  emxArray_real_T_pmpc_hil1_T *Local_x;
  emxArray_real_T_pmpc_hil1_T *Local_y;
  real_T deltax;
  real_T deltay;
  emxArray_real_T_pmpc_hil1_T *Mat_Local;
  real_T Scale[12];
  real_T ps0[2];
  real_T ps1[2];
  real_T ps3[2];
  int32_T ibcol;
  emxArray_real_T_pmpc_hil1_T *t;
  real_T C2[2];
  static const real_T WayPoints_Collect[3609] = { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0,
    7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0,
    20.0, 21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 27.0, 28.0, 29.0, 30.0, 31.0, 32.0,
    33.0, 34.0, 35.0, 36.0, 37.0, 38.0, 39.0, 40.0, 41.0, 42.0, 43.0, 44.0, 45.0,
    46.0, 47.0, 48.0, 49.0, 50.0, 51.0, 52.0, 53.0, 54.0, 55.0, 56.0, 57.0, 58.0,
    59.0, 60.0, 61.0, 62.0, 63.0, 64.0, 65.0, 66.0, 67.0, 68.0, 69.0, 70.0, 71.0,
    72.0, 73.0, 74.0, 75.0, 76.0, 77.0, 78.0, 79.0, 80.0, 81.0, 82.0, 83.0, 84.0,
    85.0, 86.0, 87.0, 88.0, 89.0, 90.0, 91.0, 92.0, 93.0, 94.0, 95.0, 96.0, 97.0,
    98.0, 99.0, 100.0, 101.0, 102.0, 103.0, 104.0, 105.0, 106.0, 107.0, 108.0,
    109.0, 110.0, 111.0, 112.0, 113.0, 114.0, 115.0, 116.0, 117.0, 118.0, 119.0,
    120.0, 121.0, 122.0, 123.0, 124.0, 125.0, 126.0, 127.0, 128.0, 129.0, 130.0,
    131.0, 132.0, 133.0, 134.0, 135.0, 136.0, 137.0, 138.0, 139.0, 140.0, 141.0,
    142.0, 143.0, 144.0, 145.0, 146.0, 147.0, 148.0, 149.0, 150.0, 151.0, 152.0,
    153.0, 154.0, 155.0, 156.0, 157.0, 158.0, 159.0, 160.0, 161.0, 162.0, 163.0,
    164.0, 165.0, 166.0, 167.0, 168.0, 169.0, 170.0, 171.0, 172.0, 173.0, 174.0,
    175.0, 176.0, 177.0, 178.0, 179.0, 180.0, 181.0, 182.0, 183.0, 184.0, 185.0,
    186.0, 187.0, 188.0, 189.0, 190.0, 191.0, 192.0, 193.0, 194.0, 195.0, 196.0,
    197.0, 198.0, 199.0, 200.0, 201.0, 202.0, 203.0, 204.0, 205.0, 206.0, 207.0,
    208.0, 209.0, 210.0, 211.0, 212.0, 213.0, 214.0, 215.0, 216.0, 217.0, 218.0,
    219.0, 220.0, 221.0, 222.0, 223.0, 224.0, 225.0, 226.0, 227.0, 228.0, 229.0,
    230.0, 231.0, 232.0, 233.0, 234.0, 235.0, 236.0, 237.0, 238.0, 239.0, 240.0,
    241.0, 242.0, 243.0, 244.0, 245.0, 246.0, 247.0, 248.0, 249.0, 250.0, 251.0,
    252.0, 253.0, 254.0, 255.0, 256.0, 257.0, 258.0, 259.0, 260.0, 261.0, 262.0,
    263.0, 264.0, 265.0, 266.0, 267.0, 268.0, 269.0, 270.0, 271.0, 272.0, 273.0,
    274.0, 275.0, 276.0, 277.0, 278.0, 279.0, 280.0, 281.0, 282.0, 283.0, 284.0,
    285.0, 286.0, 287.0, 288.0, 289.0, 290.0, 291.0, 292.0, 293.0, 294.0, 295.0,
    296.0, 297.0, 298.0, 299.0, 300.0, 301.0, 302.0, 303.0, 304.0, 305.0, 306.0,
    307.0, 308.0, 309.0, 310.0, 311.0, 312.0, 313.0, 314.0, 315.0, 316.0, 317.0,
    318.0, 319.0, 320.0, 321.0, 322.0, 323.0, 324.0, 325.0, 326.0, 327.0, 328.0,
    329.0, 330.0, 331.0, 332.0, 333.0, 334.0, 335.0, 336.0, 337.0, 338.0, 339.0,
    340.0, 341.0, 342.0, 343.0, 344.0, 345.0, 346.0, 347.0, 348.0, 349.0, 350.0,
    351.0, 352.0, 353.0, 354.0, 355.0, 356.0, 357.0, 358.0, 359.0, 360.0, 361.0,
    362.0, 363.0, 364.0, 365.0, 366.0, 367.0, 368.0, 369.0, 370.0, 371.0, 372.0,
    373.0, 374.0, 375.0, 376.0, 377.0, 378.0, 379.0, 380.0, 381.0, 382.0, 383.0,
    384.0, 385.0, 386.0, 387.0, 388.0, 389.0, 390.0, 391.0, 392.0, 393.0, 394.0,
    395.0, 396.0, 397.0, 398.0, 399.0, 400.0, 401.0, 0.0, 0.5, 1.0, 1.5, 2.0,
    2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5,
    10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0, 14.5, 15.0, 15.5, 16.0,
    16.5, 17.0, 17.5, 18.0, 18.5, 19.0, 19.5, 20.0, 20.5, 21.0, 21.5, 22.0, 22.5,
    23.0, 23.5, 24.0, 24.5, 25.0, 25.5, 26.0, 26.5, 27.0, 27.5, 28.0, 28.5, 29.0,
    29.5, 30.0, 30.5, 31.0, 31.5, 32.0, 32.5, 33.0, 33.5, 34.0, 34.5, 35.0, 35.5,
    36.0, 36.5, 37.0, 37.5, 38.0, 38.5, 39.0, 39.5, 40.0, 40.5, 41.0, 41.5, 42.0,
    42.5, 43.0, 43.5, 44.0, 44.5, 45.0, 45.5, 46.0, 46.5, 47.0, 47.5, 48.0, 48.5,
    49.0, 49.5, 50.0, 50.5, 51.0, 51.5, 52.0, 52.5, 53.0, 53.5, 54.0, 54.5, 55.0,
    55.5, 56.0, 56.5, 57.0, 57.5, 58.0, 58.5, 59.0, 59.5, 60.0, 60.5, 61.0, 61.5,
    62.0, 62.5, 63.0, 63.5, 64.0, 64.5, 65.0, 65.5, 66.0, 66.5, 67.0, 67.5, 68.0,
    68.5, 69.0, 69.5, 70.0, 70.5, 71.0, 71.5, 72.0, 72.5, 73.0, 73.5, 74.0, 74.5,
    75.0, 75.5, 76.0, 76.5, 77.0, 77.5, 78.0, 78.5, 79.0, 79.5, 80.0, 80.5, 81.0,
    81.5, 82.0, 82.5, 83.0, 83.5, 84.0, 84.5, 85.0, 85.5, 86.0, 86.5, 87.0, 87.5,
    88.0, 88.5, 89.0, 89.5, 90.0, 90.5, 91.0, 91.5, 92.0, 92.5, 93.0, 93.5, 94.0,
    94.5, 95.0, 95.5, 96.0, 96.5, 97.0, 97.5, 98.0, 98.5, 99.0, 99.5, 100.0,
    100.5, 101.0, 101.5, 102.0, 102.5, 103.0, 103.5, 104.0, 104.5, 105.0, 105.5,
    106.0, 106.5, 107.0, 107.5, 108.0, 108.5, 109.0, 109.5, 110.0, 110.5, 111.0,
    111.5, 112.0, 112.5, 113.0, 113.5, 114.0, 114.5, 115.0, 115.5, 116.0, 116.5,
    117.0, 117.5, 118.0, 118.5, 119.0, 119.5, 120.0, 120.5, 121.0, 121.5, 122.0,
    122.5, 123.0, 123.5, 124.0, 124.5, 125.0, 125.5, 126.0, 126.5, 127.0, 127.5,
    128.0, 128.5, 129.0, 129.5, 130.0, 130.5, 131.0, 131.5, 132.0, 132.5, 133.0,
    133.5, 134.0, 134.5, 135.0, 135.5, 136.0, 136.5, 137.0, 137.5, 138.0, 138.5,
    139.0, 139.5, 140.0, 140.5, 141.0, 141.5, 142.0, 142.5, 143.0, 143.5, 144.0,
    144.5, 145.0, 145.5, 146.0, 146.5, 147.0, 147.5, 148.0, 148.5, 149.0, 149.5,
    150.0, 150.5, 151.0, 151.5, 152.0, 152.5, 153.0, 153.5, 154.0, 154.5, 155.0,
    155.5, 156.0, 156.5, 157.0, 157.5, 158.0, 158.5, 159.0, 159.5, 160.0, 160.5,
    161.0, 161.5, 162.0, 162.5, 163.0, 163.5, 164.0, 164.5, 165.0, 165.5, 166.0,
    166.5, 167.0, 167.5, 168.0, 168.5, 169.0, 169.5, 170.0, 170.5, 171.0, 171.5,
    172.0, 172.5, 173.0, 173.5, 174.0, 174.5, 175.0, 175.5, 176.0, 176.5, 177.0,
    177.5, 178.0, 178.5, 179.0, 179.5, 180.0, 180.5, 181.0, 181.5, 182.0, 182.5,
    183.0, 183.5, 184.0, 184.5, 185.0, 185.5, 186.0, 186.5, 187.0, 187.5, 188.0,
    188.5, 189.0, 189.5, 190.0, 190.5, 191.0, 191.5, 192.0, 192.5, 193.0, 193.5,
    194.0, 194.5, 195.0, 195.5, 196.0, 196.5, 197.0, 197.5, 198.0, 198.5, 199.0,
    199.5, 200.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.3228606001226904E-7, 1.5271629291310949E-7, 1.7630176656541295E-7,
    2.0352977621994352E-7, 2.3496287366879493E-7, 2.7125049194906196E-7,
    3.1314236225907128E-7, 3.6150400362628236E-7, 4.1733460614040918E-7,
    4.8178767377534458E-7, 5.561948581707241E-7, 6.4209346982518171E-7,
    7.4125824120433318E-7, 8.5573799424889194E-7, 9.8789796920547181E-7,
    1.140468692920799E-6, 1.3166023936577437E-6, 1.5199381278254111E-6,
    1.7546769648556593E-6, 2.0256687841481708E-6, 2.3385124766914839E-6,
    2.6996716205580254E-6, 3.116608022258982E-6, 3.5979358799941754E-6,
    4.1535997577823537E-6, 4.79508004235572E-6, 5.5356301311798057E-6,
    6.390550249878671E-6, 7.3775035566370906E-6, 8.5168810611976928E-6,
    9.8322229012238221E-6, 1.1350704672345736E-5, 1.3103698864311212E-5,
    1.5127422993592607E-5, 1.746368782508337E-5, 2.0160761131290458E-5,
    2.3274364834152897E-5, 2.6868826115450469E-5, 3.1018406271344034E-5,
    3.5808834747812024E-5, 4.1339080029868432E-5, 4.772339394309252E-5,
    5.509367156659372E-5, 6.3602175461844143E-5, 7.342468043635046E-5,
    8.4764103718956875E-5, 9.7854695432163721E-5, 0.00011296687577283843,
    0.00013041281862655643, 0.00015055289668852958, 0.00017380312086351206,
    0.00020064372713956953, 0.00023162908765955831, 0.00026739914984866839,
    0.00030869263872514445, 0.0003563622935440203, 0.00041139245141427289,
    0.00047491933830792125, 0.00054825448285420624, 0.00063291173156181048,
    0.000730638416821457, 0.00084345131258324591, 0.00097367810850778182,
    0.0011240052433987909, 0.0012975330647785877, 0.00149783942571698,
    0.0017290529948972881, 0.0019959377439802456, 0.0023039902905212296,
    0.00265955201799473, 0.0030699381701609035, 0.0035435864282808904,
    0.0040902278298454234, 0.004721083279474729, 0.0054490893389877127,
    0.006289157465936503, 0.0072584713983140934, 0.0083768279557369964,
    0.0096670271390256954, 0.01115531805116869, 0.012871907817273587,
    0.014851541324794873, 0.017134160201938906, 0.019765649949941424,
    0.022798684471626283, 0.026293677295168155, 0.030319848444790562,
    0.034956414982043618, 0.040293911500841349, 0.046435644008828242,
    0.053499276290428978, 0.061618541556274553, 0.070945063373987621,
    0.081650257880923907, 0.093927273346502957, 0.10799290247180471,
    0.12408937659183612, 0.14248591851662218, 0.16347989176389607,
    0.18739733864609442, 0.21459264930552066, 0.24544705105479983,
    0.28036555707133648, 0.31977197313779249, 0.364101541516229,
    0.41379081650033378, 0.46926443409597079, 0.53091857757266758,
    0.59910116870045216, 0.67408914220472838, 0.75606358590855915,
    0.84508402777789693, 0.94106367260887425, 1.0437478542281236,
    1.152698267808127, 1.2672855664497911, 1.386692550104242, 1.5099293988290852,
    1.6358612447688898, 1.7632469742208312, 1.8907867239725917,
    2.0171743481008004, 2.141150423020056, 2.2615512806530367,
    2.3773501290570072, 2.4876874145399421, 2.5918889742839446,
    2.6894719595336092, 2.7801397404339707, 2.86376787623742, 2.9403836879220884,
    3.0101420315886145, 3.0732996276642957, 3.1301898662115186,
    3.1811994924544709, 3.22674806684294, 3.2672706486739411, 3.3032038008828937,
    3.3349747627571094, 3.3629934786062479, 3.3876470874666542,
    3.4092964527998375, 3.4282743239300775, 3.4448847575490911,
    3.4594034763753356, 3.4720788947412626, 3.4831335921141484,
    3.4927660621914525, 3.50115260572328, 3.5084492691636369, 3.5147937588748897,
    3.5203072825159367, 3.5250962862113533, 3.5292540689388883,
    3.5328622650568198, 3.5359921927084685, 3.5387060705777156,
    3.541058108615752, 3.5430954803117021, 3.5448591851528475,
    3.5463848103592541, 3.5477032009708043, 3.548841047054017,
    3.5498213962870269, 3.5506640995503886, 3.5513861964537004,
    3.5520022470010928, 3.5525246148674063, 3.55296370703674, 3.553328173854172,
    3.5536250728628311, 3.5538599991408883, 3.5540371842126115,
    3.5541595649779056, 3.5542288234777777, 3.5542453976792991,
    3.5542084628121189, 3.5541158821073435, 3.553964125065677, 3.553748150600847,
    3.5534612515515289, 3.5530948561141957, 3.5526382807041186,
    3.5520784275853732, 3.5513994193073737, 3.5505821605308756,
    3.5496038162104333, 3.5484371933189753, 3.5470500113603998, 3.5454040448409,
    3.5434541187067574, 3.5411469355890413, 3.538419711658698, 3.535198596195853,
    3.5313968489215251, 3.5269127491710148, 3.5216272127300763,
    3.5154010964693447, 3.5080721789643632, 3.4994518186185974,
    3.489321311401222, 3.4774280006537852, 3.4634812344942749,
    3.4471483255459661, 3.4280507465788395, 3.4057608973159459,
    3.3797999039187929, 3.3496370624372682, 3.3146917045699169,
    3.2743384340504447, 3.2279168287103555, 3.1747467853084879,
    3.1141506426936405, 3.0454829791593863, 2.9681684602932457,
    2.8817472447127424, 2.78592621123113, 2.6806327124134075, 2.5660658738325131,
    2.4427389819173739, 2.3115056946660459, 2.17356315317282, 2.0304269132940358,
    1.8838759711657593, 1.7358705759284698, 1.5884501158739357,
    1.443622010613038, 1.303254257391997, 1.1689835776965221, 1.0421481915905177,
    0.92374992107985765, 0.81444570047299925, 0.71456467815091829,
    0.62414458194355849, 0.54298006294306989, 0.47067610366042256,
    0.40670082776471128, 0.35043369434960869, 0.30120670417124717,
    0.2583376377900648, 0.22115537575118172, 0.18901801318386457,
    0.16132483080372051, 0.13752330079159591, 0.11711226863730095,
    0.09964232691595365, 0.084714232917115329, 0.071976051379076811,
    0.061119545247536156, 0.051876200679212836, 0.044013160409407615,
    0.037329251311114753, 0.031651224780145704, 0.0268302790307291,
    0.022738896979264123, 0.019268008952027849, 0.016324473273849893,
    0.013828857684227369, 0.011713498761338315, 0.0099208137960427045,
    0.0084018388636981634, 0.0071149674728929746, 0.0060248656124159972,
    0.0051015409103514209, 0.004319545715834483, 0.0036572960512288866,
    0.0030964904563615114, 0.002621614694719554, 0.0022195200806733872,
    0.0018790648028117474, 0.001590809059771825, 0.001346756098124402,
    0.0011401323577757694, 0.00096520090263307878, 0.00081710315714467185,
    0.00069172469709810613, 0.00058558146942599976, 0.000495723353387767,
    0.00041965243585950773, 0.00035525376704947931, 0.0003007366987950455,
    0.00025458519391641232, 0.000215515738849259, 0.00018244169914316544,
    0.00015444313365220452, 0.00013074123300649276, 0.00011067667502784317,
    9.3691297683662356E-5, 7.93125816191953E-5, 6.71405119914148E-5,
    5.6836455041509026E-5, 4.8113740677813155E-5, 4.0729689549490189E-5,
    3.4478863159659312E-5, 2.9187349482207026E-5, 2.4707925277311915E-5,
    2.0915960641243458E-5, 1.7705951944169129E-5, 1.4988586751307764E-5,
    1.2688259121595991E-5, 1.0740966181810307E-5, 9.09252747849365E-6,
    7.6970775797491342E-6, 6.5157900039913841E-6, 5.5157969667263274E-6,
    4.66927491737934E-6, 3.9526704065373508E-6, 3.3460447537159155E-6,
    2.83251929333872E-6, 2.3978057539508768E-6, 2.029808704673286E-6,
    1.7182890239553217E-6, 1.4545790043563045E-6, 1.2313411921205386E-6,
    1.0423642233803321E-6, 8.8239000728407291E-7, 7.4696742435875763E-7,
    6.3232847669070225E-7, 5.3528344956532692E-7, 4.5313216201492423E-7,
    3.83588836250226E-7, 3.2471849698012534E-7, 2.7488313492085581E-7,
    2.3269612992038446E-7, 1.9698366982012772E-7, 1.6675209035810212E-7,
    1.4116022706289755E-7, 1.1949601130822884E-7, 1.0115665682874919E-7,
    8.56318886910401E-8, 7.2489746649750941E-8, 6.1364562320420646E-8,
    5.194678731612612E-8, 4.3974382357703234E-8, 3.7225522220296625E-8,
    3.1512426890145662E-8, 2.6676134634584514E-8, 2.2582080649868885E-8,
    1.9116351168690926E-8, 1.6182516215934584E-8, 1.3698944645312849E-8,
    1.1596532178970165E-8, 9.81678294209587E-9, 8.3101761028103738E-9,
    7.0347918601498804E-9, 5.9551443776229007E-9, 5.0411927965399173E-9,
    4.2675085687449155E-9, 3.6125626934335742E-9, 3.0581333021473256E-9,
    2.5887940680036081E-9, 2.1914847714299412E-9, 1.8551524760823668E-9,
    1.5704371136848749E-9, 1.32941790909058E-9, 1.1253886711415362E-9,
    9.5267260746823013E-10, 8.0646334055245461E-10, 6.8269301323198306E-10,
    5.7791860186284794E-10, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 3.8127329605604831E-8, 4.4015706553143889E-8, 5.0813483306833984E-8,
    5.8661107103381909E-8, 6.7720715729118338E-8, 7.8179488590276189E-8,
    9.0253511677220148E-8, 1.0419224388133754E-7, 1.2028367014906164E-7,
    1.3886025203031401E-7, 1.6030579604983575E-7, 1.8506338303360697E-7,
    2.1364452442370698E-7, 2.4663972800113366E-7, 2.8473069867189938E-7,
    3.2870442445226E-7, 3.7946943490459393E-7, 4.3807457119788766E-7,
    5.057306563227166E-7, 5.8383551183575818E-7, 6.7400283640975255E-7,
    7.7809554556734113E-7, 8.9826425943590834E-7, 1.036991735523E-6,
    1.1971441623609729E-6, 1.3820303733965722E-6, 1.595470207521597E-6,
    1.841873425455202E-6, 2.126330811315817E-6, 2.4547193445818009E-6,
    2.833823611140458E-6, 3.2714759630757193E-6, 3.7767183212289141E-6,
    4.3599889607445313E-6, 5.0333381376553446E-6, 5.8106770090041293E-6,
    6.708064984059395E-6, 7.7440414370363336E-6, 8.9400086321233813E-6,
    1.0320673758157958E-5, 1.1914559194716712E-5, 1.3754591535857883E-5,
    1.5878781517417088E-5, 1.8331008867703509E-5, 2.1161928253953771E-5,
    2.4430014990953108E-5, 2.8202772046404097E-5, 3.25581231828885E-5,
    3.7586020897991781E-5, 4.3390302209725055E-5, 5.0090830409145787E-5,
    5.7825966731592614E-5, 6.6755422609938439E-5, 7.7063550913031371E-5,
    8.896314346065405E-5, 0.00010269981232806152, 0.00011855704420843067,
    0.00013686203058540264, 0.00015799239193930846, 0.0001823839319449839,
    0.00021053957791057881, 0.00024303968690101181, 0.00028055392345469786,
    0.00032385494494861788, 0.00037383416490349957, 0.00043151990333434038,
    0.00049809827707021951, 0.00057493723227489179, 0.00066361417659949531,
    0.00076594772985194115, 0.00088403417999034231, 0.0010202893056472935,
    0.0011774963069949541, 0.001358860672761873, 0.0015680729012404542,
    0.0018093800847736703, 0.0020876674568629538, 0.002408551083270856,
    0.0027784829454769551, 0.0032048697055944357, 0.0036962064410814561,
    0.0042622265744576586, 0.0049140690696619516, 0.0056644636853015037,
    0.0065279346166624043, 0.0075210221591415181, 0.0086625210039536545,
    0.009973732329430985, 0.011478724850315418, 0.013204597278749019,
    0.015181731053022235, 0.017444017499689175, 0.020029037596229583,
    0.022978164991310269, 0.026336553766303544, 0.030152961552156816,
    0.034479346237802064, 0.039370161176602941, 0.044881260642105729,
    0.05106831625167689, 0.057984639217846266, 0.065678307008683823,
    0.074188512167323639, 0.0835410927499672, 0.093743275562056111,
    0.10477777117836799, 0.11659650538212821, 0.12911444863283733,
    0.14220419445692059, 0.15569210497574665, 0.1693569389056,
    0.18293185006604534, 0.19611044808000058, 0.20855723266611959,
    0.21992218068627953, 0.22985866351820866, 0.23804331812078425,
    0.24419610519575669, 0.24809864141977558, 0.2496090088537638,
    0.2486715856254, 0.24532093880867745, 0.23967940257479103,
    0.23194857588587961, 0.2223955674648477, 0.21133533854290129,
    0.199110878148821, 0.18607311968603227, 0.17256242339874944,
    0.1588931114452555, 0.14534201697695839, 0.13214140702048313,
    0.11947608133398305, 0.10748402863622686, 0.096259781895378635,
    0.085859550628008763, 0.076307280891628762, 0.06760094923515822,
    0.059718584656673276, 0.05262369472884415, 0.046269926037155219,
    0.040604905843282461, 0.035573291634873536, 0.031119103320675651,
    0.027187436618987731, 0.023725662954969345, 0.020684217121935543,
    0.018017063822038132, 0.015681921332465109, 0.013640307125989249,
    0.011857457604295098, 0.010302162849151567, 0.0089465477192804677,
    0.007765822727947895, 0.00673802179689239, 0.00584373900014998,
    0.0050658725715663835, 0.0043893815441801744, 0.00380105823103792,
    0.0032893181844495544, 0.0028440081501235337, 0.0024562317552079909,
    0.0021181921482925229, 0.0018230504767249062, 0.0015647988894856946,
    0.0013381466519921848, 0.00113841792191095, 0.00096145973938766948,
    0.00080355881381115183, 0.0006613657296630597, 0.00053182523657620967,
    0.00041211132644995111, 0.00029956582805630908, 0.00019163926282016522,
    8.583270118272301E-5, -2.0360665655989352E-5, -0.00012951557123144151,
    -0.00024433774157943909, -0.00036773148992081826, -0.00050287347175895258,
    -0.00065329439371067106, -0.00082297066161624087, -0.0010164281787895353,
    -0.0012388607629532542, -0.0014962659378773111, -0.0017956011671553076,
    -0.0021449639223273353, -0.00255379929815229, -0.0030331391764818892,
    -0.0035958771549330936, -0.004257083534970816, -0.0050343645159305842,
    -0.00594826923849253, -0.0070227472833190585, -0.0082856574103190948,
    -0.00976932538569526, -0.011511144241132441, -0.013554203661377651,
    -0.015947925667538467, -0.018748670455975929, -0.022020258127058011,
    -0.0258343279876838, -0.030270426133853837, -0.035415673544746194,
    -0.041363821380219025, -0.048213449912573571, -0.056065018126080904,
    -0.065016433068377066, -0.075156799086466136, -0.086558053168171945,
    -0.099264327989743328, -0.11327914705017858, -0.12855097708836083,
    -0.14495824450278594, -0.16229561129332382, -0.18026396622604754,
    -0.19846699546808208, -0.21641708607699486, -0.23355247510670996,
    -0.24926596995453137, -0.26294350370728348, -0.27400877627984016,
    -0.28196884697643837, -0.28645515648729092, -0.28725506641943954,
    -0.28433030308321583, -0.27782029274717707, -0.26803003380303991,
    -0.25540380934732659, -0.24048768644581273, -0.22388521876794754,
    -0.20621172257578879, -0.18805255735654774, -0.16992985894917317,
    -0.152280364289366, -0.13544485265657949, -0.11966788733046993,
    -0.10510536780129602, -0.0918369971047741, -0.079880987511316823,
    -0.069208911837554676, -0.059759306209623109, -0.051449268403779939,
    -0.04418378772873835, -0.037862870129332586, -0.03238670750750524,
    -0.027659219977503573, -0.023590310670938575, -0.020097144549129423,
    -0.017104716526348287, -0.014545923386927961, -0.012361305980490076,
    -0.010498586544191784, -0.00891209184462165, -0.0075621259267933342,
    -0.0064143357341251732, -0.0054390976308043553, -0.0046109418348199531,
    -0.0039080239927669208, -0.0033116477912943547, -0.0028058389599202355,
    -0.0023769687746629294, -0.0020134238418139027, -0.0017053182434950684,
    -0.0014442438549676785, -0.0012230546496320063, -0.0010356809862065793,
    -0.00087697015086896774, -0.00074254975543204733, -0.00062871093806313172,
    -0.00053230865441034308, -0.00045067667148382097, -0.0003815551769751676,
    -0.00032302918939529579, -0.00027347619871728089, -0.00023152168358197455,
    -0.00019600134120044229, -0.00016592903204368142, -0.00014046958541438621,
    -0.00011891573650393497, -0.00010066857279300312, -8.5220959739477561E-5,
    -7.214349464808553E-5, -6.1072605121123661E-5, -5.1700466090608623E-5,
    -4.3766458596416424E-5, -3.7049935305877619E-5, -3.136409339836352E-5,
    -2.6550785686008618E-5, -2.2476126573901472E-5, -1.9026771311305631E-5,
    -1.610676549062599E-5, -1.363487751730889E-5, -1.1542340066770585E-5,
    -9.77093788203645E-6, -8.2713888407749363E-6, -7.0019733330283559E-6,
    -5.9273738898662774E-6, -5.0176928225310285E-6, -4.247620569471911E-6,
    -3.5957316430868432E-6, -3.0438886020517725E-6, -2.5767374744965638E-6,
    -2.1812806130193471E-6, -1.8465150866099452E-6, -1.5631265601877035E-6,
    -1.3232301636626524E-6, -1.1201511131981624E-6, -9.4823899976475449E-7,
    -8.0271058866526162E-7, -6.7951672999545052E-7, -5.7522970031691809E-7,
    -4.8694783183474453E-7, -4.1221478097594907E-7, -3.4895118483645151E-7,
    -2.9539679902156588E-7, -2.5006153059336547E-7, -2.1168397479342756E-7,
    -1.7919631467577611E-7, -1.5169461331509976E-7, -1.2841366503479818E-7,
    -1.0870570132936976E-7, -9.2022367059740608E-8, -7.7899465100727935E-8,
    -6.5944039562282249E-8, -5.5823442757230109E-8, -4.7256079049873245E-8,
    -4.0003570234148336E-8, -3.3864122617188728E-8, -2.8666910178998244E-8,
    -2.4267326370619454E-8, -2.0542959333624818E-8, -1.7390179962717408E-8,
    -1.4721265095829493E-8, -1.2461955467557573E-8, -1.0549387585712111E-8,
    -8.9303462402767764E-9, -7.5597834658935881E-9, -6.3995644339343016E-9,
    -5.4174065233780766E-9, -4.5859840369644189E-9, -3.88216170321698E-9,
    -3.286356076159791E-9, -2.7819910819459892E-9, -2.3550317251874731E-9,
    -1.9935990636099632E-9, -1.6876358088779853E-9, -1.4286301031063431E-9,
    -1.2093752665975899E-9, -1.0237686254299661E-9, -8.6664853071738435E-10,
    -7.3364159192124134E-10, -6.2104765774506632E-10, -5.2573456699178678E-10,
    -4.4504844254333875E-10, -3.7674530162234987E-10, -3.1892533058908157E-10,
    -2.6997959423624707E-10, -2.2854473868960667E-10, -2.0954882273827025E-10,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.8127329605604156E-8,
    4.4015706553143108E-8, 1.2686153701229154E-8, 1.464540055023802E-8,
    1.6907232422284353E-8, 1.951838148689428E-8, 2.2532795948101731E-8,
    2.6012755291061161E-8, 3.0030158471841281E-8, 3.4668008148976233E-8,
    4.0022125900773683E-8, 4.62031310032923E-8, 5.3338728373870282E-8,
    6.1576344967525156E-8, 7.1086174248190131E-8, 8.2064696451122835E-8,
    9.4738736232689156E-8, 1.0937014674561951E-7, 1.2626122141811055E-7,
    1.4576094063785189E-7, 1.6827218008700665E-7, 1.9426003373153808E-7,
    2.2426142302608726E-7, 2.5889618995555403E-7, 2.9887990292490418E-7,
    3.4503863787332454E-7, 3.9832604516024206E-7, 4.5984305205804174E-7,
    5.3086060379331475E-7, 6.1284591912520545E-7, 7.0749279982249952E-7,
    8.1675661849062788E-7, 9.4289471008339112E-7, 1.0885129976610157E-6,
    1.2566198164144302E-6, 1.4506880482411266E-6, 1.6747268463756341E-6,
    1.9333644279884919E-6, 2.2319436479967285E-6, 2.5766323210181289E-6,
    2.9745505624340962E-6, 3.4339177774549548E-6, 3.964222322323467E-6,
    4.57641733126571E-6, 5.283146735644455E-6, 6.09900612187693E-6,
    7.0408437903384865E-6, 8.1281081886862854E-6, 9.383248846588885E-6,
    1.083217901914591E-5, 1.2504809499322028E-5, 1.4435664503664286E-5,
    1.6664592172787607E-5, 1.9237584138354494E-5, 2.2207720784433359E-5,
    2.5636261313060711E-5, 2.9593900590907851E-5, 3.4162218016019845E-5,
    3.9435347359645114E-5, 4.5521900788514126E-5, 5.2547185092820611E-5,
    6.0655753604784175E-5, 7.0014343465689223E-5, 8.0815254850775118E-5,
    9.3280236531985866E-5, 0.00010766495082392402, 0.0001242641005377933,
    0.00014341731105825187, 0.00016551587203314592, 0.00019101045530252165,
    0.00022041993840203511, 0.00025434147590034951, 0.00029346197347723634,
    0.00033857113119985097, 0.00039057623180209153, 0.00045051885530271983,
    0.00051959370074403858, 0.00059916968614274785, 0.00069081347466407148,
    0.00079631553292502141, 0.00091771875863699, 0.0010573496095182373,
    0.0012178515105031947, 0.0014022200948859882, 0.001613839525606669,
    0.0018565187182749908, 0.0021345257142153327, 0.0024526176892417685,
    0.0028160630844779621, 0.0032306510559463376, 0.0037026818038403309,
    0.0042389293082691071, 0.0048465655296665239, 0.0055330322287280905,
    0.0063058432900286827, 0.0071722969780947492, 0.008139074280454869,
    0.0092116970386060485, 0.010393818958875119, 0.011686325355812443,
    0.013086225724915241, 0.014585339661976573, 0.016168804292164937,
    0.01781347304808821, 0.019486332737863449, 0.021143136499538404,
    0.022727526867564997, 0.024170990078521144, 0.025394015064315392,
    0.026308796779037084, 0.02682369345382549, 0.0268494066534501,
    0.026306520013768014, 0.025133669825485309, 0.0232953289991451,
    0.020788074147775806, 0.017644342065690054, 0.0139330522283173,
    0.0097569705688378486, 0.0052471614627055954, 0.00055518813200949012,
    -0.0041561675266880175, -0.00872292949758905, -0.012990028391760845,
    -0.016820819663266307, -0.020105300378623469, -0.022766252401327767,
    -0.024762608190357138, -0.026089601143280947, -0.026775706258264764,
    -0.026876883546443516, -0.026469049422832781, -0.025639897625941713,
    -0.024481134096905732, -0.023081931706921657, -0.021524054672870052,
    -0.019878755231701208, -0.018205279574914909, -0.016550664368341572,
    -0.01495045118349678, -0.013429965925911712, -0.012005871684093257,
    -0.010687779517943235, -0.0094797747093283511, -0.00838177661769183,
    -0.0073906955411521718, -0.0065013806996600219, -0.0057073722346705448,
    -0.0050014800228779842, -0.0043762159374204305, -0.0038241062148028156,
    -0.0033379084571151128, -0.00291075464850412, -0.0025362381114526051,
    -0.0022084589933419213, -0.0019220398759567285, -0.0016721205293466236,
    -0.0014543386991728356, -0.0012648020935528339, -0.0011000553716661082,
    -0.00095704487633978155, -0.00083308304219446372, -0.00072581380055184266,
    -0.00063317985017134835, -0.00055339233395985965, -0.0004849032275395044,
    -0.0004263805834306545, -0.00037668666685931933, -0.00033485895216603037,
    -0.000300093912002646, -0.00027173351718589515, -0.00024925436748514623,
    -0.00023225938840974362, -0.00022047205340614484, -0.00021373312264727148,
    -0.00021199992740100624, -0.00021534827206123126, -0.00022397707369815309,
    -0.00023821591116142328, -0.00025853571216599458, -0.00028556286696479867,
    -0.00032009712053812596, -0.00036313366063054172, -0.000415889884285546,
    -0.00047983738745974283, -0.00055673977566317334, -0.00064869693027330309,
    -0.00075819637337359, -0.00088817233626222586, -0.0010420730283682302,
    -0.0012239363889545302, -0.0014384742345416714, -0.0016911641229811138,
    -0.0019883473486147188, -0.002337330139306881, -0.0027464831844124329,
    -0.0032253318766412306, -0.0037846258444078442, -0.0044363711811078723,
    -0.0051938019088094431, -0.0060712583219481205, -0.007083928716726591,
    -0.0082473976621782047, -0.0095769289910020514, -0.011086396654818862,
    -0.01278676472088249, -0.014684014828464327, -0.016776434610295252,
    -0.019051227352475563, -0.021480498762749916, -0.024016839279753895,
    -0.026588961430648032, -0.029098162434947922, -0.03141671355900124,
    -0.033389521733655579, -0.0348403972490939, -0.035583804996596795,
    -0.035441964828702488, -0.034265702943414932, -0.031955950499138908,
    -0.028481877340230891, -0.023891905660979419, -0.018315369519627967,
    -0.011954806782898373, -0.0050708094346523062, 0.0020377876327164609,
    0.00905593911158155, 0.015675110729875361, 0.0216157437637987,
    0.026648265431282885, 0.030610577141569034, 0.03341926275242349,
    0.035072066982857447, 0.035640734828791473, 0.035255528045148588,
    0.034084659531175787, 0.03231271082851022, 0.0301216376374932,
    0.02767663499143606, 0.025117584231519538, 0.022555568969241539,
    0.020073257376767236, 0.017727767654709875, 0.015554791451346814,
    0.013573060990132663, 0.011788574262848362, 0.01019826644489946,
    0.0087930112344338316, 0.0075599579991594487, 0.0064842760082737885,
    0.0055504038335980862, 0.0047429054443313013, 0.004047025579559424,
    0.0034490227843474038, 0.0029363432220890725, 0.0024976842120452356,
    0.0021229843263388059, 0.0018033670428678004, 0.0015310572514658461,
    0.0012992840540679929, 0.0011021789477293174, 0.00093467531221897045,
    0.00079241286420213481, 0.0006716491604337176, 0.00056917915354296193,
    0.00048226308744316016, 0.00040856256108193131, 0.0003460843118741356,
    0.000293131117277978, 0.00024825914389162151, 0.00021024105918348874,
    0.00017803424118215282, 0.00015075346201985008, 0.00012764747273268548,
    0.0001080789725800715, 9.1507502367815685E-5, 7.7474855426089973E-5,
    6.5592650269673033E-5, 5.5531755016315555E-5, 4.7013295072718448E-5,
    3.9801012338027851E-5, 3.3694776592544421E-5, 2.8525078040619423E-5,
    2.41483545550777E-5, 2.044302851908853E-5, 1.7306146501418164E-5,
    1.4650530770602369E-5, 1.2402365189481602E-5, 1.0499149614669314E-5,
    8.8879668213076916E-6, 7.5240143727892851E-6, 6.3693610821145489E-6,
    5.3918937932925718E-6, 4.5644254234282085E-6, 3.8639396350132665E-6,
    3.2709512258384429E-6, 2.7689645489127108E-6, 2.3440149508507655E-6,
    1.9842805104621924E-6, 1.6797533203730736E-6, 1.4219611794312931E-6,
    1.2037319674123039E-6, 1.0189941685855006E-6, 8.6260798902953242E-7,
    7.3022238788487532E-7, 6.1815405283058954E-7, 5.2328492294665321E-7,
    4.4297544698915079E-7, 3.7499116389766348E-7, 3.1744052453275642E-7,
    2.6872226976921234E-7, 2.2748088834829181E-7, 1.9256889816067861E-7,
    1.6301491934095049E-7, 1.3799664699828124E-7, 1.1681798195437655E-7,
    9.8889654243080413E-8, 8.3712824228135937E-8, 7.0865215917589368E-8,
    5.99893614783278E-8, 5.0782649640977925E-8, 4.2988911985729997E-8,
    3.6391297975057573E-8, 3.0806236228641827E-8, 2.6078327497458359E-8,
    2.2076022343497826E-8, 1.8687960512409004E-8, 1.5819872523081773E-8,
    1.3391956432684518E-8, 1.1336660055150092E-8, 9.5967962465692736E-9,
    8.1239508453734255E-9, 6.8771464079020461E-9, 5.8216942377953257E-9,
    4.9282244951598353E-9, 4.1718775101173816E-9, 3.5316092272807964E-9,
    2.989604119818523E-9, 2.5307818063424747E-9, 2.1423769425155115E-9,
    1.8135803969698827E-9, 1.5352448201610969E-9, 1.2996279608046279E-9,
    1.1001706212709905E-9, 9.31324350972318E-10, 7.88392018336026E-10,
    6.673959163094878E-10, 5.6496896050362011E-10, 4.7826054228039538E-10,
    4.0486147767637704E-10, 3.4272673588020552E-10, 2.9012703350872471E-10,
    2.4560087297231803E-10, 2.0790702492945456E-10, 1.7599921520172757E-10,
    1.4898926536943691E-10, 1.2612311195425718E-10, 1.067657073861028E-10,
    9.03805918994749E-11, 6.0430771497976821E-11, 6.0430771497976821E-11, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 1.0, 1.5, 2.0,
    2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5,
    10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0, 14.5, 15.0, 15.5, 16.0,
    16.5, 17.0, 17.5, 18.0, 18.5, 19.0, 19.5, 20.0, 20.500000000000018,
    21.000000000000018, 21.500000000000018, 22.000000000000018,
    22.500000000000018, 23.000000000000018, 23.500000000000021,
    24.000000000000025, 24.500000000000028, 25.000000000000032,
    25.500000000000039, 26.000000000000046, 26.500000000000057,
    27.000000000000071, 27.500000000000089, 28.000000000000114,
    28.500000000000146, 29.000000000000188, 29.500000000000242,
    30.000000000000316, 30.500000000000416, 31.000000000000547,
    31.500000000000721, 32.000000000000952, 32.500000000001258,
    33.00000000000167, 33.500000000002217, 34.000000000002949,
    34.500000000003922, 35.000000000005222, 35.500000000006949,
    36.000000000009251, 36.500000000012321, 37.000000000016414,
    37.500000000021871, 38.000000000029146, 38.500000000038838,
    39.000000000051756, 39.500000000068972, 40.000000000091923,
    40.500000000122505, 41.000000000163261, 41.500000000217582,
    42.00000000028998, 42.500000000386464, 43.000000000515044,
    43.500000000686406, 44.000000000914781, 44.500000001219142,
    45.000000001624763, 45.500000002165336, 46.000000002885756,
    46.500000003845848, 47.000000005125344, 47.5000000068305, 48.000000009102891,
    48.50000001213121, 49.000000016166872, 49.500000021544913, 50.00000002871176,
    50.500000038262264, 51.000000050989016, 51.500000067948037,
    52.000000090546287, 52.500000120658193, 53.000000160780829,
    53.500000214240544, 54.000000285468005, 54.500000380364369,
    55.000000506788496, 55.500000675205264, 56.000000899547885,
    56.500001198364615, 57.000001596343054, 57.500002126335595,
    58.000002832049553, 58.500003771618168, 59.000005022337994,
    59.500006686949156, 60.000008901954089, 60.500011848625832, 61.0000157675593,
    61.500020977881086, 62.000027902571425, 62.50003710178521,
    63.000049316610848, 63.500065526402217, 64.000087023689332,
    64.500115511746856, 65.0001532312023, 65.500203123614057, 66.000269041737312,
    66.50035601818162, 67.000470606240626, 67.500621308638159,
    68.000819111434907, 68.501078140817782, 69.0014164591133, 69.501857011939222,
    70.002428729343791, 70.5031677680874, 71.0041188576234, 71.505336676602752,
    72.006887138298481, 72.508848402374326, 73.011311360261217,
    73.514379270437516, 74.0181661632879, 74.522793615704927, 75.028385542232911,
    75.535060792684874, 76.04292360789249, 76.552052365891768,
    77.062487514715613, 77.57422005483717, 78.0871822844506, 78.601242619183267,
    79.116206036217562, 79.631821037766017, 80.147793056453082,
    80.663803122020354, 81.179529630484652, 81.694670453126761,
    82.208962555456509, 82.722196783944526, 83.234226389111782,
    83.744968951517819, 84.254402400567088, 84.762556556796667,
    85.269501982950175, 85.775337907534521, 86.280180681585108, 86.7841537780318,
    87.287379869606909, 87.789975116271108, 88.292045502401209,
    88.793684894433227, 89.294974422977035, 89.795982800170876,
    90.296767233273414, 90.797374664730285, 91.297843140280278,
    91.798203170251341, 92.298479000673936, 92.798689749455249,
    93.298850389880656, 93.79897258128392, 94.299065357156351,
    94.799135686322572, 95.2991889247856, 95.799229175715155, 96.299259573734062,
    96.799282507764488, 97.299299794622868, 97.799312813532609,
    98.299322609883745, 98.799329974962589, 99.299335507014916,
    99.79933965788112, 100.29934276852622, 100.79934509605307,
    101.29934683420386, 101.79934812889589, 102.29934908997959,
    102.79934980012787, 103.29935032155154, 103.79935070106967,
    104.29935097393778, 104.79935116673967, 105.29935129957572,
    105.79935138772473, 106.29935144291508, 106.79935147430963,
    107.29935148928668, 107.79935149408342, 108.29935149435813,
    108.79935149572232, 109.29935150429351, 109.79935152732371,
    110.29935157396868, 110.79935165627974, 111.29935179052534,
    111.7993519989864, 112.29935231242182, 112.79935277347384,
    113.29935344138531, 113.799354398542, 114.29935575954912, 114.7993576838192,
    115.29936039301764, 115.79936419521511, 116.29936951828071,
    116.79937695597576, 117.29938733145293, 117.79940178452638,
    118.29942189127267, 118.79944982738772, 119.29948859040884,
    119.79954230055586, 120.2996166056471, 120.7997192222934, 121.29986065313126,
    121.80005512759725, 122.30032182038691, 122.80068640498739,
    123.30118299576515, 123.80185651531473, 124.30276548609309,
    124.80398517648491, 125.30561091988493, 125.80776126135882,
    126.31058036751466, 126.814238875335, 127.31893209702046, 127.82487432181249,
    128.33228798589971, 128.84138686672492, 129.35235332442375,
    129.86531098398487, 130.38029595684276, 130.89723132580372,
    131.4159105568836, 131.93599514920166, 132.45702986842744,
    132.97847554826316, 133.49975550379827, 134.02030826776505,
    134.53963774521102, 135.05735254645384, 135.5731889693329,
    136.08701593481828, 136.598823918971, 137.10870255023545, 137.61681257158727,
    138.1233574157468, 138.62855822980785, 139.13263445016142, 139.6357904799402,
    140.1382079324257, 140.64004232428459, 141.14142293879848,
    141.64245468437232, 142.1432210094685, 142.64378720172576,
    143.14420363853975, 143.64450874431395, 144.14473154266528, 144.644893777614,
    145.1450116274508, 145.64509705957096, 146.14515888315108,
    146.64520355579629, 147.14523579474223, 147.64525903572002,
    148.14527577484691, 148.64528782176546, 149.14529648609269,
    149.64530271415109, 150.14530718887443, 150.64531040258348, 151.145312709863,
    151.64531436589823, 152.14531555421888, 152.64531640674667,
    153.14531701826277, 153.6453174568372, 154.14531777134002,
    154.64531799684696, 155.145318158527, 155.64531827443679, 156.14531835752817,
    156.64531841709, 157.14531845978337, 157.64531849038437, 158.14531851231732,
    158.64531852803708, 159.14531853930347, 159.64531854737797,
    160.14531855316474, 160.64531855731192, 161.14531856028404, 161.645318562414,
    162.14531856394041, 162.6453185650343, 163.14531856581823, 163.64531856638,
    164.14531856678261, 164.64531856707112, 165.14531856727785,
    165.64531856742602, 166.1453185675322, 166.64531856760829, 167.1453185676628,
    167.64531856770188, 168.14531856772987, 168.64531856774994,
    169.14531856776432, 169.64531856777464, 170.14531856778203,
    170.64531856778731, 171.14531856779109, 171.64531856779382,
    172.14531856779578, 172.64531856779718, 173.14531856779817,
    173.64531856779888, 174.14531856779939, 174.64531856779976,
    175.14531856780002, 175.64531856780022, 176.14531856780036,
    176.64531856780044, 177.1453185678005, 177.64531856780056,
    178.14531856780059, 178.64531856780062, 179.14531856780064,
    179.64531856780064, 180.14531856780064, 180.64531856780064,
    181.14531856780064, 181.64531856780064, 182.14531856780064,
    182.64531856780064, 183.14531856780064, 183.64531856780064,
    184.14531856780064, 184.64531856780064, 185.14531856780064,
    185.64531856780064, 186.14531856780064, 186.64531856780064,
    187.14531856780064, 187.64531856780064, 188.14531856780064,
    188.64531856780064, 189.14531856780064, 189.64531856780064,
    190.14531856780064, 190.64531856780064, 191.14531856780064,
    191.64531856780064, 192.14531856780064, 192.64531856780064,
    193.14531856780064, 193.64531856780064, 194.14531856780064,
    194.64531856780064, 195.14531856780064, 195.64531856780064,
    196.14531856780064, 196.64531856780064, 197.14531856780064,
    197.64531856780064, 198.14531856780064, 198.64531856780064,
    199.14531856780064, 199.64531856780064, 200.14531856780064,
    200.64531856780064, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

  static const int8_T b_b[16] = { -1, 3, -3, 1, 3, -6, 3, 0, -3, 3, 0, 0, 1, 0,
    0, 0 };

  int32_T itilerow;
  emxArray_real_T_pmpc_hil1_T *Local_x_0;
  int32_T loop_ub;
  emxArray_real_T_pmpc_hil1_T *Local_y_0;
  real_T tmp[4];
  real_T ps0_0[8];
  real_T C1_idx_0;
  real_T C1_idx_1;
  int32_T tempDx_tmp;
  int32_T PosPsi_tmp;
  boolean_T exitg1;
  Vel = VehStateMeasured->x_dot;
  PosX = VehStateMeasured->X;
  PosY = VehStateMeasured->Y;
  PosPsi = VehStateMeasured->Yaw;
  for (itilerow = 0; itilerow < 12; itilerow++) {
    Bezier_K[itilerow] = 0.0;
    ibcol = itilerow * 3;
    RefU[ibcol] = 0.0;
    RefU[ibcol + 1] = 0.0;
    RefU[ibcol + 2] = 0.0;
  }

  *PrjP_ey = 0.0;
  *PrjP_epsi = 0.0;
  *PrjP_Velr = VehStateMeasured->x_dot;
  *PrjP_xr = VehStateMeasured->X;
  *PrjP_yr = VehStateMeasured->Y;
  *PrjP_psir = VehStateMeasured->Yaw;
  Dist_MIN = 1000.0;
  *WPIndex = 0.0;
  if (!(WayPoints_Index < 401.0)) {
    WayPoints_Index = 401.0;
  }

  if ((1.0 > WayPoints_Index) || rtIsNaN(WayPoints_Index)) {
    WayPoints_Index = 1.0;
  }

  for (itilerow = 0; itilerow < (int32_T)((1.0 - WayPoints_Index) + 401.0);
       itilerow++) {
    tempDx = WayPoints_Index + (real_T)itilerow;
    tempDy = WayPoints_Collect[(int32_T)tempDx + 400] - PosX;
    deltax = WayPoints_Collect[(int32_T)tempDx + 801] - PosY;
    tempDy = std::sqrt(tempDy * tempDy + deltax * deltax);
    if (tempDy < Dist_MIN) {
      Dist_MIN = tempDy;
      *WPIndex = tempDx;
    }
  }

  if (*WPIndex < 1.0) {
    *WPIndex = -1.0;
  } else if (*WPIndex >= 401.0) {
    *WPIndex = -2.0;
  } else {
    pmpc_hil1_func_error(VehStateMeasured->X, VehStateMeasured->Y,
                         VehStateMeasured->Yaw, PrjP_xr, PrjP_yr, PrjP_psir,
                         &Dist_MIN, &tempDx);
    *PrjP_ey = -Dist_MIN;
    *PrjP_epsi = -tempDx;
    *PrjP_Velr = VehStateMeasured->x_dot;
    Dist_MIN = 0.0;
    for (itilerow = 0; itilerow < 12; itilerow++) {
      Dist_MIN += Vel * 0.05;
    }

    pmpc_hil1_emxInit_real_T(&Local_x, 1);
    pmpc_hil1_emxInit_real_T(&Local_y, 1);
    tempDx = WayPoints_Collect[(int32_T)(*WPIndex + 1.0) + 400] - *PrjP_xr;
    tempDy = WayPoints_Collect[(int32_T)(*WPIndex + 1.0) + 801] - *PrjP_yr;
    tempDy = std::sqrt(tempDx * tempDx + tempDy * tempDy);
    ibcol = Local_x->size[0];
    Local_x->size[0] = 0;
    pmpc_h_emxEnsureCapacity_real_T(Local_x, ibcol);
    ibcol = Local_y->size[0];
    Local_y->size[0] = 0;
    pmpc_h_emxEnsureCapacity_real_T(Local_y, ibcol);
    tempDx = 0.0;
    itilerow = 0;
    pmpc_hil1_emxInit_real_T(&Local_x_0, 1);
    pmpc_hil1_emxInit_real_T(&Local_y_0, 1);
    exitg1 = false;
    while ((!exitg1) && (itilerow <= (int32_T)((1.0 - *WPIndex) + 401.0) - 1)) {
      tempDx = *WPIndex + (real_T)itilerow;
      deltax = WayPoints_Collect[(int32_T)tempDx + 400] - PosX;
      deltay = WayPoints_Collect[(int32_T)tempDx + 801] - PosY;
      ibcol = Local_x_0->size[0];
      Local_x_0->size[0] = Local_x->size[0] + 1;
      pmpc_h_emxEnsureCapacity_real_T(Local_x_0, ibcol);
      loop_ub = Local_x->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Local_x_0->data[ibcol] = Local_x->data[ibcol];
      }

      C1_idx_0 = std::cos(PosPsi);
      C1_idx_1 = std::sin(PosPsi);
      Local_x_0->data[Local_x->size[0]] = deltax * C1_idx_0 + deltay * C1_idx_1;
      ibcol = Local_x->size[0];
      Local_x->size[0] = Local_x_0->size[0];
      pmpc_h_emxEnsureCapacity_real_T(Local_x, ibcol);
      loop_ub = Local_x_0->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Local_x->data[ibcol] = Local_x_0->data[ibcol];
      }

      ibcol = Local_y_0->size[0];
      Local_y_0->size[0] = Local_y->size[0] + 1;
      pmpc_h_emxEnsureCapacity_real_T(Local_y_0, ibcol);
      loop_ub = Local_y->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Local_y_0->data[ibcol] = Local_y->data[ibcol];
      }

      Local_y_0->data[Local_y->size[0]] = deltay * C1_idx_0 - deltax * C1_idx_1;
      ibcol = Local_y->size[0];
      Local_y->size[0] = Local_y_0->size[0];
      pmpc_h_emxEnsureCapacity_real_T(Local_y, ibcol);
      loop_ub = Local_y_0->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Local_y->data[ibcol] = Local_y_0->data[ibcol];
      }

      tempDx = (WayPoints_Collect[(int32_T)tempDx + 2405] + tempDy) -
        WayPoints_Collect[(int32_T)(*WPIndex + 1.0) + 2405];
      if (tempDx >= Dist_MIN) {
        exitg1 = true;
      } else {
        itilerow++;
      }
    }

    pmpc_hil1_emxFree_real_T(&Local_y_0);
    pmpc_hil1_emxFree_real_T(&Local_x_0);
    if (tempDx < Dist_MIN) {
      *WPIndex = 0.0;
    } else {
      pmpc_hil1_emxInit_real_T(&Mat_Local, 2);
      ibcol = Mat_Local->size[0] * Mat_Local->size[1];
      Mat_Local->size[0] = Local_x->size[0];
      Mat_Local->size[1] = 2;
      pmpc_h_emxEnsureCapacity_real_T(Mat_Local, ibcol);
      loop_ub = Local_x->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Mat_Local->data[ibcol] = Local_x->data[ibcol];
      }

      loop_ub = Local_y->size[0];
      for (ibcol = 0; ibcol < loop_ub; ibcol++) {
        Mat_Local->data[ibcol + Local_x->size[0]] = Local_y->data[ibcol];
      }

      pmpc_hil1_emxInit_real_T(&t, 2);
      pmpc_hil1_linspace_k((real_T)Mat_Local->size[0], t);
      itilerow = Mat_Local->size[0];
      ps0[0] = Mat_Local->data[0];
      ps3[0] = Mat_Local->data[itilerow - 1];
      ps0[1] = Mat_Local->data[Mat_Local->size[0]];
      ps3[1] = Mat_Local->data[(itilerow + Mat_Local->size[0]) - 1];
      if (Mat_Local->size[0] == 1) {
        ps1[0] = Mat_Local->data[0];
        C2[0] = Mat_Local->data[0];
        ps1[1] = Mat_Local->data[Mat_Local->size[0]];
        C2[1] = Mat_Local->data[Mat_Local->size[0]];
      } else if (Mat_Local->size[0] == 2) {
        itilerow = Mat_Local->size[0];
        ps1[0] = Mat_Local->data[0];
        C2[0] = Mat_Local->data[itilerow - 1];
        ps1[1] = Mat_Local->data[Mat_Local->size[0]];
        C2[1] = Mat_Local->data[(itilerow + Mat_Local->size[0]) - 1];
      } else if (Mat_Local->size[0] == 3) {
        ps1[0] = Mat_Local->data[1];
        C2[0] = Mat_Local->data[1];
        itilerow = 1 + Mat_Local->size[0];
        ps1[1] = Mat_Local->data[itilerow];
        ibcol = 1 + Mat_Local->size[0];
        C2[1] = Mat_Local->data[ibcol];
      } else {
        PosX = 0.0;
        PosY = 0.0;
        PosPsi = 0.0;
        C1_idx_0 = 0.0;
        C2[0] = 0.0;
        C1_idx_1 = 0.0;
        C2[1] = 0.0;
        for (itilerow = 1; itilerow - 1 <= Mat_Local->size[0] - 3; itilerow++) {
          tempDx = rt_powd_snf(1.0 - t->data[itilerow], 3.0);
          Dist_MIN = (1.0 - t->data[itilerow]) * (1.0 - t->data[itilerow]) *
            (3.0 * t->data[itilerow]);
          tempDy = t->data[itilerow] * t->data[itilerow] * 3.0 * (1.0 - t->
            data[itilerow]);
          deltax = rt_powd_snf(t->data[itilerow], 3.0);
          PosX += Dist_MIN * Dist_MIN;
          PosY += tempDy * tempDy;
          PosPsi += Dist_MIN * tempDy;
          C1_idx_0 += ((Mat_Local->data[itilerow] - tempDx * Mat_Local->data[0])
                       - deltax * ps3[0]) * Dist_MIN;
          C2[0] += ((Mat_Local->data[itilerow] - tempDx * Mat_Local->data[0]) -
                    deltax * ps3[0]) * tempDy;
          ibcol = itilerow + Mat_Local->size[0];
          C1_idx_1 += ((Mat_Local->data[ibcol] - tempDx * Mat_Local->
                        data[Mat_Local->size[0]]) - deltax * ps3[1]) * Dist_MIN;
          ibcol = itilerow + Mat_Local->size[0];
          C2[1] += ((Mat_Local->data[ibcol] - tempDx * Mat_Local->data
                     [Mat_Local->size[0]]) - deltax * ps3[1]) * tempDy;
        }

        tempDx = PosX * PosY - PosPsi * PosPsi;
        if (tempDx == 0.0) {
          itilerow = Mat_Local->size[0];
          ps1[0] = Mat_Local->data[0];
          C2[0] = Mat_Local->data[itilerow - 1];
          ps1[1] = Mat_Local->data[Mat_Local->size[0]];
          C2[1] = Mat_Local->data[(itilerow + Mat_Local->size[0]) - 1];
        } else {
          ps1[0] = (PosY * C1_idx_0 - PosPsi * C2[0]) / tempDx;
          C2[0] = (PosX * C2[0] - PosPsi * C1_idx_0) / tempDx;
          ps1[1] = (PosY * C1_idx_1 - PosPsi * C2[1]) / tempDx;
          C2[1] = (PosX * C2[1] - PosPsi * C1_idx_1) / tempDx;
        }
      }

      PosY = rt_roundd_snf(VehStateMeasured->x_dot * 0.05 / 0.1);
      for (itilerow = 0; itilerow < 12; itilerow++) {
        if ((1.0 > PosY) || rtIsNaN(PosY)) {
          Scale[itilerow] = 1.0;
        } else {
          Scale[itilerow] = PosY;
        }
      }

      PosX = Scale[0];
      for (itilerow = 0; itilerow < 11; itilerow++) {
        PosX += Scale[itilerow + 1];
      }

      PosX += Scale[0];
      pmpc_hil1_linspace_k(PosX + 1.0, t);
      ibcol = Mat_Local->size[0] * Mat_Local->size[1];
      Mat_Local->size[0] = t->size[1];
      Mat_Local->size[1] = 2;
      pmpc_h_emxEnsureCapacity_real_T(Mat_Local, ibcol);
      loop_ub = (t->size[1] << 1) - 1;
      for (ibcol = 0; ibcol <= loop_ub; ibcol++) {
        Mat_Local->data[ibcol] = 0.0;
      }

      for (itilerow = 0; itilerow < t->size[1]; itilerow++) {
        PosX = rt_powd_snf(t->data[itilerow], 3.0);
        C1_idx_1 = t->data[itilerow] * t->data[itilerow];
        PosY = t->data[itilerow];
        for (ibcol = 0; ibcol < 4; ibcol++) {
          C1_idx_0 = (real_T)b_b[(ibcol << 2) + 3] + ((real_T)b_b[(ibcol << 2) +
            2] * PosY + ((real_T)b_b[(ibcol << 2) + 1] * C1_idx_1 + (real_T)
                         b_b[ibcol << 2] * PosX));
          tmp[ibcol] = C1_idx_0;
        }

        for (ibcol = 0; ibcol < 2; ibcol++) {
          ps0_0[ibcol << 2] = ps0[ibcol];
          ps0_0[1 + (ibcol << 2)] = ps1[ibcol];
          ps0_0[2 + (ibcol << 2)] = C2[ibcol];
          ps0_0[3 + (ibcol << 2)] = ps3[ibcol];
          tempDx_tmp = Mat_Local->size[0] * ibcol;
          Mat_Local->data[itilerow + tempDx_tmp] = 0.0;
          tempDx_tmp = Mat_Local->size[0] * ibcol;
          loop_ub = itilerow + Mat_Local->size[0] * ibcol;
          Mat_Local->data[loop_ub] = Mat_Local->data[tempDx_tmp + itilerow] +
            ps0_0[ibcol << 2] * tmp[0];
          tempDx_tmp = Mat_Local->size[0] * ibcol + itilerow;
          loop_ub = itilerow + Mat_Local->size[0] * ibcol;
          Mat_Local->data[loop_ub] = ps0_0[(ibcol << 2) + 1] * tmp[1] +
            Mat_Local->data[tempDx_tmp];
          tempDx_tmp = Mat_Local->size[0] * ibcol + itilerow;
          loop_ub = itilerow + Mat_Local->size[0] * ibcol;
          Mat_Local->data[loop_ub] = ps0_0[(ibcol << 2) + 2] * tmp[2] +
            Mat_Local->data[tempDx_tmp];
          tempDx_tmp = Mat_Local->size[0] * ibcol + itilerow;
          loop_ub = itilerow + Mat_Local->size[0] * ibcol;
          Mat_Local->data[loop_ub] = ps0_0[(ibcol << 2) + 3] * tmp[3] +
            Mat_Local->data[tempDx_tmp];
        }
      }

      pmpc_hil1_emxFree_real_T(&t);
      PosX = 0.0;
      for (itilerow = 0; itilerow < 12; itilerow++) {
        PosX += Scale[itilerow];
        PosY = PosX + Scale[0];
        loop_ub = (int32_T)(PosY + 1.0) - 1;
        PosPsi_tmp = (int32_T)(PosY - 1.0) - 1;
        PosPsi = Mat_Local->data[loop_ub] - Mat_Local->data[PosPsi_tmp];
        ibcol = ((int32_T)(PosY + 1.0) + Mat_Local->size[0]) - 1;
        tempDx_tmp = ((int32_T)(PosY - 1.0) + Mat_Local->size[0]) - 1;
        tempDx = Mat_Local->data[ibcol] - Mat_Local->data[tempDx_tmp];
        ibcol = ((int32_T)(PosY + 1.0) + Mat_Local->size[0]) - 1;
        tempDx_tmp = ((int32_T)(PosY - 1.0) + Mat_Local->size[0]) - 1;
        Bezier_K[itilerow] = (((Mat_Local->data[ibcol] + Mat_Local->
          data[tempDx_tmp]) - Mat_Local->data[((int32_T)PosY + Mat_Local->size[0])
          - 1] * 2.0) * PosPsi - ((Mat_Local->data[loop_ub] + Mat_Local->
          data[PosPsi_tmp]) - Mat_Local->data[(int32_T)PosY - 1] * 2.0) * tempDx)
          * 4.0 / (rt_powd_snf(PosPsi * PosPsi + tempDx * tempDx, 1.5) + 1.0E-12);
      }

      pmpc_hil1_emxFree_real_T(&Mat_Local);
    }

    pmpc_hil1_emxFree_real_T(&Local_y);
    pmpc_hil1_emxFree_real_T(&Local_x);
    PosPsi = VehStateMeasured->x_dot * VehStateMeasured->x_dot;
    Dist_MIN = PosPsi * -0.00033002631785821428 + 1.0;
    tempDx = Dist_MIN * 2.95;
    if ((1.0E-6 > tempDx) || rtIsNaN(tempDx)) {
      C1_idx_0 = 1.0E-6;
      tempDx = 1.0E-6;
    } else {
      C1_idx_0 = tempDx;
    }

    PosY = VehStateMeasured->x_dot * 0.097753931849183254;
    if ((0.001 > VehStateMeasured->x_dot) || rtIsNaN(VehStateMeasured->x_dot)) {
      C1_idx_1 = 0.001;
    } else {
      C1_idx_1 = VehStateMeasured->x_dot;
    }

    C1_idx_1 = 4.903325 / C1_idx_1;
    for (itilerow = 0; itilerow < 12; itilerow++) {
      PosX = Dist_MIN * (2.95 * Bezier_K[itilerow]);
      ibcol = 3 * (1 + itilerow);
      RefU[ibcol - 3] = PosX;
      tempDy = std::abs((1.0 - PosPsi * 2318.70018 / -1.1612255213981662E+6) *
                        1.7033870000000002 * Vel * PosX / C1_idx_0);
      if (!((tempDy < PosY) || rtIsNaN(PosY))) {
        tempDy = PosY;
      }

      if (PosX < 0.0) {
        deltax = -1.0;
      } else if (PosX > 0.0) {
        deltax = 1.0;
      } else if (PosX == 0.0) {
        deltax = 0.0;
      } else {
        deltax = (rtNaN);
      }

      RefU[ibcol - 2] = tempDy * deltax;
      tempDy = std::abs(Vel * PosX / tempDx);
      if (!((tempDy < C1_idx_1) || rtIsNaN(C1_idx_1))) {
        tempDy = C1_idx_1;
      }

      if (PosX < 0.0) {
        PosX = -1.0;
      } else if (PosX > 0.0) {
        PosX = 1.0;
      } else if (PosX == 0.0) {
        PosX = 0.0;
      } else {
        PosX = (rtNaN);
      }

      RefU[ibcol - 1] = tempDy * PosX;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_Envelope(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  real_T Envelope_Henv[12], real_T Envelope_Genv[2], real_T Envelope_Hsh[24],
  real_T Envelope_Gsh[4], real_T Envelope_Hr[12], real_T Envelope_Or[6], real_T
  Envelope_Gr[2], real_T *r_ssmax)
{
  real_T cd_f;
  static const int8_T b[12] = { 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, 0, 0 };

  static const int8_T c[6] = { 0, 1, 0, 0, 0, 0 };

  static const int8_T d[6] = { 0, -1, 0, 0, 0, 0 };

  static const real_T e[6] = { 0.0, 0.0, 160681.49359924142, 0.0, 0.0, 0.0 };

  int32_T i;
  real_T tmp[6];
  real_T Or_row_idx_0;
  Or_row_idx_0 = 1860.0 * VehStateMeasured->x_dot;
  *r_ssmax = 22090.001909427432 / Or_row_idx_0;
  for (i = 0; i < 12; i++) {
    Envelope_Henv[i] = b[i];
  }

  Envelope_Genv[0] = 0.5325;
  Envelope_Genv[1] = 0.5325;
  Envelope_Hsh[2] = 1.0 / VehStateMeasured->x_dot;
  Envelope_Hsh[6] = -1.7033870000000002 / VehStateMeasured->x_dot;
  Envelope_Hsh[10] = 0.0;
  Envelope_Hsh[14] = 0.0;
  Envelope_Hsh[18] = 0.0;
  Envelope_Hsh[22] = 0.0;
  Envelope_Hsh[3] = -1.0 / VehStateMeasured->x_dot;
  Envelope_Hsh[7] = 1.7033870000000002 / VehStateMeasured->x_dot;
  Envelope_Hsh[11] = 0.0;
  Envelope_Hsh[15] = 0.0;
  Envelope_Hsh[19] = 0.0;
  Envelope_Hsh[23] = 0.0;
  Envelope_Gsh[0] = *r_ssmax;
  Envelope_Gsh[1] = *r_ssmax;
  Envelope_Gsh[2] = 0.087266462599716474;
  Envelope_Gsh[3] = 0.087266462599716474;
  cd_f = std::cos(VehStateMeasured->delta_f);
  tmp[0] = (VehiclePara_CbarF * cd_f + VehiclePara_CbarR) / Or_row_idx_0 *
    343.05084000000011;
  tmp[1] = (VehiclePara_CbarF * 1.246613 * cd_f - VehiclePara_CbarR *
            1.7033870000000002) / Or_row_idx_0 * 343.05084000000011;
  tmp[2] = 0.0;
  tmp[3] = 0.0;
  tmp[4] = 0.0;
  tmp[5] = 0.0;
  Or_row_idx_0 = -VehiclePara_CbarF * cd_f / 1860.0 * 343.05084000000011 *
    6.9617082299227066E-5;
  for (i = 0; i < 6; i++) {
    Envelope_Hsh[i << 2] = c[i];
    Envelope_Hsh[1 + (i << 2)] = d[i];
    cd_f = (tmp[i] + e[i]) * 6.9617082299227066E-5;
    Envelope_Hr[i << 1] = cd_f;
    Envelope_Hr[1 + (i << 1)] = -cd_f;
  }

  Envelope_Or[0] = Or_row_idx_0;
  Envelope_Or[1] = -Or_row_idx_0;
  Envelope_Or[2] = 0.0;
  Envelope_Or[3] = -0.0;
  Envelope_Or[4] = 6.9617082299227066E-5;
  Envelope_Or[5] = -6.9617082299227066E-5;
  Envelope_Gr[0] = 0.8;
  Envelope_Gr[1] = 0.8;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_func_MRDamper(real_T v)
{
  real_T F;
  int32_T low_i;
  int32_T low_ip1;
  int32_T high_i;
  int32_T b_high_i;
  int32_T b_mid_i;
  real_T qx1;
  real_T rx;
  if (!((v > pmpc_hil1_DW.VG[0]) || rtIsNaN(pmpc_hil1_DW.VG[0]))) {
    v = pmpc_hil1_DW.VG[0];
  }

  if (!((v < pmpc_hil1_DW.VG[20]) || rtIsNaN(pmpc_hil1_DW.VG[20]))) {
    v = pmpc_hil1_DW.VG[20];
  }

  if ((v >= pmpc_hil1_DW.VG[0]) && (v <= pmpc_hil1_DW.VG[20])) {
    low_i = 0;
    low_ip1 = 2;
    high_i = 5;
    while (high_i > low_ip1) {
      b_high_i = ((low_i + high_i) + 1) >> 1;
      if (2.0 >= pmpc_hil1_DW.IG[b_high_i - 1]) {
        low_i = b_high_i - 1;
        low_ip1 = b_high_i + 1;
      } else {
        high_i = b_high_i;
      }
    }

    low_ip1 = 1;
    high_i = 2;
    b_high_i = 21;
    while (b_high_i > high_i) {
      b_mid_i = (low_ip1 + b_high_i) >> 1;
      if (v >= pmpc_hil1_DW.VG[b_mid_i - 1]) {
        low_ip1 = b_mid_i;
        high_i = b_mid_i + 1;
      } else {
        b_high_i = b_mid_i;
      }
    }

    if (2.0 == pmpc_hil1_DW.IG[low_i]) {
      qx1 = pmpc_hil1_DW.FT[(21 * low_i + low_ip1) - 1];
      F = pmpc_hil1_DW.FT[21 * low_i + low_ip1];
    } else if (pmpc_hil1_DW.IG[low_i + 1] == 2.0) {
      qx1 = pmpc_hil1_DW.FT[((low_i + 1) * 21 + low_ip1) - 1];
      F = pmpc_hil1_DW.FT[(low_i + 1) * 21 + low_ip1];
    } else {
      rx = (2.0 - pmpc_hil1_DW.IG[low_i]) / (pmpc_hil1_DW.IG[low_i + 1] -
        pmpc_hil1_DW.IG[low_i]);
      high_i = (low_i + 1) * 21 + low_ip1;
      b_high_i = 21 * low_i + low_ip1;
      if (pmpc_hil1_DW.FT[high_i - 1] == pmpc_hil1_DW.FT[b_high_i - 1]) {
        qx1 = pmpc_hil1_DW.FT[(21 * low_i + low_ip1) - 1];
      } else {
        qx1 = pmpc_hil1_DW.FT[((low_i + 1) * 21 + low_ip1) - 1] * rx +
          pmpc_hil1_DW.FT[(21 * low_i + low_ip1) - 1] * (1.0 - rx);
      }

      if (pmpc_hil1_DW.FT[high_i] == pmpc_hil1_DW.FT[b_high_i]) {
        F = pmpc_hil1_DW.FT[21 * low_i + low_ip1];
      } else {
        F = pmpc_hil1_DW.FT[(low_i + 1) * 21 + low_ip1] * rx + pmpc_hil1_DW.FT
          [21 * low_i + low_ip1] * (1.0 - rx);
      }
    }

    if ((pmpc_hil1_DW.VG[low_ip1 - 1] == v) || (qx1 == F)) {
      F = qx1;
    } else {
      if (!(v == pmpc_hil1_DW.VG[low_ip1])) {
        rx = (v - pmpc_hil1_DW.VG[low_ip1 - 1]) / (pmpc_hil1_DW.VG[low_ip1] -
          pmpc_hil1_DW.VG[low_ip1 - 1]);
        F = (1.0 - rx) * qx1 + rx * F;
      }
    }
  } else {
    F = (rtNaN);
  }

  low_i = 0;
  if (!((!rtIsInf(F)) && (!rtIsNaN(F)))) {
    low_i = 1;
  }

  if (0 <= low_i - 1) {
    F = 0.0;
  }

  return F;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void func_CostWeightingRegulation_Qu(const
  stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, const
  sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured, real_T Q[5184], real_T R
  [324], real_T S[324], real_T Wshl[64], real_T Wact[9], real_T *dFyfmax, real_T
  *dMFxmax, real_T *dMdmax, real_T *Fyfmax, real_T *MFxmax, real_T *Mdmax,
  real_T *Mdmin, s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T *Tb_u, real_T Fdu[4], real_T
  Fdl[4], real_T *Mdnom)
{
  real_T Tb_fl_max;
  real_T Tb_fr_max;
  real_T Tb_rl_max;
  real_T Tb_rr_max;
  int8_T r[6];
  int8_T b_r[3];
  int32_T k;
  real_T d[9];
  real_T b_d[36];
  int32_T e_j;
  static const real_T b[6] = { 0.0, 0.0, 20517.5396875734, 0.0,
    70532.742621613885, 10258.7698437867 };

  static const real_T c[8] = { 65656.127000234876, 65656.127000234876,
    65656.127000234876, 65656.127000234876, 555555.5555555555, 555555.5555555555,
    78125.0, 78125.0 };

  int8_T k_0;
  real_T varargin_1;
  real_T varargin_2;
  real_T Fd_nom_idx_0;
  real_T Fd_nom_idx_2;
  real_T z1_idx_0;
  real_T b_z1_idx_2;
  real_T z1_idx_2;
  real_T u1;
  real_T u0;
  boolean_T tmp;
  int32_T R_tmp;
  Tb_fl_max = 0.5 * ParaHAT->Fz_l1;
  Tb_fr_max = 0.5 * ParaHAT->Fz_r1;
  Tb_rl_max = 0.5 * ParaHAT->Fz_l2;
  Tb_rr_max = 0.5 * ParaHAT->Fz_r2;
  u1 = Tb_fl_max * Tb_fl_max - ParaHAT->Fy_l1 * ParaHAT->Fy_l1;
  if ((0.0 > u1) || rtIsNaN(u1)) {
    u1 = 0.0;
  }

  u0 = std::sqrt(u1) * 0.393;
  if (!(u0 < 3000.0)) {
    u0 = 3000.0;
  }

  if ((0.0 > ParaHAT->Td_L1) || rtIsNaN(ParaHAT->Td_L1)) {
    u1 = 0.0;
  } else {
    u1 = ParaHAT->Td_L1;
  }

  Tb_fl_max = u0 - u1;
  if ((0.0 > Tb_fl_max) || rtIsNaN(Tb_fl_max)) {
    Tb_fl_max = 0.0;
  }

  u1 = Tb_fr_max * Tb_fr_max - ParaHAT->Fy_r1 * ParaHAT->Fy_r1;
  if ((0.0 > u1) || rtIsNaN(u1)) {
    u1 = 0.0;
  }

  u0 = std::sqrt(u1) * 0.393;
  if (!(u0 < 3000.0)) {
    u0 = 3000.0;
  }

  if ((0.0 > ParaHAT->Td_R1) || rtIsNaN(ParaHAT->Td_R1)) {
    u1 = 0.0;
  } else {
    u1 = ParaHAT->Td_R1;
  }

  Tb_fr_max = u0 - u1;
  if ((0.0 > Tb_fr_max) || rtIsNaN(Tb_fr_max)) {
    Tb_fr_max = 0.0;
  }

  u1 = Tb_rl_max * Tb_rl_max - ParaHAT->Fy_l2 * ParaHAT->Fy_l2;
  if ((0.0 > u1) || rtIsNaN(u1)) {
    u1 = 0.0;
  }

  u0 = std::sqrt(u1) * 0.393;
  if (!(u0 < 3000.0)) {
    u0 = 3000.0;
  }

  if ((0.0 > ParaHAT->Td_L2) || rtIsNaN(ParaHAT->Td_L2)) {
    u1 = 0.0;
  } else {
    u1 = ParaHAT->Td_L2;
  }

  Tb_rl_max = u0 - u1;
  if ((0.0 > Tb_rl_max) || rtIsNaN(Tb_rl_max)) {
    Tb_rl_max = 0.0;
  }

  u1 = Tb_rr_max * Tb_rr_max - ParaHAT->Fy_r2 * ParaHAT->Fy_r2;
  if ((0.0 > u1) || rtIsNaN(u1)) {
    u1 = 0.0;
  }

  u0 = std::sqrt(u1) * 0.393;
  if (!(u0 < 3000.0)) {
    u0 = 3000.0;
  }

  if ((0.0 > ParaHAT->Td_R2) || rtIsNaN(ParaHAT->Td_R2)) {
    u1 = 0.0;
  } else {
    u1 = ParaHAT->Td_R2;
  }

  Tb_rr_max = u0 - u1;
  if ((0.0 > Tb_rr_max) || rtIsNaN(Tb_rr_max)) {
    Tb_rr_max = 0.0;
  }

  Tb_u->Tb_L1 = Tb_fl_max;
  Tb_u->Tb_R1 = Tb_fr_max;
  Tb_u->Tb_L2 = Tb_rl_max;
  Tb_u->Tb_R2 = Tb_rr_max;
  if (std::abs(VehStateMeasured->delta_f) < 0.15) {
    Tb_fl_max = (Tb_fl_max + Tb_rl_max) * 2.0038167938931295;
    Tb_rr_max = (-Tb_fr_max - Tb_rr_max) * 2.0038167938931295;
  } else {
    u1 = std::cos(VehStateMeasured->delta_f);
    u0 = 1.246613 * std::sin(VehStateMeasured->delta_f) / 0.393;
    Tb_fl_max = (Tb_fl_max * u1 + Tb_rl_max) * 2.0038167938931295 - u0 *
      Tb_fl_max;
    Tb_rr_max = (-Tb_fr_max * u1 - Tb_rr_max) * 2.0038167938931295 - u0 *
      Tb_fr_max;
  }

  u0 = std::abs(Tb_fl_max);
  *MFxmax = std::abs(Tb_rr_max);
  if ((u0 < *MFxmax) || rtIsNaN(*MFxmax)) {
    *MFxmax = u0;
  }

  *dMFxmax = 897.76816171875;
  *Fyfmax = 0.24639942381096414;
  *dFyfmax = 0.0073919827143289251;
  if (VehStateMeasured->V_l1 < 0.0) {
    u1 = -1.0;
  } else if (VehStateMeasured->V_l1 > 0.0) {
    u1 = 1.0;
  } else if (VehStateMeasured->V_l1 == 0.0) {
    u1 = 0.0;
  } else {
    u1 = (rtNaN);
  }

  u0 = std::abs(VehStateMeasured->V_l1);
  Fdu[0] = ((1230.0 * u0 + 1916.0) * (real_T)(u0 > 0.15) + (real_T)(u0 <= 0.15) *
            (14000.0 * u0)) * u1;
  Fdl[0] = 830.0 * VehStateMeasured->V_l1;
  if (VehStateMeasured->V_r1 < 0.0) {
    u1 = -1.0;
  } else if (VehStateMeasured->V_r1 > 0.0) {
    u1 = 1.0;
  } else if (VehStateMeasured->V_r1 == 0.0) {
    u1 = 0.0;
  } else {
    u1 = (rtNaN);
  }

  u0 = std::abs(VehStateMeasured->V_r1);
  Fdu[1] = ((1230.0 * u0 + 1916.0) * (real_T)(u0 > 0.15) + (real_T)(u0 <= 0.15) *
            (14000.0 * u0)) * u1;
  Fdl[1] = 830.0 * VehStateMeasured->V_r1;
  if (VehStateMeasured->V_l2 < 0.0) {
    u1 = -1.0;
  } else if (VehStateMeasured->V_l2 > 0.0) {
    u1 = 1.0;
  } else if (VehStateMeasured->V_l2 == 0.0) {
    u1 = 0.0;
  } else {
    u1 = (rtNaN);
  }

  u0 = std::abs(VehStateMeasured->V_l2);
  Fdu[2] = ((1230.0 * u0 + 1916.0) * (real_T)(u0 > 0.15) + (real_T)(u0 <= 0.15) *
            (14000.0 * u0)) * u1;
  Fdl[2] = 830.0 * VehStateMeasured->V_l2;
  if (VehStateMeasured->V_r2 < 0.0) {
    u1 = -1.0;
  } else if (VehStateMeasured->V_r2 > 0.0) {
    u1 = 1.0;
  } else if (VehStateMeasured->V_r2 == 0.0) {
    u1 = 0.0;
  } else {
    u1 = (rtNaN);
  }

  u0 = std::abs(VehStateMeasured->V_r2);
  Fdu[3] = ((1230.0 * u0 + 1916.0) * (real_T)(u0 > 0.15) + (real_T)(u0 <= 0.15) *
            (14000.0 * u0)) * u1;
  Fdl[3] = 830.0 * VehStateMeasured->V_r2;
  tmp = rtIsNaN(Fdu[0]);
  if ((Fdl[0] < Fdu[0]) || tmp) {
    u1 = Fdl[0];
  } else {
    u1 = Fdu[0];
  }

  if ((Fdl[0] > Fdu[0]) || tmp) {
    u0 = Fdl[0];
  } else {
    u0 = Fdu[0];
  }

  varargin_1 = -0.55 * u1;
  varargin_2 = -0.55 * u0;
  if ((varargin_1 > varargin_2) || rtIsNaN(varargin_2)) {
    Tb_fl_max = varargin_1;
  } else {
    Tb_fl_max = varargin_2;
  }

  Fd_nom_idx_0 = u1;
  z1_idx_0 = u0;
  tmp = rtIsNaN(Fdu[1]);
  if ((Fdl[1] < Fdu[1]) || tmp) {
    u1 = Fdl[1];
  } else {
    u1 = Fdu[1];
  }

  if ((Fdl[1] > Fdu[1]) || tmp) {
    u0 = Fdl[1];
  } else {
    u0 = Fdu[1];
  }

  varargin_1 = 0.55 * u1;
  varargin_2 = 0.55 * u0;
  if ((varargin_1 > varargin_2) || rtIsNaN(varargin_2)) {
    Tb_fr_max = varargin_1;
  } else {
    Tb_fr_max = varargin_2;
  }

  Tb_rl_max = u1;
  Tb_rr_max = u0;
  tmp = rtIsNaN(Fdu[2]);
  if ((Fdl[2] < Fdu[2]) || tmp) {
    u1 = Fdl[2];
  } else {
    u1 = Fdu[2];
  }

  if ((Fdl[2] > Fdu[2]) || tmp) {
    u0 = Fdl[2];
  } else {
    u0 = Fdu[2];
  }

  varargin_1 = -0.55 * u1;
  varargin_2 = -0.55 * u0;
  if ((varargin_1 > varargin_2) || rtIsNaN(varargin_2)) {
    b_z1_idx_2 = varargin_1;
  } else {
    b_z1_idx_2 = varargin_2;
  }

  Fd_nom_idx_2 = u1;
  z1_idx_2 = u0;
  tmp = rtIsNaN(Fdu[3]);
  if ((Fdl[3] < Fdu[3]) || tmp) {
    u1 = Fdl[3];
  } else {
    u1 = Fdu[3];
  }

  if ((Fdl[3] > Fdu[3]) || tmp) {
    u0 = Fdl[3];
  } else {
    u0 = Fdu[3];
  }

  varargin_1 = 0.55 * u1;
  varargin_2 = 0.55 * u0;
  if ((varargin_1 > varargin_2) || rtIsNaN(varargin_2)) {
    varargin_2 = varargin_1;
  }

  *Mdmax = ((Tb_fl_max + Tb_fr_max) + b_z1_idx_2) + varargin_2;
  Fd_nom_idx_0 *= -0.55;
  z1_idx_0 *= -0.55;
  if ((Fd_nom_idx_0 < z1_idx_0) || rtIsNaN(z1_idx_0)) {
    Tb_fl_max = Fd_nom_idx_0;
  } else {
    Tb_fl_max = z1_idx_0;
  }

  Fd_nom_idx_0 = 0.55 * Tb_rl_max;
  z1_idx_0 = 0.55 * Tb_rr_max;
  if ((Fd_nom_idx_0 < z1_idx_0) || rtIsNaN(z1_idx_0)) {
    Tb_fr_max = Fd_nom_idx_0;
  } else {
    Tb_fr_max = z1_idx_0;
  }

  Fd_nom_idx_0 = -0.55 * Fd_nom_idx_2;
  z1_idx_0 = -0.55 * z1_idx_2;
  if ((Fd_nom_idx_0 < z1_idx_0) || rtIsNaN(z1_idx_0)) {
    b_z1_idx_2 = Fd_nom_idx_0;
  } else {
    b_z1_idx_2 = z1_idx_0;
  }

  Fd_nom_idx_0 = 0.55 * u1;
  z1_idx_0 = 0.55 * u0;
  if ((Fd_nom_idx_0 < z1_idx_0) || rtIsNaN(z1_idx_0)) {
    z1_idx_0 = Fd_nom_idx_0;
  }

  *Mdmin = ((Tb_fl_max + Tb_fr_max) + b_z1_idx_2) + z1_idx_0;
  u1 = pmpc_hil1_func_MRDamper(VehStateMeasured->V_l1);
  u0 = pmpc_hil1_func_MRDamper(VehStateMeasured->V_r1);
  Tb_fl_max = pmpc_hil1_func_MRDamper(VehStateMeasured->V_l2);
  Tb_fr_max = pmpc_hil1_func_MRDamper(VehStateMeasured->V_r2);
  u0 = ((-0.55 * u1 + 0.55 * u0) + -0.55 * Tb_fl_max) + 0.55 * Tb_fr_max;
  tmp = rtIsNaN(*Mdmax);
  if ((*Mdmin < *Mdmax) || tmp) {
    u1 = *Mdmin;
  } else {
    u1 = *Mdmax;
  }

  if ((u0 > u1) || rtIsNaN(u1)) {
    u1 = u0;
  }

  if ((*Mdmin > *Mdmax) || tmp) {
    *Mdnom = *Mdmin;
  } else {
    *Mdnom = *Mdmax;
  }

  if ((u1 < *Mdnom) || rtIsNaN(*Mdnom)) {
    *Mdnom = u1;
  }

  *dMdmax = 1551.7333333333338;
  memset(&Q[0], 0, 5184U * sizeof(real_T));
  for (k = 0; k < 12; k++) {
    k_0 = (int8_T)(k * 6 + 1);
    for (e_j = 0; e_j < 6; e_j++) {
      r[e_j] = (int8_T)(e_j + k_0);
    }

    if (1 + k == 12) {
      memset(&b_d[0], 0, 36U * sizeof(real_T));
      for (e_j = 0; e_j < 6; e_j++) {
        b_d[e_j + 6 * e_j] = b[e_j];
      }

      for (e_j = 0; e_j < 6; e_j++) {
        for (R_tmp = 0; R_tmp < 6; R_tmp++) {
          Q[(r[R_tmp] + 72 * (r[e_j] - 1)) - 1] = b_d[6 * e_j + R_tmp];
        }
      }
    } else {
      memset(&b_d[0], 0, 36U * sizeof(real_T));
      for (e_j = 0; e_j < 6; e_j++) {
        b_d[e_j + 6 * e_j] = b[e_j];
      }

      for (e_j = 0; e_j < 6; e_j++) {
        for (R_tmp = 0; R_tmp < 6; R_tmp++) {
          Q[(r[R_tmp] + 72 * (r[e_j] - 1)) - 1] = b_d[6 * e_j + R_tmp];
        }
      }
    }
  }

  memset(&R[0], 0, 324U * sizeof(real_T));
  for (k = 0; k < 6; k++) {
    k_0 = (int8_T)(k * 3 + 1);
    b_r[0] = k_0;
    b_r[1] = (int8_T)(1 + k_0);
    b_r[2] = (int8_T)(2 + k_0);
    memset(&d[0], 0, 9U * sizeof(real_T));
    d[0] = 18301.138795397259;
    d[4] = 1.2407137658514824E-5;
    d[8] = 2.0765185992128159E-6;
    for (e_j = 0; e_j < 3; e_j++) {
      R_tmp = 18 * (b_r[e_j] - 1);
      R[(k_0 + R_tmp) - 1] = d[3 * e_j];
      R[(b_r[1] + R_tmp) - 1] = d[3 * e_j + 1];
      R[(b_r[2] + R_tmp) - 1] = d[3 * e_j + 2];
    }
  }

  memset(&S[0], 0, 324U * sizeof(real_T));
  for (k = 0; k < 6; k++) {
    k_0 = (int8_T)(k * 3 + 1);
    b_r[0] = k_0;
    b_r[1] = (int8_T)(1 + k_0);
    b_r[2] = (int8_T)(2 + k_0);
    for (e_j = 0; e_j < 3; e_j++) {
      R_tmp = 18 * (b_r[e_j] - 1);
      S[(k_0 + R_tmp) - 1] = 0.0;
      S[(b_r[1] + R_tmp) - 1] = 0.0;
      S[(b_r[2] + R_tmp) - 1] = 0.0;
    }
  }

  memset(&Wshl[0], 0, sizeof(real_T) << 6U);
  for (k = 0; k < 8; k++) {
    Wshl[k + (k << 3)] = c[k];
  }

  memset(&Wact[0], 0, 9U * sizeof(real_T));
  Wact[0] = 100.0;
  Wact[4] = 80000.0;
  Wact[8] = 1.0;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_DynamicalModel(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  real_T StateSpaceModel_C_aug[54], real_T StateSpaceModel_A_aug[972], real_T
  StateSpaceModel_B_aug[324], real_T StateSpaceModel_D_aug[324], real_T
  StateSpaceModel_off[24], boolean_T *StateSpaceModel_off_valid)
{
  real_T Vel_eff;
  real_T A[36];
  real_T B[18];
  real_T D[18];
  real_T unusedU1[18];
  real_T Aa[81];
  real_T Ba[27];
  real_T Da[27];
  int8_T I[36];
  int32_T k;
  real_T A2[36];
  real_T A3[36];
  int8_T b_I[9];
  static const int8_T b[6] = { 0, 0, 0, 1, 0, 0 };

  static const int8_T c[6] = { 0, 1, 0, 0, 0, 0 };

  int32_T i;
  int32_T i_0;
  real_T A_0[18];
  real_T A2_0[18];
  real_T A3_0[18];
  real_T A3_1[36];
  real_T VehStateMeasured_0;
  real_T A_tmp;
  real_T A_tmp_0;
  int32_T A2_tmp;
  int32_T A_tmp_1;
  int32_T A_tmp_2;
  Vel_eff = std::abs(VehStateMeasured->x_dot);
  if (!(Vel_eff > 0.5)) {
    Vel_eff = 0.5;
  }

  if (VehStateMeasured->x_dot + 1.0E-6 < 0.0) {
    VehStateMeasured_0 = -1.0;
  } else if (VehStateMeasured->x_dot + 1.0E-6 > 0.0) {
    VehStateMeasured_0 = 1.0;
  } else if (VehStateMeasured->x_dot + 1.0E-6 == 0.0) {
    VehStateMeasured_0 = 0.0;
  } else {
    VehStateMeasured_0 = (rtNaN);
  }

  Vel_eff *= VehStateMeasured_0;
  for (i = 0; i < 36; i++) {
    I[i] = 0;
  }

  for (k = 0; k < 6; k++) {
    I[k + 6 * k] = 1;
  }

  for (i = 0; i < 36; i++) {
    StateSpaceModel_C_aug[i] = I[i];
  }

  memset(&StateSpaceModel_C_aug[36], 0, 18U * sizeof(real_T));
  memset(&StateSpaceModel_off[0], 0, 24U * sizeof(real_T));
  *StateSpaceModel_off_valid = false;
  VehStateMeasured_0 = std::cos(VehStateMeasured->delta_f);
  A_tmp = VehiclePara_CbarF * VehStateMeasured_0 + VehiclePara_CbarR;
  A[0] = A_tmp / (1860.0 * Vel_eff);
  A_tmp_0 = VehiclePara_CbarF * 1.246613 * VehStateMeasured_0 -
    VehiclePara_CbarR * 1.7033870000000002;
  A[6] = A_tmp_0 / (1860.0 * Vel_eff) - Vel_eff;
  A[12] = 0.0;
  A[18] = 0.0;
  A[24] = 0.0;
  A[30] = 0.0;
  A[1] = (1.246613 * VehiclePara_CbarF * VehStateMeasured_0 - 1.7033870000000002
          * VehiclePara_CbarR) / (3438.54 * Vel_eff);
  A[7] = (1.554043971769 * VehiclePara_CbarF * VehStateMeasured_0 +
          2.9015272717690008 * VehiclePara_CbarR) / (3438.54 * Vel_eff);
  A[13] = 0.0;
  A[19] = 0.0;
  A[25] = 0.0;
  A[31] = 0.0;
  A[3] = A_tmp * 906.3 / (1.663584E+6 * Vel_eff);
  A[9] = A_tmp_0 * 906.3 / (1.663584E+6 * Vel_eff);
  A[15] = -169.71570517021627;
  A[21] = 0.0;
  A[27] = 0.0;
  A[33] = 0.0;
  A[4] = 1.0;
  A[10] = 0.0;
  A[16] = 0.0;
  A[22] = 0.0;
  A[28] = 0.0;
  A[34] = Vel_eff;
  for (i = 0; i < 6; i++) {
    A[2 + 6 * i] = b[i];
    A[5 + 6 * i] = c[i];
  }

  B[0] = -VehiclePara_CbarF * VehStateMeasured_0 / 1860.0;
  B[6] = 0.0;
  B[12] = 0.0;
  B[1] = -1.246613 * VehiclePara_CbarF * VehStateMeasured_0 / 3438.54;
  B[7] = 0.00029082110430589728;
  B[13] = 0.0;
  B[3] = -(906.3 * VehiclePara_CbarF * VehStateMeasured_0) / 1.663584E+6;
  B[9] = 0.0;
  B[15] = -0.0011180679785330948;
  D[0] = 0.0;
  D[6] = VehStateMeasured_0 / 1860.0;
  D[12] = 0.00053763440860215054;
  D[1] = 0.0;
  D[7] = 1.246613 * VehStateMeasured_0 / 3438.54;
  D[13] = -0.0004953808884003095;
  D[3] = 0.0;
  D[9] = 906.3 * VehStateMeasured_0 / 1.663584E+6;
  D[15] = 0.00054478763921749667;
  B[2] = 0.0;
  B[4] = 0.0;
  B[5] = 0.0;
  D[2] = 0.0;
  D[4] = 0.0;
  B[8] = 0.0;
  B[10] = 0.0;
  B[11] = 0.0;
  D[8] = 0.0;
  D[10] = 0.0;
  B[14] = 0.0;
  B[16] = 0.0;
  B[17] = 0.0;
  D[14] = 0.0;
  D[16] = 0.0;
  D[5] = -Vel_eff;
  D[11] = 0.0;
  D[17] = 0.0;
  for (i = 0; i < 6; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      A2_tmp = i + 6 * i_0;
      A2[A2_tmp] = 0.0;
      for (k = 0; k < 6; k++) {
        A2[A2_tmp] = A[6 * k + i] * A[6 * i_0 + k] + A2[6 * i_0 + i];
      }
    }

    for (i_0 = 0; i_0 < 6; i_0++) {
      A2_tmp = i + 6 * i_0;
      A3[A2_tmp] = 0.0;
      for (k = 0; k < 6; k++) {
        A3[A2_tmp] = A2[6 * k + i] * A[6 * i_0 + k] + A3[6 * i_0 + i];
      }
    }
  }

  for (i = 0; i < 36; i++) {
    I[i] = 0;
  }

  for (k = 0; k < 6; k++) {
    I[k + 6 * k] = 1;
    for (i = 0; i < 3; i++) {
      A2_tmp = k + 6 * i;
      A_0[A2_tmp] = 0.0;
      A2_0[A2_tmp] = 0.0;
      A3_0[A2_tmp] = 0.0;
      for (i_0 = 0; i_0 < 6; i_0++) {
        A_tmp_1 = 6 * i_0 + k;
        A_tmp_2 = 6 * i + k;
        A_0[A2_tmp] = A[A_tmp_1] * B[6 * i + i_0] + A_0[A_tmp_2];
        A2_0[A2_tmp] = A2[A_tmp_1] * B[6 * i + i_0] + A2_0[A_tmp_2];
        A3_0[A2_tmp] = A3[A_tmp_1] * B[6 * i + i_0] + A3_0[A_tmp_2];
      }
    }
  }

  for (i = 0; i < 3; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      k = 6 * i + i_0;
      unusedU1[i_0 + 6 * i] = ((B[k] * 0.05 + A_0[k] * 0.0012500000000000002) +
        A2_0[k] * 2.0833333333333339E-5) + A3_0[k] * 2.6041666666666673E-7;
    }
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  b_I[0] = 1;
  b_I[4] = 1;
  b_I[8] = 1;
  for (i = 0; i < 6; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      A2_tmp = i_0 + 6 * i;
      A3_1[A2_tmp] = 0.0;
      for (k = 0; k < 6; k++) {
        A3_1[A2_tmp] = A3[6 * k + i_0] * A[6 * i + k] + A3_1[6 * i + i_0];
      }
    }
  }

  for (i = 0; i < 6; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      k = 6 * i + i_0;
      Aa[i_0 + 9 * i] = (((A[k] * 0.05 + (real_T)I[k]) + A2[k] *
                          0.0012500000000000002) + A3[k] * 2.0833333333333339E-5)
        + A3_1[k] * 2.6041666666666673E-7;
    }
  }

  for (i = 0; i < 3; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      Aa[i_0 + 9 * (i + 6)] = unusedU1[6 * i + i_0];
    }
  }

  for (i = 0; i < 6; i++) {
    Aa[6 + 9 * i] = 0.0;
    Aa[7 + 9 * i] = 0.0;
    Aa[8 + 9 * i] = 0.0;
  }

  for (i = 0; i < 3; i++) {
    k = 9 * (i + 6);
    Aa[6 + k] = b_I[3 * i];
    Aa[7 + k] = b_I[3 * i + 1];
    Aa[8 + k] = b_I[3 * i + 2];
  }

  for (i = 0; i < 9; i++) {
    b_I[i] = 0;
  }

  for (k = 0; k < 3; k++) {
    b_I[k + 3 * k] = 1;
    for (i = 0; i < 6; i++) {
      Ba[i + 9 * k] = unusedU1[6 * k + i];
    }
  }

  for (i = 0; i < 3; i++) {
    Ba[6 + 9 * i] = b_I[3 * i];
    Ba[7 + 9 * i] = b_I[3 * i + 1];
    Ba[8 + 9 * i] = b_I[3 * i + 2];
    for (i_0 = 0; i_0 < 6; i_0++) {
      A2_tmp = i_0 + 6 * i;
      A_0[A2_tmp] = 0.0;
      A2_0[A2_tmp] = 0.0;
      A3_0[A2_tmp] = 0.0;
      for (k = 0; k < 6; k++) {
        A_tmp_1 = 6 * k + i_0;
        A_tmp_2 = 6 * i + i_0;
        A_0[A2_tmp] = A[A_tmp_1] * D[6 * i + k] + A_0[A_tmp_2];
        A2_0[A2_tmp] = A2[A_tmp_1] * D[6 * i + k] + A2_0[A_tmp_2];
        A3_0[A2_tmp] = A3[A_tmp_1] * D[6 * i + k] + A3_0[A_tmp_2];
      }
    }
  }

  for (i = 0; i < 3; i++) {
    for (i_0 = 0; i_0 < 6; i_0++) {
      k = 6 * i + i_0;
      Da[i_0 + 9 * i] = ((D[k] * 0.05 + A_0[k] * 0.0012500000000000002) + A2_0[k]
                         * 2.0833333333333339E-5) + A3_0[k] *
        2.6041666666666673E-7;
    }

    Da[6 + 9 * i] = 0.0;
    Da[7 + 9 * i] = 0.0;
    Da[8 + 9 * i] = 0.0;
  }

  for (k = 0; k < 12; k++) {
    for (i = 0; i < 9; i++) {
      memcpy(&StateSpaceModel_A_aug[k * 81 + i * 9], &Aa[i * 9], 9U * sizeof
             (real_T));
    }

    for (i = 0; i < 3; i++) {
      for (i_0 = 0; i_0 < 9; i_0++) {
        A2_tmp = 9 * i + i_0;
        A_tmp_1 = (i_0 + 9 * i) + 27 * k;
        StateSpaceModel_B_aug[A_tmp_1] = Ba[A2_tmp];
        StateSpaceModel_D_aug[A_tmp_1] = Da[A2_tmp];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_eye(real_T I[81])
{
  int32_T k;
  memset(&I[0], 0, 81U * sizeof(real_T));
  for (k = 0; k < 9; k++) {
    I[k + 9 * k] = 1.0;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_SystemFurture(const real_T StateSpaceModel_C_aug[54],
  const real_T StateSpaceModel_A_aug[972], const real_T StateSpaceModel_B_aug
  [324], const real_T StateSpaceModel_D_aug[324], const real_T Bezier_SK[12],
  const real_T dist_data[], real_T PSI[648], real_T THETA[1296], real_T GAMMA[36],
  real_T PHI[2592])
{
  int8_T rp[6];
  real_T A_pk[81];
  real_T dist_p[24];
  int32_T p;
  int32_T b;
  int32_T jj;
  real_T StateSpaceModel_A_aug_0[81];
  int32_T i;
  int32_T i_0;
  int8_T p_0;
  int32_T k;
  real_T StateSpaceModel_C_aug_0[54];
  int32_T k_0;
  int32_T StateSpaceModel_A_aug_tmp;
  int32_T PSI_tmp;
  memset(&PSI[0], 0, 648U * sizeof(real_T));
  memset(&THETA[0], 0, 1296U * sizeof(real_T));
  memset(&PHI[0], 0, 2592U * sizeof(real_T));
  memset(&pmpc_hil1_B.Aprod[0], 0, 972U * sizeof(real_T));
  for (p = 0; p < 12; p++) {
    if (1 + p == 1) {
      for (i = 0; i < 9; i++) {
        memcpy(&pmpc_hil1_B.Aprod[i * 9], &StateSpaceModel_A_aug[i * 9], 9U *
               sizeof(real_T));
      }
    } else {
      for (i = 0; i < 9; i++) {
        for (i_0 = 0; i_0 < 9; i_0++) {
          StateSpaceModel_A_aug_tmp = i + 9 * i_0;
          StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] = 0.0;
          for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
            StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] =
              StateSpaceModel_A_aug[(9 * PSI_tmp + i) + 81 * p] *
              pmpc_hil1_B.Aprod[(9 * i_0 + PSI_tmp) + (p - 1) * 81] +
              StateSpaceModel_A_aug_0[9 * i_0 + i];
          }
        }
      }

      for (i = 0; i < 9; i++) {
        memcpy(&pmpc_hil1_B.Aprod[p * 81 + i * 9], &StateSpaceModel_A_aug_0[i *
               9], 9U * sizeof(real_T));
      }
    }
  }

  for (p = 0; p < 12; p++) {
    p_0 = (int8_T)(p * 6 + 1);
    for (i = 0; i < 6; i++) {
      rp[i] = (int8_T)(i + p_0);
    }

    for (k = 0; k < 6; k++) {
      for (i = 0; i < 9; i++) {
        PSI_tmp = (rp[k] + 72 * i) - 1;
        PSI[PSI_tmp] = 0.0;
        for (i_0 = 0; i_0 < 9; i_0++) {
          PSI[PSI_tmp] = pmpc_hil1_B.Aprod[(9 * i + i_0) + 81 * p] *
            StateSpaceModel_C_aug[6 * i_0 + k] + PSI[(72 * i + rp[k]) - 1];
        }
      }

      if (1 + k <= 1 + p) {
        pmpc_hil1_eye(A_pk);
        b = p - k;
        for (jj = 0; jj < b; jj++) {
          k_0 = (k + jj) + 1;
          for (i = 0; i < 9; i++) {
            for (i_0 = 0; i_0 < 9; i_0++) {
              StateSpaceModel_A_aug_tmp = i + 9 * i_0;
              StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] = 0.0;
              for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
                StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] =
                  StateSpaceModel_A_aug[(9 * PSI_tmp + i) + 81 * k_0] * A_pk[9 *
                  i_0 + PSI_tmp] + StateSpaceModel_A_aug_0[9 * i_0 + i];
              }
            }
          }

          for (i = 0; i < 9; i++) {
            memcpy(&A_pk[i * 9], &StateSpaceModel_A_aug_0[i * 9], 9U * sizeof
                   (real_T));
          }
        }

        k_0 = k * 3;
        for (i = 0; i < 6; i++) {
          for (i_0 = 0; i_0 < 9; i_0++) {
            StateSpaceModel_A_aug_tmp = i + 6 * i_0;
            StateSpaceModel_C_aug_0[StateSpaceModel_A_aug_tmp] = 0.0;
            for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
              StateSpaceModel_C_aug_0[StateSpaceModel_A_aug_tmp] =
                StateSpaceModel_C_aug[6 * PSI_tmp + i] * A_pk[9 * i_0 + PSI_tmp]
                + StateSpaceModel_C_aug_0[6 * i_0 + i];
            }
          }

          for (i_0 = 0; i_0 < 3; i_0++) {
            StateSpaceModel_A_aug_tmp = i_0 + k_0;
            b = (rp[i] + 72 * StateSpaceModel_A_aug_tmp) - 1;
            THETA[b] = 0.0;
            for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
              THETA[b] = THETA[(StateSpaceModel_A_aug_tmp * 72 + rp[i]) - 1] +
                StateSpaceModel_B_aug[(9 * i_0 + PSI_tmp) + 27 * k] *
                StateSpaceModel_C_aug_0[6 * PSI_tmp + i];
            }
          }
        }
      }
    }

    for (k = 0; k < 12; k++) {
      if (1 + k <= 1 + p) {
        pmpc_hil1_eye(A_pk);
        b = p - k;
        for (jj = 0; jj < b; jj++) {
          k_0 = (k + jj) + 1;
          for (i = 0; i < 9; i++) {
            for (i_0 = 0; i_0 < 9; i_0++) {
              StateSpaceModel_A_aug_tmp = i + 9 * i_0;
              StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] = 0.0;
              for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
                StateSpaceModel_A_aug_0[StateSpaceModel_A_aug_tmp] =
                  StateSpaceModel_A_aug[(9 * PSI_tmp + i) + 81 * k_0] * A_pk[9 *
                  i_0 + PSI_tmp] + StateSpaceModel_A_aug_0[9 * i_0 + i];
              }
            }
          }

          for (i = 0; i < 9; i++) {
            memcpy(&A_pk[i * 9], &StateSpaceModel_A_aug_0[i * 9], 9U * sizeof
                   (real_T));
          }
        }

        k_0 = k * 3;
        for (i = 0; i < 6; i++) {
          for (i_0 = 0; i_0 < 9; i_0++) {
            StateSpaceModel_A_aug_tmp = i + 6 * i_0;
            StateSpaceModel_C_aug_0[StateSpaceModel_A_aug_tmp] = 0.0;
            for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
              StateSpaceModel_C_aug_0[StateSpaceModel_A_aug_tmp] =
                StateSpaceModel_C_aug[6 * PSI_tmp + i] * A_pk[9 * i_0 + PSI_tmp]
                + StateSpaceModel_C_aug_0[6 * i_0 + i];
            }
          }

          for (i_0 = 0; i_0 < 3; i_0++) {
            StateSpaceModel_A_aug_tmp = i_0 + k_0;
            b = (rp[i] + 72 * StateSpaceModel_A_aug_tmp) - 1;
            PHI[b] = 0.0;
            for (PSI_tmp = 0; PSI_tmp < 9; PSI_tmp++) {
              PHI[b] = PHI[(StateSpaceModel_A_aug_tmp * 72 + rp[i]) - 1] +
                StateSpaceModel_D_aug[(9 * i_0 + PSI_tmp) + 27 * k] *
                StateSpaceModel_C_aug_0[6 * PSI_tmp + i];
            }
          }
        }
      }
    }

    dist_p[p << 1] = dist_data[0];
    dist_p[1 + (p << 1)] = dist_data[1];
    GAMMA[3 * p] = Bezier_SK[p];
    GAMMA[1 + 3 * p] = dist_p[p << 1];
    GAMMA[2 + 3 * p] = dist_p[(p << 1) + 1];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron(const real_T B[3], real_T K[18])
{
  int32_T kidx;
  int32_T i1;
  kidx = -1;
  for (i1 = 0; i1 < 6; i1++) {
    kidx++;
    K[kidx] = B[0];
    kidx++;
    K[kidx] = B[1];
    kidx++;
    K[kidx] = B[2];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_diag_e(const real_T v[64], real_T d[8])
{
  int32_T k;
  for (k = 0; k < 8; k++) {
    d[k] = v[(k << 3) + k];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_BuildQPCost(const real_T Pred_PSI[648], const real_T
  Pred_THETA[1296], const real_T Pred_PHI[2592], const real_T Pred_GAMMA[36],
  const real_T Wts_Q[5184], const real_T Wts_R[324], const real_T Wts_S[324],
  const real_T Wts_W[64], const real_T zeta[9], const real_T AI[324], const
  real_T Ut[18], const real_T ref_Vy[12], const real_T ref_r[12], real_T H[676],
  real_T f[26])
{
  static const real_T y[676] = { 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-8 };

  static const real_T eps_scale[8] = { 0.87266462599716477, 0.87266462599716477,
    0.87266462599716477, 0.87266462599716477, 3.0, 3.0, 8.0, 8.0 };

  real_T tmp[8];
  int32_T i;
  int32_T i_0;
  real_T AI_0[324];
  real_T Pred_THETA_0[324];
  real_T AI_1[324];
  real_T tmp_0;
  real_T Pred_PSI_0[72];
  real_T Pred_PHI_0[72];
  real_T ref_Vy_0[72];
  real_T Pred_PSI_1[72];
  real_T Wts_S_0[18];
  real_T Pred_THETA_1[18];
  real_T AI_2[18];
  int32_T Pred_THETA_tmp;
  int32_T H_tmp;
  memset(&H[0], 0, 676U * sizeof(real_T));
  for (i = 0; i < 18; i++) {
    for (i_0 = 0; i_0 < 72; i_0++) {
      Pred_THETA_tmp = i + 18 * i_0;
      pmpc_hil1_B.Pred_THETA[Pred_THETA_tmp] = 0.0;
      for (H_tmp = 0; H_tmp < 72; H_tmp++) {
        pmpc_hil1_B.Pred_THETA[Pred_THETA_tmp] = Pred_THETA[72 * i + H_tmp] *
          Wts_Q[72 * i_0 + H_tmp] + pmpc_hil1_B.Pred_THETA[18 * i_0 + i];
      }
    }

    for (i_0 = 0; i_0 < 18; i_0++) {
      Pred_THETA_tmp = i + 18 * i_0;
      AI_0[Pred_THETA_tmp] = 0.0;
      for (H_tmp = 0; H_tmp < 18; H_tmp++) {
        AI_0[Pred_THETA_tmp] = AI[18 * i + H_tmp] * Wts_S[18 * i_0 + H_tmp] +
          AI_0[18 * i_0 + i];
      }

      tmp_0 = 0.0;
      for (H_tmp = 0; H_tmp < 72; H_tmp++) {
        tmp_0 += pmpc_hil1_B.Pred_THETA[18 * H_tmp + i] * Pred_THETA[72 * i_0 +
          H_tmp];
      }

      Pred_THETA_0[Pred_THETA_tmp] = Wts_R[18 * i_0 + i] + tmp_0;
    }

    for (i_0 = 0; i_0 < 18; i_0++) {
      Pred_THETA_tmp = i + 18 * i_0;
      AI_1[Pred_THETA_tmp] = 0.0;
      for (H_tmp = 0; H_tmp < 18; H_tmp++) {
        AI_1[Pred_THETA_tmp] = AI_0[18 * H_tmp + i] * AI[18 * i_0 + H_tmp] +
          AI_1[18 * i_0 + i];
      }
    }
  }

  for (i = 0; i < 18; i++) {
    for (i_0 = 0; i_0 < 18; i_0++) {
      H_tmp = 18 * i + i_0;
      H[i_0 + 26 * i] = (Pred_THETA_0[H_tmp] + AI_1[H_tmp]) * 2.0;
    }
  }

  for (i = 0; i < 8; i++) {
    for (i_0 = 0; i_0 < 8; i_0++) {
      H[(i_0 + 26 * (18 + i)) + 18] = Wts_W[(i << 3) + i_0] * 24.0;
    }
  }

  for (i = 0; i < 26; i++) {
    for (i_0 = 0; i_0 < 26; i_0++) {
      H_tmp = 26 * i + i_0;
      pmpc_hil1_B.H_c[i_0 + 26 * i] = (H[H_tmp] + H[26 * i_0 + i]) / 2.0 +
        y[H_tmp];
    }
  }

  for (i = 0; i < 26; i++) {
    memcpy(&H[i * 26], &pmpc_hil1_B.H_c[i * 26], 26U * sizeof(real_T));
  }

  pmpc_hil1_diag_e(Wts_W, tmp);
  for (i = 0; i < 72; i++) {
    Pred_PSI_0[i] = 0.0;
    for (i_0 = 0; i_0 < 9; i_0++) {
      Pred_PSI_0[i] += Pred_PSI[72 * i_0 + i] * zeta[i_0];
    }

    Pred_PHI_0[i] = 0.0;
    for (i_0 = 0; i_0 < 36; i_0++) {
      Pred_PHI_0[i] += Pred_PHI[72 * i_0 + i] * Pred_GAMMA[i_0];
    }
  }

  for (i = 0; i < 12; i++) {
    ref_Vy_0[6 * i] = ref_Vy[i];
    ref_Vy_0[1 + 6 * i] = ref_r[i];
    ref_Vy_0[2 + 6 * i] = 0.0;
    ref_Vy_0[3 + 6 * i] = 0.0;
    ref_Vy_0[4 + 6 * i] = 0.0;
    ref_Vy_0[5 + 6 * i] = 0.0;
  }

  for (i = 0; i < 72; i++) {
    Pred_PSI_1[i] = (Pred_PSI_0[i] + Pred_PHI_0[i]) - ref_Vy_0[i];
  }

  for (i = 0; i < 72; i++) {
    Pred_PSI_0[i] = 0.0;
    for (i_0 = 0; i_0 < 72; i_0++) {
      Pred_PSI_0[i] += Wts_Q[72 * i_0 + i] * Pred_PSI_1[i_0];
    }
  }

  for (i = 0; i < 18; i++) {
    Wts_S_0[i] = 0.0;
    for (i_0 = 0; i_0 < 18; i_0++) {
      Wts_S_0[i] += Wts_S[18 * i_0 + i] * Ut[i_0];
    }

    Pred_THETA_1[i] = 0.0;
    for (i_0 = 0; i_0 < 72; i_0++) {
      Pred_THETA_1[i] += Pred_THETA[72 * i + i_0] * Pred_PSI_0[i_0];
    }
  }

  for (i = 0; i < 18; i++) {
    AI_2[i] = 0.0;
    for (i_0 = 0; i_0 < 18; i_0++) {
      AI_2[i] += AI[18 * i + i_0] * Wts_S_0[i_0];
    }

    f[i] = (Pred_THETA_1[i] + AI_2[i]) * 2.0;
  }

  for (i = 0; i < 8; i++) {
    f[i + 18] = 12.0 * tmp[i] * eps_scale[i];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_k(const real_T A[36], const real_T B[24], real_T K
  [864])
{
  int32_T kidx;
  int32_T b_j1;
  int32_T j2;
  int32_T i1;
  kidx = -1;
  for (b_j1 = 0; b_j1 < 6; b_j1++) {
    for (j2 = 0; j2 < 6; j2++) {
      for (i1 = 0; i1 < 6; i1++) {
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[j2 << 2];
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[(j2 << 2) + 1];
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[(j2 << 2) + 2];
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[(j2 << 2) + 3];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_kaq(const real_T A[144], const real_T B[12], real_T
  K[1728])
{
  int32_T kidx;
  int32_T b_j1;
  int32_T j2;
  int32_T i1;
  kidx = -1;
  for (b_j1 = 0; b_j1 < 12; b_j1++) {
    for (j2 = 0; j2 < 6; j2++) {
      for (i1 = 0; i1 < 12; i1++) {
        kidx++;
        K[kidx] = A[12 * b_j1 + i1] * B[j2 << 1];
        kidx++;
        K[kidx] = A[12 * b_j1 + i1] * B[(j2 << 1) + 1];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_kaqb3(const real_T A[36], const real_T B[12], real_T
  K[432])
{
  int32_T kidx;
  int32_T b_j1;
  int32_T j2;
  int32_T i1;
  kidx = -1;
  for (b_j1 = 0; b_j1 < 6; b_j1++) {
    for (j2 = 0; j2 < 6; j2++) {
      for (i1 = 0; i1 < 6; i1++) {
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[j2 << 1];
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[(j2 << 1) + 1];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_kaqb31d(const real_T A[36], const real_T B[6], real_T
  K[216])
{
  int32_T kidx;
  int32_T b_j1;
  int32_T j2;
  int32_T i1;
  kidx = -1;
  for (b_j1 = 0; b_j1 < 6; b_j1++) {
    for (j2 = 0; j2 < 3; j2++) {
      for (i1 = 0; i1 < 6; i1++) {
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[j2 << 1];
        kidx++;
        K[kidx] = A[6 * b_j1 + i1] * B[(j2 << 1) + 1];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_ka(const real_T B[4], real_T K[24])
{
  int32_T kidx;
  int32_T i1;
  kidx = -1;
  for (i1 = 0; i1 < 6; i1++) {
    kidx++;
    K[kidx] = B[0];
    kidx++;
    K[kidx] = B[1];
    kidx++;
    K[kidx] = B[2];
    kidx++;
    K[kidx] = B[3];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_kaqb31(const real_T B[2], real_T K[12])
{
  int32_T kidx;
  int32_T i1;
  kidx = -1;
  for (i1 = 0; i1 < 6; i1++) {
    kidx++;
    K[kidx] = B[0];
    kidx++;
    K[kidx] = B[1];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_kron_kaqb(const real_T B[2], real_T K[24])
{
  int32_T kidx;
  int32_T i1;
  kidx = -1;
  for (i1 = 0; i1 < 12; i1++) {
    kidx++;
    K[kidx] = B[0];
    kidx++;
    K[kidx] = B[1];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hi_func_BuildQPConstraints(const real_T Envelope_Henv[12],
  const real_T Envelope_Genv[2], const real_T Envelope_Hsh[24], const real_T
  Envelope_Gsh[4], const real_T Envelope_Hr[12], const real_T Envelope_Or[6],
  const real_T Envelope_Gr[2], const real_T Pred_PSI[648], const real_T
  Pred_THETA[1296], const real_T Pred_PHI[2592], const real_T Pred_GAMMA[36],
  const real_T AI[324], const real_T Ut[18], const real_T zeta[9], real_T
  Lim_MFxmax, real_T Lim_Mdmax, real_T Lim_Mdmin, const real_T Lim_eps_ub[8],
  real_T Lim_dMFxmax, real_T Lim_dMdmax, real_T Lim_dlt_ub, real_T Lim_dlt_lb,
  real_T A_cons[2496], real_T b_cons[96], real_T lb[26], real_T ub[26], real_T
  umax[3], real_T umin[3])
{
  real_T xi0[72];
  real_T Md_up;
  real_T Md_low;
  real_T du_v[3];
  real_T O_r[216];
  real_T z1[3];
  static const int8_T b[2592] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0 };

  static const int8_T b_b[5184] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  static const real_T c[36] = { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  static const int8_T y[192] = { -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0,
    0, -1, 0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0,
    0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1,
    0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0,
    -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0 };

  static const int8_T b_y[96] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 0, -1, 0, -1, 0,
    -1, 0, -1, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0 };

  static const int8_T c_y[192] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0,
    -1, 0, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1,
    0, -1, 0, -1 };

  static const real_T a[144] = { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  real_T tmp[12];
  real_T tmp_0[24];
  real_T tmp_1[18];
  real_T tmp_2[18];
  real_T Pred_PSI_0[72];
  real_T Pred_PHI_0[72];
  int32_T i;
  int32_T i_0;
  real_T A_sh[432];
  real_T a_0[216];
  real_T A_r[216];
  real_T a_1[216];
  real_T tmp_3[12];
  real_T a_2[12];
  real_T u0;
  boolean_T tmp_4;
  int32_T A_sh_tmp;
  int32_T A_cons_tmp;
  for (i = 0; i < 72; i++) {
    Pred_PSI_0[i] = 0.0;
    for (i_0 = 0; i_0 < 9; i_0++) {
      Pred_PSI_0[i] += Pred_PSI[72 * i_0 + i] * zeta[i_0];
    }

    Pred_PHI_0[i] = 0.0;
    for (i_0 = 0; i_0 < 36; i_0++) {
      Pred_PHI_0[i] += Pred_PHI[72 * i_0 + i] * Pred_GAMMA[i_0];
    }

    xi0[i] = Pred_PSI_0[i] + Pred_PHI_0[i];
  }

  tmp_4 = rtIsNaN(Lim_Mdmin);
  if ((Lim_Mdmax > Lim_Mdmin) || tmp_4) {
    Md_up = Lim_Mdmax;
  } else {
    Md_up = Lim_Mdmin;
  }

  if ((Lim_Mdmax < Lim_Mdmin) || tmp_4) {
    Md_low = Lim_Mdmax;
  } else {
    Md_low = Lim_Mdmin;
  }

  umax[1] = 0.95 * Lim_MFxmax;
  u0 = (real_T)(Md_up >= 0.0) * 0.9 * Md_up + (real_T)(Md_up < 0.0) * 1.1 *
    Md_up;
  if ((u0 < Md_up) || rtIsNaN(Md_up)) {
    umax[2] = u0;
  } else {
    umax[2] = Md_up;
  }

  umin[1] = -0.95 * Lim_MFxmax;
  u0 = (real_T)(Md_low <= 0.0) * 0.9 * Md_low + (real_T)(Md_low > 0.0) * 1.1 *
    Md_low;
  if ((u0 > Md_low) || rtIsNaN(Md_low)) {
    umin[2] = u0;
  } else {
    umin[2] = Md_low;
  }

  if ((Lim_dlt_ub > zeta[6] - 0.0073919827143289251) || rtIsNaN(zeta[6] -
       0.0073919827143289251)) {
    u0 = Lim_dlt_ub;
  } else {
    u0 = zeta[6] - 0.0073919827143289251;
  }

  umax[0] = u0;
  z1[0] = u0;
  Md_up = zeta[7] - Lim_dMFxmax;
  if ((umax[1] > Md_up) || rtIsNaN(Md_up)) {
    u0 = umax[1];
  } else {
    u0 = Md_up;
  }

  Md_low = zeta[7] + Lim_dMFxmax;
  umax[1] = u0;
  z1[1] = u0;
  Md_up = zeta[8] - Lim_dMdmax;
  if ((umax[2] > Md_up) || rtIsNaN(Md_up)) {
    u0 = umax[2];
  } else {
    u0 = Md_up;
  }

  Md_up = zeta[8] + Lim_dMdmax;
  umax[2] = u0;
  z1[2] = u0;
  if ((Lim_dlt_lb < zeta[6] + 0.0073919827143289251) || rtIsNaN(zeta[6] +
       0.0073919827143289251)) {
    u0 = Lim_dlt_lb;
  } else {
    u0 = zeta[6] + 0.0073919827143289251;
  }

  umin[0] = u0;
  du_v[0] = u0;
  if ((umin[1] < Md_low) || rtIsNaN(Md_low)) {
    u0 = umin[1];
  } else {
    u0 = Md_low;
  }

  umin[1] = u0;
  du_v[1] = u0;
  if ((umin[2] < Md_up) || rtIsNaN(Md_up)) {
    u0 = umin[2];
  } else {
    u0 = Md_up;
  }

  umin[2] = u0;
  du_v[2] = u0;
  pmpc_hil1_kron_k(c, Envelope_Hsh, pmpc_hil1_B.dv2);
  pmpc_hil1_kron_kaq(a, Envelope_Henv, pmpc_hil1_B.dv1);
  pmpc_hil1_kron_kaqb3(c, Envelope_Hr, A_sh);
  for (i = 0; i < 72; i++) {
    for (i_0 = 0; i_0 < 24; i_0++) {
      A_sh_tmp = i_0 + 24 * i;
      pmpc_hil1_B.A_sh[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 36; A_cons_tmp++) {
        pmpc_hil1_B.A_sh[A_sh_tmp] = pmpc_hil1_B.dv2[24 * A_cons_tmp + i_0] *
          (real_T)b[36 * i + A_cons_tmp] + pmpc_hil1_B.A_sh[24 * i + i_0];
      }

      pmpc_hil1_B.A_env[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 72; A_cons_tmp++) {
        pmpc_hil1_B.A_env[A_sh_tmp] = pmpc_hil1_B.dv1[24 * A_cons_tmp + i_0] *
          (real_T)b_b[72 * i + A_cons_tmp] + pmpc_hil1_B.A_env[24 * i + i_0];
      }
    }

    for (i_0 = 0; i_0 < 12; i_0++) {
      A_sh_tmp = i_0 + 12 * i;
      pmpc_hil1_B.A_r[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 36; A_cons_tmp++) {
        pmpc_hil1_B.A_r[A_sh_tmp] = A_sh[12 * A_cons_tmp + i_0] * (real_T)b[36 *
          i + A_cons_tmp] + pmpc_hil1_B.A_r[12 * i + i_0];
      }
    }
  }

  pmpc_hil1_kron_kaqb31d(c, Envelope_Or, O_r);
  memset(&A_cons[0], 0, 2496U * sizeof(real_T));
  memset(&b_cons[0], 0, 96U * sizeof(real_T));
  for (i = 0; i < 18; i++) {
    memcpy(&A_cons[i * 96], &AI[i * 18], 18U * sizeof(real_T));
  }

  for (i = 0; i < 8; i++) {
    memset(&A_cons[i * 96 + 1728], 0, 18U * sizeof(real_T));
  }

  for (i = 0; i < 18; i++) {
    for (i_0 = 0; i_0 < 18; i_0++) {
      A_cons[(i_0 + 96 * i) + 18] = -AI[18 * i + i_0];
    }
  }

  for (i = 0; i < 8; i++) {
    memset(&A_cons[i * 96 + 1746], 0, 18U * sizeof(real_T));
  }

  pmpc_hil1_kron(z1, tmp_1);
  pmpc_hil1_kron(du_v, tmp_2);
  for (i = 0; i < 18; i++) {
    b_cons[i] = tmp_1[i] - Ut[i];
    b_cons[i + 18] = Ut[i] - tmp_2[i];
    for (i_0 = 0; i_0 < 24; i_0++) {
      A_sh_tmp = i_0 + 24 * i;
      A_sh[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 72; A_cons_tmp++) {
        A_sh[A_sh_tmp] = pmpc_hil1_B.A_sh[24 * A_cons_tmp + i_0] * Pred_THETA[72
          * i + A_cons_tmp] + A_sh[24 * i + i_0];
      }
    }
  }

  for (i = 0; i < 18; i++) {
    memcpy(&A_cons[i * 96 + 36], &A_sh[i * 24], 24U * sizeof(real_T));
  }

  for (i = 0; i < 8; i++) {
    for (i_0 = 0; i_0 < 24; i_0++) {
      A_cons[(i_0 + 96 * (i + 18)) + 36] = y[24 * i + i_0];
    }
  }

  pmpc_hil1_kron_ka(Envelope_Gsh, tmp_0);
  for (i = 0; i < 24; i++) {
    Md_up = 0.0;
    for (i_0 = 0; i_0 < 72; i_0++) {
      Md_up += pmpc_hil1_B.A_sh[24 * i_0 + i] * xi0[i_0];
    }

    b_cons[36 + i] = tmp_0[i] - Md_up;
  }

  for (i = 0; i < 12; i++) {
    for (i_0 = 0; i_0 < 18; i_0++) {
      A_sh_tmp = i + 12 * i_0;
      a_0[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 12; A_cons_tmp++) {
        a_0[A_sh_tmp] = a[12 * A_cons_tmp + i] * O_r[12 * i_0 + A_cons_tmp] +
          a_0[12 * i_0 + i];
      }

      A_r[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 72; A_cons_tmp++) {
        A_r[A_sh_tmp] = pmpc_hil1_B.A_r[12 * A_cons_tmp + i] * Pred_THETA[72 *
          i_0 + A_cons_tmp] + A_r[12 * i_0 + i];
      }
    }

    for (i_0 = 0; i_0 < 18; i_0++) {
      A_sh_tmp = i + 12 * i_0;
      a_1[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 18; A_cons_tmp++) {
        a_1[A_sh_tmp] = a_0[12 * A_cons_tmp + i] * AI[18 * i_0 + A_cons_tmp] +
          a_1[12 * i_0 + i];
      }
    }
  }

  for (i = 0; i < 18; i++) {
    for (i_0 = 0; i_0 < 12; i_0++) {
      A_cons_tmp = 12 * i + i_0;
      A_cons[(i_0 + 96 * i) + 60] = A_r[A_cons_tmp] + a_1[A_cons_tmp];
    }
  }

  for (i = 0; i < 8; i++) {
    for (i_0 = 0; i_0 < 12; i_0++) {
      A_cons[(i_0 + 96 * (i + 18)) + 60] = b_y[12 * i + i_0];
    }
  }

  pmpc_hil1_kron_kaqb31(Envelope_Gr, tmp);
  for (i = 0; i < 12; i++) {
    for (i_0 = 0; i_0 < 18; i_0++) {
      A_sh_tmp = i + 12 * i_0;
      a_0[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 12; A_cons_tmp++) {
        a_0[A_sh_tmp] = a[12 * A_cons_tmp + i] * O_r[12 * i_0 + A_cons_tmp] +
          a_0[12 * i_0 + i];
      }
    }

    Md_up = 0.0;
    for (i_0 = 0; i_0 < 72; i_0++) {
      Md_up += pmpc_hil1_B.A_r[12 * i_0 + i] * xi0[i_0];
    }

    tmp_3[i] = tmp[i] - Md_up;
    a_2[i] = 0.0;
    for (i_0 = 0; i_0 < 18; i_0++) {
      a_2[i] += a_0[12 * i_0 + i] * Ut[i_0];
    }

    b_cons[60 + i] = tmp_3[i] - a_2[i];
  }

  for (i = 0; i < 18; i++) {
    for (i_0 = 0; i_0 < 24; i_0++) {
      A_sh_tmp = i_0 + 24 * i;
      A_sh[A_sh_tmp] = 0.0;
      for (A_cons_tmp = 0; A_cons_tmp < 72; A_cons_tmp++) {
        A_sh[A_sh_tmp] = pmpc_hil1_B.A_env[24 * A_cons_tmp + i_0] * Pred_THETA
          [72 * i + A_cons_tmp] + A_sh[24 * i + i_0];
      }
    }
  }

  for (i = 0; i < 18; i++) {
    memcpy(&A_cons[i * 96 + 72], &A_sh[i * 24], 24U * sizeof(real_T));
  }

  for (i = 0; i < 8; i++) {
    for (i_0 = 0; i_0 < 24; i_0++) {
      A_cons[(i_0 + 96 * (i + 18)) + 72] = c_y[24 * i + i_0];
    }
  }

  pmpc_hil1_kron_kaqb(Envelope_Genv, tmp_0);
  for (i = 0; i < 24; i++) {
    Md_up = 0.0;
    for (i_0 = 0; i_0 < 72; i_0++) {
      Md_up += pmpc_hil1_B.A_env[24 * i_0 + i] * xi0[i_0];
    }

    b_cons[72 + i] = tmp_0[i] - Md_up;
  }

  du_v[0] = 0.0073919827143289251;
  du_v[1] = Lim_dMFxmax;
  du_v[2] = Lim_dMdmax;
  z1[0] = -0.0073919827143289251;
  z1[1] = -Lim_dMFxmax;
  z1[2] = -Lim_dMdmax;
  pmpc_hil1_kron(z1, tmp_1);
  memcpy(&lb[0], &tmp_1[0], 18U * sizeof(real_T));
  memset(&lb[18], 0, sizeof(real_T) << 3U);
  pmpc_hil1_kron(du_v, tmp_1);
  memcpy(&ub[0], &tmp_1[0], 18U * sizeof(real_T));
  memcpy(&ub[18], &Lim_eps_ub[0], sizeof(real_T) << 3U);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_isfinite_c(const real_T x[26], boolean_T b[26])
{
  int32_T i;
  for (i = 0; i < 26; i++) {
    b[i] = ((!rtIsInf(x[i])) && (!rtIsNaN(x[i])));
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_all(const boolean_T x[26])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 26)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_isfinite_cn5(const real_T x[676], boolean_T b[676])
{
  int32_T i;
  for (i = 0; i < 676; i++) {
    b[i] = ((!rtIsInf(x[i])) && (!rtIsNaN(x[i])));
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_all_n(const boolean_T x[676])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 676)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_isfinite_cn5c(const real_T x[2496], boolean_T b[2496])
{
  int32_T i;
  for (i = 0; i < 2496; i++) {
    b[i] = ((!rtIsInf(x[i])) && (!rtIsNaN(x[i])));
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_all_ns(const boolean_T x[2496])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2496)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_isfinite_cn5ck(const real_T x[96], boolean_T b[96])
{
  int32_T i;
  for (i = 0; i < 96; i++) {
    b[i] = ((!rtIsInf(x[i])) && (!rtIsNaN(x[i])));
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_all_ns5(const boolean_T x[96])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 96)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_any(const boolean_T x[26])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 26)) {
    if (x[k]) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static boolean_T pmpc_hil1_isfinite(real_T x)
{
  return (!rtIsInf(x)) && (!rtIsNaN(x));
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_diag_eek(const real_T v[676], real_T d[26])
{
  int32_T k;
  for (k = 0; k < 26; k++) {
    d[k] = v[26 * k + k];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_sqrt_fk(real_T x[26])
{
  int32_T k;
  for (k = 0; k < 26; k++) {
    x[k] = std::sqrt(x[k]);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_bsxfun(const real_T a[2496], const real_T b[26], real_T c
  [2496])
{
  int32_T k;
  int32_T b_k;
  for (k = 0; k < 26; k++) {
    for (b_k = 0; b_k < 96; b_k++) {
      c[b_k + 96 * k] = a[96 * k + b_k] * b[k];
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_local_warmstart(boolean_T iA_data[], int32_T *iA_size)
{
  if (!pmpc_hil1_DW.iA_ws_not_empty) {
    pmpc_hil1_DW.iA_ws.size = 148;
    memset(&pmpc_hil1_DW.iA_ws.data[0], 0, 148U * sizeof(boolean_T));
    pmpc_hil1_DW.iA_ws_not_empty = true;
  }

  *iA_size = 148;
  memcpy(&iA_data[0], &pmpc_hil1_DW.iA_ws.data[0], 148U * sizeof(boolean_T));
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_xpotrf(real_T A_data[], int32_T A_size[2], int32_T lda)
{
  int32_T info;
  int32_T n;
  int32_T jj;
  real_T ajj;
  int32_T j;
  int32_T ix;
  int32_T iy;
  int32_T k;
  real_T c;
  int32_T b_iy;
  int32_T iac;
  int32_T e;
  int32_T ia;
  boolean_T exitg1;
  n = A_size[0];
  info = 0;
  j = 0;
  exitg1 = false;
  while ((!exitg1) && (j + 1 <= n)) {
    jj = j * lda + j;
    ajj = 0.0;
    if (!(j < 1)) {
      ix = j;
      iy = j;
      for (k = 1; k <= j; k++) {
        ajj += A_data[ix] * A_data[iy];
        ix += lda;
        iy += lda;
      }
    }

    ajj = A_data[jj] - ajj;
    if (ajj > 0.0) {
      ajj = std::sqrt(ajj);
      A_data[jj] = ajj;
      if (j + 1 < n) {
        ix = (n - j) - 1;
        if (j != 0) {
          iy = j;
          k = ((j - 1) * lda + j) + 2;
          for (iac = j + 2; iac <= k; iac += lda) {
            c = -A_data[iy];
            b_iy = jj + 1;
            e = (iac + ix) - 1;
            for (ia = iac; ia <= e; ia++) {
              A_data[b_iy] += A_data[ia - 1] * c;
              b_iy++;
            }

            iy += lda;
          }
        }

        ajj = 1.0 / ajj;
        ix += jj;
        for (jj++; jj < ix + 1; jj++) {
          A_data[jj] *= ajj;
        }
      }

      j++;
    } else {
      A_data[jj] = ajj;
      info = j + 1;
      exitg1 = true;
    }
  }

  return info;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_cholesky(real_T A_data[], int32_T A_size[2])
{
  int32_T info;
  int32_T n;
  int32_T i;
  int32_T loop_ub;
  int32_T i_0;
  int32_T loop_ub_0;
  int32_T b_A_size[2];
  n = A_size[1];
  b_A_size[0] = A_size[0];
  b_A_size[1] = A_size[1];
  loop_ub = A_size[0] * A_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&pmpc_hil1_B.b_A_data_g[0], &A_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  info = pmpc_hil1_xpotrf(pmpc_hil1_B.b_A_data_g, b_A_size, A_size[1]);
  A_size[0] = b_A_size[0];
  A_size[1] = b_A_size[1];
  loop_ub = b_A_size[1];
  for (i = 0; i < loop_ub; i++) {
    loop_ub_0 = b_A_size[0];
    for (i_0 = 0; i_0 < loop_ub_0; i_0++) {
      A_data[i_0 + A_size[0] * i] = pmpc_hil1_B.b_A_data_g[b_A_size[0] * i + i_0];
    }
  }

  if (info != 0) {
    n = info - 1;
  }

  for (loop_ub = 1; loop_ub < n; loop_ub++) {
    for (i = 1; i <= loop_ub; i++) {
      A_data[(i + A_size[0] * loop_ub) - 1] = 0.0;
    }
  }

  if (1 > n) {
    n = 0;
    loop_ub = 0;
  } else {
    loop_ub = n;
  }

  for (i = 0; i < loop_ub; i++) {
    for (i_0 = 0; i_0 < n; i_0++) {
      pmpc_hil1_B.b_A_data_g[i_0 + n * i] = A_data[A_size[0] * i + i_0];
    }
  }

  A_size[0] = n;
  A_size[1] = loop_ub;
  for (i = 0; i < loop_ub; i++) {
    for (i_0 = 0; i_0 < n; i_0++) {
      A_data[i_0 + A_size[0] * i] = pmpc_hil1_B.b_A_data_g[n * i + i_0];
    }
  }

  return info;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_ixamax_n(int32_T n, const real_T x_data[], int32_T ix0)
{
  int32_T idxmax;
  int32_T ix;
  real_T smax;
  real_T s;
  int32_T k;
  if (n < 1) {
    idxmax = 0;
  } else {
    idxmax = 1;
    if (n > 1) {
      ix = ix0 - 1;
      smax = std::abs(x_data[ix0 - 1]);
      for (k = 2; k <= n; k++) {
        ix++;
        s = std::abs(x_data[ix]);
        if (s > smax) {
          idxmax = k;
          smax = s;
        }
      }
    }
  }

  return idxmax;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xswap(int32_T n, real_T x_data[], int32_T ix0, int32_T iy0)
{
  int32_T ix;
  int32_T iy;
  real_T temp;
  int32_T k;
  ix = ix0 - 1;
  iy = iy0 - 1;
  for (k = 1; k <= n; k++) {
    temp = x_data[ix];
    x_data[ix] = x_data[iy];
    x_data[iy] = temp;
    ix++;
    iy++;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_xnrm2(int32_T n, const real_T x_data[], int32_T ix0)
{
  real_T y;
  real_T scale;
  int32_T kend;
  real_T absxk;
  real_T t;
  int32_T k;
  y = 0.0;
  if (!(n < 1)) {
    if (n == 1) {
      y = std::abs(x_data[ix0 - 1]);
    } else {
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (k = ix0; k <= kend; k++) {
        absxk = std::abs(x_data[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * std::sqrt(y);
    }
  }

  return y;
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  a = std::abs(u0);
  y = std::abs(u1);
  if (a < y) {
    a /= y;
    y *= std::sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = std::sqrt(y * y + 1.0) * a;
  } else {
    if (!rtIsNaN(y)) {
      y = a * 1.4142135623730951;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_xzlarfg(int32_T n, real_T *alpha1, real_T x_data[],
  int32_T ix0)
{
  real_T tau;
  real_T xnorm;
  int32_T knt;
  int32_T b_k;
  int32_T c_k;
  tau = 0.0;
  if (!(n <= 0)) {
    xnorm = pmpc_hil1_xnrm2(n - 1, x_data, ix0);
    if (xnorm != 0.0) {
      xnorm = rt_hypotd_snf(*alpha1, xnorm);
      if (*alpha1 >= 0.0) {
        xnorm = -xnorm;
      }

      if (std::abs(xnorm) < 1.0020841800044864E-292) {
        knt = 0;
        b_k = (ix0 + n) - 2;
        do {
          knt++;
          for (c_k = ix0; c_k <= b_k; c_k++) {
            x_data[c_k - 1] *= 9.9792015476736E+291;
          }

          xnorm *= 9.9792015476736E+291;
          *alpha1 *= 9.9792015476736E+291;
        } while (!(std::abs(xnorm) >= 1.0020841800044864E-292));

        xnorm = rt_hypotd_snf(*alpha1, pmpc_hil1_xnrm2(n - 1, x_data, ix0));
        if (*alpha1 >= 0.0) {
          xnorm = -xnorm;
        }

        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        b_k = (ix0 + n) - 2;
        for (c_k = ix0; c_k <= b_k; c_k++) {
          x_data[c_k - 1] *= *alpha1;
        }

        for (b_k = 1; b_k <= knt; b_k++) {
          xnorm *= 1.0020841800044864E-292;
        }

        *alpha1 = xnorm;
      } else {
        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        knt = (ix0 + n) - 2;
        for (b_k = ix0; b_k <= knt; b_k++) {
          x_data[b_k - 1] *= *alpha1;
        }

        *alpha1 = xnorm;
      }
    }
  }

  return tau;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_ilazlc(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda)
{
  int32_T j;
  int32_T coltop;
  int32_T ia;
  int32_T exitg1;
  boolean_T exitg2;
  j = n;
  exitg2 = false;
  while ((!exitg2) && (j > 0)) {
    coltop = (j - 1) * lda + ia0;
    ia = coltop;
    do {
      exitg1 = 0;
      if (ia <= (coltop + m) - 1) {
        if (A_data[ia - 1] != 0.0) {
          exitg1 = 1;
        } else {
          ia++;
        }
      } else {
        j--;
        exitg1 = 2;
      }
    } while (exitg1 == 0);

    if (exitg1 == 1) {
      exitg2 = true;
    }
  }

  return j;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgemv(int32_T m, int32_T n, const real_T A_data[], int32_T
  ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y_data[])
{
  int32_T ix;
  real_T c;
  int32_T iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if (n != 0) {
    for (iy = 1; iy <= n; iy++) {
      y_data[iy - 1] = 0.0;
    }

    iy = 0;
    b = (n - 1) * lda + ia0;
    iac = ia0;
    while ((lda > 0) && (iac <= b)) {
      ix = ix0;
      c = 0.0;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += A_data[ia - 1] * x_data[ix - 1];
        ix++;
      }

      y_data[iy] += c;
      iy++;
      iac += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xger(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y_data[], real_T A_data[], int32_T ia0, int32_T lda)
{
  int32_T jA;
  int32_T jy;
  real_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 1; j <= n; j++) {
      if (y_data[jy] != 0.0) {
        temp = y_data[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          A_data[ijA] += A_data[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xzlarf(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C_data[], int32_T ic0, int32_T ldc, real_T work_data[])
{
  int32_T lastv;
  int32_T lastc;
  if (tau != 0.0) {
    lastv = m;
    lastc = iv0 + m;
    while ((lastv > 0) && (C_data[lastc - 2] == 0.0)) {
      lastv--;
      lastc--;
    }

    lastc = pmpc_hil1_ilazlc(lastv, n, C_data, ic0, ldc);
  } else {
    lastv = 0;
    lastc = 0;
  }

  if (lastv > 0) {
    pmpc_hil1_xgemv(lastv, lastc, C_data, ic0, ldc, C_data, iv0, work_data);
    pmpc_hil1_xger(lastv, lastc, -tau, iv0, work_data, C_data, ic0, ldc);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgeqp3(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size, int32_T jpvt_data[], int32_T jpvt_size[2])
{
  int32_T m;
  int32_T n;
  int32_T mn;
  real_T work_data[26];
  real_T vn1_data[26];
  real_T vn2_data[26];
  int32_T i_i;
  int32_T nmi;
  int32_T pvt;
  int32_T itemp;
  real_T temp2;
  real_T b_atmp;
  int32_T b_n;
  int32_T yk;
  int8_T c_idx_0;
  m = A_size[0];
  n = A_size[1];
  if (A_size[0] < A_size[1]) {
    mn = A_size[0];
  } else {
    mn = A_size[1];
  }

  *tau_size = (int8_T)mn;
  if (A_size[1] < 1) {
    b_n = 0;
  } else {
    b_n = A_size[1];
  }

  jpvt_size[0] = 1;
  jpvt_size[1] = b_n;
  if (b_n > 0) {
    jpvt_data[0] = 1;
    yk = 1;
    for (i_i = 2; i_i <= b_n; i_i++) {
      yk++;
      jpvt_data[i_i - 1] = yk;
    }
  }

  if (A_size[1] != 0) {
    c_idx_0 = (int8_T)A_size[1];
    if (0 <= c_idx_0 - 1) {
      memset(&work_data[0], 0, c_idx_0 * sizeof(real_T));
    }

    b_n = 1;
    for (yk = 0; yk < n; yk++) {
      vn1_data[yk] = pmpc_hil1_xnrm2(m, A_data, b_n);
      vn2_data[yk] = vn1_data[yk];
      b_n += m;
    }

    for (b_n = 0; b_n < mn; b_n++) {
      i_i = b_n * m + b_n;
      nmi = (n - b_n) - 1;
      yk = (m - b_n) - 1;
      pvt = (pmpc_hil1_ixamax_n(1 + nmi, vn1_data, b_n + 1) + b_n) - 1;
      if (pvt + 1 != b_n + 1) {
        pmpc_hil1_xswap(m, A_data, 1 + m * pvt, 1 + m * b_n);
        itemp = jpvt_data[pvt];
        jpvt_data[pvt] = jpvt_data[b_n];
        jpvt_data[b_n] = itemp;
        vn1_data[pvt] = vn1_data[b_n];
        vn2_data[pvt] = vn2_data[b_n];
      }

      if (b_n + 1 < m) {
        b_atmp = A_data[i_i];
        tau_data[b_n] = pmpc_hil1_xzlarfg(yk + 1, &b_atmp, A_data, i_i + 2);
        A_data[i_i] = b_atmp;
      } else {
        tau_data[b_n] = 0.0;
      }

      if (b_n + 1 < n) {
        b_atmp = A_data[i_i];
        A_data[i_i] = 1.0;
        pmpc_hil1_xzlarf(yk + 1, nmi, i_i + 1, tau_data[b_n], A_data, (b_n +
          (b_n + 1) * m) + 1, m, work_data);
        A_data[i_i] = b_atmp;
      }

      for (i_i = b_n + 1; i_i < n; i_i++) {
        if (vn1_data[i_i] != 0.0) {
          b_atmp = std::abs(A_data[A_size[0] * i_i + b_n]) / vn1_data[i_i];
          b_atmp = 1.0 - b_atmp * b_atmp;
          if (b_atmp < 0.0) {
            b_atmp = 0.0;
          }

          temp2 = vn1_data[i_i] / vn2_data[i_i];
          temp2 = temp2 * temp2 * b_atmp;
          if (temp2 <= 1.4901161193847656E-8) {
            if (b_n + 1 < m) {
              vn1_data[i_i] = pmpc_hil1_xnrm2(yk, A_data, (m * i_i + b_n) + 2);
              vn2_data[i_i] = vn1_data[i_i];
            } else {
              vn1_data[i_i] = 0.0;
              vn2_data[i_i] = 0.0;
            }
          } else {
            vn1_data[i_i] *= std::sqrt(b_atmp);
          }
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_rankFromQR(const real_T A_data[], const int32_T A_size
  [2])
{
  int32_T r;
  int32_T minmn;
  int32_T maxmn;
  r = 0;
  if (A_size[0] < A_size[1]) {
    minmn = A_size[0];
    maxmn = A_size[1];
  } else {
    minmn = A_size[1];
    maxmn = A_size[0];
  }

  if (minmn > 0) {
    while ((r < minmn) && (!(std::abs(A_data[A_size[0] * r + r]) <= (real_T)
             maxmn * std::abs(A_data[0]) * 2.2204460492503131E-16))) {
      r++;
    }
  }

  return r;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xunormqr(const real_T Q_data[], const int32_T Q_size[2],
  real_T C[676], const real_T tau_data[])
{
  real_T wj;
  int32_T j;
  int32_T k;
  int32_T i;
  for (j = 0; j < Q_size[1]; j++) {
    if (tau_data[j] != 0.0) {
      for (k = 0; k < 26; k++) {
        wj = C[26 * k + j];
        for (i = j + 1; i < 26; i++) {
          wj += Q_data[Q_size[0] * j + i] * C[26 * k + i];
        }

        wj *= tau_data[j];
        if (wj != 0.0) {
          C[j + 26 * k] -= wj;
          for (i = j + 1; i < 26; i++) {
            C[i + 26 * k] -= Q_data[Q_size[0] * j + i] * wj;
          }
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_LSQFromQR_j(const real_T A_data[], const int32_T A_size[2],
  const real_T tau_data[], const int32_T jpvt_data[], int32_T rankA, real_T
  Y_data[], int32_T Y_size[2])
{
  int32_T i;
  int32_T b_i;
  static const int8_T c[676] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  int32_T loop_ub;
  int8_T b_idx_0;
  int32_T Y_data_tmp;
  int32_T Y_data_tmp_0;
  b_idx_0 = (int8_T)A_size[1];
  Y_size[0] = b_idx_0;
  Y_size[1] = 26;
  loop_ub = b_idx_0 * 26 - 1;
  if (0 <= loop_ub) {
    memset(&Y_data[0], 0, (loop_ub + 1) * sizeof(real_T));
  }

  for (loop_ub = 0; loop_ub < 676; loop_ub++) {
    pmpc_hil1_B.B[loop_ub] = c[loop_ub];
  }

  pmpc_hil1_xunormqr(A_data, A_size, pmpc_hil1_B.B, tau_data);
  for (loop_ub = 0; loop_ub < 26; loop_ub++) {
    for (i = 0; i < rankA; i++) {
      Y_data[(jpvt_data[i] + b_idx_0 * loop_ub) - 1] = pmpc_hil1_B.B[26 *
        loop_ub + i];
    }

    for (i = rankA - 1; i + 1 > 0; i--) {
      Y_data_tmp = b_idx_0 * loop_ub;
      Y_data_tmp_0 = A_size[0] * i;
      Y_data[(jpvt_data[i] + Y_data_tmp) - 1] /= A_data[Y_data_tmp_0 + i];
      for (b_i = 0; b_i < i; b_i++) {
        Y_data[(jpvt_data[b_i] + Y_data_tmp) - 1] -= Y_data[(b_idx_0 * loop_ub +
          jpvt_data[i]) - 1] * A_data[Y_data_tmp_0 + b_i];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qrsolve_i(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2])
{
  real_T tau_data[26];
  int32_T jpvt_data[26];
  int32_T loop_ub;
  int32_T jpvt_size[2];
  int32_T b_A_size[2];
  b_A_size[0] = 26;
  b_A_size[1] = A_size[1];
  loop_ub = A_size[0] * A_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&pmpc_hil1_B.b_A_data_c[0], &A_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  pmpc_hil1_xgeqp3(pmpc_hil1_B.b_A_data_c, b_A_size, tau_data, &loop_ub,
                   jpvt_data, jpvt_size);
  pmpc_hil1_LSQFromQR_j(pmpc_hil1_B.b_A_data_c, b_A_size, tau_data, jpvt_data,
                        pmpc_hil1_rankFromQR(pmpc_hil1_B.b_A_data_c, b_A_size),
                        Y_data, Y_size);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static int32_T pmpc_hil1_ixamax(int32_T n, const real_T x_data[], int32_T ix0)
{
  int32_T idxmax;
  int32_T ix;
  real_T smax;
  real_T s;
  int32_T k;
  idxmax = 1;
  ix = ix0 - 1;
  smax = std::abs(x_data[ix0 - 1]);
  for (k = 2; k <= n; k++) {
    ix++;
    s = std::abs(x_data[ix]);
    if (s > smax) {
      idxmax = k;
      smax = s;
    }
  }

  return idxmax;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xswap_h(real_T x_data[], int32_T ix0, int32_T iy0)
{
  int32_T ix;
  int32_T iy;
  real_T temp;
  int32_T k;
  ix = ix0 - 1;
  iy = iy0 - 1;
  for (k = 0; k < 26; k++) {
    temp = x_data[ix];
    x_data[ix] = x_data[iy];
    x_data[iy] = temp;
    ix += 26;
    iy += 26;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgetrf(real_T A_data[], int32_T A_size[2], int32_T ipiv[26],
  int32_T *info)
{
  int32_T jpiv_offset;
  int32_T j;
  int32_T c;
  int32_T jy;
  real_T yjy;
  int32_T ix;
  int32_T b_j;
  int32_T d;
  int32_T ijA;
  for (j = 0; j < 26; j++) {
    ipiv[j] = 1 + j;
  }

  *info = 0;
  for (j = 0; j < 25; j++) {
    c = j * 27;
    jpiv_offset = pmpc_hil1_ixamax(26 - j, A_data, 1 + c);
    if (A_data[(c + jpiv_offset) - 1] != 0.0) {
      if (pmpc_hil1_ixamax(26 - j, A_data, 1 + c) - 1 != 0) {
        ipiv[j] = j + jpiv_offset;
        pmpc_hil1_xswap_h(A_data, j + 1, j + jpiv_offset);
      }

      jpiv_offset = (c - j) + 26;
      for (jy = c + 1; jy < jpiv_offset; jy++) {
        A_data[jy] /= A_data[c];
      }
    } else {
      *info = j + 1;
    }

    jpiv_offset = c + 27;
    jy = c + 26;
    for (b_j = 1; b_j <= 25 - j; b_j++) {
      yjy = A_data[jy];
      if (A_data[jy] != 0.0) {
        ix = c + 1;
        d = (jpiv_offset - j) + 25;
        for (ijA = jpiv_offset; ijA < d; ijA++) {
          A_data[ijA] += A_data[ix] * -yjy;
          ix++;
        }
      }

      jy += 26;
      jpiv_offset += 26;
    }
  }

  if ((*info == 0) && (!(A_data[A_size[0] * 25 + 25] != 0.0))) {
    *info = 26;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xtrsm(const real_T A_data[], real_T B[676])
{
  int32_T jBcol;
  int32_T kAcol;
  int32_T j;
  int32_T k;
  int32_T i;
  int32_T tmp;
  for (j = 0; j < 26; j++) {
    jBcol = 26 * j;
    for (k = 0; k < 26; k++) {
      kAcol = 26 * k;
      if (B[k + jBcol] != 0.0) {
        for (i = k + 1; i + 1 < 27; i++) {
          tmp = i + jBcol;
          B[tmp] -= B[k + jBcol] * A_data[i + kAcol];
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xtrsm_l(const real_T A_data[], real_T B[676])
{
  int32_T jBcol;
  int32_T kAcol;
  int32_T j;
  int32_T k;
  int32_T i;
  int32_T tmp;
  int32_T tmp_0;
  for (j = 0; j < 26; j++) {
    jBcol = 26 * j;
    for (k = 25; k >= 0; k--) {
      kAcol = 26 * k;
      tmp = k + jBcol;
      if (B[tmp] != 0.0) {
        B[tmp] = B[k + jBcol] / A_data[k + kAcol];
        for (i = 0; i < k; i++) {
          tmp_0 = i + jBcol;
          B[tmp_0] -= B[tmp] * A_data[i + kAcol];
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_lusolve(const real_T A_data[], const int32_T A_size[2],
  real_T X[676])
{
  int32_T temp;
  int32_T ip;
  int32_T ipiv[26];
  int32_T xj;
  static const int8_T B[676] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  int32_T loop_ub;
  int32_T b_A_size[2];
  b_A_size[0] = 26;
  b_A_size[1] = A_size[1];
  loop_ub = A_size[0] * A_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&pmpc_hil1_B.b_A_data_p[0], &A_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  pmpc_hil1_xgetrf(pmpc_hil1_B.b_A_data_p, b_A_size, ipiv, &loop_ub);
  for (loop_ub = 0; loop_ub < 676; loop_ub++) {
    X[loop_ub] = B[loop_ub];
  }

  for (loop_ub = 0; loop_ub < 25; loop_ub++) {
    if (loop_ub + 1 != ipiv[loop_ub]) {
      ip = ipiv[loop_ub] - 1;
      for (xj = 0; xj < 26; xj++) {
        temp = (int32_T)X[26 * xj + loop_ub];
        X[loop_ub + 26 * xj] = X[26 * xj + ip];
        X[ip + 26 * xj] = temp;
      }
    }
  }

  pmpc_hil1_xtrsm(pmpc_hil1_B.b_A_data_p, X);
  pmpc_hil1_xtrsm_l(pmpc_hil1_B.b_A_data_p, X);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_mldivide_j(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2])
{
  if (A_size[1] == 0) {
    Y_size[0] = 0;
    Y_size[1] = 26;
  } else if (26 == A_size[1]) {
    pmpc_hil1_lusolve(A_data, A_size, pmpc_hil1_B.b);
    Y_size[0] = 26;
    Y_size[1] = 26;
    memcpy(&Y_data[0], &pmpc_hil1_B.b[0], 676U * sizeof(real_T));
  } else {
    pmpc_hil1_qrsolve_i(A_data, A_size, Y_data, Y_size);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_Unconstrained_p(const real_T Hinv[676], const real_T f[26],
  real_T x_data[], int16_T n)
{
  int16_T i;
  real_T tmp;
  int32_T i_0;
  for (i = 1; i <= n; i++) {
    tmp = 0.0;
    for (i_0 = 0; i_0 < 26; i_0++) {
      tmp += -Hinv[(26 * i_0 + i) - 1] * f[i_0];
    }

    x_data[i - 1] = tmp;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_norm(const real_T x_data[], const int32_T *x_size)
{
  real_T y;
  real_T scale;
  real_T absxk;
  real_T t;
  int32_T k;
  if (*x_size == 0) {
    y = 0.0;
  } else {
    y = 0.0;
    if (*x_size == 1) {
      y = std::abs(x_data[0]);
    } else {
      scale = 3.3121686421112381E-170;
      for (k = 1; k <= *x_size; k++) {
        absxk = std::abs(x_data[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * std::sqrt(y);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_abs_jm(const real_T x[26], real_T y[26])
{
  int32_T k;
  for (k = 0; k < 26; k++) {
    y[k] = std::abs(x[k]);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_abs_jm4(const real_T x[148], real_T y[148])
{
  int32_T k;
  for (k = 0; k < 148; k++) {
    y[k] = std::abs(x[k]);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_xzlarfg_h(int32_T n, real_T *alpha1, real_T x_data[],
  int32_T ix0)
{
  real_T tau;
  real_T xnorm;
  int32_T knt;
  int32_T b_k;
  int32_T c_k;
  tau = 0.0;
  if (!(n <= 0)) {
    xnorm = pmpc_hil1_xnrm2(n - 1, x_data, ix0);
    if (xnorm != 0.0) {
      xnorm = rt_hypotd_snf(*alpha1, xnorm);
      if (*alpha1 >= 0.0) {
        xnorm = -xnorm;
      }

      if (std::abs(xnorm) < 1.0020841800044864E-292) {
        knt = 0;
        b_k = (ix0 + n) - 2;
        do {
          knt++;
          for (c_k = ix0; c_k <= b_k; c_k++) {
            x_data[c_k - 1] *= 9.9792015476736E+291;
          }

          xnorm *= 9.9792015476736E+291;
          *alpha1 *= 9.9792015476736E+291;
        } while (!(std::abs(xnorm) >= 1.0020841800044864E-292));

        xnorm = rt_hypotd_snf(*alpha1, pmpc_hil1_xnrm2(n - 1, x_data, ix0));
        if (*alpha1 >= 0.0) {
          xnorm = -xnorm;
        }

        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        b_k = (ix0 + n) - 2;
        for (c_k = ix0; c_k <= b_k; c_k++) {
          x_data[c_k - 1] *= *alpha1;
        }

        for (b_k = 1; b_k <= knt; b_k++) {
          xnorm *= 1.0020841800044864E-292;
        }

        *alpha1 = xnorm;
      } else {
        tau = (xnorm - *alpha1) / xnorm;
        *alpha1 = 1.0 / (*alpha1 - xnorm);
        knt = (ix0 + n) - 2;
        for (b_k = ix0; b_k <= knt; b_k++) {
          x_data[b_k - 1] *= *alpha1;
        }

        *alpha1 = xnorm;
      }
    }
  }

  return tau;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgemv_kx(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y[26])
{
  int32_T ix;
  real_T c;
  int32_T iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if (n != 0) {
    for (iy = 1; iy <= n; iy++) {
      y[iy - 1] = 0.0;
    }

    iy = 0;
    b = (n - 1) * lda + ia0;
    iac = ia0;
    while ((lda > 0) && (iac <= b)) {
      ix = ix0;
      c = 0.0;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += A_data[ia - 1] * x_data[ix - 1];
        ix++;
      }

      y[iy] += c;
      iy++;
      iac += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xger_ky(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[26], real_T A_data[], int32_T ia0, int32_T lda)
{
  int32_T jA;
  int32_T jy;
  real_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 1; j <= n; j++) {
      if (y[jy] != 0.0) {
        temp = y[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          A_data[ijA] += A_data[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xzlarf_cu(int32_T m, int32_T n, int32_T iv0, real_T tau,
  real_T C_data[], int32_T ic0, int32_T ldc, real_T work[26])
{
  int32_T lastv;
  int32_T lastc;
  if (tau != 0.0) {
    lastv = m;
    lastc = iv0 + m;
    while ((lastv > 0) && (C_data[lastc - 2] == 0.0)) {
      lastv--;
      lastc--;
    }

    lastc = pmpc_hil1_ilazlc(lastv, n, C_data, ic0, ldc);
  } else {
    lastv = 0;
    lastc = 0;
  }

  if (lastv > 0) {
    pmpc_hil1_xgemv_kx(lastv, lastc, C_data, ic0, ldc, C_data, iv0, work);
    pmpc_hil1_xger_ky(lastv, lastc, -tau, iv0, work, C_data, ic0, ldc);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgeqrf_ft(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size)
{
  int32_T m;
  real_T work[26];
  int32_T i_i;
  int32_T mmi;
  real_T b_atmp;
  int32_T i;
  m = A_size[0];
  *tau_size = (int8_T)A_size[0];
  if (A_size[0] != 0) {
    memset(&work[0], 0, 26U * sizeof(real_T));
    for (i = 0; i < m; i++) {
      i_i = i * m + i;
      mmi = m - i;
      if (i + 1 < m) {
        b_atmp = A_data[i_i];
        tau_data[i] = pmpc_hil1_xzlarfg_h(mmi, &b_atmp, A_data, i_i + 2);
        A_data[i_i] = b_atmp;
      } else {
        tau_data[i] = 0.0;
      }

      if (i + 1 < 26) {
        b_atmp = A_data[i_i];
        A_data[i_i] = 1.0;
        pmpc_hil1_xzlarf_cu(mmi, 25 - i, i_i + 1, tau_data[i], A_data, (i + (i +
          1) * m) + 1, m, work);
        A_data[i_i] = b_atmp;
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xscal_i(int32_T n, real_T a, real_T x_data[], int32_T ix0)
{
  int32_T b;
  int32_T k;
  b = (ix0 + n) - 1;
  for (k = ix0; k <= b; k++) {
    x_data[k - 1] *= a;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qr_e(const real_T A_data[], const int32_T A_size[2],
  real_T Q_data[], int32_T Q_size[2], real_T R_data[], int32_T R_size[2])
{
  int32_T m;
  real_T tau_data[26];
  int32_T e_i;
  int32_T itau;
  real_T work[26];
  int32_T iaii;
  int32_T e_j;
  int32_T b_A_size[2];
  int8_T b_idx_0;
  m = A_size[0];
  b_idx_0 = (int8_T)A_size[0];
  Q_size[0] = (int8_T)A_size[0];
  Q_size[1] = (int8_T)A_size[0];
  R_size[0] = A_size[0];
  R_size[1] = A_size[1];
  b_A_size[0] = A_size[0];
  b_A_size[1] = 26;
  itau = A_size[0] * A_size[1] - 1;
  if (0 <= itau) {
    memcpy(&pmpc_hil1_B.b_A_data_f[0], &A_data[0], (itau + 1) * sizeof(real_T));
  }

  pmpc_hil1_xgeqrf_ft(pmpc_hil1_B.b_A_data_f, b_A_size, tau_data, &itau);
  for (itau = 0; itau < m; itau++) {
    for (e_i = 0; e_i < itau + 1; e_i++) {
      R_data[e_i + R_size[0] * itau] = pmpc_hil1_B.b_A_data_f[b_A_size[0] * itau
        + e_i];
    }

    for (e_i = itau; e_i + 2 <= m; e_i++) {
      R_data[(e_i + R_size[0] * itau) + 1] = 0.0;
    }
  }

  for (itau = A_size[0]; itau + 1 < 27; itau++) {
    for (e_i = 0; e_i < m; e_i++) {
      R_data[e_i + R_size[0] * itau] = pmpc_hil1_B.b_A_data_f[b_A_size[0] * itau
        + e_i];
    }
  }

  if (!(A_size[0] < 1)) {
    for (itau = A_size[0]; itau < m; itau++) {
      e_i = itau * m;
      for (iaii = 0; iaii < m; iaii++) {
        pmpc_hil1_B.b_A_data_f[e_i + iaii] = 0.0;
      }

      pmpc_hil1_B.b_A_data_f[e_i + itau] = 1.0;
    }

    itau = A_size[0] - 1;
    memset(&work[0], 0, 26U * sizeof(real_T));
    for (e_i = A_size[0]; e_i >= 1; e_i--) {
      iaii = (e_i - 1) * m + e_i;
      if (e_i < m) {
        pmpc_hil1_B.b_A_data_f[iaii - 1] = 1.0;
        pmpc_hil1_xzlarf_cu((m - e_i) + 1, m - e_i, iaii, tau_data[itau],
                            pmpc_hil1_B.b_A_data_f, iaii + m, m, work);
        pmpc_hil1_xscal_i(m - e_i, -tau_data[itau], pmpc_hil1_B.b_A_data_f, iaii
                          + 1);
      }

      pmpc_hil1_B.b_A_data_f[iaii - 1] = 1.0 - tau_data[itau];
      for (e_j = 1; e_j < e_i; e_j++) {
        pmpc_hil1_B.b_A_data_f[(iaii - e_j) - 1] = 0.0;
      }

      itau--;
    }
  }

  for (itau = 0; itau < m; itau++) {
    for (e_i = 0; e_i < m; e_i++) {
      Q_data[e_i + b_idx_0 * itau] = pmpc_hil1_B.b_A_data_f[b_A_size[0] * itau +
        e_i];
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_KWIKfactor_p(const real_T Ac[3848], const int16_T iC[148],
  int16_T nA, const real_T Linv_data[], const int32_T Linv_size[2], real_T
  RLinv_data[], int32_T RLinv_size[2], real_T D_data[], int32_T D_size[2],
  real_T H_data[], int32_T H_size[2], int16_T n)
{
  real_T Status;
  int16_T i;
  int16_T f_i;
  int16_T d_k;
  real_T a_data[26];
  real_T b_data[26];
  int32_T m;
  int32_T aoffset;
  int32_T h_i;
  int32_T RLinv;
  int32_T loop_ub;
  real_T tmp;
  int32_T QQ_size[2];
  int32_T RR_size[2];
  int32_T TL_size_idx_0;
  int32_T exitg1;
  TL_size_idx_0 = Linv_size[0];
  Status = 1.0;
  RLinv = RLinv_size[0];
  for (m = 0; m < 26; m++) {
    for (loop_ub = 0; loop_ub < RLinv; loop_ub++) {
      RLinv_data[loop_ub + RLinv_size[0] * m] = 0.0;
    }
  }

  for (i = 1; i <= nA; i++) {
    m = Linv_size[0];
    loop_ub = Linv_size[0];
    for (RLinv = 1; RLinv <= m; RLinv++) {
      b_data[RLinv - 1] = 0.0;
    }

    for (RLinv = 0; RLinv < 26; RLinv++) {
      if (Ac[(iC[i - 1] + 148 * RLinv) - 1] != 0.0) {
        aoffset = RLinv * m;
        for (h_i = 0; h_i < m; h_i++) {
          b_data[h_i] += Ac[(iC[i - 1] + 148 * RLinv) - 1] * Linv_data[aoffset +
            h_i];
        }
      }
    }

    for (m = 0; m < loop_ub; m++) {
      RLinv_data[m + RLinv_size[0] * (i - 1)] = b_data[m];
    }
  }

  pmpc_hil1_qr_e(RLinv_data, RLinv_size, pmpc_hil1_B.QQ_data_g, QQ_size,
                 pmpc_hil1_B.RR_data, RR_size);
  i = 1;
  do {
    exitg1 = 0;
    if (i <= nA) {
      if (std::abs(pmpc_hil1_B.RR_data[((i - 1) * RR_size[0] + i) - 1]) <
          1.0E-12) {
        Status = -2.0;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      for (i = 1; i <= n; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          loop_ub = Linv_size[0];
          for (m = 0; m < loop_ub; m++) {
            a_data[m] = Linv_data[(i - 1) * Linv_size[0] + m];
          }

          RLinv = QQ_size[0];
          for (m = 0; m < RLinv; m++) {
            b_data[m] = pmpc_hil1_B.QQ_data_g[(f_i - 1) * QQ_size[0] + m];
          }

          if ((Linv_size[0] == 1) || (QQ_size[0] == 1)) {
            tmp = 0.0;
            for (m = 0; m < loop_ub; m++) {
              tmp += a_data[m] * b_data[m];
            }

            pmpc_hil1_B.TL_data[(i + TL_size_idx_0 * (f_i - 1)) - 1] = tmp;
          } else {
            tmp = 0.0;
            for (m = 0; m < loop_ub; m++) {
              tmp += a_data[m] * b_data[m];
            }

            pmpc_hil1_B.TL_data[(i + TL_size_idx_0 * (f_i - 1)) - 1] = tmp;
          }
        }
      }

      RLinv = RLinv_size[0];
      for (m = 0; m < 26; m++) {
        for (loop_ub = 0; loop_ub < RLinv; loop_ub++) {
          RLinv_data[loop_ub + RLinv_size[0] * m] = 0.0;
        }
      }

      i = nA;
      while (i > 0) {
        m = i - 1;
        RLinv_data[(i + RLinv_size[0] * m) - 1] = 1.0;
        for (f_i = i; f_i <= nA; f_i++) {
          loop_ub = f_i - 1;
          RLinv_data[(i + RLinv_size[0] * loop_ub) - 1] /= pmpc_hil1_B.RR_data
            [((i - 1) * RR_size[0] + i) - 1];
        }

        if (i > 1) {
          for (f_i = 1; f_i <= m; f_i++) {
            for (d_k = i; d_k <= nA; d_k++) {
              loop_ub = d_k - 1;
              RLinv = loop_ub * RLinv_size[0];
              RLinv_data[(f_i + RLinv_size[0] * loop_ub) - 1] = RLinv_data
                [(RLinv + f_i) - 1] - pmpc_hil1_B.RR_data[(m * RR_size[0] + f_i)
                - 1] * RLinv_data[(RLinv + i) - 1];
            }
          }
        }

        i = (int16_T)m;
      }

      for (i = 1; i <= n; i++) {
        for (f_i = i; f_i <= n; f_i++) {
          m = f_i - 1;
          loop_ub = (i + H_size[0] * m) - 1;
          H_data[loop_ub] = 0.0;
          for (d_k = (int16_T)(nA + 1); d_k <= n; d_k++) {
            RLinv = (d_k - 1) * TL_size_idx_0;
            H_data[loop_ub] = H_data[((f_i - 1) * H_size[0] + i) - 1] -
              pmpc_hil1_B.TL_data[(RLinv + i) - 1] * pmpc_hil1_B.TL_data[(RLinv
              + f_i) - 1];
          }

          H_data[(f_i + H_size[0] * (i - 1)) - 1] = H_data[(m * H_size[0] + i) -
            1];
        }
      }

      for (i = 1; i <= nA; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          m = i - 1;
          loop_ub = (f_i + D_size[0] * m) - 1;
          D_data[loop_ub] = 0.0;
          for (d_k = i; d_k <= nA; d_k++) {
            RLinv = d_k - 1;
            D_data[loop_ub] = pmpc_hil1_B.TL_data[(RLinv * TL_size_idx_0 + f_i)
              - 1] * RLinv_data[(RLinv * RLinv_size[0] + i) - 1] + D_data[(m *
              D_size[0] + f_i) - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_DropConstraint_a(int16_T kDrop, int16_T iA_data[], int16_T
  *nA, int16_T iC[148])
{
  int16_T i;
  int32_T tmp;
  iA_data[iC[kDrop - 1] - 1] = 0;
  if (kDrop < *nA) {
    tmp = *nA - 1;
    if (tmp < -32768) {
      tmp = -32768;
    }

    for (i = kDrop; i <= (int16_T)tmp; i++) {
      iC[i - 1] = iC[i];
    }
  }

  iC[*nA - 1] = 0;
  tmp = *nA - 1;
  if (tmp < -32768) {
    tmp = -32768;
  }

  *nA = (int16_T)tmp;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qpkwik_o(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T Hinv[676], const real_T f[26], const real_T Ac[3848],
  const real_T b[148], int16_T iA_data[], int32_T *iA_size, int16_T n, real_T
  x_data[], int32_T *x_size, real_T lambda[148], real_T *status)
{
  real_T r_data[26];
  real_T rMin;
  real_T cTol[148];
  boolean_T cTolComputed;
  int16_T iC[148];
  int16_T nA;
  real_T Opt_data[52];
  real_T Rhs_data[52];
  boolean_T DualFeasible;
  boolean_T ColdReset;
  int16_T kDrop;
  real_T Xnorm0;
  real_T cMin;
  int16_T kNext;
  real_T cVal;
  real_T AcRow[26];
  real_T z_data[26];
  real_T t;
  int16_T iSave;
  uint16_T q;
  uint16_T b_x;
  real_T varargin_1[148];
  int32_T aoffset;
  int32_T l_i;
  int32_T idx;
  int32_T i;
  int32_T loop_ub;
  real_T Rhs_data_0[26];
  int32_T RLinv_size[2];
  int32_T D_size[2];
  int32_T H_size[2];
  int32_T U_size_idx_0;
  int32_T U_data_tmp;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *status = 1.0;
  memset(&lambda[0], 0, 148U * sizeof(real_T));
  *x_size = n;
  if (0 <= n - 1) {
    memset(&x_data[0], 0, n * sizeof(real_T));
  }

  if (0 <= n - 1) {
    memset(&r_data[0], 0, n * sizeof(real_T));
  }

  rMin = 0.0;
  RLinv_size[0] = Linv_size[0];
  RLinv_size[1] = Linv_size[1];
  D_size[0] = Linv_size[0];
  D_size[1] = Linv_size[1];
  H_size[0] = Linv_size[0];
  H_size[1] = Linv_size[1];
  U_size_idx_0 = Linv_size[0];
  cTolComputed = false;
  for (i = 0; i < 148; i++) {
    cTol[i] = 1.0;
    iC[i] = 0;
  }

  nA = 0;
  for (kNext = 0; kNext < 148; kNext++) {
    if (iA_data[kNext] == 1) {
      i = nA + 1;
      if (i > 32767) {
        i = 32767;
      }

      nA = (int16_T)i;
      iC[(int16_T)i - 1] = (int16_T)(kNext + 1);
    }
  }

  guard1 = false;
  if (nA > 0) {
    if (n > 16383) {
      loop_ub = 32767;
    } else if (n <= -16384) {
      loop_ub = -32768;
    } else {
      loop_ub = (int16_T)(n << 1);
    }

    if (0 <= loop_ub - 1) {
      memset(&Opt_data[0], 0, loop_ub * sizeof(real_T));
    }

    memcpy(&Rhs_data[0], &f[0], 26U * sizeof(real_T));
    if (0 <= n - 1) {
      memset(&Rhs_data[26], 0, n * sizeof(real_T));
    }

    DualFeasible = false;
    i = 3 * nA;
    if (i > 32767) {
      i = 32767;
    }

    if ((int16_T)i > 50) {
      kNext = (int16_T)i;
    } else {
      kNext = 50;
    }

    q = (uint16_T)(kNext / 10U);
    b_x = (uint16_T)((uint32_T)kNext - q * 10);
    if ((b_x > 0) && (b_x >= 5)) {
      q++;
    }

    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && (*status <= 2500.0)) {
        Xnorm0 = pmpc_hil1_KWIKfactor_p(Ac, iC, nA, Linv_data, Linv_size,
          pmpc_hil1_B.RLinv_data, RLinv_size, pmpc_hil1_B.D_data, D_size,
          pmpc_hil1_B.H_data, H_size, n);
        if (Xnorm0 < 0.0) {
          if (ColdReset) {
            *status = -2.0;
            exitg3 = 2;
          } else {
            nA = 0;
            *iA_size = 148;
            memset(&iA_data[0], 0, 148U * sizeof(int16_T));
            memset(&iC[0], 0, 148U * sizeof(int16_T));
            ColdReset = true;
          }
        } else {
          for (kNext = 1; kNext <= nA; kNext++) {
            i = n + kNext;
            if (i > 32767) {
              i = 32767;
            } else {
              if (i < -32768) {
                i = -32768;
              }
            }

            loop_ub = kNext - 1;
            Rhs_data[i - 1] = b[iC[loop_ub] - 1];
            for (kDrop = kNext; kDrop <= nA; kDrop++) {
              i = (kDrop + U_size_idx_0 * loop_ub) - 1;
              pmpc_hil1_B.U_data[i] = 0.0;
              for (iSave = 1; iSave <= nA; iSave++) {
                U_data_tmp = (iSave - 1) * RLinv_size[0];
                pmpc_hil1_B.U_data[i] = pmpc_hil1_B.RLinv_data[(U_data_tmp +
                  kDrop) - 1] * pmpc_hil1_B.RLinv_data[(U_data_tmp + kNext) - 1]
                  + pmpc_hil1_B.U_data[((kNext - 1) * U_size_idx_0 + kDrop) - 1];
              }

              pmpc_hil1_B.U_data[(kNext + U_size_idx_0 * (kDrop - 1)) - 1] =
                pmpc_hil1_B.U_data[(loop_ub * U_size_idx_0 + kDrop) - 1];
            }
          }

          if (1 <= n) {
            if (1 > n) {
              aoffset = 0;
            } else {
              aoffset = n;
            }
          }

          for (kNext = 1; kNext <= n; kNext++) {
            if (0 <= aoffset - 1) {
              memcpy(&Rhs_data_0[0], &Rhs_data[0], aoffset * sizeof(real_T));
            }

            cVal = 0.0;
            for (i = 0; i < 26; i++) {
              cVal += pmpc_hil1_B.H_data[(H_size[0] * i + kNext) - 1] *
                Rhs_data_0[i];
            }

            loop_ub = kNext - 1;
            Opt_data[loop_ub] = cVal;
            for (kDrop = 1; kDrop <= nA; kDrop++) {
              i = n + kDrop;
              if (i > 32767) {
                i = 32767;
              }

              Opt_data[loop_ub] += pmpc_hil1_B.D_data[((kDrop - 1) * D_size[0] +
                kNext) - 1] * Rhs_data[i - 1];
            }
          }

          if (1 <= nA) {
            if (1 > n) {
              idx = 0;
            } else {
              idx = n;
            }

            l_i = D_size[0];
            if (0 <= idx - 1) {
              memcpy(&z_data[0], &Rhs_data[0], idx * sizeof(real_T));
            }
          }

          for (kNext = 1; kNext <= nA; kNext++) {
            for (i = 0; i < l_i; i++) {
              AcRow[i] = pmpc_hil1_B.D_data[(kNext - 1) * D_size[0] + i];
            }

            if ((D_size[0] == 1) || (idx == 1)) {
              cVal = 0.0;
              for (i = 0; i < l_i; i++) {
                cVal += AcRow[i] * z_data[i];
              }

              i = n + kNext;
              if (i > 32767) {
                i = 32767;
              }

              Opt_data[i - 1] = cVal;
            } else {
              cVal = 0.0;
              for (i = 0; i < l_i; i++) {
                cVal += AcRow[i] * z_data[i];
              }

              i = n + kNext;
              if (i > 32767) {
                i = 32767;
              }

              Opt_data[i - 1] = cVal;
            }

            for (kDrop = 1; kDrop <= nA; kDrop++) {
              i = n + kNext;
              if (i > 32767) {
                i = 32767;
              }

              loop_ub = n + kNext;
              if (loop_ub > 32767) {
                loop_ub = 32767;
              }

              U_data_tmp = n + kDrop;
              if (U_data_tmp > 32767) {
                U_data_tmp = 32767;
              }

              Opt_data[i - 1] = pmpc_hil1_B.U_data[((kDrop - 1) * U_size_idx_0 +
                kNext) - 1] * Rhs_data[U_data_tmp - 1] + Opt_data[loop_ub - 1];
            }
          }

          Xnorm0 = -1.0E-12;
          kDrop = 0;
          for (kNext = 1; kNext <= nA; kNext++) {
            i = n + kNext;
            loop_ub = i;
            if (i > 32767) {
              loop_ub = 32767;
            }

            lambda[iC[kNext - 1] - 1] = Opt_data[loop_ub - 1];
            loop_ub = i;
            if (i > 32767) {
              loop_ub = 32767;
            }

            if ((Opt_data[loop_ub - 1] < Xnorm0) && (kNext <= nA)) {
              kDrop = kNext;
              if (i > 32767) {
                i = 32767;
              }

              Xnorm0 = Opt_data[i - 1];
            }
          }

          if (kDrop <= 0) {
            DualFeasible = true;
            if (1 > n) {
              loop_ub = 0;
            } else {
              loop_ub = n;
            }

            *x_size = loop_ub;
            if (0 <= loop_ub - 1) {
              memcpy(&x_data[0], &Opt_data[0], loop_ub * sizeof(real_T));
            }
          } else {
            (*status)++;
            if ((int32_T)*status > q) {
              nA = 0;
              *iA_size = 148;
              memset(&iA_data[0], 0, 148U * sizeof(int16_T));
              memset(&iC[0], 0, 148U * sizeof(int16_T));
              ColdReset = true;
            } else {
              lambda[iC[kDrop - 1] - 1] = 0.0;
              pmpc_hil1_DropConstraint_a(kDrop, iA_data, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          memset(&lambda[0], 0, 148U * sizeof(real_T));
          pmpc_hil1_Unconstrained_p(Hinv, f, x_data, n);
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    pmpc_hil1_Unconstrained_p(Hinv, f, x_data, n);
    guard1 = true;
  }

  if (guard1) {
    Xnorm0 = pmpc_hil1_norm(x_data, x_size);
    do {
      exitg2 = 0;
      if (*status <= 2500.0) {
        cMin = -1.0E-6;
        kNext = 0;
        for (kDrop = 0; kDrop < 148; kDrop++) {
          if (!cTolComputed) {
            U_size_idx_0 = kDrop + 1;
            if (0 <= *x_size - 1) {
              memcpy(&AcRow[0], &x_data[0], *x_size * sizeof(real_T));
            }

            for (i = 0; i < 26; i++) {
              z_data[i] = Ac[(148 * i + U_size_idx_0) - 1] * AcRow[i];
            }

            pmpc_hil1_abs_jm(z_data, AcRow);
            if (!rtIsNaN(AcRow[0])) {
              idx = 1;
            } else {
              idx = 0;
              i = 2;
              exitg4 = false;
              while ((!exitg4) && (i < 27)) {
                if (!rtIsNaN(AcRow[i - 1])) {
                  idx = i;
                  exitg4 = true;
                } else {
                  i++;
                }
              }
            }

            if (idx == 0) {
              cVal = AcRow[0];
            } else {
              cVal = AcRow[idx - 1];
              while (idx + 1 < 27) {
                if (cVal < AcRow[idx]) {
                  cVal = AcRow[idx];
                }

                idx++;
              }
            }

            if (!((cTol[kDrop] > cVal) || rtIsNaN(cVal))) {
              cTol[kDrop] = cVal;
            }
          }

          if (iA_data[kDrop] == 0) {
            U_size_idx_0 = kDrop + 1;
            cVal = 0.0;
            for (i = 0; i < 26; i++) {
              cVal += Ac[(148 * i + U_size_idx_0) - 1] * x_data[i];
            }

            cVal = (cVal - b[kDrop]) / cTol[kDrop];
            if (cVal < cMin) {
              cMin = cVal;
              kNext = (int16_T)(kDrop + 1);
            }
          }
        }

        cTolComputed = true;
        if (kNext <= 0) {
          exitg2 = 1;
        } else {
          do {
            exitg1 = 0;
            if ((kNext > 0) && (*status <= 2500.0)) {
              guard2 = false;
              if (nA == 0) {
                idx = 26;
                for (i = 0; i < 26; i++) {
                  AcRow[i] = 0.0;
                  for (loop_ub = 0; loop_ub < 26; loop_ub++) {
                    AcRow[i] += Ac[(148 * loop_ub + kNext) - 1] * Hinv[26 *
                      loop_ub + i];
                  }

                  z_data[i] = AcRow[i];
                }

                guard2 = true;
              } else {
                cMin = pmpc_hil1_KWIKfactor_p(Ac, iC, nA, Linv_data, Linv_size,
                  pmpc_hil1_B.RLinv_data, RLinv_size, pmpc_hil1_B.D_data, D_size,
                  pmpc_hil1_B.H_data, H_size, n);
                if (cMin <= 0.0) {
                  *status = -2.0;
                  exitg1 = 1;
                } else {
                  U_size_idx_0 = H_size[0];
                  loop_ub = H_size[0] * H_size[1] - 1;
                  for (i = 0; i <= loop_ub; i++) {
                    pmpc_hil1_B.U_data[i] = -pmpc_hil1_B.H_data[i];
                  }

                  idx = H_size[0];
                  for (i = 1; i <= U_size_idx_0; i++) {
                    z_data[i - 1] = 0.0;
                  }

                  for (i = 0; i < 26; i++) {
                    if (Ac[(148 * i + kNext) - 1] != 0.0) {
                      aoffset = i * U_size_idx_0;
                      for (l_i = 0; l_i < U_size_idx_0; l_i++) {
                        z_data[l_i] += Ac[(148 * i + kNext) - 1] *
                          pmpc_hil1_B.U_data[aoffset + l_i];
                      }
                    }
                  }

                  for (kDrop = 1; kDrop <= nA; kDrop++) {
                    loop_ub = D_size[0];
                    for (i = 0; i < loop_ub; i++) {
                      AcRow[i] = pmpc_hil1_B.D_data[(kDrop - 1) * D_size[0] + i];
                    }

                    cVal = 0.0;
                    for (i = 0; i < 26; i++) {
                      cVal += Ac[(148 * i + kNext) - 1] * AcRow[i];
                    }

                    r_data[kDrop - 1] = cVal;
                  }

                  guard2 = true;
                }
              }

              if (guard2) {
                kDrop = 0;
                cMin = 0.0;
                DualFeasible = true;
                ColdReset = true;
                if (nA > 0) {
                  iSave = 1;
                  exitg4 = false;
                  while ((!exitg4) && (iSave <= nA)) {
                    if (r_data[iSave - 1] >= 1.0E-12) {
                      ColdReset = false;
                      exitg4 = true;
                    } else {
                      iSave++;
                    }
                  }
                }

                if (!((nA == 0) || ColdReset)) {
                  for (iSave = 1; iSave <= nA; iSave++) {
                    i = iSave - 1;
                    if (r_data[i] > 1.0E-12) {
                      cVal = lambda[iC[i] - 1] / r_data[iSave - 1];
                      if ((kDrop == 0) || (cVal < rMin)) {
                        rMin = cVal;
                        kDrop = iSave;
                      }
                    }
                  }

                  if (kDrop > 0) {
                    cMin = rMin;
                    DualFeasible = false;
                  }
                }

                if (0 <= idx - 1) {
                  memcpy(&AcRow[0], &z_data[0], idx * sizeof(real_T));
                }

                cVal = 0.0;
                for (i = 0; i < 26; i++) {
                  cVal += Ac[(148 * i + kNext) - 1] * AcRow[i];
                }

                if (cVal <= 0.0) {
                  cVal = 0.0;
                  ColdReset = true;
                } else {
                  t = 0.0;
                  for (i = 0; i < 26; i++) {
                    t += Ac[(148 * i + kNext) - 1] * x_data[i];
                  }

                  cVal = (b[kNext - 1] - t) / cVal;
                  ColdReset = false;
                }

                if (DualFeasible && ColdReset) {
                  *status = -1.0;
                  exitg1 = 1;
                } else {
                  if (ColdReset) {
                    t = cMin;
                  } else if (DualFeasible) {
                    t = cVal;
                  } else if ((cMin < cVal) || rtIsNaN(cVal)) {
                    t = cMin;
                  } else {
                    t = cVal;
                  }

                  for (iSave = 1; iSave <= nA; iSave++) {
                    U_size_idx_0 = iSave - 1;
                    idx = iC[U_size_idx_0] - 1;
                    lambda[idx] -= r_data[U_size_idx_0] * t;
                    if (lambda[iC[iSave - 1] - 1] < 0.0) {
                      lambda[idx] = 0.0;
                    }
                  }

                  lambda[kNext - 1] += t;
                  if (t == cMin) {
                    pmpc_hil1_DropConstraint_a(kDrop, iA_data, &nA, iC);
                  }

                  if (!ColdReset) {
                    loop_ub = *x_size;
                    for (i = 0; i < loop_ub; i++) {
                      x_data[i] += t * z_data[i];
                    }

                    if (t == cVal) {
                      if (nA == n) {
                        *status = -1.0;
                        exitg1 = 1;
                      } else {
                        i = nA + 1;
                        if (i > 32767) {
                          i = 32767;
                        }

                        nA = (int16_T)i;
                        iC[(int16_T)i - 1] = kNext;
                        kDrop = (int16_T)i;
                        exitg4 = false;
                        while ((!exitg4) && (kDrop > 1)) {
                          i = kDrop - 1;
                          loop_ub = kDrop - 2;
                          if (iC[i] > iC[loop_ub]) {
                            exitg4 = true;
                          } else {
                            iSave = iC[kDrop - 1];
                            iC[i] = iC[kDrop - 2];
                            iC[loop_ub] = iSave;
                            kDrop = (int16_T)i;
                          }
                        }

                        iA_data[kNext - 1] = 1;
                        kNext = 0;
                        (*status)++;
                      }
                    } else {
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                }
              }
            } else {
              cMin = pmpc_hil1_norm(x_data, x_size);
              if (std::abs(cMin - Xnorm0) > 0.001) {
                Xnorm0 = cMin;
                pmpc_hil1_abs_jm4(b, varargin_1);
                for (idx = 0; idx < 148; idx++) {
                  if (varargin_1[idx] > 1.0) {
                    cTol[idx] = varargin_1[idx];
                  } else {
                    cTol[idx] = 1.0;
                  }
                }

                cTolComputed = false;
              }

              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = 1;
          }
        }
      } else {
        *status = 0.0;
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_mpcqpsolver_h(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T f[26], const real_T A[3848], const real_T b[148],
  const boolean_T iA0_data[], real_T x_data[], int32_T *x_size, real_T *status,
  boolean_T iA[148])
{
  real_T lam[148];
  int16_T iA1_data[148];
  int32_T coffset;
  int32_T boffset;
  int32_T aoffset;
  int32_T j;
  int32_T i;
  int32_T b_i;
  int32_T loop_ub;
  int32_T a_size_idx_1;
  a_size_idx_1 = Linv_size[0];
  loop_ub = Linv_size[0];
  for (j = 0; j < loop_ub; j++) {
    for (coffset = 0; coffset < 26; coffset++) {
      pmpc_hil1_B.a_data[coffset + 26 * j] = Linv_data[Linv_size[0] * coffset +
        j];
    }
  }

  if (Linv_size[0] == 1) {
    for (j = 0; j < 26; j++) {
      for (coffset = 0; coffset < 26; coffset++) {
        loop_ub = j + 26 * coffset;
        pmpc_hil1_B.Hinv[loop_ub] = 0.0;
        for (boffset = 0; boffset < a_size_idx_1; boffset++) {
          pmpc_hil1_B.Hinv[loop_ub] = pmpc_hil1_B.a_data[26 * boffset + j] *
            Linv_data[Linv_size[0] * coffset + boffset] + pmpc_hil1_B.Hinv[26 *
            coffset + j];
        }
      }
    }
  } else {
    for (j = 0; j < 26; j++) {
      coffset = j * 26;
      boffset = j * a_size_idx_1 - 1;
      memset(&pmpc_hil1_B.Hinv[coffset], 0, 26U * sizeof(real_T));
      for (i = 1; i <= a_size_idx_1; i++) {
        if (Linv_data[boffset + i] != 0.0) {
          aoffset = (i - 1) * 26;
          for (b_i = 0; b_i < 26; b_i++) {
            loop_ub = coffset + b_i;
            pmpc_hil1_B.Hinv[loop_ub] += Linv_data[boffset + i] *
              pmpc_hil1_B.a_data[aoffset + b_i];
          }
        }
      }
    }
  }

  j = 148;
  for (j = 0; j < 148; j++) {
    iA1_data[j] = iA0_data[j];
  }

  pmpc_hil1_qpkwik_o(Linv_data, Linv_size, pmpc_hil1_B.Hinv, f, A, b, iA1_data,
                     &j, (int16_T)Linv_size[0], x_data, x_size, lam, status);
  for (j = 0; j < 148; j++) {
    iA[j] = (iA1_data[j] != 0);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_local_warmstart_i(const boolean_T iA_new[148])
{
  if (!pmpc_hil1_DW.iA_ws_not_empty) {
    pmpc_hil1_DW.iA_ws.size = 148;
    memset(&pmpc_hil1_DW.iA_ws.data[0], 0, 148U * sizeof(boolean_T));
    pmpc_hil1_DW.iA_ws_not_empty = true;
  }

  pmpc_hil1_DW.iA_ws.size = 148;
  memcpy(&pmpc_hil1_DW.iA_ws.data[0], &iA_new[0], 148U * sizeof(boolean_T));
  pmpc_hil1_DW.iA_ws_not_empty = true;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_sum(const boolean_T x[148])
{
  real_T y;
  int32_T k;
  y = x[0];
  for (k = 0; k < 147; k++) {
    y += (real_T)x[k + 1];
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_QPKwik_cz(const real_T H[676], const real_T f[26],
  const real_T A[2496], const real_T b[96], const real_T lb[26], const real_T
  ub[26], real_T x_data[], int32_T *x_size, real_T *status, real_T *nAct)
{
  real_T ubf[26];
  real_T lbf[26];
  boolean_T iA0_data[148];
  boolean_T iA_out[148];
  int8_T c_data[26];
  int8_T d_data[26];
  int32_T trueCount;
  static const int8_T e[676] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  static const int8_T g[676] = { -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, -1 };

  boolean_T h[26];
  int32_T i;
  real_T b_0[148];
  boolean_T tmp[26];
  int32_T Linv_size[2];
  int32_T B_size[2];
  boolean_T h_0;
  int32_T c_size_idx_0;
  int32_T A_tmp;
  pmpc_hil1_isfinite_c(ub, tmp);
  trueCount = 0;
  for (i = 0; i < 26; i++) {
    ubf[i] = ub[i];
    lbf[i] = lb[i];
    h_0 = !tmp[i];
    if (h_0) {
      trueCount++;
    }

    h[i] = h_0;
  }

  c_size_idx_0 = trueCount;
  trueCount = 0;
  for (i = 0; i < 26; i++) {
    if (h[i]) {
      c_data[trueCount] = (int8_T)(i + 1);
      trueCount++;
    }
  }

  for (trueCount = 0; trueCount < c_size_idx_0; trueCount++) {
    ubf[c_data[trueCount] - 1] = 1.0E+12;
  }

  pmpc_hil1_isfinite_c(lb, tmp);
  trueCount = 0;
  for (i = 0; i < 26; i++) {
    h_0 = !tmp[i];
    if (h_0) {
      trueCount++;
    }

    h[i] = h_0;
  }

  c_size_idx_0 = trueCount;
  trueCount = 0;
  for (i = 0; i < 26; i++) {
    if (h[i]) {
      d_data[trueCount] = (int8_T)(i + 1);
      trueCount++;
    }
  }

  for (trueCount = 0; trueCount < c_size_idx_0; trueCount++) {
    lbf[d_data[trueCount] - 1] = -1.0E+12;
  }

  pmpc_hil1_local_warmstart(iA0_data, &trueCount);
  B_size[0] = 26;
  B_size[1] = 26;
  memcpy(&pmpc_hil1_B.B_data_b[0], &H[0], 676U * sizeof(real_T));
  trueCount = pmpc_hil1_cholesky(pmpc_hil1_B.B_data_b, B_size);
  if (trueCount != 0) {
    *x_size = 26;
    memset(&x_data[0], 0, 26U * sizeof(real_T));
    *status = -2.0;
    *nAct = 0.0;
  } else {
    pmpc_hil1_mldivide_j(pmpc_hil1_B.B_data_b, B_size, pmpc_hil1_B.Linv_data,
                         Linv_size);
    for (trueCount = 0; trueCount < 26; trueCount++) {
      for (i = 0; i < 96; i++) {
        pmpc_hil1_B.A[i + 148 * trueCount] = -A[96 * trueCount + i];
      }

      for (i = 0; i < 26; i++) {
        c_size_idx_0 = 26 * trueCount + i;
        A_tmp = i + 148 * trueCount;
        pmpc_hil1_B.A[A_tmp + 96] = e[c_size_idx_0];
        pmpc_hil1_B.A[A_tmp + 122] = g[c_size_idx_0];
      }
    }

    for (trueCount = 0; trueCount < 96; trueCount++) {
      b_0[trueCount] = -b[trueCount];
    }

    for (trueCount = 0; trueCount < 26; trueCount++) {
      b_0[trueCount + 96] = lbf[trueCount];
      b_0[trueCount + 122] = -ubf[trueCount];
    }

    pmpc_hil1_mpcqpsolver_h(pmpc_hil1_B.Linv_data, Linv_size, f, pmpc_hil1_B.A,
      b_0, iA0_data, x_data, x_size, status, iA_out);
    pmpc_hil1_local_warmstart_i(iA_out);
    *nAct = pmpc_hil1_sum(iA_out);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_SolveMPCQP(const real_T H[676], const real_T f[26],
  const real_T A_cons[2496], const real_T b_cons[96], const real_T lb[26], const
  real_T ub[26], real_T WarmStart[26], real_T x_opt[26], real_T *exitflag,
  real_T delta_U_first[3], real_T rho_val[3], real_T epsilon_val[8])
{
  char_T bad_data[29];
  real_T Hx0[26];
  real_T sc[26];
  real_T unusedU0;
  real_T ex;
  int32_T idx;
  int32_T k;
  b_cell_wrap_2_pmpc_hil1_T validatedHoleFilling;
  char_T varargin_1_data[30];
  static const char_T e[7] = { 'A', '_', 'c', 'o', 'n', 's', ' ' };

  static const char_T g[7] = { 'b', '_', 'c', 'o', 'n', 's', ' ' };

  static const char_T i[8] = { 'u', 'b', '(', 'N', 'a', 'N', ')', ' ' };

  real_T sc_0[26];
  real_T lb_0[26];
  real_T ub_0[26];
  real_T A_cons_0[96];
  boolean_T tmp[96];
  boolean_T tmp_0[2496];
  boolean_T tmp_1[676];
  boolean_T tmp_2[26];
  int32_T bad_size_idx_1;
  boolean_T guard1 = false;
  boolean_T exitg1;
  pmpc_hil1_isfinite_c(WarmStart, tmp_2);
  if (!pmpc_hil1_all(tmp_2)) {
    fprintf(stderr,
            "func_SolveMPCQP: WarmStart size invalid or non-finite; reset to zero.\n");
    fflush(stderr);
    memset(&WarmStart[0], 0, 26U * sizeof(real_T));
  }

  bad_size_idx_1 = 0;
  pmpc_hil1_isfinite_cn5(H, tmp_1);
  if (!pmpc_hil1_all_n(tmp_1)) {
    bad_size_idx_1 = 2;
    bad_data[0] = 'H';
    bad_data[1] = ' ';
  }

  pmpc_hil1_isfinite_c(f, tmp_2);
  if (!pmpc_hil1_all(tmp_2)) {
    idx = bad_size_idx_1;
    bad_size_idx_1 += 2;
    bad_data[idx] = 'f';
    bad_data[idx + 1] = ' ';
  }

  pmpc_hil1_isfinite_cn5c(A_cons, tmp_0);
  if (!pmpc_hil1_all_ns(tmp_0)) {
    idx = bad_size_idx_1;
    bad_size_idx_1 += 7;
    for (k = 0; k < 7; k++) {
      bad_data[idx + k] = e[k];
    }
  }

  pmpc_hil1_isfinite_cn5ck(b_cons, tmp);
  if (!pmpc_hil1_all_ns5(tmp)) {
    idx = bad_size_idx_1;
    bad_size_idx_1 += 7;
    for (k = 0; k < 7; k++) {
      bad_data[idx + k] = g[k];
    }
  }

  pmpc_hil1_isfinite_c(lb, tmp_2);
  if (!pmpc_hil1_all(tmp_2)) {
    idx = bad_size_idx_1;
    bad_size_idx_1 += 3;
    bad_data[idx] = 'l';
    bad_data[idx + 1] = 'b';
    bad_data[idx + 2] = ' ';
  }

  for (k = 0; k < 26; k++) {
    tmp_2[k] = rtIsNaN(ub[k]);
  }

  if (pmpc_hil1_any(tmp_2)) {
    idx = bad_size_idx_1;
    bad_size_idx_1 += 8;
    for (k = 0; k < 8; k++) {
      bad_data[idx + k] = i[k];
    }
  }

  if (!(bad_size_idx_1 == 0)) {
    validatedHoleFilling.f1.size[1] = bad_size_idx_1 + 1;
    for (k = 0; k < bad_size_idx_1; k++) {
      validatedHoleFilling.f1.data[k] = bad_data[k];
    }

    validatedHoleFilling.f1.data[bad_size_idx_1] = '\x00';
    idx = validatedHoleFilling.f1.size[1] - 1;
    for (k = 0; k <= idx; k++) {
      varargin_1_data[k] = validatedHoleFilling.f1.data[k];
    }

    fprintf(stderr,
            "func_SolveMPCQP: QP matrices contain Inf/NaN: %s-> holding previous control\n",
            &varargin_1_data[0]);
    fflush(stderr);
    memset(&x_opt[0], 0, 26U * sizeof(real_T));
    *exitflag = -3.0;
    delta_U_first[0] = 0.0;
    rho_val[0] = 0.0;
    delta_U_first[1] = 0.0;
    rho_val[1] = 0.0;
    delta_U_first[2] = 0.0;
    rho_val[2] = 0.0;
    memset(&epsilon_val[0], 0, sizeof(real_T) << 3U);
    memset(&WarmStart[0], 0, 26U * sizeof(real_T));
  } else {
    for (k = 0; k < 26; k++) {
      Hx0[k] = 0.0;
      for (idx = 0; idx < 26; idx++) {
        Hx0[k] += H[26 * idx + k] * WarmStart[idx];
      }
    }

    pmpc_hil1_isfinite_c(Hx0, tmp_2);
    guard1 = false;
    if (!pmpc_hil1_all(tmp_2)) {
      guard1 = true;
    } else {
      ex = 0.0;
      for (k = 0; k < 26; k++) {
        ex += WarmStart[k] * Hx0[k];
      }

      if (!pmpc_hil1_isfinite(ex)) {
        guard1 = true;
      } else {
        ex = 0.0;
        for (k = 0; k < 26; k++) {
          ex += f[k] * WarmStart[k];
        }

        if (!pmpc_hil1_isfinite(ex)) {
          guard1 = true;
        } else {
          for (k = 0; k < 96; k++) {
            A_cons_0[k] = 0.0;
            for (idx = 0; idx < 26; idx++) {
              A_cons_0[k] += A_cons[96 * idx + k] * WarmStart[idx];
            }
          }

          pmpc_hil1_isfinite_cn5ck(A_cons_0, tmp);
          if (!pmpc_hil1_all_ns5(tmp)) {
            guard1 = true;
          }
        }
      }
    }

    if (guard1) {
      fprintf(stderr,
              "func_SolveMPCQP: WarmStart produced Inf/NaN in QP; reset to zero.\n");
      fflush(stderr);
      memset(&WarmStart[0], 0, 26U * sizeof(real_T));
    }

    pmpc_hil1_diag_eek(H, Hx0);
    if (!rtIsNaN(Hx0[0])) {
      idx = 1;
    } else {
      idx = 0;
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k < 27)) {
        if (!rtIsNaN(Hx0[k - 1])) {
          idx = k;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }

    if (idx == 0) {
      ex = Hx0[0];
    } else {
      ex = Hx0[idx - 1];
      while (idx + 1 < 27) {
        if (ex < Hx0[idx]) {
          ex = Hx0[idx];
        }

        idx++;
      }
    }

    pmpc_hil1_diag_eek(H, Hx0);
    ex *= 2.2204460492503131E-16;
    for (idx = 0; idx < 26; idx++) {
      if ((Hx0[idx] > ex) || rtIsNaN(ex)) {
        sc[idx] = Hx0[idx];
      } else {
        sc[idx] = ex;
      }
    }

    pmpc_hil1_sqrt_fk(sc);
    for (k = 0; k < 26; k++) {
      sc[k] = 1.0 / sc[k];
    }

    for (k = 0; k < 26; k++) {
      for (idx = 0; idx < 26; idx++) {
        pmpc_hil1_B.sc[k + 26 * idx] = sc[k] * sc[idx];
      }
    }

    for (k = 0; k < 26; k++) {
      for (idx = 0; idx < 26; idx++) {
        bad_size_idx_1 = 26 * k + idx;
        pmpc_hil1_B.Hs[idx + 26 * k] = pmpc_hil1_B.sc[bad_size_idx_1] *
          H[bad_size_idx_1];
      }
    }

    pmpc_hil1_bsxfun(A_cons, sc, pmpc_hil1_B.dv0);
    for (k = 0; k < 26; k++) {
      for (idx = 0; idx < 26; idx++) {
        pmpc_hil1_B.sc[idx + 26 * k] = (pmpc_hil1_B.Hs[26 * k + idx] +
          pmpc_hil1_B.Hs[26 * idx + k]) / 2.0;
      }

      sc_0[k] = sc[k] * f[k];
      lb_0[k] = lb[k] / sc[k];
      ub_0[k] = ub[k] / sc[k];
    }

    pmpc_hil1_func_QPKwik_cz(pmpc_hil1_B.sc, sc_0, pmpc_hil1_B.dv0, b_cons, lb_0,
      ub_0, Hx0, &bad_size_idx_1, &ex, &unusedU0);
    if (ex > 0.0) {
      *exitflag = 1.0;
    } else {
      *exitflag = ex - 10.0;
    }

    memset(&x_opt[0], 0, 26U * sizeof(real_T));
    if (bad_size_idx_1 == 26) {
      for (k = 0; k < 26; k++) {
        x_opt[k] = sc[k] * Hx0[k];
      }
    }

    if (*exitflag == 1.0) {
      memcpy(&WarmStart[0], &x_opt[3], 15U * sizeof(real_T));
      WarmStart[15] = 0.0;
      WarmStart[16] = 0.0;
      WarmStart[17] = 0.0;
      delta_U_first[0] = x_opt[0];
      rho_val[0] = 1.0;
      delta_U_first[1] = x_opt[1];
      rho_val[1] = 1.0;
      delta_U_first[2] = x_opt[2];
      rho_val[2] = 1.0;
      memcpy(&WarmStart[18], &x_opt[18], sizeof(real_T) << 3U);
      memcpy(&epsilon_val[0], &x_opt[18], sizeof(real_T) << 3U);
    } else {
      delta_U_first[0] = 0.0;
      rho_val[0] = 0.0;
      delta_U_first[1] = 0.0;
      rho_val[1] = 0.0;
      delta_U_first[2] = 0.0;
      rho_val[2] = 0.0;
      memset(&epsilon_val[0], 0, sizeof(real_T) << 3U);
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_diag(const real_T v[3], real_T d[9])
{
  memset(&d[0], 0, 9U * sizeof(real_T));
  d[0] = v[0];
  d[4] = v[1];
  d[8] = v[2];
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_isfinite_cn(const real_T x[4], boolean_T b[4])
{
  b[0] = ((!rtIsInf(x[0])) && (!rtIsNaN(x[0])));
  b[1] = ((!rtIsInf(x[1])) && (!rtIsNaN(x[1])));
  b[2] = ((!rtIsInf(x[2])) && (!rtIsNaN(x[2])));
  b[3] = ((!rtIsInf(x[3])) && (!rtIsNaN(x[3])));
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_LSQFromQR(const real_T A_data[], const int32_T A_size[2],
  const real_T tau_data[], const int32_T jpvt_data[], int32_T rankA, real_T
  Y_data[], int32_T Y_size[2])
{
  int32_T b_i;
  real_T B[16];
  int32_T m;
  int32_T mn;
  real_T wj;
  int32_T b_j;
  static const int8_T C[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };

  int8_T b_idx_0;
  b_idx_0 = (int8_T)A_size[1];
  Y_size[0] = b_idx_0;
  Y_size[1] = 4;
  mn = (b_idx_0 << 2) - 1;
  if (0 <= mn) {
    memset(&Y_data[0], 0, (mn + 1) * sizeof(real_T));
  }

  for (mn = 0; mn < 16; mn++) {
    B[mn] = C[mn];
  }

  m = A_size[0];
  if (A_size[0] < A_size[1]) {
    mn = A_size[0];
  } else {
    mn = A_size[1];
  }

  for (b_j = 0; b_j < mn; b_j++) {
    if (tau_data[b_j] != 0.0) {
      wj = B[b_j];
      for (b_i = b_j + 1; b_i < m; b_i++) {
        wj += A_data[A_size[0] * b_j + b_i] * B[b_i];
      }

      wj *= tau_data[b_j];
      if (wj != 0.0) {
        B[b_j] -= wj;
        for (b_i = b_j + 1; b_i < m; b_i++) {
          B[b_i] -= A_data[A_size[0] * b_j + b_i] * wj;
        }
      }

      wj = B[b_j + 4];
      for (b_i = b_j + 1; b_i < m; b_i++) {
        wj += A_data[A_size[0] * b_j + b_i] * B[b_i + 4];
      }

      wj *= tau_data[b_j];
      if (wj != 0.0) {
        B[b_j + 4] -= wj;
        for (b_i = b_j + 1; b_i < m; b_i++) {
          B[b_i + 4] -= A_data[A_size[0] * b_j + b_i] * wj;
        }
      }

      wj = B[b_j + 8];
      for (b_i = b_j + 1; b_i < m; b_i++) {
        wj += A_data[A_size[0] * b_j + b_i] * B[b_i + 8];
      }

      wj *= tau_data[b_j];
      if (wj != 0.0) {
        B[b_j + 8] -= wj;
        for (b_i = b_j + 1; b_i < m; b_i++) {
          B[b_i + 8] -= A_data[A_size[0] * b_j + b_i] * wj;
        }
      }

      wj = B[b_j + 12];
      for (b_i = b_j + 1; b_i < m; b_i++) {
        wj += A_data[A_size[0] * b_j + b_i] * B[b_i + 12];
      }

      wj *= tau_data[b_j];
      if (wj != 0.0) {
        B[b_j + 12] -= wj;
        for (b_i = b_j + 1; b_i < m; b_i++) {
          B[b_i + 12] -= A_data[A_size[0] * b_j + b_i] * wj;
        }
      }
    }
  }

  for (mn = 0; mn < rankA; mn++) {
    Y_data[jpvt_data[mn] - 1] = B[mn];
  }

  for (mn = rankA - 1; mn + 1 > 0; mn--) {
    m = A_size[0] * mn;
    Y_data[jpvt_data[mn] - 1] /= A_data[m + mn];
    for (b_i = 0; b_i < mn; b_i++) {
      Y_data[jpvt_data[b_i] - 1] -= A_data[m + b_i] * Y_data[jpvt_data[mn] - 1];
    }
  }

  for (mn = 0; mn < rankA; mn++) {
    Y_data[(jpvt_data[mn] + b_idx_0) - 1] = B[mn + 4];
  }

  for (mn = rankA - 1; mn + 1 > 0; mn--) {
    m = (jpvt_data[mn] + b_idx_0) - 1;
    b_j = A_size[0] * mn;
    Y_data[m] /= A_data[b_j + mn];
    for (b_i = 0; b_i < mn; b_i++) {
      m = (jpvt_data[b_i] + b_idx_0) - 1;
      Y_data[m] -= Y_data[(jpvt_data[mn] + b_idx_0) - 1] * A_data[b_j + b_i];
    }
  }

  for (mn = 0; mn < rankA; mn++) {
    Y_data[(jpvt_data[mn] + (b_idx_0 << 1)) - 1] = B[mn + 8];
  }

  for (mn = rankA - 1; mn + 1 > 0; mn--) {
    m = A_size[0] * mn;
    Y_data[(jpvt_data[mn] + (b_idx_0 << 1)) - 1] /= A_data[m + mn];
    for (b_i = 0; b_i < mn; b_i++) {
      Y_data[(jpvt_data[b_i] + (b_idx_0 << 1)) - 1] -= Y_data[((b_idx_0 << 1) +
        jpvt_data[mn]) - 1] * A_data[m + b_i];
    }
  }

  for (mn = 0; mn < rankA; mn++) {
    Y_data[(jpvt_data[mn] + b_idx_0 * 3) - 1] = B[mn + 12];
  }

  for (mn = rankA - 1; mn + 1 > 0; mn--) {
    m = b_idx_0 * 3;
    b_j = A_size[0] * mn;
    Y_data[(jpvt_data[mn] + m) - 1] /= A_data[b_j + mn];
    for (b_i = 0; b_i < mn; b_i++) {
      Y_data[(jpvt_data[b_i] + m) - 1] -= Y_data[(b_idx_0 * 3 + jpvt_data[mn]) -
        1] * A_data[b_j + b_i];
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qrsolve(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2])
{
  real_T tau_data[26];
  int32_T jpvt_data[26];
  int32_T loop_ub;
  int32_T b_A_size[2];
  int32_T jpvt_size[2];
  b_A_size[0] = A_size[0];
  b_A_size[1] = A_size[1];
  loop_ub = A_size[0] * A_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&pmpc_hil1_B.b_A_data[0], &A_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  pmpc_hil1_xgeqp3(pmpc_hil1_B.b_A_data, b_A_size, tau_data, &loop_ub, jpvt_data,
                   jpvt_size);
  pmpc_hil1_LSQFromQR(pmpc_hil1_B.b_A_data, b_A_size, tau_data, jpvt_data,
                      pmpc_hil1_rankFromQR(pmpc_hil1_B.b_A_data, b_A_size),
                      Y_data, Y_size);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_mldivide(const real_T A_data[], const int32_T A_size[2],
  real_T Y_data[], int32_T Y_size[2])
{
  real_T B[16];
  int32_T ip;
  real_T b_A_data[16];
  int32_T ipiv[4];
  int32_T jpiv_offset;
  int32_T iy;
  real_T b_temp;
  int32_T k;
  int32_T b_ix;
  int32_T d;
  int32_T ijA;
  static const int8_T b_B[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1
  };

  int32_T loop_ub;
  if (A_size[1] == 0) {
    Y_size[0] = 0;
    Y_size[1] = 4;
  } else if (4 == A_size[1]) {
    loop_ub = (A_size[0] << 2) - 1;
    if (0 <= loop_ub) {
      memcpy(&b_A_data[0], &A_data[0], (loop_ub + 1) * sizeof(real_T));
    }

    ipiv[0] = 1;
    ipiv[1] = 2;
    ipiv[2] = 3;
    ipiv[3] = 4;
    for (loop_ub = 0; loop_ub < 3; loop_ub++) {
      ip = loop_ub * 5;
      iy = pmpc_hil1_ixamax(4 - loop_ub, b_A_data, 1 + ip) - 1;
      jpiv_offset = pmpc_hil1_ixamax(4 - loop_ub, b_A_data, 1 + ip);
      if (b_A_data[(ip + jpiv_offset) - 1] != 0.0) {
        if (iy != 0) {
          ipiv[loop_ub] = loop_ub + jpiv_offset;
          iy += loop_ub;
          b_temp = b_A_data[loop_ub];
          b_A_data[loop_ub] = b_A_data[iy];
          b_A_data[iy] = b_temp;
          jpiv_offset = loop_ub + 4;
          iy += 4;
          b_temp = b_A_data[jpiv_offset];
          b_A_data[jpiv_offset] = b_A_data[iy];
          b_A_data[iy] = b_temp;
          jpiv_offset += 4;
          iy += 4;
          b_temp = b_A_data[jpiv_offset];
          b_A_data[jpiv_offset] = b_A_data[iy];
          b_A_data[iy] = b_temp;
          jpiv_offset += 4;
          iy += 4;
          b_temp = b_A_data[jpiv_offset];
          b_A_data[jpiv_offset] = b_A_data[iy];
          b_A_data[iy] = b_temp;
        }

        jpiv_offset = (ip - loop_ub) + 4;
        for (iy = ip + 1; iy < jpiv_offset; iy++) {
          b_A_data[iy] /= b_A_data[ip];
        }
      }

      jpiv_offset = ip + 5;
      iy = ip + 4;
      for (k = 1; k <= 3 - loop_ub; k++) {
        b_temp = b_A_data[iy];
        if (b_A_data[iy] != 0.0) {
          b_ix = ip + 1;
          d = (jpiv_offset - loop_ub) + 3;
          for (ijA = jpiv_offset; ijA < d; ijA++) {
            b_A_data[ijA] += b_A_data[b_ix] * -b_temp;
            b_ix++;
          }
        }

        iy += 4;
        jpiv_offset += 4;
      }
    }

    for (loop_ub = 0; loop_ub < 16; loop_ub++) {
      B[loop_ub] = b_B[loop_ub];
    }

    for (loop_ub = 0; loop_ub < 3; loop_ub++) {
      if (loop_ub + 1 != ipiv[loop_ub]) {
        ip = ipiv[loop_ub] - 1;
        iy = (int32_T)B[loop_ub];
        B[loop_ub] = B[ip];
        B[ip] = iy;
        iy = (int32_T)B[loop_ub + 4];
        B[loop_ub + 4] = B[ip + 4];
        B[ip + 4] = iy;
        iy = (int32_T)B[loop_ub + 8];
        B[loop_ub + 8] = B[ip + 8];
        B[ip + 8] = iy;
        iy = (int32_T)B[loop_ub + 12];
        B[loop_ub + 12] = B[ip + 12];
        B[ip + 12] = iy;
      }
    }

    for (loop_ub = 0; loop_ub < 4; loop_ub++) {
      ip = loop_ub << 2;
      if (B[ip] != 0.0) {
        for (k = 1; k + 1 < 5; k++) {
          B[k + ip] -= B[ip] * b_A_data[k];
        }
      }

      if (B[1 + ip] != 0.0) {
        for (k = 2; k + 1 < 5; k++) {
          B[k + ip] -= B[1 + ip] * b_A_data[k + 4];
        }
      }

      if (B[2 + ip] != 0.0) {
        for (k = 3; k + 1 < 5; k++) {
          B[k + ip] -= B[2 + ip] * b_A_data[k + 8];
        }
      }
    }

    for (loop_ub = 0; loop_ub < 4; loop_ub++) {
      ip = loop_ub << 2;
      if (B[3 + ip] != 0.0) {
        B[3 + ip] /= b_A_data[15];
        for (k = 0; k < 3; k++) {
          B[k + ip] -= B[3 + ip] * b_A_data[k + 12];
        }
      }

      if (B[2 + ip] != 0.0) {
        B[2 + ip] /= b_A_data[10];
        for (k = 0; k < 2; k++) {
          B[k + ip] -= B[2 + ip] * b_A_data[k + 8];
        }
      }

      if (B[1 + ip] != 0.0) {
        B[1 + ip] /= b_A_data[5];
        for (k = 0; k < 1; k++) {
          B[k + ip] -= B[1 + ip] * b_A_data[k + 4];
        }
      }

      if (B[ip] != 0.0) {
        B[ip] /= b_A_data[0];
      }
    }

    Y_size[0] = 4;
    Y_size[1] = 4;
    memcpy(&Y_data[0], &B[0], sizeof(real_T) << 4U);
  } else {
    pmpc_hil1_qrsolve(A_data, A_size, Y_data, Y_size);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_Unconstrained(const real_T Hinv[16], const real_T f[4],
  real_T x_data[], int16_T n)
{
  int16_T i;
  int32_T tmp;
  for (i = 1; i <= n; i++) {
    tmp = i - 1;
    x_data[tmp] = ((-Hinv[tmp] * f[0] + -Hinv[i + 3] * f[1]) + -Hinv[i + 7] * f
                   [2]) + -Hinv[i + 11] * f[3];
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_abs(const real_T x[4], real_T y[4])
{
  y[0] = std::abs(x[0]);
  y[1] = std::abs(x[1]);
  y[2] = std::abs(x[2]);
  y[3] = std::abs(x[3]);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_abs_j(const real_T x[8], real_T y[8])
{
  int32_T k;
  for (k = 0; k < 8; k++) {
    y[k] = std::abs(x[k]);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgemv_k(int32_T m, int32_T n, const real_T A_data[],
  int32_T ia0, int32_T lda, const real_T x_data[], int32_T ix0, real_T y[4])
{
  int32_T ix;
  real_T c;
  int32_T iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if (n != 0) {
    for (iy = 1; iy <= n; iy++) {
      y[iy - 1] = 0.0;
    }

    iy = 0;
    b = (n - 1) * lda + ia0;
    iac = ia0;
    while ((lda > 0) && (iac <= b)) {
      ix = ix0;
      c = 0.0;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += A_data[ia - 1] * x_data[ix - 1];
        ix++;
      }

      y[iy] += c;
      iy++;
      iac += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xger_k(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[4], real_T A_data[], int32_T ia0, int32_T lda)
{
  int32_T jA;
  int32_T jy;
  real_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 1; j <= n; j++) {
      if (y[jy] != 0.0) {
        temp = y[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          A_data[ijA] += A_data[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += lda;
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgeqrf_f(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size)
{
  int32_T m;
  int32_T mn;
  real_T work[4];
  int32_T i_i;
  int32_T mmi;
  int32_T i_ip1;
  real_T b_atmp;
  int32_T i;
  real_T xnorm;
  int32_T knt;
  int32_T c_k;
  int32_T coltop;
  int32_T exitg1;
  boolean_T exitg2;
  m = A_size[0];
  if (A_size[0] < 4) {
    mn = A_size[0];
  } else {
    mn = 4;
  }

  *tau_size = (int8_T)mn;
  if (A_size[0] != 0) {
    work[0] = 0.0;
    work[1] = 0.0;
    work[2] = 0.0;
    work[3] = 0.0;
    for (i = 0; i < mn; i++) {
      i_i = i * m + i;
      mmi = m - i;
      if (i + 1 < m) {
        b_atmp = A_data[i_i];
        tau_data[i] = 0.0;
        if (!(mmi <= 0)) {
          xnorm = pmpc_hil1_xnrm2(mmi - 1, A_data, i_i + 2);
          if (xnorm != 0.0) {
            xnorm = rt_hypotd_snf(A_data[i_i], xnorm);
            if (A_data[i_i] >= 0.0) {
              xnorm = -xnorm;
            }

            if (std::abs(xnorm) < 1.0020841800044864E-292) {
              knt = 0;
              coltop = i_i + mmi;
              do {
                knt++;
                for (c_k = i_i + 1; c_k < coltop; c_k++) {
                  A_data[c_k] *= 9.9792015476736E+291;
                }

                xnorm *= 9.9792015476736E+291;
                b_atmp *= 9.9792015476736E+291;
              } while (!(std::abs(xnorm) >= 1.0020841800044864E-292));

              xnorm = rt_hypotd_snf(b_atmp, pmpc_hil1_xnrm2(mmi - 1, A_data, i_i
                + 2));
              if (b_atmp >= 0.0) {
                xnorm = -xnorm;
              }

              tau_data[i] = (xnorm - b_atmp) / xnorm;
              b_atmp = 1.0 / (b_atmp - xnorm);
              coltop = i_i + mmi;
              for (c_k = i_i + 1; c_k < coltop; c_k++) {
                A_data[c_k] *= b_atmp;
              }

              for (i_ip1 = 1; i_ip1 <= knt; i_ip1++) {
                xnorm *= 1.0020841800044864E-292;
              }

              b_atmp = xnorm;
            } else {
              tau_data[i] = (xnorm - A_data[i_i]) / xnorm;
              b_atmp = 1.0 / (A_data[i_i] - xnorm);
              knt = i_i + mmi;
              for (coltop = i_i + 1; coltop < knt; coltop++) {
                A_data[coltop] *= b_atmp;
              }

              b_atmp = xnorm;
            }
          }
        }

        A_data[i_i] = b_atmp;
      } else {
        tau_data[i] = 0.0;
      }

      if (i + 1 < 4) {
        b_atmp = A_data[i_i];
        A_data[i_i] = 1.0;
        i_ip1 = ((i + 1) * m + i) + 1;
        if (tau_data[i] != 0.0) {
          knt = mmi;
          mmi = (i_i + mmi) - 1;
          while ((knt > 0) && (A_data[mmi] == 0.0)) {
            knt--;
            mmi--;
          }

          mmi = 3 - i;
          exitg2 = false;
          while ((!exitg2) && (mmi > 0)) {
            coltop = (mmi - 1) * m + i_ip1;
            c_k = coltop;
            do {
              exitg1 = 0;
              if (c_k <= (coltop + knt) - 1) {
                if (A_data[c_k - 1] != 0.0) {
                  exitg1 = 1;
                } else {
                  c_k++;
                }
              } else {
                mmi--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);

            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        } else {
          knt = 0;
          mmi = 0;
        }

        if (knt > 0) {
          pmpc_hil1_xgemv_k(knt, mmi, A_data, i_ip1, m, A_data, i_i + 1, work);
          pmpc_hil1_xger_k(knt, mmi, -tau_data[i], i_i + 1, work, A_data, i_ip1,
                           m);
        }

        A_data[i_i] = b_atmp;
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xgeqrf(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size)
{
  int32_T m;
  int32_T n;
  int32_T mn;
  real_T work_data[26];
  int32_T i_i;
  int32_T mmi;
  real_T b_atmp;
  int32_T loop_ub;
  int8_T c_idx_0;
  m = A_size[0];
  n = A_size[1];
  if (A_size[0] < A_size[1]) {
    mn = A_size[0];
  } else {
    mn = A_size[1];
  }

  *tau_size = (int8_T)mn;
  if (!((A_size[0] == 0) || (A_size[1] == 0))) {
    c_idx_0 = (int8_T)A_size[1];
    if (0 <= c_idx_0 - 1) {
      memset(&work_data[0], 0, c_idx_0 * sizeof(real_T));
    }

    for (loop_ub = 0; loop_ub < mn; loop_ub++) {
      i_i = loop_ub * m + loop_ub;
      mmi = m - loop_ub;
      if (loop_ub + 1 < m) {
        b_atmp = A_data[i_i];
        tau_data[loop_ub] = pmpc_hil1_xzlarfg(mmi, &b_atmp, A_data, i_i + 2);
        A_data[i_i] = b_atmp;
      } else {
        tau_data[loop_ub] = 0.0;
      }

      if (loop_ub + 1 < n) {
        b_atmp = A_data[i_i];
        A_data[i_i] = 1.0;
        pmpc_hil1_xzlarf(mmi, (n - loop_ub) - 1, i_i + 1, tau_data[loop_ub],
                         A_data, (loop_ub + (loop_ub + 1) * m) + 1, m, work_data);
        A_data[i_i] = b_atmp;
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_xscal(int32_T n, real_T a, real_T x_data[], int32_T ix0)
{
  int32_T b;
  int32_T k;
  b = (ix0 + n) - 1;
  for (k = ix0; k <= b; k++) {
    x_data[k - 1] *= a;
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qr(const real_T A_data[], const int32_T A_size[2], real_T
  Q_data[], int32_T Q_size[2], real_T R_data[], int32_T R_size[2])
{
  int32_T m;
  real_T b_A_data[104];
  real_T tau_data[4];
  real_T b_tau_data[26];
  int32_T i_i;
  int32_T itau;
  real_T work[4];
  int32_T iaii;
  int32_T lastv;
  int32_T lastc;
  int32_T coltop;
  int32_T ia;
  real_T b_work_data[26];
  int32_T b_A_size[2];
  int8_T b_idx_0;
  int32_T b_c_tmp;
  int32_T exitg1;
  boolean_T exitg2;
  m = A_size[0];
  b_idx_0 = (int8_T)A_size[0];
  Q_size[0] = (int8_T)A_size[0];
  Q_size[1] = (int8_T)A_size[0];
  R_size[0] = A_size[0];
  R_size[1] = A_size[1];
  if (A_size[0] > 4) {
    for (i_i = 0; i_i < m; i_i++) {
      Q_data[i_i] = A_data[i_i];
    }

    for (i_i = 0; i_i < m; i_i++) {
      Q_data[i_i + b_idx_0] = A_data[i_i + A_size[0]];
    }

    for (i_i = 0; i_i < m; i_i++) {
      Q_data[i_i + (b_idx_0 << 1)] = A_data[(A_size[0] << 1) + i_i];
    }

    for (i_i = 0; i_i < m; i_i++) {
      Q_data[i_i + b_idx_0 * 3] = A_data[A_size[0] * 3 + i_i];
    }

    for (itau = 5; itau <= m; itau++) {
      for (i_i = 1; i_i <= m; i_i++) {
        Q_data[(i_i + b_idx_0 * (itau - 1)) - 1] = 0.0;
      }
    }

    pmpc_hil1_xgeqrf(Q_data, Q_size, b_tau_data, &itau);
    for (i_i = 0; i_i < 1; i_i++) {
      R_data[i_i] = Q_data[i_i];
    }

    for (i_i = 1; i_i < m; i_i++) {
      R_data[i_i] = 0.0;
    }

    for (i_i = 0; i_i < 2; i_i++) {
      R_data[i_i + R_size[0]] = Q_data[i_i + Q_size[0]];
    }

    for (i_i = 2; i_i < m; i_i++) {
      R_data[i_i + R_size[0]] = 0.0;
    }

    for (i_i = 0; i_i < 3; i_i++) {
      R_data[i_i + (R_size[0] << 1)] = Q_data[(Q_size[0] << 1) + i_i];
    }

    for (i_i = 3; i_i < m; i_i++) {
      R_data[i_i + (R_size[0] << 1)] = 0.0;
    }

    for (i_i = 0; i_i < 4; i_i++) {
      R_data[i_i + R_size[0] * 3] = Q_data[Q_size[0] * 3 + i_i];
    }

    for (i_i = 4; i_i < m; i_i++) {
      R_data[i_i + R_size[0] * 3] = 0.0;
    }

    for (itau = 4; itau < m; itau++) {
      i_i = itau * m;
      for (iaii = 0; iaii < m; iaii++) {
        Q_data[i_i + iaii] = 0.0;
      }

      Q_data[i_i + itau] = 1.0;
    }

    b_idx_0 = (int8_T)Q_size[1];
    if (0 <= b_idx_0 - 1) {
      memset(&b_work_data[0], 0, b_idx_0 * sizeof(real_T));
    }

    iaii = 3 * A_size[0] + 3;
    Q_data[iaii] = 1.0;
    pmpc_hil1_xzlarf(A_size[0] - 3, A_size[0] - 4, iaii + 1, b_tau_data[3],
                     Q_data, (iaii + A_size[0]) + 1, A_size[0], b_work_data);
    pmpc_hil1_xscal(A_size[0] - 4, -b_tau_data[3], Q_data, iaii + 2);
    Q_data[iaii] = 1.0 - b_tau_data[3];
    for (lastc = 1; lastc < 4; lastc++) {
      Q_data[iaii - lastc] = 0.0;
    }

    iaii = (A_size[0] << 1) + 2;
    Q_data[iaii] = 1.0;
    pmpc_hil1_xzlarf(A_size[0] - 2, A_size[0] - 3, iaii + 1, b_tau_data[2],
                     Q_data, (iaii + A_size[0]) + 1, A_size[0], b_work_data);
    pmpc_hil1_xscal(A_size[0] - 3, -b_tau_data[2], Q_data, iaii + 2);
    Q_data[iaii] = 1.0 - b_tau_data[2];
    for (lastc = 1; lastc < 3; lastc++) {
      Q_data[iaii - lastc] = 0.0;
    }

    iaii = 1 + A_size[0];
    Q_data[iaii] = 1.0;
    pmpc_hil1_xzlarf(A_size[0] - 1, A_size[0] - 2, iaii + 1, b_tau_data[1],
                     Q_data, (iaii + A_size[0]) + 1, A_size[0], b_work_data);
    pmpc_hil1_xscal(A_size[0] - 2, -b_tau_data[1], Q_data, iaii + 2);
    Q_data[iaii] = 1.0 - b_tau_data[1];
    Q_data[iaii - 1] = 0.0;
    Q_data[0] = 1.0;
    pmpc_hil1_xzlarf(A_size[0], A_size[0] - 1, 1, b_tau_data[0], Q_data, A_size
                     [0] + 1, A_size[0], b_work_data);
    pmpc_hil1_xscal(A_size[0] - 1, -b_tau_data[0], Q_data, 2);
    Q_data[0] = 1.0 - b_tau_data[0];
  } else {
    b_A_size[0] = A_size[0];
    b_A_size[1] = 4;
    itau = A_size[0] * A_size[1] - 1;
    if (0 <= itau) {
      memcpy(&b_A_data[0], &A_data[0], (itau + 1) * sizeof(real_T));
    }

    pmpc_hil1_xgeqrf_f(b_A_data, b_A_size, tau_data, &itau);
    for (itau = 0; itau < m; itau++) {
      for (i_i = 0; i_i < itau + 1; i_i++) {
        R_data[i_i + R_size[0] * itau] = b_A_data[b_A_size[0] * itau + i_i];
      }

      for (i_i = itau + 1; i_i < m; i_i++) {
        R_data[i_i + R_size[0] * itau] = 0.0;
      }
    }

    for (itau = A_size[0]; itau + 1 < 5; itau++) {
      for (i_i = 0; i_i < m; i_i++) {
        R_data[i_i + R_size[0] * itau] = b_A_data[b_A_size[0] * itau + i_i];
      }
    }

    if (!(A_size[0] < 1)) {
      for (itau = A_size[0]; itau < m; itau++) {
        i_i = itau * m;
        for (iaii = 0; iaii < m; iaii++) {
          b_A_data[i_i + iaii] = 0.0;
        }

        b_A_data[i_i + itau] = 1.0;
      }

      itau = A_size[0] - 1;
      work[0] = 0.0;
      work[1] = 0.0;
      work[2] = 0.0;
      work[3] = 0.0;
      for (i_i = A_size[0]; i_i >= 1; i_i--) {
        iaii = (i_i - 1) * m + i_i;
        if (i_i < m) {
          b_A_data[iaii - 1] = 1.0;
          coltop = m - i_i;
          lastc = coltop - 1;
          b_c_tmp = iaii + m;
          if (tau_data[itau] != 0.0) {
            lastv = lastc + 2;
            lastc += iaii;
            while ((lastv > 0) && (b_A_data[lastc] == 0.0)) {
              lastv--;
              lastc--;
            }

            lastc = coltop;
            exitg2 = false;
            while ((!exitg2) && (lastc > 0)) {
              coltop = (lastc - 1) * m + b_c_tmp;
              ia = coltop;
              do {
                exitg1 = 0;
                if (ia <= (coltop + lastv) - 1) {
                  if (b_A_data[ia - 1] != 0.0) {
                    exitg1 = 1;
                  } else {
                    ia++;
                  }
                } else {
                  lastc--;
                  exitg1 = 2;
                }
              } while (exitg1 == 0);

              if (exitg1 == 1) {
                exitg2 = true;
              }
            }
          } else {
            lastv = 0;
            lastc = 0;
          }

          if (lastv > 0) {
            pmpc_hil1_xgemv_k(lastv, lastc, b_A_data, b_c_tmp, m, b_A_data, iaii,
                              work);
            pmpc_hil1_xger_k(lastv, lastc, -tau_data[itau], iaii, work, b_A_data,
                             b_c_tmp, m);
          }

          lastc = b_c_tmp - i_i;
          for (lastv = iaii; lastv < lastc; lastv++) {
            b_A_data[lastv] *= -tau_data[itau];
          }
        }

        b_A_data[iaii - 1] = 1.0 - tau_data[itau];
        for (lastc = 1; lastc < i_i; lastc++) {
          b_A_data[(iaii - lastc) - 1] = 0.0;
        }

        itau--;
      }
    }

    for (itau = 0; itau < m; itau++) {
      for (i_i = 0; i_i < m; i_i++) {
        Q_data[i_i + b_idx_0 * itau] = b_A_data[b_A_size[0] * itau + i_i];
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static real_T pmpc_hil1_KWIKfactor(const int16_T iC[8], int16_T nA, const real_T
  Linv_data[], const int32_T Linv_size[2], real_T RLinv_data[], int32_T
  RLinv_size[2], real_T D_data[], int32_T D_size[2], real_T H_data[], int32_T
  H_size[2], int16_T n)
{
  real_T Status;
  real_T TL_data[104];
  real_T RR_data[104];
  int16_T i;
  int16_T f_i;
  int16_T d_k;
  real_T a_data[26];
  real_T b_data[26];
  int32_T m;
  int32_T aoffset;
  int32_T g_i;
  int32_T h_i;
  static const int8_T Ac[32] = { 1, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, -1, 0,
    0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, -1 };

  int32_T RLinv;
  real_T tmp;
  int32_T QQ_size[2];
  int32_T RR_size[2];
  int32_T TL_size_idx_0;
  int32_T exitg1;
  TL_size_idx_0 = Linv_size[0];
  Status = 1.0;
  RLinv = RLinv_size[0];
  if (0 <= RLinv - 1) {
    memset(&RLinv_data[0], 0, RLinv * sizeof(real_T));
  }

  for (g_i = 0; g_i < RLinv; g_i++) {
    RLinv_data[g_i + RLinv_size[0]] = 0.0;
  }

  for (g_i = 0; g_i < RLinv; g_i++) {
    RLinv_data[g_i + (RLinv_size[0] << 1)] = 0.0;
  }

  for (g_i = 0; g_i < RLinv; g_i++) {
    RLinv_data[g_i + RLinv_size[0] * 3] = 0.0;
  }

  for (i = 1; i <= nA; i++) {
    m = Linv_size[0];
    RLinv = Linv_size[0];
    for (g_i = 1; g_i <= m; g_i++) {
      b_data[g_i - 1] = 0.0;
    }

    g_i = i - 1;
    if (Ac[iC[g_i] - 1] != 0) {
      for (h_i = 0; h_i < m; h_i++) {
        b_data[h_i] += (real_T)Ac[iC[i - 1] - 1] * Linv_data[h_i];
      }
    }

    if (Ac[iC[i - 1] + 7] != 0) {
      for (h_i = 0; h_i < m; h_i++) {
        b_data[h_i] += (real_T)Ac[iC[i - 1] + 7] * Linv_data[m + h_i];
      }
    }

    if (Ac[iC[i - 1] + 15] != 0) {
      aoffset = Linv_size[0] << 1;
      for (h_i = 0; h_i < m; h_i++) {
        b_data[h_i] += (real_T)Ac[iC[i - 1] + 15] * Linv_data[aoffset + h_i];
      }
    }

    if (Ac[iC[i - 1] + 23] != 0) {
      aoffset = 3 * Linv_size[0];
      for (h_i = 0; h_i < m; h_i++) {
        b_data[h_i] += (real_T)Ac[iC[i - 1] + 23] * Linv_data[aoffset + h_i];
      }
    }

    for (m = 0; m < RLinv; m++) {
      RLinv_data[m + RLinv_size[0] * g_i] = b_data[m];
    }
  }

  pmpc_hil1_qr(RLinv_data, RLinv_size, pmpc_hil1_B.QQ_data, QQ_size, RR_data,
               RR_size);
  i = 1;
  do {
    exitg1 = 0;
    if (i <= nA) {
      if (std::abs(RR_data[((i - 1) * RR_size[0] + i) - 1]) < 1.0E-12) {
        Status = -2.0;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      for (i = 1; i <= n; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          RLinv = Linv_size[0];
          for (g_i = 0; g_i < RLinv; g_i++) {
            a_data[g_i] = Linv_data[(i - 1) * Linv_size[0] + g_i];
          }

          m = QQ_size[0];
          for (g_i = 0; g_i < m; g_i++) {
            b_data[g_i] = pmpc_hil1_B.QQ_data[(f_i - 1) * QQ_size[0] + g_i];
          }

          if ((Linv_size[0] == 1) || (QQ_size[0] == 1)) {
            tmp = 0.0;
            for (g_i = 0; g_i < RLinv; g_i++) {
              tmp += a_data[g_i] * b_data[g_i];
            }

            TL_data[(i + TL_size_idx_0 * (f_i - 1)) - 1] = tmp;
          } else {
            tmp = 0.0;
            for (g_i = 0; g_i < RLinv; g_i++) {
              tmp += a_data[g_i] * b_data[g_i];
            }

            TL_data[(i + TL_size_idx_0 * (f_i - 1)) - 1] = tmp;
          }
        }
      }

      RLinv = RLinv_size[0];
      if (0 <= RLinv - 1) {
        memset(&RLinv_data[0], 0, RLinv * sizeof(real_T));
      }

      for (g_i = 0; g_i < RLinv; g_i++) {
        RLinv_data[g_i + RLinv_size[0]] = 0.0;
      }

      for (g_i = 0; g_i < RLinv; g_i++) {
        RLinv_data[g_i + (RLinv_size[0] << 1)] = 0.0;
      }

      for (g_i = 0; g_i < RLinv; g_i++) {
        RLinv_data[g_i + RLinv_size[0] * 3] = 0.0;
      }

      i = nA;
      while (i > 0) {
        g_i = i - 1;
        RLinv_data[(i + RLinv_size[0] * g_i) - 1] = 1.0;
        for (f_i = i; f_i <= nA; f_i++) {
          m = f_i - 1;
          RLinv_data[(i + RLinv_size[0] * m) - 1] /= RR_data[((i - 1) * RR_size
            [0] + i) - 1];
        }

        if (i > 1) {
          for (f_i = 1; f_i <= g_i; f_i++) {
            for (d_k = i; d_k <= nA; d_k++) {
              m = d_k - 1;
              RLinv = m * RLinv_size[0];
              RLinv_data[(f_i + RLinv_size[0] * m) - 1] = RLinv_data[(RLinv +
                f_i) - 1] - RR_data[(g_i * RR_size[0] + f_i) - 1] * RLinv_data
                [(RLinv + i) - 1];
            }
          }
        }

        i = (int16_T)g_i;
      }

      for (i = 1; i <= n; i++) {
        for (f_i = i; f_i <= n; f_i++) {
          g_i = f_i - 1;
          m = (i + H_size[0] * g_i) - 1;
          H_data[m] = 0.0;
          for (d_k = (int16_T)(nA + 1); d_k <= n; d_k++) {
            RLinv = (d_k - 1) * TL_size_idx_0;
            H_data[m] = H_data[((f_i - 1) * H_size[0] + i) - 1] - TL_data[(RLinv
              + i) - 1] * TL_data[(RLinv + f_i) - 1];
          }

          H_data[(f_i + H_size[0] * (i - 1)) - 1] = H_data[(g_i * H_size[0] + i)
            - 1];
        }
      }

      for (i = 1; i <= nA; i++) {
        for (f_i = 1; f_i <= n; f_i++) {
          g_i = i - 1;
          m = (f_i + D_size[0] * g_i) - 1;
          D_data[m] = 0.0;
          for (d_k = i; d_k <= nA; d_k++) {
            RLinv = d_k - 1;
            D_data[m] = TL_data[(RLinv * TL_size_idx_0 + f_i) - 1] * RLinv_data
              [(RLinv * RLinv_size[0] + i) - 1] + D_data[(g_i * D_size[0] + f_i)
              - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_DropConstraint(int16_T kDrop, int16_T iA[8], int16_T *nA,
  int16_T iC[8])
{
  int16_T i;
  int32_T tmp;
  iA[iC[kDrop - 1] - 1] = 0;
  if (kDrop < *nA) {
    tmp = *nA - 1;
    if (tmp < -32768) {
      tmp = -32768;
    }

    for (i = kDrop; i <= (int16_T)tmp; i++) {
      iC[i - 1] = iC[i];
    }
  }

  iC[*nA - 1] = 0;
  tmp = *nA - 1;
  if (tmp < -32768) {
    tmp = -32768;
  }

  *nA = (int16_T)tmp;
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_qpkwik(const real_T Linv_data[], const int32_T Linv_size[2],
  const real_T Hinv[16], const real_T f[4], const real_T b[8], int16_T n, real_T
  x_data[], int32_T *x_size, real_T lambda[8], real_T *status, int16_T iA[8])
{
  real_T r_data[26];
  real_T rMin;
  real_T RLinv_data[104];
  real_T D_data[104];
  real_T H_data[104];
  real_T cTol[8];
  boolean_T cTolComputed;
  int16_T iC[8];
  int16_T nA;
  int16_T kDrop;
  real_T Xnorm0;
  real_T cMin;
  int16_T kNext;
  real_T cVal;
  real_T AcRow[4];
  real_T z_data[26];
  boolean_T isT1Inf;
  boolean_T tempOK;
  real_T t;
  int16_T iSave;
  real_T varargin_1[8];
  real_T a_data[104];
  int32_T aoffset;
  static const int8_T Ac[32] = { 1, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, -1, 0,
    0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, -1 };

  int32_T i;
  real_T Ac_0[4];
  int32_T loop_ub;
  real_T x_data_0[26];
  int32_T RLinv_size[2];
  int32_T D_size[2];
  int32_T H_size[2];
  int32_T a_size_idx_0;
  int32_T z_size_idx_0;
  int32_T exitg1;
  int32_T exitg2;
  boolean_T exitg3;
  boolean_T guard1 = false;
  *status = 1.0;
  memset(&lambda[0], 0, sizeof(real_T) << 3U);
  for (i = 0; i < 8; i++) {
    iA[i] = 0;
  }

  if (0 <= n - 1) {
    memset(&r_data[0], 0, n * sizeof(real_T));
  }

  rMin = 0.0;
  RLinv_size[0] = Linv_size[0];
  RLinv_size[1] = Linv_size[1];
  D_size[0] = Linv_size[0];
  D_size[1] = Linv_size[1];
  H_size[0] = Linv_size[0];
  H_size[1] = Linv_size[1];
  cTolComputed = false;
  for (i = 0; i < 8; i++) {
    cTol[i] = 1.0;
    iC[i] = 0;
  }

  nA = 0;
  *x_size = n;
  if (0 <= n - 1) {
    memset(&x_data[0], 0, n * sizeof(real_T));
  }

  pmpc_hil1_Unconstrained(Hinv, f, x_data, n);
  Xnorm0 = pmpc_hil1_norm(x_data, x_size);
  do {
    exitg2 = 0;
    if (*status <= 200.0) {
      cMin = -1.0E-6;
      kNext = 0;
      for (kDrop = 0; kDrop < 8; kDrop++) {
        if (!cTolComputed) {
          i = kDrop + 1;
          if (0 <= *x_size - 1) {
            memcpy(&x_data_0[0], &x_data[0], *x_size * sizeof(real_T));
          }

          Ac_0[0] = (real_T)Ac[i - 1] * x_data_0[0];
          Ac_0[1] = (real_T)Ac[i + 7] * x_data_0[1];
          Ac_0[2] = (real_T)Ac[i + 15] * x_data_0[2];
          Ac_0[3] = (real_T)Ac[i + 23] * x_data_0[3];
          pmpc_hil1_abs(Ac_0, AcRow);
          if (!rtIsNaN(AcRow[0])) {
            i = 1;
          } else {
            i = 0;
            loop_ub = 2;
            exitg3 = false;
            while ((!exitg3) && (loop_ub < 5)) {
              if (!rtIsNaN(AcRow[loop_ub - 1])) {
                i = loop_ub;
                exitg3 = true;
              } else {
                loop_ub++;
              }
            }
          }

          if (i == 0) {
            cVal = AcRow[0];
          } else {
            cVal = AcRow[i - 1];
            while (i + 1 < 5) {
              if (cVal < AcRow[i]) {
                cVal = AcRow[i];
              }

              i++;
            }
          }

          if (!((cTol[kDrop] > cVal) || rtIsNaN(cVal))) {
            cTol[kDrop] = cVal;
          }
        }

        if (iA[kDrop] == 0) {
          i = kDrop + 1;
          cVal = (((((real_T)Ac[i - 1] * x_data[0] + (real_T)Ac[i + 7] * x_data
                     [1]) + (real_T)Ac[i + 15] * x_data[2]) + (real_T)Ac[i + 23]
                   * x_data[3]) - b[kDrop]) / cTol[kDrop];
          if (cVal < cMin) {
            cMin = cVal;
            kNext = (int16_T)(kDrop + 1);
          }
        }
      }

      cTolComputed = true;
      if (kNext <= 0) {
        exitg2 = 1;
      } else {
        do {
          exitg1 = 0;
          if ((kNext > 0) && (*status <= 200.0)) {
            i = kNext - 1;
            AcRow[0] = Ac[i];
            AcRow[1] = Ac[kNext + 7];
            AcRow[2] = Ac[kNext + 15];
            AcRow[3] = Ac[kNext + 23];
            guard1 = false;
            if (nA == 0) {
              z_size_idx_0 = 4;
              for (aoffset = 0; aoffset < 4; aoffset++) {
                cMin = Hinv[aoffset + 12] * AcRow[3] + (Hinv[aoffset + 8] *
                  AcRow[2] + (Hinv[aoffset + 4] * AcRow[1] + Hinv[aoffset] *
                              AcRow[0]));
                z_data[aoffset] = cMin;
              }

              guard1 = true;
            } else {
              cMin = pmpc_hil1_KWIKfactor(iC, nA, Linv_data, Linv_size,
                RLinv_data, RLinv_size, D_data, D_size, H_data, H_size, n);
              if (cMin <= 0.0) {
                *status = -2.0;
                exitg1 = 1;
              } else {
                a_size_idx_0 = H_size[0];
                loop_ub = H_size[0] * H_size[1] - 1;
                for (aoffset = 0; aoffset <= loop_ub; aoffset++) {
                  a_data[aoffset] = -H_data[aoffset];
                }

                z_size_idx_0 = H_size[0];
                for (loop_ub = 1; loop_ub <= a_size_idx_0; loop_ub++) {
                  z_data[loop_ub - 1] = 0.0;
                }

                if (Ac[kNext - 1] != 0.0) {
                  for (loop_ub = 0; loop_ub < a_size_idx_0; loop_ub++) {
                    z_data[loop_ub] += AcRow[0] * a_data[loop_ub];
                  }
                }

                if (Ac[kNext + 7] != 0.0) {
                  for (loop_ub = 0; loop_ub < a_size_idx_0; loop_ub++) {
                    z_data[loop_ub] += a_data[a_size_idx_0 + loop_ub] * AcRow[1];
                  }
                }

                if (Ac[kNext + 15] != 0.0) {
                  aoffset = H_size[0] << 1;
                  for (loop_ub = 0; loop_ub < a_size_idx_0; loop_ub++) {
                    z_data[loop_ub] += a_data[aoffset + loop_ub] * AcRow[2];
                  }
                }

                if (Ac[kNext + 23] != 0.0) {
                  aoffset = 3 * H_size[0];
                  for (loop_ub = 0; loop_ub < a_size_idx_0; loop_ub++) {
                    z_data[loop_ub] += a_data[aoffset + loop_ub] * AcRow[3];
                  }
                }

                for (kDrop = 1; kDrop <= nA; kDrop++) {
                  loop_ub = D_size[0];
                  for (aoffset = 0; aoffset < loop_ub; aoffset++) {
                    x_data_0[aoffset] = D_data[(kDrop - 1) * D_size[0] + aoffset];
                  }

                  r_data[kDrop - 1] = ((AcRow[0] * x_data_0[0] + AcRow[1] *
                                        x_data_0[1]) + AcRow[2] * x_data_0[2]) +
                    AcRow[3] * x_data_0[3];
                }

                guard1 = true;
              }
            }

            if (guard1) {
              kDrop = 0;
              cMin = 0.0;
              isT1Inf = true;
              tempOK = true;
              if (nA > 0) {
                iSave = 1;
                exitg3 = false;
                while ((!exitg3) && (iSave <= nA)) {
                  if (r_data[iSave - 1] >= 1.0E-12) {
                    tempOK = false;
                    exitg3 = true;
                  } else {
                    iSave++;
                  }
                }
              }

              if (!((nA == 0) || tempOK)) {
                for (iSave = 1; iSave <= nA; iSave++) {
                  aoffset = iSave - 1;
                  if (r_data[aoffset] > 1.0E-12) {
                    cVal = lambda[iC[aoffset] - 1] / r_data[iSave - 1];
                    if ((kDrop == 0) || (cVal < rMin)) {
                      rMin = cVal;
                      kDrop = iSave;
                    }
                  }
                }

                if (kDrop > 0) {
                  cMin = rMin;
                  isT1Inf = false;
                }
              }

              if (0 <= z_size_idx_0 - 1) {
                memcpy(&x_data_0[0], &z_data[0], z_size_idx_0 * sizeof(real_T));
              }

              cVal = (((real_T)Ac[kNext - 1] * x_data_0[0] + (real_T)Ac[kNext +
                       7] * x_data_0[1]) + (real_T)Ac[kNext + 15] * x_data_0[2])
                + (real_T)Ac[kNext + 23] * x_data_0[3];
              if (cVal <= 0.0) {
                cVal = 0.0;
                tempOK = true;
              } else {
                cVal = (b[i] - ((((real_T)Ac[kNext - 1] * x_data[0] + (real_T)
                                  Ac[kNext + 7] * x_data[1]) + (real_T)Ac[kNext
                                 + 15] * x_data[2]) + (real_T)Ac[kNext + 23] *
                                x_data[3])) / cVal;
                tempOK = false;
              }

              if (isT1Inf && tempOK) {
                *status = -1.0;
                exitg1 = 1;
              } else {
                if (tempOK) {
                  t = cMin;
                } else if (isT1Inf) {
                  t = cVal;
                } else if ((cMin < cVal) || rtIsNaN(cVal)) {
                  t = cMin;
                } else {
                  t = cVal;
                }

                for (iSave = 1; iSave <= nA; iSave++) {
                  a_size_idx_0 = iSave - 1;
                  z_size_idx_0 = iC[a_size_idx_0] - 1;
                  lambda[z_size_idx_0] -= r_data[a_size_idx_0] * t;
                  if (lambda[iC[iSave - 1] - 1] < 0.0) {
                    lambda[z_size_idx_0] = 0.0;
                  }
                }

                lambda[i] += t;
                if (t == cMin) {
                  pmpc_hil1_DropConstraint(kDrop, iA, &nA, iC);
                }

                if (!tempOK) {
                  loop_ub = *x_size;
                  for (aoffset = 0; aoffset < loop_ub; aoffset++) {
                    x_data[aoffset] += t * z_data[aoffset];
                  }

                  if (t == cVal) {
                    if (nA == n) {
                      *status = -1.0;
                      exitg1 = 1;
                    } else {
                      aoffset = nA + 1;
                      if (aoffset > 32767) {
                        aoffset = 32767;
                      }

                      nA = (int16_T)aoffset;
                      iC[(int16_T)aoffset - 1] = kNext;
                      kDrop = (int16_T)aoffset;
                      exitg3 = false;
                      while ((!exitg3) && (kDrop > 1)) {
                        aoffset = kDrop - 1;
                        a_size_idx_0 = kDrop - 2;
                        if (iC[aoffset] > iC[a_size_idx_0]) {
                          exitg3 = true;
                        } else {
                          iSave = iC[kDrop - 1];
                          iC[aoffset] = iC[kDrop - 2];
                          iC[a_size_idx_0] = iSave;
                          kDrop = (int16_T)aoffset;
                        }
                      }

                      iA[i] = 1;
                      kNext = 0;
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                } else {
                  (*status)++;
                }
              }
            }
          } else {
            cMin = pmpc_hil1_norm(x_data, x_size);
            if (std::abs(cMin - Xnorm0) > 0.001) {
              Xnorm0 = cMin;
              pmpc_hil1_abs_j(b, varargin_1);
              for (i = 0; i < 8; i++) {
                if (varargin_1[i] > 1.0) {
                  cTol[i] = varargin_1[i];
                } else {
                  cTol[i] = 1.0;
                }
              }

              cTolComputed = false;
            }

            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = 1;
        }
      }
    } else {
      *status = 0.0;
      exitg2 = 1;
    }
  } while (exitg2 == 0);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_mpcqpsolver(const real_T Linv_data[], const int32_T
  Linv_size[2], const real_T f[4], const real_T b[8], real_T x_data[], int32_T
  *x_size, real_T *status, boolean_T iA[8])
{
  real_T Hinv[16];
  real_T lam[8];
  int16_T iA1[8];
  real_T a_data[104];
  int32_T coffset;
  int32_T boffset;
  int32_T aoffset;
  int32_T j;
  int32_T i;
  int32_T a_size_idx_1;
  a_size_idx_1 = Linv_size[0];
  coffset = Linv_size[0];
  for (j = 0; j < coffset; j++) {
    a_data[j << 2] = Linv_data[j];
    a_data[1 + (j << 2)] = Linv_data[j + Linv_size[0]];
    a_data[2 + (j << 2)] = Linv_data[(Linv_size[0] << 1) + j];
    a_data[3 + (j << 2)] = Linv_data[Linv_size[0] * 3 + j];
  }

  if (Linv_size[0] == 1) {
    for (j = 0; j < 4; j++) {
      Hinv[j] = 0.0;
      for (coffset = 0; coffset < a_size_idx_1; coffset++) {
        Hinv[j] += a_data[(coffset << 2) + j] * Linv_data[coffset];
      }

      Hinv[j + 4] = 0.0;
      for (coffset = 0; coffset < a_size_idx_1; coffset++) {
        Hinv[j + 4] += a_data[(coffset << 2) + j] * Linv_data[coffset +
          Linv_size[0]];
      }

      Hinv[j + 8] = 0.0;
      for (coffset = 0; coffset < a_size_idx_1; coffset++) {
        Hinv[j + 8] += a_data[(coffset << 2) + j] * Linv_data[(Linv_size[0] << 1)
          + coffset];
      }

      Hinv[j + 12] = 0.0;
      for (coffset = 0; coffset < a_size_idx_1; coffset++) {
        Hinv[j + 12] += a_data[(coffset << 2) + j] * Linv_data[Linv_size[0] * 3
          + coffset];
      }
    }
  } else {
    for (j = 0; j < 4; j++) {
      coffset = j << 2;
      boffset = j * a_size_idx_1 - 1;
      Hinv[coffset] = 0.0;
      Hinv[coffset + 1] = 0.0;
      Hinv[coffset + 2] = 0.0;
      Hinv[coffset + 3] = 0.0;
      for (i = 1; i <= a_size_idx_1; i++) {
        if (Linv_data[boffset + i] != 0.0) {
          aoffset = (i - 1) << 2;
          Hinv[coffset] += Linv_data[boffset + i] * a_data[aoffset];
          Hinv[coffset + 1] += Linv_data[boffset + i] * a_data[aoffset + 1];
          Hinv[coffset + 2] += Linv_data[boffset + i] * a_data[aoffset + 2];
          Hinv[coffset + 3] += Linv_data[boffset + i] * a_data[aoffset + 3];
        }
      }
    }
  }

  pmpc_hil1_qpkwik(Linv_data, Linv_size, Hinv, f, b, (int16_T)Linv_size[0],
                   x_data, x_size, lam, status, iA1);
  for (i = 0; i < 8; i++) {
    iA[i] = (iA1[i] != 0);
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_QPKwik(const real_T H[16], const real_T f[4], const
  real_T ub[4], real_T x_data[], int32_T *x_size, real_T *status, real_T *nAct)
{
  real_T ubf[4];
  real_T Linv_data[104];
  boolean_T iA_out[8];
  int8_T b_data[4];
  int32_T trueCount;
  real_T tmp[8];
  boolean_T tmp_0[4];
  int32_T Linv_size[2];
  int32_T B_size[2];
  boolean_T c;
  int32_T b_size_idx_0;
  boolean_T c_idx_0;
  boolean_T c_idx_1;
  boolean_T c_idx_2;
  pmpc_hil1_isfinite_cn(ub, tmp_0);
  trueCount = 0;
  ubf[0] = ub[0];
  c = !tmp_0[0];
  if (c) {
    trueCount = 1;
  }

  c_idx_0 = c;
  ubf[1] = ub[1];
  c = !tmp_0[1];
  if (c) {
    trueCount++;
  }

  c_idx_1 = c;
  ubf[2] = ub[2];
  c = !tmp_0[2];
  if (c) {
    trueCount++;
  }

  c_idx_2 = c;
  ubf[3] = ub[3];
  c = !tmp_0[3];
  if (c) {
    trueCount++;
  }

  b_size_idx_0 = trueCount;
  trueCount = 0;
  if (c_idx_0) {
    b_data[0] = 1;
    trueCount = 1;
  }

  if (c_idx_1) {
    b_data[trueCount] = 2;
    trueCount++;
  }

  if (c_idx_2) {
    b_data[trueCount] = 3;
    trueCount++;
  }

  if (c) {
    b_data[trueCount] = 4;
  }

  for (trueCount = 0; trueCount < b_size_idx_0; trueCount++) {
    ubf[b_data[trueCount] - 1] = 1.0E+12;
  }

  B_size[0] = 4;
  B_size[1] = 4;
  memcpy(&pmpc_hil1_B.B_data[0], &H[0], sizeof(real_T) << 4U);
  trueCount = pmpc_hil1_cholesky(pmpc_hil1_B.B_data, B_size);
  if (trueCount != 0) {
    *x_size = 4;
    x_data[0] = 0.0;
    x_data[1] = 0.0;
    x_data[2] = 0.0;
    x_data[3] = 0.0;
    *status = -2.0;
    *nAct = 0.0;
  } else {
    pmpc_hil1_mldivide(pmpc_hil1_B.B_data, B_size, Linv_data, Linv_size);
    tmp[0] = 0.0;
    tmp[4] = -ubf[0];
    tmp[1] = 0.0;
    tmp[5] = -ubf[1];
    tmp[2] = 0.0;
    tmp[6] = -ubf[2];
    tmp[3] = 0.0;
    tmp[7] = -ubf[3];
    pmpc_hil1_mpcqpsolver(Linv_data, Linv_size, f, tmp, x_data, x_size, status,
                          iA_out);
    *nAct = iA_out[0];
    for (trueCount = 0; trueCount < 7; trueCount++) {
      *nAct += (real_T)iA_out[trueCount + 1];
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_QPA_DB(const real_T InitialParams_prevstate_Tb[4],
  const stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, real_T MFx, real_T delta_wheel,
  const s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T Tb_u, real_T Fx_dem, real_T *Tb_L1,
  real_T *Tb_L2, real_T *Tb_R1, real_T *Tb_R2)
{
  real_T Bb[4];
  real_T Gamma_u[16];
  real_T Fz_tot;
  real_T M_ref;
  real_T Tb_pre[4];
  real_T kd;
  real_T Tb_data[26];
  int32_T k;
  boolean_T y;
  static const int8_T b_b[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1
  };

  boolean_T c[4];
  boolean_T d[4];
  real_T tmp[4];
  real_T Bb_0[16];
  real_T Bb_1[4];
  real_T ParaHAT_0;
  real_T Bb_tmp;
  boolean_T exitg1;
  Bb_tmp = std::cos(delta_wheel);
  Fz_tot = 1.246613 * std::sin(delta_wheel);
  Bb[0] = (0.7875 * Bb_tmp - Fz_tot) * 2.5445292620865141;
  Bb[1] = (-0.7875 * Bb_tmp - Fz_tot) * 2.5445292620865141;
  Bb[2] = 2.00381679389313;
  Bb[3] = -2.00381679389313;
  if (ParaHAT->Fz_l1 > 1.0) {
    ParaHAT_0 = ParaHAT->Fz_l1;
  } else {
    ParaHAT_0 = 1.0;
  }

  Fz_tot = 1.0 / (0.1965 * ParaHAT_0);
  if (ParaHAT->Fz_r1 > 1.0) {
    ParaHAT_0 = ParaHAT->Fz_r1;
  } else {
    ParaHAT_0 = 1.0;
  }

  M_ref = 1.0 / (0.1965 * ParaHAT_0);
  if (ParaHAT->Fz_l2 > 1.0) {
    ParaHAT_0 = ParaHAT->Fz_l2;
  } else {
    ParaHAT_0 = 1.0;
  }

  kd = 1.0 / (0.1965 * ParaHAT_0);
  if (ParaHAT->Fz_r2 > 1.0) {
    ParaHAT_0 = ParaHAT->Fz_r2;
  } else {
    ParaHAT_0 = 1.0;
  }

  ParaHAT_0 = 1.0 / (0.1965 * ParaHAT_0);
  memset(&Gamma_u[0], 0, sizeof(real_T) << 4U);
  Gamma_u[0] = Fz_tot * Fz_tot;
  Gamma_u[5] = M_ref * M_ref;
  Gamma_u[10] = kd * kd;
  Gamma_u[15] = ParaHAT_0 * ParaHAT_0;
  Fz_tot = ((ParaHAT->Fz_l1 + ParaHAT->Fz_r1) + ParaHAT->Fz_l2) + ParaHAT->Fz_r2;
  M_ref = 0.5 * Fz_tot * 1.575 / 4.0;
  if (!(M_ref > 1.0)) {
    M_ref = 1.0;
  }

  Tb_pre[0] = InitialParams_prevstate_Tb[0];
  c[0] = !rtIsInf(InitialParams_prevstate_Tb[0]);
  d[0] = !rtIsNaN(InitialParams_prevstate_Tb[0]);
  Tb_pre[1] = InitialParams_prevstate_Tb[1];
  c[1] = !rtIsInf(InitialParams_prevstate_Tb[1]);
  d[1] = !rtIsNaN(InitialParams_prevstate_Tb[1]);
  Tb_pre[2] = InitialParams_prevstate_Tb[2];
  c[2] = !rtIsInf(InitialParams_prevstate_Tb[2]);
  d[2] = !rtIsNaN(InitialParams_prevstate_Tb[2]);
  Tb_pre[3] = InitialParams_prevstate_Tb[3];
  c[3] = !rtIsInf(InitialParams_prevstate_Tb[3]);
  d[3] = !rtIsNaN(InitialParams_prevstate_Tb[3]);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 4)) {
    if (!(c[k] && d[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }

  if (y) {
    Tb_pre[0] = 0.0;
    Tb_pre[1] = 0.0;
    Tb_pre[2] = 0.0;
    Tb_pre[3] = 0.0;
  }

  kd = 0.1965 * Fz_tot / 4.0;
  if (!(kd > 1.0)) {
    kd = 1.0;
  }

  kd = M_ref / kd;
  kd = kd * kd * 0.003;
  ParaHAT_0 = 2.0 * kd;
  for (k = 0; k < 4; k++) {
    Bb_0[k] = Bb[k] * Bb[0] + 0.1 * Gamma_u[k];
    Bb_0[k + 4] = Gamma_u[k + 4] * 0.1 + Bb[k] * Bb[1];
    Bb_0[k + 8] = Gamma_u[k + 8] * 0.1 + Bb[k] * 2.00381679389313;
    Bb_0[k + 12] = Gamma_u[k + 12] * 0.1 + Bb[k] * -2.00381679389313;
  }

  kd *= 2.0;
  for (k = 0; k < 4; k++) {
    Gamma_u[k << 2] = Bb_0[k << 2] * 2.0 + (real_T)b_b[k << 2] * ParaHAT_0;
    Gamma_u[1 + (k << 2)] = Bb_0[(k << 2) + 1] * 2.0 + (real_T)b_b[(k << 2) + 1]
      * ParaHAT_0;
    Gamma_u[2 + (k << 2)] = Bb_0[(k << 2) + 2] * 2.0 + (real_T)b_b[(k << 2) + 2]
      * ParaHAT_0;
    Gamma_u[3 + (k << 2)] = Bb_0[(k << 2) + 3] * 2.0 + (real_T)b_b[(k << 2) + 3]
      * ParaHAT_0;
    Bb[k] = -2.0 * Bb[k] * MFx - kd * Tb_pre[k];
  }

  if (Fx_dem > 0.0) {
    Bb_tmp *= 2.5445292620865141;
    Tb_pre[0] = Bb_tmp;
    Tb_pre[1] = Bb_tmp;
    Tb_pre[2] = 2.5445292620865141;
    Tb_pre[3] = 2.5445292620865141;
    kd = 0.5 * Fz_tot;
    if (!(kd > 1.0)) {
      kd = 1.0;
    }

    Fz_tot = M_ref / kd;
    Fz_tot = Fz_tot * Fz_tot * 0.1;
    M_ref = 2.0 * Fz_tot;
    for (k = 0; k < 4; k++) {
      Bb_0[k] = Tb_pre[k] * Bb_tmp;
      Bb_0[k + 4] = Tb_pre[k] * Bb_tmp;
      Bb_0[k + 8] = Tb_pre[k] * 2.5445292620865141;
      Bb_0[k + 12] = Tb_pre[k] * 2.5445292620865141;
    }

    Fz_tot *= 2.0;
    for (k = 0; k < 4; k++) {
      Gamma_u[k << 2] += Bb_0[k << 2] * M_ref;
      Gamma_u[1 + (k << 2)] += Bb_0[(k << 2) + 1] * M_ref;
      Gamma_u[2 + (k << 2)] += Bb_0[(k << 2) + 2] * M_ref;
      Gamma_u[3 + (k << 2)] += Bb_0[(k << 2) + 3] * M_ref;
      Bb_1[k] = Bb[k] - Tb_pre[k] * Fx_dem * Fz_tot;
    }

    Bb[0] = Bb_1[0];
    Bb[1] = Bb_1[1];
    Bb[2] = Bb_1[2];
    Bb[3] = Bb_1[3];
  }

  if (Tb_u.Tb_L1 < 3000.0) {
    tmp[0] = Tb_u.Tb_L1;
  } else {
    tmp[0] = 3000.0;
  }

  if (Tb_u.Tb_R1 < 3000.0) {
    tmp[1] = Tb_u.Tb_R1;
  } else {
    tmp[1] = 3000.0;
  }

  if (Tb_u.Tb_L2 < 3000.0) {
    tmp[2] = Tb_u.Tb_L2;
  } else {
    tmp[2] = 3000.0;
  }

  if (Tb_u.Tb_R2 < 3000.0) {
    tmp[3] = Tb_u.Tb_R2;
  } else {
    tmp[3] = 3000.0;
  }

  pmpc_hil1_func_QPKwik(Gamma_u, Bb, tmp, Tb_data, &k, &Fz_tot, &M_ref);
  if (Fz_tot > 0.0) {
    Fz_tot = 1.0;
  } else {
    Fz_tot -= 10.0;
  }

  if (Fz_tot <= 0.0) {
    fprintf(stderr,
            "func_QPA_DB: brake torque allocation QP failed, exitflag_DB=%.0f\n",
            Fz_tot);
    fflush(stderr);
    Tb_data[0] = 0.0;
    Tb_data[1] = 0.0;
    Tb_data[2] = 0.0;
    Tb_data[3] = 0.0;
  }

  *Tb_L1 = Tb_data[0];
  *Tb_L2 = Tb_data[2];
  *Tb_R1 = Tb_data[1];
  *Tb_R2 = Tb_data[3];
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_QPKwik_c(const real_T H[16], const real_T f[4], const
  real_T lb[4], const real_T ub[4], real_T x_data[], int32_T *x_size, real_T
  *status, real_T *nAct)
{
  real_T ubf[4];
  real_T lbf[4];
  real_T Linv_data[104];
  boolean_T iA_out[8];
  int8_T b_data[4];
  int8_T c_data[4];
  int32_T trueCount;
  real_T lbf_0[8];
  boolean_T tmp[4];
  int32_T Linv_size[2];
  int32_T B_size[2];
  boolean_T d;
  int32_T b_size_idx_0;
  boolean_T d_idx_0;
  boolean_T d_idx_1;
  boolean_T d_idx_2;
  pmpc_hil1_isfinite_cn(ub, tmp);
  trueCount = 0;
  ubf[0] = ub[0];
  lbf[0] = lb[0];
  d = !tmp[0];
  if (d) {
    trueCount = 1;
  }

  d_idx_0 = d;
  ubf[1] = ub[1];
  lbf[1] = lb[1];
  d = !tmp[1];
  if (d) {
    trueCount++;
  }

  d_idx_1 = d;
  ubf[2] = ub[2];
  lbf[2] = lb[2];
  d = !tmp[2];
  if (d) {
    trueCount++;
  }

  d_idx_2 = d;
  ubf[3] = ub[3];
  lbf[3] = lb[3];
  d = !tmp[3];
  if (d) {
    trueCount++;
  }

  b_size_idx_0 = trueCount;
  trueCount = 0;
  if (d_idx_0) {
    b_data[0] = 1;
    trueCount = 1;
  }

  if (d_idx_1) {
    b_data[trueCount] = 2;
    trueCount++;
  }

  if (d_idx_2) {
    b_data[trueCount] = 3;
    trueCount++;
  }

  if (d) {
    b_data[trueCount] = 4;
  }

  for (trueCount = 0; trueCount < b_size_idx_0; trueCount++) {
    ubf[b_data[trueCount] - 1] = 1.0E+12;
  }

  pmpc_hil1_isfinite_cn(lb, tmp);
  trueCount = 0;
  d = !tmp[0];
  if (d) {
    trueCount = 1;
  }

  d_idx_0 = d;
  d = !tmp[1];
  if (d) {
    trueCount++;
  }

  d_idx_1 = d;
  d = !tmp[2];
  if (d) {
    trueCount++;
  }

  d_idx_2 = d;
  d = !tmp[3];
  if (d) {
    trueCount++;
  }

  b_size_idx_0 = trueCount;
  trueCount = 0;
  if (d_idx_0) {
    c_data[0] = 1;
    trueCount = 1;
  }

  if (d_idx_1) {
    c_data[trueCount] = 2;
    trueCount++;
  }

  if (d_idx_2) {
    c_data[trueCount] = 3;
    trueCount++;
  }

  if (d) {
    c_data[trueCount] = 4;
  }

  for (trueCount = 0; trueCount < b_size_idx_0; trueCount++) {
    lbf[c_data[trueCount] - 1] = -1.0E+12;
  }

  B_size[0] = 4;
  B_size[1] = 4;
  memcpy(&pmpc_hil1_B.B_data_k[0], &H[0], sizeof(real_T) << 4U);
  trueCount = pmpc_hil1_cholesky(pmpc_hil1_B.B_data_k, B_size);
  if (trueCount != 0) {
    *x_size = 4;
    x_data[0] = 0.0;
    x_data[1] = 0.0;
    x_data[2] = 0.0;
    x_data[3] = 0.0;
    *status = -2.0;
    *nAct = 0.0;
  } else {
    pmpc_hil1_mldivide(pmpc_hil1_B.B_data_k, B_size, Linv_data, Linv_size);
    lbf_0[0] = lbf[0];
    lbf_0[4] = -ubf[0];
    lbf_0[1] = lbf[1];
    lbf_0[5] = -ubf[1];
    lbf_0[2] = lbf[2];
    lbf_0[6] = -ubf[2];
    lbf_0[3] = lbf[3];
    lbf_0[7] = -ubf[3];
    pmpc_hil1_mpcqpsolver(Linv_data, Linv_size, f, lbf_0, x_data, x_size, status,
                          iA_out);
    *nAct = iA_out[0];
    for (trueCount = 0; trueCount < 7; trueCount++) {
      *nAct += (real_T)iA_out[trueCount + 1];
    }
  }
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_QPA_CDC(const real_T InitialParams_prevstate_Fd[4],
  real_T MFd, const real_T Fdu[4], const real_T Fdl[4], real_T *Fd_L1, real_T
  *Fd_L2, real_T *Fd_R1, real_T *Fd_R2, real_T *Md_real, real_T *exitflag_Fd)
{
  real_T Gamma_d[16];
  real_T Fd_data[26];
  real_T z1[4];
  int32_T k;
  real_T b_z1[4];
  boolean_T e_y;
  boolean_T x_data[26];
  static const real_T f_y[16] = { 0.30250000000000005, -0.30250000000000005,
    0.30250000000000005, -0.30250000000000005, -0.30250000000000005,
    0.30250000000000005, -0.30250000000000005, 0.30250000000000005,
    0.30250000000000005, -0.30250000000000005, 0.30250000000000005,
    -0.30250000000000005, -0.30250000000000005, 0.30250000000000005,
    -0.30250000000000005, 0.30250000000000005 };

  static const real_T g_y[16] = { 0.05, 0.0, 0.0, 0.0, 0.0, 0.05, 0.0, 0.0, 0.0,
    0.0, 0.05, 0.0, 0.0, 0.0, 0.0, 0.05 };

  real_T tmp[16];
  real_T tmp_0[4];
  int32_T Fd_size;
  real_T z1_0;
  real_T b_z1_0;
  real_T c_z1;
  real_T c_z1_0;
  real_T Wd_idx_0;
  real_T d_z1_idx_0;
  real_T d_z1_idx_1;
  real_T Wd_idx_1;
  real_T d_z1_idx_2;
  real_T Wd_idx_2;
  real_T Wd_idx_3;
  boolean_T guard1 = false;
  boolean_T exitg1;
  e_y = rtIsNaN(Fdu[0]);
  if ((Fdl[0] < Fdu[0]) || e_y) {
    z1_0 = Fdl[0];
  } else {
    z1_0 = Fdu[0];
  }

  if ((Fdl[0] > Fdu[0]) || e_y) {
    b_z1_0 = Fdl[0];
  } else {
    b_z1_0 = Fdu[0];
  }

  if ((InitialParams_prevstate_Fd[0] > z1_0) || rtIsNaN(z1_0)) {
    c_z1 = InitialParams_prevstate_Fd[0];
  } else {
    c_z1 = z1_0;
  }

  if ((c_z1 < b_z1_0) || rtIsNaN(b_z1_0)) {
    d_z1_idx_0 = c_z1;
  } else {
    d_z1_idx_0 = b_z1_0;
  }

  Wd_idx_0 = b_z1_0 - z1_0;
  z1[0] = z1_0;
  b_z1[0] = b_z1_0;
  e_y = rtIsNaN(Fdu[1]);
  if ((Fdl[1] < Fdu[1]) || e_y) {
    z1_0 = Fdl[1];
  } else {
    z1_0 = Fdu[1];
  }

  if ((Fdl[1] > Fdu[1]) || e_y) {
    b_z1_0 = Fdl[1];
  } else {
    b_z1_0 = Fdu[1];
  }

  if ((InitialParams_prevstate_Fd[1] > z1_0) || rtIsNaN(z1_0)) {
    c_z1 = InitialParams_prevstate_Fd[1];
  } else {
    c_z1 = z1_0;
  }

  if ((c_z1 < b_z1_0) || rtIsNaN(b_z1_0)) {
    d_z1_idx_1 = c_z1;
  } else {
    d_z1_idx_1 = b_z1_0;
  }

  Wd_idx_1 = b_z1_0 - z1_0;
  z1[1] = z1_0;
  b_z1[1] = b_z1_0;
  e_y = rtIsNaN(Fdu[2]);
  if ((Fdl[2] < Fdu[2]) || e_y) {
    z1_0 = Fdl[2];
  } else {
    z1_0 = Fdu[2];
  }

  if ((Fdl[2] > Fdu[2]) || e_y) {
    b_z1_0 = Fdl[2];
  } else {
    b_z1_0 = Fdu[2];
  }

  if ((InitialParams_prevstate_Fd[2] > z1_0) || rtIsNaN(z1_0)) {
    c_z1 = InitialParams_prevstate_Fd[2];
  } else {
    c_z1 = z1_0;
  }

  if ((c_z1 < b_z1_0) || rtIsNaN(b_z1_0)) {
    d_z1_idx_2 = c_z1;
  } else {
    d_z1_idx_2 = b_z1_0;
  }

  Wd_idx_2 = b_z1_0 - z1_0;
  z1[2] = z1_0;
  b_z1[2] = b_z1_0;
  e_y = rtIsNaN(Fdu[3]);
  if ((Fdl[3] < Fdu[3]) || e_y) {
    z1_0 = Fdl[3];
  } else {
    z1_0 = Fdu[3];
  }

  if ((Fdl[3] > Fdu[3]) || e_y) {
    b_z1_0 = Fdl[3];
  } else {
    b_z1_0 = Fdu[3];
  }

  if ((InitialParams_prevstate_Fd[3] > z1_0) || rtIsNaN(z1_0)) {
    c_z1 = InitialParams_prevstate_Fd[3];
  } else {
    c_z1 = z1_0;
  }

  Wd_idx_3 = b_z1_0 - z1_0;
  z1[3] = z1_0;
  b_z1[3] = b_z1_0;
  if (!(Wd_idx_0 > 1.0)) {
    Wd_idx_0 = 1.0;
  }

  if (!(Wd_idx_1 > 1.0)) {
    Wd_idx_1 = 1.0;
  }

  if (!(Wd_idx_2 > 1.0)) {
    Wd_idx_2 = 1.0;
  }

  if (!(Wd_idx_3 > 1.0)) {
    Wd_idx_3 = 1.0;
  }

  z1_0 = (((Wd_idx_0 + Wd_idx_1) + Wd_idx_2) + Wd_idx_3) / 4.0;
  c_z1_0 = z1_0 / Wd_idx_0;
  Wd_idx_0 = c_z1_0 * c_z1_0;
  c_z1_0 = z1_0 / Wd_idx_1;
  Wd_idx_1 = c_z1_0 * c_z1_0;
  c_z1_0 = z1_0 / Wd_idx_2;
  Wd_idx_2 = c_z1_0 * c_z1_0;
  c_z1_0 = z1_0 / Wd_idx_3;
  Wd_idx_3 = c_z1_0 * c_z1_0;
  z1_0 = (((Wd_idx_0 + Wd_idx_1) + Wd_idx_2) + Wd_idx_3) / 4.0;
  Wd_idx_0 /= z1_0;
  Wd_idx_1 /= z1_0;
  Wd_idx_2 /= z1_0;
  memset(&Gamma_d[0], 0, sizeof(real_T) << 4U);
  Gamma_d[0] = Wd_idx_0;
  Gamma_d[5] = Wd_idx_1;
  Gamma_d[10] = Wd_idx_2;
  Gamma_d[15] = Wd_idx_3 / z1_0;
  for (k = 0; k < 16; k++) {
    tmp[k] = ((0.005 * Gamma_d[k] + f_y[k]) + g_y[k]) * 2.0;
  }

  tmp_0[0] = (-0.55 * MFd + 0.05 * d_z1_idx_0) * -2.0;
  tmp_0[1] = (0.55 * MFd + 0.05 * d_z1_idx_1) * -2.0;
  tmp_0[2] = (-0.55 * MFd + 0.05 * d_z1_idx_2) * -2.0;
  if ((c_z1 < b_z1_0) || rtIsNaN(b_z1_0)) {
    b_z1_0 = c_z1;
  }

  tmp_0[3] = (0.55 * MFd + 0.05 * b_z1_0) * -2.0;
  pmpc_hil1_func_QPKwik_c(tmp, tmp_0, z1, b_z1, Fd_data, &Fd_size, &z1_0,
    &b_z1_0);
  if (z1_0 > 0.0) {
    *exitflag_Fd = 1.0;
  } else {
    *exitflag_Fd = z1_0 - 10.0;
  }

  guard1 = false;
  if (*exitflag_Fd <= 0.0) {
    guard1 = true;
  } else {
    for (k = 0; k < Fd_size; k++) {
      x_data[k] = !((!rtIsInf(Fd_data[k])) && (!rtIsNaN(Fd_data[k])));
    }

    e_y = false;
    k = 1;
    exitg1 = false;
    while ((!exitg1) && (k <= Fd_size)) {
      if (x_data[k - 1]) {
        e_y = true;
        exitg1 = true;
      } else {
        k++;
      }
    }

    if (e_y) {
      guard1 = true;
    }
  }

  if (guard1) {
    fprintf(stderr,
            "func_QPA_CDC: MR damper allocation QP failed; returning zeros\n");
    fflush(stderr);
    Fd_data[0] = 0.0;
    Fd_data[1] = 0.0;
    Fd_data[2] = 0.0;
    Fd_data[3] = 0.0;
    *exitflag_Fd = -1.0;
  }

  *Fd_L1 = Fd_data[0];
  *Fd_R1 = Fd_data[1];
  *Fd_L2 = Fd_data[2];
  *Fd_R2 = Fd_data[3];
  *Md_real = ((-0.55 * Fd_data[0] + 0.55 * Fd_data[1]) + -0.55 * Fd_data[2]) +
    0.55 * Fd_data[3];
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_ReportStatus(sCbhmMeZ4DAZChEA352SZoG_pmpc__T
  *InitialParams, real_T exitflag, real_T PrjP_ey, real_T PrjP_epsi, real_T Vel)
{
  real_T tmp;
  switch ((int32_T)exitflag) {
   case 1:
    InitialParams->failed_num.solve++;
    break;

   case 0:
    InitialParams->failed_num.conv++;
    break;

   case -2:
    InitialParams->failed_num.unsolved++;
    break;

   case -3:
    InitialParams->failed_num.NaN_or_Inf++;
    break;

   default:
    InitialParams->failed_num.b_else++;
    break;
  }

  InitialParams->n_solve++;
  if (InitialParams->n_solve <= 20000.0) {
    InitialParams->t_solve[(int32_T)InitialParams->n_solve - 1] = 0.0;
  }

  if (InitialParams->n_solve <= 20000.0) {
    InitialParams->ey_hist[(int32_T)InitialParams->n_solve - 1] = PrjP_ey;
    InitialParams->epsi_hist[(int32_T)InitialParams->n_solve - 1] = PrjP_epsi;
  }

  tmp = std::abs(PrjP_ey);
  if (tmp >= std::abs(InitialParams->emax.y)) {
    InitialParams->emax.y = tmp;
  }

  tmp = std::abs(PrjP_epsi);
  if (tmp >= std::abs(InitialParams->emax.psi)) {
    InitialParams->emax.psi = tmp;
  }

  printf("Vel: %.0f\nMPC solve %.0f ms, sim %.2f s\nmax ey: %.2f m, max epsi: %.2f deg\nsolved:%.0f notconv:%.0f infeas:%.0f NaNInf:%.0f other:%.0f\n",
         Vel * 3.6, 0.0, InitialParams->InitialGapflag * 0.01,
         InitialParams->emax.y, 57.295779513082323 * InitialParams->emax.psi,
         InitialParams->failed_num.solve, InitialParams->failed_num.conv,
         InitialParams->failed_num.unsolved,
         InitialParams->failed_num.NaN_or_Inf, InitialParams->failed_num.b_else);
  fflush(stdout);
}

/* Function for MATLAB Function: '<Root>/PMPC_MF' */
static void pmpc_hil1_func_LTRDiagnosis(real_T VehiclePara_CbarF, real_T
  VehiclePara_CbarR, const sbvkBze56SjuXgPM3czyE9E_pmpc__T *VehStateMeasured,
  const stqsoKSc3kjr3PcXZyE6mmG_pmpc__T *ParaHAT, const real_T Y[72], const
  real_T x_opt[26], real_T exitflag, const real_T AI[324], const real_T Ut[18],
  real_T Md_next, real_T *LTR_real, real_T *LTR_calc, real_T *LTR_Npdc)
{
  real_T U_pred_Nc[18];
  boolean_T exitflag_0;
  int32_T i;
  int32_T i_0;
  real_T VehiclePara_CbarF_0[6];
  real_T u0;
  real_T u0_tmp;
  real_T cd_f_tmp;
  cd_f_tmp = std::cos(VehStateMeasured->delta_f);
  u0_tmp = ParaHAT->Fz_l1 + ParaHAT->Fz_l2;
  u0 = (u0_tmp + ParaHAT->Fz_r1) + ParaHAT->Fz_r2;
  if (!(u0 > 1.0)) {
    u0 = 1.0;
  }

  *LTR_real = ((ParaHAT->Fz_r1 + ParaHAT->Fz_r2) - u0_tmp) / u0;
  *LTR_calc = (((((ParaHAT->Fy_l1 + ParaHAT->Fy_r1) * cd_f_tmp + ParaHAT->Fy_l2)
                 + ParaHAT->Fy_r2) / 1860.0 * 343.05084000000011 +
                160681.49359924142 * ParaHAT->Roll) + Md_next) *
    6.9617082299227066E-5;
  exitflag_0 = (exitflag == 1.0);
  for (i = 0; i < 18; i++) {
    u0_tmp = 0.0;
    for (i_0 = 0; i_0 < 18; i_0++) {
      u0_tmp += AI[18 * i_0 + i] * x_opt[i_0];
    }

    if (exitflag_0) {
      U_pred_Nc[i] = Ut[i] + u0_tmp;
    } else {
      U_pred_Nc[i] = Ut[i];
    }
  }

  u0_tmp = 1860.0 * VehStateMeasured->x_dot;
  VehiclePara_CbarF_0[0] = (VehiclePara_CbarF * cd_f_tmp + VehiclePara_CbarR) /
    u0_tmp;
  VehiclePara_CbarF_0[1] = (VehiclePara_CbarF * 1.246613 * cd_f_tmp -
    VehiclePara_CbarR * 1.7033870000000002) / u0_tmp;
  VehiclePara_CbarF_0[2] = 0.0;
  VehiclePara_CbarF_0[3] = 0.0;
  VehiclePara_CbarF_0[4] = 0.0;
  VehiclePara_CbarF_0[5] = 0.0;
  u0_tmp = 0.0;
  for (i = 0; i < 6; i++) {
    u0_tmp += Y[30 + i] * VehiclePara_CbarF_0[i];
  }

  *LTR_Npdc = (((((-VehiclePara_CbarF * cd_f_tmp / 1860.0 * U_pred_Nc[15] + 0.0 *
                   U_pred_Nc[16]) + 0.0 * U_pred_Nc[17]) + u0_tmp) *
                343.05084000000011 + 160681.49359924142 * Y[32]) + U_pred_Nc[17])
    * 6.9617082299227066E-5;
}

/* Model output function */
void pmpc_hil1_output(void)
{
  seSWzzkDqqnmIb9KZFsj0XH_pmpc__T St_Constraints;
  s4H9mukNN3ugNJ0MwoCbpqE_pmpc__T VehiclePara;
  real_T WarmStart[26];
  real_T rho[9];
  real_T ab_f;
  real_T ab_r;
  real_T F_off_f;
  real_T F_off_r;
  real_T Envelope_Henv[12];
  real_T Envelope_Genv[2];
  real_T Envelope_Hsh[24];
  real_T Envelope_Gsh[4];
  real_T Envelope_Hr[12];
  real_T Envelope_Or[6];
  real_T Envelope_Gr[2];
  real_T zeta[9];
  real_T Ut[18];
  real_T Flim;
  real_T Cm;
  real_T Md_next;
  real_T Y[72];
  sbvkBze56SjuXgPM3czyE9E_pmpc__T VehStateMeasured;
  stqsoKSc3kjr3PcXZyE6mmG_pmpc__T ParaHAT;
  real_T fb_f;
  real_T fb_r;
  real_T cb_r;
  real_T WPIndex;
  real_T RefU[36];
  real_T Bezier_SK[12];
  real_T PrjP_Velr;
  real_T PrjP_xr;
  real_T PrjP_psir;
  real_T R[324];
  real_T S[324];
  real_T W[64];
  real_T Mdmin;
  s1YBrsQ6z6NwvX1uvcMMCjG_pmpc__T Tb_u;
  real_T Fdu[4];
  real_T Fdl[4];
  real_T GAMMA[36];
  real_T f[26];
  real_T b_cons[96];
  real_T lb[26];
  real_T ub[26];
  real_T umax[3];
  real_T umin[3];
  real_T x_opt[26];
  real_T epsilon_val[8];
  real_T Fd_L1;
  real_T Fd_L2;
  real_T Fd_R1;
  real_T Fd_R2;
  real_T Md_real;
  real_T exitflag_Fd;
  real_T b_maxval;
  static const real_T c[8] = { 8.7266462599716483, 8.7266462599716483,
    8.7266462599716483, 8.7266462599716483, 30.0, 30.0, 80.0, 80.0 };

  static const real_T d[324] = { 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0,
    0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  static const real_T g[141] = { -0.35, -0.345, -0.33999999999999997,
    -0.33499999999999996, -0.32999999999999996, -0.32499999999999996, -0.32,
    -0.315, -0.31, -0.305, -0.3, -0.295, -0.29, -0.285, -0.27999999999999997,
    -0.27499999999999997, -0.26999999999999996, -0.265, -0.26, -0.255,
    -0.24999999999999997, -0.245, -0.24, -0.235, -0.22999999999999998,
    -0.22499999999999998, -0.21999999999999997, -0.215, -0.21, -0.205,
    -0.19999999999999998, -0.19499999999999998, -0.18999999999999997, -0.185,
    -0.18, -0.175, -0.16999999999999998, -0.16499999999999998, -0.16, -0.155,
    -0.14999999999999997, -0.145, -0.13999999999999999, -0.13499999999999998,
    -0.13, -0.125, -0.12, -0.11499999999999999, -0.11000000000000001,
    -0.10500000000000001, -0.099999999999999978, -0.095000000000000029,
    -0.089999999999999969, -0.08500000000000002, -0.080000000000000016,
    -0.074999999999999956, -0.07, -0.065, -0.06, -0.054999999999999993,
    -0.049999999999999989, -0.044999999999999984, -0.03999999999999998,
    -0.035000000000000031, -0.029999999999999971, -0.024999999999999967,
    -0.020000000000000018, -0.015000000000000013, -0.010000000000000009,
    -0.0050000000000000044, 0.0, 0.0050000000000000044, 0.010000000000000009,
    0.014999999999999958, 0.020000000000000018, 0.025000000000000022,
    0.029999999999999971, 0.035000000000000031, 0.03999999999999998,
    0.044999999999999984, 0.050000000000000044, 0.054999999999999993, 0.06,
    0.065, 0.07, 0.074999999999999956, 0.080000000000000016, 0.08500000000000002,
    0.089999999999999969, 0.095000000000000029, 0.099999999999999978,
    0.10499999999999998, 0.10999999999999999, 0.11499999999999999, 0.12, 0.125,
    0.12999999999999995, 0.13499999999999995, 0.13999999999999996,
    0.14500000000000002, 0.15000000000000002, 0.15499999999999992,
    0.15999999999999992, 0.16500000000000004, 0.17000000000000004,
    0.17500000000000004, 0.17999999999999994, 0.18499999999999994,
    0.18999999999999995, 0.19499999999999995, 0.20000000000000007,
    0.20499999999999996, 0.20999999999999996, 0.21499999999999997,
    0.21999999999999997, 0.22499999999999998, 0.22999999999999998, 0.235, 0.24,
    0.245, 0.25, 0.25499999999999989, 0.26, 0.265, 0.27, 0.275,
    0.27999999999999992, 0.28499999999999992, 0.29000000000000004,
    0.29500000000000004, 0.30000000000000004, 0.30499999999999994,
    0.30999999999999994, 0.31499999999999995, 0.31999999999999995,
    0.32500000000000007, 0.32999999999999996, 0.33499999999999996,
    0.33999999999999997, 0.345, 0.35 };

  static const real_T h[9870] = { 79.293273583631859, 79.548131800120643,
    79.805107742611952, 80.064067205811455, 80.3248228962887, 80.58729722728458,
    80.851538250007692, 81.11750688426612, 81.3850440594615, 81.653837899703632,
    81.923472058948548, 82.193971267424331, 82.465337324859718,
    82.736964993508067, 83.00871628069892, 83.280128900978966, 83.5508620488556,
    83.820588186861883, 84.088657657171, 84.35489749823391, 84.618003885453319,
    84.877750049477044, 85.133394296662317, 85.3840193487177, 85.628993894944443,
    85.866501697846189, 86.096316211876385, 86.3159576733733, 86.525018329494884,
    86.721357258012119, 86.902858110083145, 87.069200199426533,
    87.214767096254619, 87.34143692557717, 87.4418826411481, 87.51572639559673,
    87.551998619140292, 87.564211934010231, 87.526978530304874, 87.456842629037,
    87.324054167468077, 87.142538529007084, 86.892098009675053,
    86.572507555905332, 86.172957753662345, 85.67962045965227,
    85.089755803321609, 84.381180119260023, 83.550686434790876,
    82.575195827393046, 81.443139350012387, 80.137663866924328,
    78.632846034476373, 76.919582596123178, 74.962179659509516, 72.7527129703236,
    70.25709797129376, 67.4564573916632, 64.33322756070082, 60.853229989847925,
    57.0208803840711, 52.798101301542275, 48.203881071051377, 43.221804712476832,
    37.86852729418694, 32.176041662205456, 26.150063372654071,
    19.885491865239302, 13.383787128891928, 6.645724202078112, 0.0,
    -6.645724202078112, -13.383787128891928, -19.885491865239235,
    -26.150063372654071, -32.17604166220552, -37.86852729418694,
    -43.221804712476832, -48.203881071051377, -52.798101301542275,
    -57.020880384071141, -60.853229989847925, -64.33322756070082,
    -67.4564573916632, -70.25709797129376, -72.7527129703236,
    -74.962179659509516, -76.919582596123178, -78.632846034476373,
    -80.137663866924328, -81.443139350012387, -82.575195827393046,
    -83.550686434790862, -84.381180119260023, -85.089755803321609,
    -85.67962045965227, -86.172957753662345, -86.572507555905332,
    -86.892098009675053, -87.142538529007084, -87.324054167468077,
    -87.456842629037, -87.526978530304874, -87.564211934010231,
    -87.551998619140292, -87.51572639559673, -87.4418826411481,
    -87.34143692557717, -87.214767096254619, -87.069200199426533,
    -86.902858110083145, -86.721357258012119, -86.525018329494884,
    -86.3159576733733, -86.096316211876385, -85.866501697846189,
    -85.628993894944443, -85.3840193487177, -85.133394296662317,
    -84.877750049477044, -84.618003885453319, -84.35489749823391,
    -84.088657657171, -83.820588186861883, -83.5508620488556,
    -83.280128900978951, -83.00871628069892, -82.736964993508067,
    -82.465337324859718, -82.193971267424331, -81.923472058948533,
    -81.653837899703632, -81.385044059461521, -81.117506884266135,
    -80.851538250007692, -80.58729722728458, -80.3248228962887,
    -80.064067205811455, -79.805107742611952, -79.548131800120643,
    -79.293273583631859, 158.58654716726372, 159.09626360024129,
    159.6102154852239, 160.12813441162291, 160.64964579257739,
    161.17459445456916, 161.70307650001538, 162.23501376853224, 162.770088118923,
    163.30767579940726, 163.8469441178971, 164.38794253484866,
    164.93067464971944, 165.47392998701613, 166.01743256139784,
    166.56025780195793, 167.10172409771121, 167.64117637372377, 168.177315314342,
    168.70979499646782, 169.23600777090664, 169.75550009895409,
    170.26678859332463, 170.7680386974354, 171.25798778988889,
    171.73300339569238, 172.19263242375277, 172.63191534674661,
    173.05003665898977, 173.44271451602424, 173.80571622016629,
    174.13840039885307, 174.42953419250924, 174.68287385115434,
    174.8837652822962, 175.03145279119346, 175.10399723828058,
    175.12842386802046, 175.05395706060975, 174.913685258074, 174.64810833493615,
    174.28507705801417, 173.78419601935011, 173.14501511181066,
    172.34591550732469, 171.35924091930454, 170.17951160664322,
    168.76236023852005, 167.10137286958175, 165.15039165478609,
    162.88627870002477, 160.27532773384866, 157.26569206895275,
    153.83916519224636, 149.92435931901903, 145.5054259406472,
    140.51419594258752, 134.91291478332641, 128.66645512140164,
    121.70645997969585, 114.0417607681422, 105.59620260308455,
    96.407762142102754, 86.443609424953664, 75.73705458837388,
    64.352083324410913, 52.300126745308141, 39.770983730478605,
    26.767574257783856, 13.291448404156224, 0.0, -13.291448404156224,
    -26.767574257783856, -39.77098373047847, -52.300126745308141,
    -64.352083324411041, -75.73705458837388, -86.443609424953664,
    -96.407762142102754, -105.59620260308455, -114.04176076814228,
    -121.70645997969585, -128.66645512140164, -134.91291478332641,
    -140.51419594258752, -145.5054259406472, -149.92435931901903,
    -153.83916519224636, -157.26569206895275, -160.27532773384866,
    -162.88627870002477, -165.15039165478609, -167.10137286958172,
    -168.76236023852005, -170.17951160664322, -171.35924091930454,
    -172.34591550732469, -173.14501511181066, -173.78419601935011,
    -174.28507705801417, -174.64810833493615, -174.913685258074,
    -175.05395706060975, -175.12842386802046, -175.10399723828058,
    -175.03145279119346, -174.8837652822962, -174.68287385115434,
    -174.42953419250924, -174.13840039885307, -173.80571622016629,
    -173.44271451602424, -173.05003665898977, -172.63191534674661,
    -172.19263242375277, -171.73300339569238, -171.25798778988889,
    -170.7680386974354, -170.26678859332463, -169.75550009895409,
    -169.23600777090664, -168.70979499646782, -168.177315314342,
    -167.64117637372377, -167.10172409771121, -166.5602578019579,
    -166.01743256139784, -165.47392998701613, -164.93067464971944,
    -164.38794253484866, -163.84694411789707, -163.30767579940726,
    -162.77008811892304, -162.23501376853227, -161.70307650001538,
    -161.17459445456916, -160.64964579257739, -160.12813441162291,
    -159.6102154852239, -159.09626360024129, -158.58654716726372,
    237.87982075089559, 238.64439540036196, 239.41532322783587,
    240.19220161743434, 240.9744686888661, 241.76189168185377,
    242.55461475002309, 243.35252065279838, 244.15513217838452,
    244.96151369911087, 245.77041617684563, 246.58191380227302,
    247.39601197457918, 248.21089498052422, 249.02614884209677,
    249.84038670293688, 250.65258614656682, 251.46176456058566, 252.265972971513,
    253.06469249470175, 253.85401165635997, 254.63325014843113, 255.400182889987,
    256.15205804615312, 256.88698168483336, 257.59950509353854,
    258.28894863562914, 258.94787302011986, 259.57505498848468,
    260.16407177403642, 260.70857433024946, 261.20760059827961,
    261.64430128876381, 262.02431077673151, 262.32564792344431,
    262.54717918679017, 262.65599585742086, 262.69263580203068,
    262.58093559091463, 262.370527887111, 261.97216250240422, 261.42761558702125,
    260.67629402902514, 259.71752266771597, 258.51887326098705,
    257.03886137895682, 255.26926740996481, 253.14354035778007,
    250.65205930437261, 247.72558748217912, 244.32941805003716, 240.412991600773,
    235.8985381034291, 230.75874778836953, 224.88653897852856,
    218.25813891097084, 210.77129391388129, 202.36937217498965,
    192.99968268210245, 182.55968996954377, 171.0626411522133,
    158.39430390462684, 144.61164321315414, 129.66541413743047,
    113.60558188256081, 96.528124986616362, 78.450190117962222,
    59.656475595717922, 40.151361386675788, 19.93717260623432, 0.0,
    -19.93717260623432, -40.151361386675788, -59.656475595717708,
    -78.450190117962222, -96.528124986616547, -113.60558188256081,
    -129.66541413743047, -144.61164321315414, -158.39430390462684,
    -171.06264115221342, -182.55968996954377, -192.99968268210245,
    -202.36937217498965, -210.77129391388129, -218.25813891097084,
    -224.88653897852856, -230.75874778836953, -235.8985381034291,
    -240.412991600773, -244.32941805003716, -247.72558748217912,
    -250.65205930437261, -253.14354035778007, -255.26926740996481,
    -257.03886137895682, -258.51887326098705, -259.71752266771597,
    -260.67629402902514, -261.42761558702125, -261.97216250240422,
    -262.370527887111, -262.58093559091463, -262.69263580203068,
    -262.65599585742086, -262.54717918679017, -262.32564792344431,
    -262.02431077673151, -261.64430128876387, -261.20760059827961,
    -260.70857433024946, -260.16407177403642, -259.57505498848468,
    -258.94787302011991, -258.28894863562914, -257.59950509353854,
    -256.88698168483336, -256.15205804615312, -255.400182889987,
    -254.63325014843113, -253.85401165635994, -253.06469249470175,
    -252.265972971513, -251.46176456058566, -250.65258614656679,
    -249.84038670293685, -249.0261488420968, -248.21089498052424,
    -247.39601197457915, -246.58191380227302, -245.77041617684563,
    -244.9615136991109, -244.15513217838455, -243.35252065279838,
    -242.55461475002309, -241.76189168185374, -240.9744686888661,
    -240.19220161743434, -239.41532322783587, -238.64439540036196,
    -237.87982075089559, 317.17309433452743, 318.19252720048257,
    319.22043097044781, 320.25626882324582, 321.29929158515478,
    322.34918890913832, 323.40615300003077, 324.47002753706448, 325.540176237846,
    326.61535159881453, 327.69388823579419, 328.77588506969732,
    329.86134929943887, 330.94785997403227, 332.03486512279568,
    333.12051560391586, 334.20344819542242, 335.28235274744753, 336.354630628684,
    337.41958999293564, 338.47201554181328, 339.51100019790817,
    340.53357718664927, 341.5360773948708, 342.51597557977777,
    343.46600679138476, 344.38526484750554, 345.26383069349322,
    346.10007331797954, 346.88542903204848, 347.61143244033258,
    348.27680079770613, 348.85906838501847, 349.36574770230868,
    349.76753056459239, 350.06290558238692, 350.20799447656117,
    350.25684773604092, 350.10791412121949, 349.827370516148, 349.29621666987231,
    348.57015411602833, 347.56839203870021, 346.29003022362133,
    344.69183101464938, 342.71848183860908, 340.35902321328643,
    337.52472047704009, 334.2027457391635, 330.30078330957218,
    325.77255740004955, 320.55065546769731, 314.53138413790549,
    307.67833038449271, 299.84871863803806, 291.0108518812944,
    281.02839188517504, 269.82582956665283, 257.33291024280328,
    243.4129199593917, 228.08352153628439, 211.1924052061691, 192.81552428420551,
    172.88721884990733, 151.47410917674776, 128.70416664882183,
    104.60025349061628, 79.54196746095721, 53.535148515567712,
    26.582896808312448, 0.0, -26.582896808312448, -53.535148515567712,
    -79.54196746095694, -104.60025349061628, -128.70416664882208,
    -151.47410917674776, -172.88721884990733, -192.81552428420551,
    -211.1924052061691, -228.08352153628456, -243.4129199593917,
    -257.33291024280328, -269.82582956665283, -281.02839188517504,
    -291.0108518812944, -299.84871863803806, -307.67833038449271,
    -314.53138413790549, -320.55065546769731, -325.77255740004955,
    -330.30078330957218, -334.20274573916345, -337.52472047704009,
    -340.35902321328643, -342.71848183860908, -344.69183101464938,
    -346.29003022362133, -347.56839203870021, -348.57015411602833,
    -349.29621666987231, -349.827370516148, -350.10791412121949,
    -350.25684773604092, -350.20799447656117, -350.06290558238692,
    -349.76753056459239, -349.36574770230868, -348.85906838501847,
    -348.27680079770613, -347.61143244033258, -346.88542903204848,
    -346.10007331797954, -345.26383069349322, -344.38526484750554,
    -343.46600679138476, -342.51597557977777, -341.5360773948708,
    -340.53357718664927, -339.51100019790817, -338.47201554181328,
    -337.41958999293564, -336.354630628684, -335.28235274744753,
    -334.20344819542242, -333.12051560391581, -332.03486512279568,
    -330.94785997403227, -329.86134929943887, -328.77588506969732,
    -327.69388823579413, -326.61535159881453, -325.54017623784608,
    -324.47002753706454, -323.40615300003077, -322.34918890913832,
    -321.29929158515478, -320.25626882324582, -319.22043097044781,
    -318.19252720048257, -317.17309433452743, 396.46636791815934,
    397.74065900060327, 399.02553871305975, 400.32033602905727,
    401.62411448144348, 402.9364861364229, 404.25769125003842,
    405.58753442133064, 406.92522029730753, 408.26918949851813,
    409.6173602947427, 410.96985633712166, 412.32668662429859,
    413.68482496754035, 415.04358140349461, 416.40064450489479, 417.754310244278,
    419.1029409343094, 420.44328828585503, 421.77448749116957,
    423.09001942726655, 424.38875024738519, 425.66697148331161,
    426.92009674358854, 428.14496947472225, 429.332508489231, 430.48158105938194,
    431.57978836686652, 432.62509164747445, 433.60678629006065,
    434.51429055041575, 435.34600099713271, 436.07383548127308,
    436.70718462788591, 437.20941320574053, 437.57863197798366,
    437.75999309570142, 437.82105967005117, 437.63489265152441, 437.284213145185,
    436.6202708373404, 435.71269264503547, 434.46049004837528,
    432.86253777952663, 430.86478876831171, 428.39810229826134,
    425.44877901660806, 421.90590059630011, 417.75343217395437,
    412.87597913696521, 407.21569675006191, 400.68831933462167,
    393.16423017238185, 384.59791298061589, 374.81089829754757, 363.763564851618,
    351.28548985646881, 337.28228695831609, 321.66613780350411,
    304.2661499492396, 285.10440192035549, 263.99050650771142,
    241.01940535525688, 216.10902356238415, 189.34263647093468,
    160.88020831102725, 130.75031686327037, 99.427459326196526,
    66.918935644459651, 33.228621010390526, 0.0, -33.228621010390526,
    -66.918935644459651, -99.427459326196185, -130.75031686327037,
    -160.88020831102756, -189.34263647093468, -216.10902356238415,
    -241.01940535525688, -263.99050650771142, -285.10440192035571,
    -304.2661499492396, -321.66613780350411, -337.28228695831609,
    -351.28548985646881, -363.763564851618, -374.81089829754757,
    -384.59791298061589, -393.16423017238185, -400.68831933462167,
    -407.21569675006191, -412.87597913696516, -417.75343217395431,
    -421.90590059630011, -425.44877901660806, -428.39810229826134,
    -430.86478876831171, -432.86253777952663, -434.46049004837528,
    -435.71269264503547, -436.6202708373404, -437.284213145185,
    -437.63489265152435, -437.82105967005117, -437.75999309570142,
    -437.57863197798366, -437.20941320574053, -436.70718462788591,
    -436.07383548127308, -435.34600099713271, -434.51429055041575,
    -433.60678629006065, -432.62509164747445, -431.57978836686652,
    -430.48158105938194, -429.332508489231, -428.14496947472225,
    -426.92009674358854, -425.66697148331161, -424.38875024738519,
    -423.09001942726655, -421.77448749116957, -420.44328828585503,
    -419.1029409343094, -417.754310244278, -416.40064450489479,
    -415.04358140349467, -413.68482496754035, -412.32668662429859,
    -410.96985633712166, -409.6173602947427, -408.26918949851813,
    -406.92522029730759, -405.58753442133064, -404.25769125003848,
    -402.9364861364229, -401.62411448144348, -400.32033602905727,
    -399.02553871305975, -397.74065900060327, -396.46636791815934,
    475.75964150179118, 477.28879080072392, 478.83064645567174,
    480.38440323486867, 481.94893737773219, 483.52378336370754,
    485.10922950004618, 486.70504130559675, 488.31026435676904,
    489.92302739822173, 491.54083235369126, 493.16382760454604,
    494.79202394915836, 496.42178996104843, 498.05229768419355,
    499.68077340587377, 501.30517229313364, 502.92352912117133, 504.531945943026,
    506.12938498940349, 507.70802331271994, 509.26650029686226, 510.800365779974,
    512.30411609230623, 513.77396336966672, 515.19901018707708,
    516.57789727125828, 517.89574604023971, 519.15010997696936,
    520.32814354807283, 521.41714866049892, 522.41520119655922,
    523.28860257752763, 524.048621553463, 524.65129584688862, 525.09435837358035,
    525.31199171484172, 525.38527160406136, 525.16187118182927, 524.741055774222,
    523.94432500480843, 522.8552311740425, 521.35258805805029,
    519.43504533543194, 517.0377465219741, 514.07772275791365,
    510.53853481992962, 506.28708071556014, 501.30411860874523,
    495.45117496435824, 488.65883610007432, 480.825983201546, 471.79707620685821,
    461.51749557673907, 449.77307795705713, 436.51627782194169,
    421.54258782776259, 404.7387443499793, 385.99936536420489,
    365.11937993908754, 342.12528230442661, 316.78860780925368,
    289.22328642630828, 259.33082827486095, 227.21116376512163,
    193.05624997323272, 156.90038023592444, 119.31295119143584,
    80.302722773351576, 39.87434521246864, 0.0, -39.87434521246864,
    -80.302722773351576, -119.31295119143542, -156.90038023592444,
    -193.05624997323309, -227.21116376512163, -259.33082827486095,
    -289.22328642630828, -316.78860780925368, -342.12528230442683,
    -365.11937993908754, -385.99936536420489, -404.7387443499793,
    -421.54258782776259, -436.51627782194169, -449.77307795705713,
    -461.51749557673907, -471.79707620685821, -480.825983201546,
    -488.65883610007432, -495.45117496435824, -501.30411860874523,
    -506.28708071556014, -510.53853481992962, -514.07772275791365,
    -517.0377465219741, -519.43504533543194, -521.35258805805029,
    -522.8552311740425, -523.94432500480843, -524.741055774222,
    -525.16187118182927, -525.38527160406136, -525.31199171484172,
    -525.09435837358035, -524.65129584688862, -524.048621553463,
    -523.28860257752774, -522.41520119655922, -521.41714866049892,
    -520.32814354807283, -519.15010997696936, -517.89574604023983,
    -516.57789727125828, -515.19901018707708, -513.77396336966672,
    -512.30411609230623, -510.800365779974, -509.26650029686226,
    -507.70802331271989, -506.12938498940349, -504.531945943026,
    -502.92352912117133, -501.30517229313358, -499.68077340587371,
    -498.0522976841936, -496.42178996104849, -494.79202394915831,
    -493.16382760454604, -491.54083235369126, -489.92302739822179,
    -488.3102643567691, -486.70504130559675, -485.10922950004618,
    -483.52378336370748, -481.94893737773219, -480.38440323486867,
    -478.83064645567174, -477.28879080072392, -475.75964150179118,
    555.052915085423, 556.83692260084456, 558.63575419828362, 560.44847044068013,
    562.2737602740209, 564.11108059099206, 565.96076775005383, 567.8225481898628,
    569.69530841623055, 571.57686529792534, 573.46430441263976,
    575.35779887197032, 577.257361274018, 579.15875495455646, 581.06101396489248,
    582.96090230685274, 584.85603434198924, 586.7441173080332,
    588.62060360019711, 590.48428248763742, 592.32602719817316,
    594.14425034633928, 595.9337600766363, 597.688135441024, 599.40295726461113,
    601.06551188492335, 602.67421348313462, 604.211703713613, 605.6751283064641,
    607.04950080608478, 608.320006770582, 609.48440139598586, 610.50336967378234,
    611.39005847904014, 612.09317848803664, 612.61008476917709, 612.863990333982,
    612.94948353807172, 612.68884971213424, 612.197898403259, 611.26837917227658,
    609.99776970304958, 608.24468606772541, 606.00755289133724,
    603.21070427563643, 599.7573432175659, 595.62829062325136, 590.6682608348201,
    584.85480504353609, 578.02637079175122, 570.10197545008668,
    560.96364706847032, 550.42992224133457, 538.43707817286224,
    524.73525761656651, 509.26899079226524, 491.79968579905631,
    472.19520174164251, 450.33259292490573, 425.97260992893547,
    399.14616268849767, 369.58670911079594, 337.42716749735962,
    302.5526329873378, 265.07969105930857, 225.23229163543817,
    183.05044360857852, 139.19844305667513, 93.6865099022435, 46.520069414546732,
    0.0, -46.520069414546732, -93.6865099022435, -139.19844305667465,
    -183.05044360857852, -225.23229163543863, -265.07969105930857,
    -302.5526329873378, -337.42716749735962, -369.58670911079594,
    -399.14616268849795, -425.97260992893547, -450.33259292490573,
    -472.19520174164251, -491.79968579905631, -509.26899079226524,
    -524.73525761656651, -538.43707817286224, -550.42992224133457,
    -560.96364706847032, -570.10197545008668, -578.02637079175122,
    -584.854805043536, -590.6682608348201, -595.62829062325136,
    -599.7573432175659, -603.21070427563632, -606.00755289133724,
    -608.24468606772541, -609.9977697030497, -611.26837917227658,
    -612.197898403259, -612.68884971213424, -612.94948353807172,
    -612.863990333982, -612.61008476917709, -612.09317848803664,
    -611.39005847904014, -610.50336967378234, -609.48440139598586,
    -608.320006770582, -607.04950080608489, -605.6751283064641,
    -604.21170371361313, -602.67421348313462, -601.06551188492335,
    -599.40295726461113, -597.688135441024, -595.9337600766363,
    -594.14425034633928, -592.32602719817316, -590.48428248763742,
    -588.62060360019711, -586.7441173080332, -584.85603434198924,
    -582.96090230685263, -581.06101396489248, -579.15875495455646,
    -577.257361274018, -575.35779887197032, -573.46430441263976,
    -571.57686529792534, -569.69530841623055, -567.8225481898628,
    -565.96076775005383, -564.11108059099206, -562.2737602740209,
    -560.44847044068013, -558.63575419828362, -556.83692260084456,
    -555.052915085423, 634.34618866905487, 636.38505440096515,
    638.44086194089562, 640.51253764649164, 642.59858317030955,
    644.69837781827664, 646.81230600006154, 648.940055074129, 651.080352475692,
    653.230703197629, 655.38777647158838, 657.55177013939465, 659.72269859887774,
    661.89571994806454, 664.06973024559136, 666.24103120783172,
    668.40689639084485, 670.56470549489507, 672.709261257368, 674.83917998587128,
    676.94403108362656, 679.02200039581635, 681.06715437329854,
    683.0721547897416, 685.03195115955555, 686.93201358276951,
    688.77052969501108, 690.52766138698644, 692.20014663595907, 693.770858064097,
    695.22286488066516, 696.55360159541226, 697.718136770037, 698.73149540461736,
    699.53506112918478, 700.12581116477384, 700.41598895312234,
    700.51369547208185, 700.215828242439, 699.654741032296, 698.59243333974462,
    697.14030823205667, 695.13678407740042, 692.58006044724266,
    689.38366202929876, 685.43696367721816, 680.71804642657287,
    675.04944095408018, 668.405491478327, 660.60156661914436, 651.5451148000991,
    641.10131093539462, 629.062768275811, 615.35666076898542, 599.69743727607613,
    582.0217037625888, 562.05678377035008, 539.65165913330566,
    514.66582048560656, 486.8258399187834, 456.16704307256879, 422.3848104123382,
    385.631048568411, 345.77443769981465, 302.94821835349552, 257.40833329764365,
    209.20050698123256, 159.08393492191442, 107.07029703113542,
    53.165793616624896, 0.0, -53.165793616624896, -107.07029703113542,
    -159.08393492191388, -209.20050698123256, -257.40833329764416,
    -302.94821835349552, -345.77443769981465, -385.631048568411,
    -422.3848104123382, -456.16704307256913, -486.8258399187834,
    -514.66582048560656, -539.65165913330566, -562.05678377035008,
    -582.0217037625888, -599.69743727607613, -615.35666076898542,
    -629.062768275811, -641.10131093539462, -651.5451148000991,
    -660.60156661914436, -668.40549147832689, -675.04944095408018,
    -680.71804642657287, -685.43696367721816, -689.38366202929876,
    -692.58006044724266, -695.13678407740042, -697.14030823205667,
    -698.59243333974462, -699.654741032296, -700.215828242439,
    -700.51369547208185, -700.41598895312234, -700.12581116477384,
    -699.53506112918478, -698.73149540461736, -697.718136770037,
    -696.55360159541226, -695.22286488066516, -693.770858064097,
    -692.20014663595907, -690.52766138698644, -688.77052969501108,
    -686.93201358276951, -685.03195115955555, -683.0721547897416,
    -681.06715437329854, -679.02200039581635, -676.94403108362656,
    -674.83917998587128, -672.709261257368, -670.56470549489507,
    -668.40689639084485, -666.24103120783161, -664.06973024559136,
    -661.89571994806454, -659.72269859887774, -657.55177013939465,
    -655.38777647158827, -653.230703197629, -651.08035247569217,
    -648.94005507412908, -646.81230600006154, -644.69837781827664,
    -642.59858317030955, -640.51253764649164, -638.44086194089562,
    -636.38505440096515, -634.34618866905487, 713.63946225268683,
    715.93318620108585, 718.2459696835075, 720.576604852303, 722.92340606659832,
    725.28567504556122, 727.66384425006913, 730.05756195839513,
    732.46539653515356, 734.88454109733254, 737.31124853053689,
    739.74574140681909, 742.18803592373752, 744.63268494157262,
    747.07844652629035, 749.52116010881059, 751.95775843970034,
    754.38529368175693, 756.79791891453908, 759.19407748410526,
    761.56203496907983, 763.89975044529331, 766.200548669961, 768.45617413845935,
    770.66094505450008, 772.79851528061567, 774.86684590688742,
    776.84361906035963, 778.72516496545393, 780.492215322109, 782.12572299074827,
    783.62280179483889, 784.93290386629155, 786.07293233019459,
    786.97694377033292, 787.64153756037058, 787.96798757226259,
    788.07790740609209, 787.742806772744, 787.111583661333, 785.91648750721265,
    784.28284676106375, 782.02888208707554, 779.152568003148, 775.55661978296109,
    771.11658413687042, 765.80780222989449, 759.43062107334015,
    751.95617791311781, 743.17676244653728, 732.9882541501114,
    721.23897480231892, 707.69561431028728, 692.2762433651086,
    674.65961693558563, 654.77441673291241, 632.31388174164385,
    607.10811652496886, 578.99904804630739, 547.67906990863139, 513.18792345664,
    475.18291171388051, 433.83492963946236, 388.99624241229145,
    340.81674564768247, 289.58437495984907, 235.35057035388664,
    178.96942678715374, 120.45408416002735, 59.811517818702974, 0.0,
    -59.811517818702974, -120.45408416002735, -178.96942678715311,
    -235.35057035388664, -289.58437495984964, -340.81674564768247,
    -388.99624241229145, -433.83492963946236, -475.18291171388051,
    -513.18792345664031, -547.67906990863139, -578.99904804630739,
    -607.10811652496886, -632.31388174164385, -654.77441673291241,
    -674.65961693558563, -692.2762433651086, -707.69561431028728,
    -721.23897480231892, -732.9882541501114, -743.17676244653728,
    -751.95617791311781, -759.43062107334015, -765.80780222989449,
    -771.11658413687042, -775.55661978296109, -779.152568003148,
    -782.02888208707554, -784.28284676106375, -785.91648750721265,
    -787.111583661333, -787.742806772744, -788.07790740609209,
    -787.96798757226259, -787.64153756037058, -786.97694377033292,
    -786.07293233019459, -784.93290386629155, -783.62280179483889,
    -782.12572299074827, -780.49221532210913, -778.72516496545393,
    -776.84361906035974, -774.86684590688742, -772.79851528061567,
    -770.66094505450008, -768.45617413845935, -766.200548669961,
    -763.89975044529331, -761.56203496907983, -759.19407748410526,
    -756.79791891453908, -754.38529368175693, -751.95775843970034,
    -749.52116010881059, -747.07844652629035, -744.63268494157273,
    -742.18803592373752, -739.74574140681909, -737.31124853053689,
    -734.88454109733266, -732.46539653515356, -730.05756195839513,
    -727.66384425006925, -725.28567504556122, -722.92340606659832,
    -720.576604852303, -718.2459696835075, -715.93318620108585,
    -713.63946225268683, 792.93273583631867, 795.48131800120655,
    798.05107742611949, 800.64067205811455, 803.248228962887, 805.8729722728458,
    808.51538250007684, 811.17506884266129, 813.85044059461507,
    816.53837899703626, 819.23472058948539, 821.93971267424331,
    824.65337324859718, 827.3696499350807, 830.08716280698923,
    832.80128900978957, 835.508620488556, 838.2058818686188, 840.88657657171007,
    843.54897498233913, 846.18003885453311, 848.77750049477038,
    851.33394296662323, 853.84019348717709, 856.28993894944449, 858.665016978462,
    860.96316211876388, 863.159576733733, 865.2501832949489, 867.21357258012131,
    869.0285811008315, 870.69200199426541, 872.14767096254616,
    873.41436925577182, 874.41882641148106, 875.15726395596732,
    875.51998619140284, 875.64211934010234, 875.26978530304882, 874.56842629037,
    873.2405416746808, 871.425385290071, 868.92098009675055, 865.72507555905327,
    861.72957753662342, 856.79620459652267, 850.89755803321611,
    843.81180119260023, 835.50686434790873, 825.75195827393043,
    814.43139350012382, 801.37663866924333, 786.3284603447637,
    769.19582596123178, 749.62179659509513, 727.527129703236, 702.57097971293763,
    674.56457391663218, 643.33227560700823, 608.53229989847921, 570.208803840711,
    527.98101301542283, 482.03881071051376, 432.2180471247683,
    378.68527294186936, 321.76041662205449, 261.50063372654074,
    198.85491865239305, 133.8378712889193, 66.457242020781052, 0.0,
    -66.457242020781052, -133.8378712889193, -198.85491865239237,
    -261.50063372654074, -321.76041662205512, -378.68527294186936,
    -432.2180471247683, -482.03881071051376, -527.98101301542283,
    -570.20880384071143, -608.53229989847921, -643.33227560700823,
    -674.56457391663218, -702.57097971293763, -727.527129703236,
    -749.62179659509513, -769.19582596123178, -786.3284603447637,
    -801.37663866924333, -814.43139350012382, -825.75195827393031,
    -835.50686434790862, -843.81180119260023, -850.89755803321611,
    -856.79620459652267, -861.72957753662342, -865.72507555905327,
    -868.92098009675055, -871.425385290071, -873.2405416746808, -874.56842629037,
    -875.26978530304871, -875.64211934010234, -875.51998619140284,
    -875.15726395596732, -874.41882641148106, -873.41436925577182,
    -872.14767096254616, -870.69200199426541, -869.0285811008315,
    -867.21357258012131, -865.2501832949489, -863.159576733733,
    -860.96316211876388, -858.665016978462, -856.28993894944449,
    -853.84019348717709, -851.33394296662323, -848.77750049477038,
    -846.18003885453311, -843.54897498233913, -840.88657657171007,
    -838.2058818686188, -835.508620488556, -832.80128900978957,
    -830.08716280698934, -827.3696499350807, -824.65337324859718,
    -821.93971267424331, -819.23472058948539, -816.53837899703626,
    -813.85044059461518, -811.17506884266129, -808.515382500077,
    -805.8729722728458, -803.248228962887, -800.64067205811455,
    -798.05107742611949, -795.48131800120655, -792.93273583631867,
    872.22600941995051, 875.02944980132713, 877.85618516873149, 880.704739263926,
    883.57305185917573, 886.46026950013038, 889.36692075008455,
    892.29257572692734, 895.23548465407657, 898.19221689673986, 901.158192648434,
    904.13368394166764, 907.118710573457, 910.10661492858878, 913.09587908768822,
    916.08141791076855, 919.05948253741155, 922.02647005548079, 924.975234228881,
    927.903872480573, 930.7980427399865, 933.65525054424756, 936.46733726328569,
    939.22421283589472, 941.918932844389, 944.53151867630811, 947.0594783306401,
    949.47553440710624, 951.77520162444375, 953.93492983813337,
    955.93143921091462, 957.76120219369193, 959.36243805880076,
    960.75580618134893, 961.86070905262909, 962.672990351564, 963.0719848105432,
    963.20633127411259, 962.79676383335368, 962.025268919407, 960.56459584214883,
    958.56792381907792, 955.81307810642568, 952.29758311495868,
    947.90253529028575, 942.47582505617493, 935.98731383653774,
    928.19298131186019, 919.05755078269954, 908.32715410132346,
    895.87453285013623, 881.51430253616763, 864.96130637924, 846.115408557355,
    824.58397625460475, 800.27984267355976, 772.82807768423129,
    742.02103130829539, 707.66550316770906, 669.38552988832726,
    627.22968422478209, 580.77911431696509, 530.2426917815651, 475.4398518372451,
    416.5538002360563, 353.93645828425997, 287.65069709919476,
    218.74041051763234, 147.22165841781123, 73.102966222859209, 0.0,
    -73.102966222859209, -147.22165841781123, -218.74041051763157,
    -287.65069709919476, -353.93645828426071, -416.5538002360563,
    -475.4398518372451, -530.2426917815651, -580.77911431696509,
    -627.22968422478255, -669.38552988832726, -707.66550316770906,
    -742.02103130829539, -772.82807768423129, -800.27984267355976,
    -824.58397625460475, -846.115408557355, -864.96130637924,
    -881.51430253616763, -895.87453285013623, -908.32715410132346,
    -919.05755078269954, -928.19298131186019, -935.98731383653774,
    -942.47582505617493, -947.90253529028575, -952.29758311495857,
    -955.81307810642568, -958.567923819078, -960.56459584214883,
    -962.025268919407, -962.79676383335368, -963.20633127411259,
    -963.0719848105432, -962.672990351564, -961.86070905262909,
    -960.75580618134893, -959.36243805880076, -957.76120219369193,
    -955.93143921091462, -953.93492983813337, -951.77520162444375,
    -949.47553440710624, -947.0594783306401, -944.53151867630811,
    -941.918932844389, -939.22421283589472, -936.46733726328569,
    -933.65525054424756, -930.7980427399865, -927.90387248057311,
    -924.975234228881, -922.02647005548079, -919.05948253741155,
    -916.08141791076855, -913.09587908768822, -910.10661492858878,
    -907.11871057345684, -904.13368394166764, -901.1581926484339,
    -898.19221689673986, -895.23548465407657, -892.29257572692734,
    -889.36692075008455, -886.46026950013027, -883.57305185917573,
    -880.704739263926, -877.85618516873149, -875.02944980132713,
    -872.22600941995051, 951.51928300358236, 954.57758160144783,
    957.66129291134348, 960.76880646973734, 963.89787475546439,
    967.04756672741507, 970.21845900009237, 973.4100826111935,
    976.62052871353808, 979.84605479644347, 983.08166470738252,
    986.32765520909209, 989.58404789831673, 992.84357992209686,
    996.10459536838709, 999.36154681174753, 1002.6103445862673,
    1005.8470582423427, 1009.063891886052, 1012.258769978807, 1015.4160466254399,
    1018.5330005937245, 1021.600731559948, 1024.6082321846125,
    1027.5479267393334, 1030.3980203741542, 1033.1557945425166,
    1035.7914920804794, 1038.3002199539387, 1040.6562870961457,
    1042.8342973209978, 1044.8304023931184, 1046.5772051550553,
    1048.097243106926, 1049.3025916937772, 1050.1887167471607,
    1050.6239834296834, 1050.7705432081227, 1050.3237423636585,
    1049.482111548444, 1047.8886500096169, 1045.710462348085, 1042.7051761161006,
    1038.8700906708639, 1034.0754930439482, 1028.1554455158273,
    1021.0770696398592, 1012.5741614311203, 1002.6082372174905,
    990.90234992871649, 977.31767220014865, 961.651966403092, 943.59415241371642,
    923.03499115347813, 899.54615591411425, 873.03255564388337,
    843.08517565552518, 809.4774886999586, 771.99873072840978,
    730.23875987817507, 684.25056460885321, 633.57721561850735,
    578.44657285261655, 518.6616565497219, 454.42232753024325,
    386.11249994646545, 313.80076047184889, 238.62590238287169,
    160.60544554670315, 79.74869042493728, 0.0, -79.74869042493728,
    -160.60544554670315, -238.62590238287083, -313.80076047184889,
    -386.11249994646619, -454.42232753024325, -518.6616565497219,
    -578.44657285261655, -633.57721561850735, -684.25056460885367,
    -730.23875987817507, -771.99873072840978, -809.4774886999586,
    -843.08517565552518, -873.03255564388337, -899.54615591411425,
    -923.03499115347813, -943.59415241371642, -961.651966403092,
    -977.31767220014865, -990.90234992871649, -1002.6082372174905,
    -1012.5741614311203, -1021.0770696398592, -1028.1554455158273,
    -1034.0754930439482, -1038.8700906708639, -1042.7051761161006,
    -1045.710462348085, -1047.8886500096169, -1049.482111548444,
    -1050.3237423636585, -1050.7705432081227, -1050.6239834296834,
    -1050.1887167471607, -1049.3025916937772, -1048.097243106926,
    -1046.5772051550555, -1044.8304023931184, -1042.8342973209978,
    -1040.6562870961457, -1038.3002199539387, -1035.7914920804797,
    -1033.1557945425166, -1030.3980203741542, -1027.5479267393334,
    -1024.6082321846125, -1021.600731559948, -1018.5330005937245,
    -1015.4160466254398, -1012.258769978807, -1009.063891886052,
    -1005.8470582423427, -1002.6103445862672, -999.36154681174742,
    -996.10459536838721, -992.843579922097, -989.58404789831661,
    -986.32765520909209, -983.08166470738252, -979.84605479644358,
    -976.62052871353819, -973.4100826111935, -970.21845900009237,
    -967.047566727415, -963.89787475546439, -960.76880646973734,
    -957.66129291134348, -954.57758160144783, -951.51928300358236,
    1030.8125565872142, 1034.1257134015684, 1037.4664006539551,
    1040.8328736755489, 1044.2226976517532, 1047.6348639546995, 1051.0699972501,
    1054.5275894954598, 1058.0055727729996, 1061.4998926961471,
    1065.0051367663311, 1068.5216264765163, 1072.0493852231764,
    1075.5805449156051, 1079.113311649086, 1082.6416757127265,
    1086.1612066351229, 1089.6676464292045, 1093.1525495432231,
    1096.613667477041, 1100.0340505108932, 1103.4107506432015,
    1106.7341258566103, 1109.9922515333303, 1113.1769206342778,
    1116.2645220720005, 1119.252110754393, 1122.107449753853, 1124.8252382834335,
    1127.3776443541576, 1129.737155431081, 1131.8996025925451, 1133.79197225131,
    1135.4386800325033, 1136.7444743349254, 1137.7044431427573,
    1138.1759820488237, 1138.334755142133, 1137.8507208939634, 1136.938954177481,
    1135.212704177085, 1132.8530008770922, 1129.5972741257756,
    1125.4425982267694, 1120.2484507976105, 1113.8350659754794,
    1106.1668254431809, 1096.9553415503801, 1086.1589236522811,
    1073.4775457561095, 1058.760811550161, 1041.7896302700162,
    1022.2269984481927, 999.95457374960131, 974.50833557362375,
    945.78526861420687, 913.34227362681884, 876.93394609162181,
    836.33195828911073, 791.09198986802312, 741.27144499292433,
    686.37531692004973, 626.6504539236679, 561.88346126219881, 492.2908548244302,
    418.28854160867087, 339.95082384450291, 258.51139424811095,
    173.98923267559505, 86.394414627015408, 0.0, -86.394414627015408,
    -173.98923267559505, -258.51139424811004, -339.95082384450291,
    -418.28854160867166, -492.2908548244302, -561.88346126219881,
    -626.6504539236679, -686.37531692004973, -741.2714449929249,
    -791.09198986802312, -836.33195828911073, -876.93394609162181,
    -913.34227362681884, -945.78526861420687, -974.50833557362375,
    -999.95457374960131, -1022.2269984481927, -1041.7896302700162,
    -1058.760811550161, -1073.4775457561095, -1086.1589236522811,
    -1096.9553415503801, -1106.1668254431809, -1113.8350659754794,
    -1120.2484507976105, -1125.4425982267692, -1129.5972741257756,
    -1132.8530008770922, -1135.212704177085, -1136.938954177481,
    -1137.8507208939634, -1138.334755142133, -1138.1759820488237,
    -1137.7044431427573, -1136.7444743349254, -1135.4386800325033,
    -1133.79197225131, -1131.8996025925451, -1129.737155431081,
    -1127.3776443541576, -1124.8252382834335, -1122.107449753853,
    -1119.252110754393, -1116.2645220720005, -1113.1769206342778,
    -1109.9922515333303, -1106.7341258566103, -1103.4107506432015,
    -1100.0340505108932, -1096.613667477041, -1093.1525495432231,
    -1089.6676464292045, -1086.1612066351229, -1082.6416757127265,
    -1079.1133116490862, -1075.5805449156051, -1072.0493852231764,
    -1068.5216264765163, -1065.0051367663309, -1061.4998926961471,
    -1058.0055727729996, -1054.5275894954598, -1051.0699972501,
    -1047.6348639546995, -1044.2226976517532, -1040.8328736755489,
    -1037.4664006539551, -1034.1257134015684, -1030.8125565872142,
    1110.105830170846, 1113.6738452016891, 1117.2715083965672,
    1120.8969408813603, 1124.5475205480418, 1128.2221611819841,
    1131.9215355001077, 1135.6450963797256, 1139.3906168324611,
    1143.1537305958507, 1146.9286088252795, 1150.7155977439406,
    1154.5147225480359, 1158.3175099091129, 1162.122027929785,
    1165.9218046137055, 1169.7120686839785, 1173.4882346160664,
    1177.2412072003942, 1180.9685649752748, 1184.6520543963463,
    1188.2885006926786, 1191.8675201532726, 1195.3762708820479,
    1198.8059145292223, 1202.1310237698467, 1205.3484269662692,
    1208.423407427226, 1211.3502566129282, 1214.0990016121696,
    1216.6400135411641, 1218.9688027919717, 1221.0067393475647,
    1222.7801169580803, 1224.1863569760733, 1225.2201695383542,
    1225.7279806679639, 1225.8989670761434, 1225.3776994242685,
    1224.3957968065181, 1222.5367583445532, 1219.9955394060992,
    1216.4893721354508, 1212.0151057826745, 1206.4214085512729,
    1199.5146864351318, 1191.2565812465027, 1181.3365216696402,
    1169.7096100870722, 1156.0527415835024, 1140.2039509001734,
    1121.9272941369406, 1100.8598444826691, 1076.8741563457245,
    1049.470515233133, 1018.5379815845305, 983.59937159811261, 944.390403483285,
    900.66518584981145, 851.94521985787094, 798.29232537699534,
    739.17341822159187, 674.85433499471924, 605.1052659746756,
    530.15938211861715, 450.46458327087635, 366.10088721715704,
    278.39688611335026, 187.373019804487, 93.040138829093465, 0.0,
    -93.040138829093465, -187.373019804487, -278.3968861133493,
    -366.10088721715704, -450.46458327087726, -530.15938211861715,
    -605.1052659746756, -674.85433499471924, -739.17341822159187,
    -798.2923253769959, -851.94521985787094, -900.66518584981145,
    -944.390403483285, -983.59937159811261, -1018.5379815845305,
    -1049.470515233133, -1076.8741563457245, -1100.8598444826691,
    -1121.9272941369406, -1140.2039509001734, -1156.0527415835024,
    -1169.709610087072, -1181.3365216696402, -1191.2565812465027,
    -1199.5146864351318, -1206.4214085512726, -1212.0151057826745,
    -1216.4893721354508, -1219.9955394060994, -1222.5367583445532,
    -1224.3957968065181, -1225.3776994242685, -1225.8989670761434,
    -1225.7279806679639, -1225.2201695383542, -1224.1863569760733,
    -1222.7801169580803, -1221.0067393475647, -1218.9688027919717,
    -1216.6400135411641, -1214.0990016121698, -1211.3502566129282,
    -1208.4234074272263, -1205.3484269662692, -1202.1310237698467,
    -1198.8059145292223, -1195.3762708820479, -1191.8675201532726,
    -1188.2885006926786, -1184.6520543963463, -1180.9685649752748,
    -1177.2412072003942, -1173.4882346160664, -1169.7120686839785,
    -1165.9218046137053, -1162.122027929785, -1158.3175099091129,
    -1154.5147225480359, -1150.7155977439406, -1146.9286088252795,
    -1143.1537305958507, -1139.3906168324611, -1135.6450963797256,
    -1131.9215355001077, -1128.2221611819841, -1124.5475205480418,
    -1120.8969408813603, -1117.2715083965672, -1113.6738452016891,
    -1110.105830170846, 1189.3991037544779, 1193.2219770018096,
    1197.0766161391791, 1200.9610080871714, 1204.8723434443302,
    1208.8094584092685, 1212.7730737501151, 1216.7626032639919,
    1220.7756608919226, 1224.8075684955543, 1228.8520808842279,
    1232.9095690113647, 1236.9800598728957, 1241.054474902621,
    1245.1307442104837, 1249.2019335146842, 1253.2629307328339,
    1257.3088228029283, 1261.3298648575649, 1265.3234624735085,
    1269.2700582817997, 1273.1662507421554, 1277.0009144499347,
    1280.7602902307656, 1284.4349084241667, 1287.9975254676926,
    1291.4447431781457, 1294.7393651005993, 1297.8752749424229,
    1300.8203588701815, 1303.542871651247, 1306.0380029913979,
    1308.2215064438192, 1310.1215538836575, 1311.6282396172214,
    1312.7358959339508, 1313.2799792871042, 1313.4631790101535,
    1312.9046779545731, 1311.8526394355549, 1309.8608125120211,
    1307.1380779351061, 1303.3814701451256, 1298.5876133385798,
    1292.5943663049352, 1285.1943068947839, 1276.3463370498241,
    1265.7177017889003, 1253.260296521863, 1238.6279374108954,
    1221.6470902501856, 1202.0649580038648, 1179.4926905171455,
    1153.7937389418476, 1124.4326948926425, 1091.2906945548539,
    1053.8564695694063, 1011.8468608749481, 964.99841341051217,
    912.79844984771876, 855.31320576106646, 791.97151952313413,
    723.05821606577058, 648.32707068715229, 568.027909412804, 482.64062493308177,
    392.250950589811, 298.28237797858952, 200.7568069333789, 99.685863031171621,
    0.0, -99.685863031171621, -200.7568069333789, -298.2823779785885,
    -392.250950589811, -482.64062493308268, -568.027909412804,
    -648.32707068715229, -723.05821606577058, -791.97151952313413,
    -855.313205761067, -912.79844984771876, -964.99841341051217,
    -1011.8468608749481, -1053.8564695694063, -1091.2906945548539,
    -1124.4326948926425, -1153.7937389418476, -1179.4926905171455,
    -1202.0649580038648, -1221.6470902501856, -1238.6279374108954,
    -1253.260296521863, -1265.7177017889003, -1276.3463370498241,
    -1285.1943068947839, -1292.594366304935, -1298.5876133385798,
    -1303.3814701451256, -1307.1380779351061, -1309.8608125120211,
    -1311.8526394355549, -1312.9046779545731, -1313.4631790101535,
    -1313.2799792871042, -1312.7358959339508, -1311.6282396172214,
    -1310.1215538836575, -1308.2215064438192, -1306.0380029913979,
    -1303.542871651247, -1300.8203588701817, -1297.8752749424232,
    -1294.7393651005993, -1291.4447431781457, -1287.9975254676926,
    -1284.4349084241667, -1280.7602902307656, -1277.0009144499347,
    -1273.1662507421554, -1269.2700582817995, -1265.3234624735087,
    -1261.3298648575649, -1257.3088228029283, -1253.2629307328339,
    -1249.2019335146842, -1245.1307442104837, -1241.054474902621,
    -1236.9800598728957, -1232.9095690113647, -1228.8520808842279,
    -1224.8075684955543, -1220.7756608919226, -1216.7626032639919,
    -1212.7730737501151, -1208.8094584092685, -1204.8723434443302,
    -1200.9610080871714, -1197.0766161391791, -1193.2219770018096,
    -1189.3991037544779, 1268.6923773381097, 1272.7701088019303,
    1276.8817238817912, 1281.0250752929833, 1285.1971663406191,
    1289.3967556365533, 1293.6246120001231, 1297.8801101482579,
    1302.1607049513841, 1306.4614063952581, 1310.7755529431768,
    1315.1035402787893, 1319.4453971977555, 1323.7914398961291,
    1328.1394604911827, 1332.4820624156634, 1336.8137927816897,
    1341.1294109897901, 1345.418522514736, 1349.6783599717426,
    1353.8880621672531, 1358.0440007916327, 1362.1343087465971,
    1366.1443095794832, 1370.0639023191111, 1373.864027165539,
    1377.5410593900222, 1381.0553227739729, 1384.4002932719181,
    1387.5417161281939, 1390.4457297613303, 1393.1072031908245,
    1395.4362735400739, 1397.4629908092347, 1399.0701222583696,
    1400.2516223295477, 1400.8319779062447, 1401.0273909441637,
    1400.431656484878, 1399.309482064592, 1397.1848666794892, 1394.2806164641133,
    1390.2735681548008, 1385.1601208944853, 1378.7673240585975,
    1370.8739273544363, 1361.4360928531457, 1350.0988819081604,
    1336.810982956654, 1321.2031332382887, 1303.0902296001982,
    1282.2026218707892, 1258.125536551622, 1230.7133215379708,
    1199.3948745521523, 1164.0434075251776, 1124.1135675407002,
    1079.3033182666113, 1029.3316409712131, 973.6516798375668,
    912.33408614513758, 844.76962082467639, 771.262097136822, 691.54887539962931,
    605.896436706991, 514.8166665952873, 418.40101396246513, 318.16786984382884,
    214.14059406227085, 106.33158723324979, 0.0, -106.33158723324979,
    -214.14059406227085, -318.16786984382776, -418.40101396246513,
    -514.81666659528832, -605.896436706991, -691.54887539962931,
    -771.262097136822, -844.76962082467639, -912.33408614513826,
    -973.6516798375668, -1029.3316409712131, -1079.3033182666113,
    -1124.1135675407002, -1164.0434075251776, -1199.3948745521523,
    -1230.7133215379708, -1258.125536551622, -1282.2026218707892,
    -1303.0902296001982, -1321.2031332382887, -1336.8109829566538,
    -1350.0988819081604, -1361.4360928531457, -1370.8739273544363,
    -1378.7673240585975, -1385.1601208944853, -1390.2735681548008,
    -1394.2806164641133, -1397.1848666794892, -1399.309482064592,
    -1400.431656484878, -1401.0273909441637, -1400.8319779062447,
    -1400.2516223295477, -1399.0701222583696, -1397.4629908092347,
    -1395.4362735400739, -1393.1072031908245, -1390.4457297613303,
    -1387.5417161281939, -1384.4002932719181, -1381.0553227739729,
    -1377.5410593900222, -1373.864027165539, -1370.0639023191111,
    -1366.1443095794832, -1362.1343087465971, -1358.0440007916327,
    -1353.8880621672531, -1349.6783599717426, -1345.418522514736,
    -1341.1294109897901, -1336.8137927816897, -1332.4820624156632,
    -1328.1394604911827, -1323.7914398961291, -1319.4453971977555,
    -1315.1035402787893, -1310.7755529431765, -1306.4614063952581,
    -1302.1607049513843, -1297.8801101482582, -1293.6246120001231,
    -1289.3967556365533, -1285.1971663406191, -1281.0250752929833,
    -1276.8817238817912, -1272.7701088019303, -1268.6923773381097,
    1347.9856509217416, 1352.318240602051, 1356.6868316244031,
    1361.0891424987944, 1365.5219892369078, 1369.9840528638379,
    1374.4761502501308, 1378.997617032524, 1383.5457490108454,
    1388.1152442949613, 1392.6990250021252, 1397.2975115462136,
    1401.910734522615, 1406.5284048896369, 1411.1481767718815,
    1415.7621913166422, 1420.3646548305451, 1424.9499991766518,
    1429.5071801719068, 1434.0332574699764, 1438.5060660527063,
    1442.9217508411095, 1447.2677030432594, 1451.5283289282008,
    1455.6928962140555, 1459.7305288633852, 1463.6373756018984,
    1467.371280447346, 1470.9253116014129, 1474.2630733862061,
    1477.3485878714134, 1480.1764033902509, 1482.6510406363282,
    1484.8044277348117, 1486.5120048995175, 1487.7673487251443,
    1488.3839765253847, 1488.5916028781739, 1487.9586350151828,
    1486.7663246936288, 1484.5089208469572, 1481.4231549931203,
    1477.1656661644759, 1471.7326284503904, 1464.9402818122596,
    1456.5535478140885, 1446.5258486564671, 1434.4800620274202,
    1420.3616693914448, 1403.7783290656816, 1384.5333689502104,
    1362.3402857377137, 1336.7583825860982, 1307.6329041340939,
    1274.3570542116615, 1236.7961204955011, 1194.3706655119938,
    1146.7597756582745, 1093.6648685319137, 1034.5049098274146,
    969.35496652920858, 897.56772212621865, 819.46597820787326, 734.770680112106,
    643.76496400117787, 546.99270825749272, 444.5510773351192,
    338.05336170906816, 227.52438119116275, 112.97731143532778, 0.0,
    -112.97731143532778, -227.52438119116275, -338.05336170906696,
    -444.5510773351192, -546.99270825749375, -643.76496400117787,
    -734.770680112106, -819.46597820787326, -897.56772212621865,
    -969.35496652920938, -1034.5049098274146, -1093.6648685319137,
    -1146.7597756582745, -1194.3706655119938, -1236.7961204955011,
    -1274.3570542116615, -1307.6329041340939, -1336.7583825860982,
    -1362.3402857377137, -1384.5333689502104, -1403.7783290656814,
    -1420.3616693914446, -1434.4800620274202, -1446.5258486564671,
    -1456.5535478140885, -1464.9402818122596, -1471.7326284503904,
    -1477.1656661644756, -1481.4231549931203, -1484.5089208469572,
    -1486.7663246936288, -1487.9586350151828, -1488.5916028781739,
    -1488.3839765253847, -1487.7673487251443, -1486.5120048995175,
    -1484.804427734812, -1482.6510406363284, -1480.1764033902509,
    -1477.3485878714134, -1474.2630733862061, -1470.9253116014129,
    -1467.371280447346, -1463.6373756018984, -1459.7305288633852,
    -1455.6928962140555, -1451.5283289282008, -1447.2677030432594,
    -1442.9217508411095, -1438.5060660527063, -1434.0332574699764,
    -1429.5071801719068, -1424.9499991766518, -1420.3646548305451,
    -1415.7621913166422, -1411.1481767718817, -1406.5284048896372,
    -1401.910734522615, -1397.2975115462136, -1392.6990250021252,
    -1388.1152442949615, -1383.5457490108454, -1378.997617032524,
    -1374.4761502501308, -1369.9840528638379, -1365.5219892369078,
    -1361.0891424987944, -1356.6868316244031, -1352.318240602051,
    -1347.9856509217416, 1427.2789245053737, 1431.8663724021717,
    1436.491939367015, 1441.1532097046061, 1445.8468121331966,
    1450.5713500911224, 1455.3276885001383, 1460.1151239167903,
    1464.9307930703071, 1469.7690821946651, 1474.6224970610738,
    1479.4914828136382, 1484.376071847475, 1489.2653698831452,
    1494.1568930525807, 1499.0423202176212, 1503.9155168794007,
    1508.7705873635139, 1513.5958378290782, 1518.3881549682105,
    1523.1240699381597, 1527.7995008905866, 1532.401097339922,
    1536.9123482769187, 1541.3218901090002, 1545.5970305612313,
    1549.7336918137748, 1553.6872381207193, 1557.4503299309079,
    1560.984430644218, 1564.2514459814965, 1567.2456035896778,
    1569.8658077325831, 1572.1458646603892, 1573.9538875406658,
    1575.2830751207412, 1575.9359751445252, 1576.1558148121842,
    1575.4856135454879, 1574.2231673226661, 1571.8329750144253,
    1568.5656935221275, 1564.0577641741511, 1558.3051360062959,
    1551.1132395659222, 1542.2331682737408, 1531.615604459789,
    1518.8612421466803, 1503.9123558262356, 1486.3535248930746,
    1465.9765083002228, 1442.4779496046378, 1415.3912286205746,
    1384.5524867302172, 1349.3192338711713, 1309.5488334658248,
    1264.6277634832877, 1214.2162330499377, 1157.9980960926148,
    1095.3581398172628, 1026.37584691328, 950.365823427761, 867.66985927892472,
    777.9924848245829, 681.63349129536493, 579.16874991969814,
    470.70114070777328, 357.93885357430747, 240.9081683200547,
    119.62303563740595, 0.0, -119.62303563740595, -240.9081683200547,
    -357.93885357430622, -470.70114070777328, -579.16874991969928,
    -681.63349129536493, -777.9924848245829, -867.66985927892472,
    -950.365823427761, -1026.3758469132806, -1095.3581398172628,
    -1157.9980960926148, -1214.2162330499377, -1264.6277634832877,
    -1309.5488334658248, -1349.3192338711713, -1384.5524867302172,
    -1415.3912286205746, -1442.4779496046378, -1465.9765083002228,
    -1486.3535248930746, -1503.9123558262356, -1518.8612421466803,
    -1531.615604459789, -1542.2331682737408, -1551.1132395659222,
    -1558.3051360062959, -1564.0577641741511, -1568.5656935221275,
    -1571.8329750144253, -1574.2231673226661, -1575.4856135454879,
    -1576.1558148121842, -1575.9359751445252, -1575.2830751207412,
    -1573.9538875406658, -1572.1458646603892, -1569.8658077325831,
    -1567.2456035896778, -1564.2514459814965, -1560.9844306442183,
    -1557.4503299309079, -1553.6872381207195, -1549.7336918137748,
    -1545.5970305612313, -1541.3218901090002, -1536.9123482769187,
    -1532.401097339922, -1527.7995008905866, -1523.1240699381597,
    -1518.3881549682105, -1513.5958378290782, -1508.7705873635139,
    -1503.9155168794007, -1499.0423202176212, -1494.1568930525807,
    -1489.2653698831455, -1484.376071847475, -1479.4914828136382,
    -1474.6224970610738, -1469.7690821946653, -1464.9307930703071,
    -1460.1151239167903, -1455.3276885001385, -1450.5713500911224,
    -1445.8468121331966, -1441.1532097046061, -1436.491939367015,
    -1431.8663724021717, -1427.2789245053737, 1506.5721980890053,
    1511.4145042022922, 1516.2970471096269, 1521.2172769104175,
    1526.1716350294853, 1531.158647318407, 1536.179226750146, 1541.2326308010563,
    1546.3158371297686, 1551.4229200943687, 1556.5459691200222,
    1561.6854540810621, 1566.8414091723346, 1572.0023348766533,
    1577.1656093332795, 1582.3224491186002, 1587.4663789282563,
    1592.5911755503757, 1597.684495486249, 1602.7430524664442,
    1607.7420738236128, 1612.6772509400637, 1617.5344916365841,
    1622.2963676256363, 1626.9508840039443, 1631.4635322590775,
    1635.8300080256511, 1640.0031957940926, 1643.9753482604026,
    1647.7057879022302, 1651.1543040915797, 1654.3148037891042,
    1657.0805748288376, 1659.4873015859662, 1661.3957701818138,
    1662.7988015163376, 1663.4879737636652, 1663.7200267461942,
    1663.0125920757926, 1661.6800099517029, 1659.1570291818932,
    1655.7082320511345, 1650.9498621838259, 1644.877643562201,
    1637.2861973195845, 1627.912788733393, 1616.7053602631106,
    1603.2424222659404, 1587.4630422610264, 1568.9287207204677,
    1547.4196476502352, 1522.6156134715623, 1494.024074655051,
    1461.4720693263403, 1424.2814135306805, 1382.3015464361483,
    1334.8848614545811, 1281.6726904416009, 1222.3313236533156,
    1156.2113698071105, 1083.3967272973507, 1003.1639247293032,
    915.87374034997606, 821.21428953705959, 719.50201858955177,
    611.34479158190356, 496.85120408042735, 377.82434543954679,
    254.29195544894662, 126.26875983948399, 0.0, -126.26875983948399,
    -254.29195544894662, -377.82434543954548, -496.85120408042735,
    -611.3447915819047, -719.50201858955177, -821.21428953705959,
    -915.87374034997606, -1003.1639247293032, -1083.3967272973516,
    -1156.2113698071105, -1222.3313236533156, -1281.6726904416009,
    -1334.8848614545811, -1382.3015464361483, -1424.2814135306805,
    -1461.4720693263403, -1494.024074655051, -1522.6156134715623,
    -1547.4196476502352, -1568.9287207204677, -1587.4630422610264,
    -1603.2424222659404, -1616.7053602631106, -1627.912788733393,
    -1637.2861973195843, -1644.877643562201, -1650.9498621838259,
    -1655.7082320511345, -1659.1570291818932, -1661.6800099517029,
    -1663.0125920757926, -1663.7200267461942, -1663.4879737636652,
    -1662.7988015163376, -1661.3957701818138, -1659.4873015859662,
    -1657.0805748288376, -1654.3148037891042, -1651.1543040915797,
    -1647.7057879022302, -1643.9753482604026, -1640.0031957940926,
    -1635.8300080256511, -1631.4635322590775, -1626.9508840039443,
    -1622.2963676256363, -1617.5344916365841, -1612.6772509400637,
    -1607.7420738236128, -1602.7430524664444, -1597.684495486249,
    -1592.5911755503757, -1587.4663789282563, -1582.3224491186,
    -1577.1656093332795, -1572.0023348766533, -1566.8414091723346,
    -1561.6854540810621, -1556.5459691200222, -1551.4229200943687,
    -1546.3158371297686, -1541.2326308010563, -1536.1792267501462,
    -1531.1586473184068, -1526.1716350294853, -1521.2172769104175,
    -1516.2970471096269, -1511.4145042022922, -1506.5721980890053,
    1585.8654716726373, 1590.9626360024131, 1596.102154852239,
    1601.2813441162291, 1606.4964579257739, 1611.7459445456916,
    1617.0307650001537, 1622.3501376853226, 1627.7008811892301,
    1633.0767579940725, 1638.4694411789708, 1643.8794253484866,
    1649.3067464971944, 1654.7392998701614, 1660.1743256139785,
    1665.6025780195791, 1671.0172409771119, 1676.4117637372376,
    1681.7731531434201, 1687.0979499646783, 1692.3600777090662,
    1697.5550009895408, 1702.6678859332465, 1707.6803869743542,
    1712.579877898889, 1717.3300339569239, 1721.9263242375278,
    1726.3191534674661, 1730.5003665898978, 1734.4271451602426,
    1738.057162201663, 1741.3840039885308, 1744.2953419250923,
    1746.8287385115436, 1748.8376528229621, 1750.3145279119346,
    1751.0399723828057, 1751.2842386802047, 1750.5395706060976, 1749.13685258074,
    1746.4810833493616, 1742.8507705801419, 1737.8419601935011,
    1731.4501511181065, 1723.4591550732468, 1713.5924091930453,
    1701.7951160664322, 1687.6236023852005, 1671.0137286958175,
    1651.5039165478609, 1628.8627870002476, 1602.7532773384867,
    1572.6569206895274, 1538.3916519224636, 1499.2435931901903,
    1455.0542594064721, 1405.1419594258753, 1349.1291478332644,
    1286.6645512140165, 1217.0645997969584, 1140.4176076814219,
    1055.9620260308457, 964.07762142102752, 864.43609424953661,
    757.37054588373871, 643.520833244109, 523.00126745308148, 397.70983730478611,
    267.67574257783861, 132.9144840415621, 0.0, -132.9144840415621,
    -267.67574257783861, -397.70983730478474, -523.00126745308148,
    -643.52083324411024, -757.37054588373871, -864.43609424953661,
    -964.07762142102752, -1055.9620260308457, -1140.4176076814229,
    -1217.0645997969584, -1286.6645512140165, -1349.1291478332644,
    -1405.1419594258753, -1455.0542594064721, -1499.2435931901903,
    -1538.3916519224636, -1572.6569206895274, -1602.7532773384867,
    -1628.8627870002476, -1651.5039165478606, -1671.0137286958172,
    -1687.6236023852005, -1701.7951160664322, -1713.5924091930453,
    -1723.4591550732468, -1731.4501511181065, -1737.8419601935011,
    -1742.8507705801419, -1746.4810833493616, -1749.13685258074,
    -1750.5395706060974, -1751.2842386802047, -1751.0399723828057,
    -1750.3145279119346, -1748.8376528229621, -1746.8287385115436,
    -1744.2953419250923, -1741.3840039885308, -1738.057162201663,
    -1734.4271451602426, -1730.5003665898978, -1726.3191534674661,
    -1721.9263242375278, -1717.3300339569239, -1712.579877898889,
    -1707.6803869743542, -1702.6678859332465, -1697.5550009895408,
    -1692.3600777090662, -1687.0979499646783, -1681.7731531434201,
    -1676.4117637372376, -1671.0172409771119, -1665.6025780195791,
    -1660.1743256139787, -1654.7392998701614, -1649.3067464971944,
    -1643.8794253484866, -1638.4694411789708, -1633.0767579940725,
    -1627.7008811892304, -1622.3501376853226, -1617.0307650001539,
    -1611.7459445456916, -1606.4964579257739, -1601.2813441162291,
    -1596.102154852239, -1590.9626360024131, -1585.8654716726373,
    1665.158745256269, 1670.5107678025336, 1675.9072625948509,
    1681.3454113220403, 1686.8212808220626, 1692.3332417729762,
    1697.8823032501614, 1703.4676445695884, 1709.0859252486914,
    1714.7305958937759, 1720.3929132379192, 1726.073396615911,
    1731.7720838220541, 1737.4762648636695, 1743.1830418946774,
    1748.8827069205581, 1754.5681030259675, 1760.2323519240995,
    1765.8618108005908, 1771.4528474629119, 1776.9780815945196,
    1782.4327510390176, 1787.8012802299086, 1793.0644063230716,
    1798.2088717938334, 1803.1965356547698, 1808.022640449404,
    1812.6351111408392, 1817.0253849193925, 1821.1485024182546,
    1824.9600203117459, 1828.453204187957, 1831.5101090213468,
    1834.1701754371206, 1836.27953546411, 1837.830254307531, 1838.5919710019457,
    1838.8484506142147, 1838.0665491364023, 1836.5936952097768,
    1833.8051375168295, 1829.9933091091486, 1824.7340582031761,
    1818.0226586740116, 1809.632112826909, 1799.2720296526975,
    1786.8848718697536, 1772.0047825044603, 1754.5644151306083,
    1734.0791123752538, 1710.30592635026, 1682.8909412054109, 1651.2897667240036,
    1615.3112345185866, 1574.2057728496998, 1527.8069723767958,
    1475.3990573971689, 1416.5856052249273, 1350.9977787747171,
    1277.9178297868061, 1197.4384880654929, 1108.7601273323878,
    1012.2815024920787, 907.65789896201329, 795.23907317792555,
    675.69687490631441, 549.15133082573539, 417.59532917002537,
    281.05952970673047, 139.56020824364026, 0.0, -139.56020824364026,
    -281.05952970673047, -417.59532917002389, -549.15133082573539,
    -675.69687490631577, -795.23907317792555, -907.65789896201329,
    -1012.2815024920787, -1108.7601273323878, -1197.4384880654939,
    -1277.9178297868061, -1350.9977787747171, -1416.5856052249273,
    -1475.3990573971689, -1527.8069723767958, -1574.2057728496998,
    -1615.3112345185866, -1651.2897667240036, -1682.8909412054109,
    -1710.30592635026, -1734.0791123752538, -1754.5644151306083,
    -1772.0047825044603, -1786.8848718697536, -1799.2720296526975,
    -1809.632112826909, -1818.0226586740116, -1824.7340582031761,
    -1829.9933091091489, -1833.8051375168295, -1836.5936952097768,
    -1838.0665491364023, -1838.8484506142147, -1838.5919710019457,
    -1837.830254307531, -1836.27953546411, -1834.1701754371206,
    -1831.5101090213468, -1828.4532041879572, -1824.9600203117459,
    -1821.1485024182546, -1817.0253849193925, -1812.6351111408394,
    -1808.022640449404, -1803.1965356547698, -1798.2088717938334,
    -1793.0644063230716, -1787.8012802299086, -1782.4327510390176,
    -1776.9780815945196, -1771.4528474629121, -1765.8618108005908,
    -1760.2323519240995, -1754.5681030259675, -1748.8827069205579,
    -1743.1830418946774, -1737.4762648636695, -1731.7720838220539,
    -1726.073396615911, -1720.3929132379192, -1714.7305958937759,
    -1709.0859252486916, -1703.4676445695886, -1697.8823032501614,
    -1692.333241772976, -1686.8212808220626, -1681.3454113220403,
    -1675.9072625948509, -1670.5107678025336, -1665.158745256269,
    1744.452018839901, 1750.0588996026543, 1755.712370337463, 1761.4094785278519,
    1767.1461037183515, 1772.9205390002608, 1778.7338415001691,
    1784.5851514538547, 1790.4709693081531, 1796.3844337934797,
    1802.316385296868, 1808.2673678833353, 1814.2374211469139,
    1820.2132298571776, 1826.1917581753764, 1832.1628358215371,
    1838.1189650748231, 1844.0529401109616, 1849.9504684577621,
    1855.807744961146, 1861.596085479973, 1867.3105010884951, 1872.9346745265714,
    1878.4484256717894, 1883.837865688778, 1889.0630373526162,
    1894.1189566612802, 1898.9510688142125, 1903.5504032488875,
    1907.8698596762667, 1911.8628784218292, 1915.5224043873839,
    1918.7248761176015, 1921.5116123626979, 1923.7214181052582,
    1925.3459807031279, 1926.1439696210864, 1926.4126625482252,
    1925.5935276667074, 1924.0505378388141, 1921.1291916842977,
    1917.1358476381558, 1911.6261562128514, 1904.5951662299174,
    1895.8050705805715, 1884.9516501123499, 1871.9746276730755,
    1856.3859626237204, 1838.1151015653991, 1816.6543082026469,
    1791.7490657002725, 1763.0286050723353, 1729.92261275848, 1692.23081711471,
    1649.1679525092095, 1600.5596853471195, 1545.6561553684626,
    1484.0420626165908, 1415.3310063354181, 1338.7710597766545,
    1254.4593684495642, 1161.5582286339302, 1060.4853835631302,
    950.8797036744902, 833.10760047211261, 707.87291656851994,
    575.30139419838952, 437.48082103526468, 294.44331683562245,
    146.20593244571842, 0.0, -146.20593244571842, -294.44331683562245,
    -437.48082103526315, -575.30139419838952, -707.87291656852142,
    -833.10760047211261, -950.8797036744902, -1060.4853835631302,
    -1161.5582286339302, -1254.4593684495651, -1338.7710597766545,
    -1415.3310063354181, -1484.0420626165908, -1545.6561553684626,
    -1600.5596853471195, -1649.1679525092095, -1692.23081711471,
    -1729.92261275848, -1763.0286050723353, -1791.7490657002725,
    -1816.6543082026469, -1838.1151015653991, -1856.3859626237204,
    -1871.9746276730755, -1884.9516501123499, -1895.8050705805715,
    -1904.5951662299171, -1911.6261562128514, -1917.1358476381561,
    -1921.1291916842977, -1924.0505378388141, -1925.5935276667074,
    -1926.4126625482252, -1926.1439696210864, -1925.3459807031279,
    -1923.7214181052582, -1921.5116123626979, -1918.7248761176015,
    -1915.5224043873839, -1911.8628784218292, -1907.8698596762667,
    -1903.5504032488875, -1898.9510688142125, -1894.1189566612802,
    -1889.0630373526162, -1883.837865688778, -1878.4484256717894,
    -1872.9346745265714, -1867.3105010884951, -1861.596085479973,
    -1855.8077449611462, -1849.9504684577621, -1844.0529401109616,
    -1838.1189650748231, -1832.1628358215371, -1826.1917581753764,
    -1820.2132298571776, -1814.2374211469137, -1808.2673678833353,
    -1802.3163852968678, -1796.3844337934797, -1790.4709693081531,
    -1784.5851514538547, -1778.7338415001691, -1772.9205390002605,
    -1767.1461037183515, -1761.4094785278519, -1755.712370337463,
    -1750.0588996026543, -1744.452018839901, 1823.7452924235326,
    1829.6070314027747, 1835.5174780800746, 1841.4735457336633,
    1847.4709266146401, 1853.5078362275453, 1859.5853797501768,
    1865.7026583381207, 1871.8560133676147, 1878.0382716931833,
    1884.2398573558164, 1890.4613391507596, 1896.7027584717734,
    1902.9501948506854, 1909.2004744560752, 1915.4429647225159,
    1921.6698271236787, 1927.8735282978232, 1934.039126114933,
    1940.1626424593799, 1946.2140893654262, 1952.1882511379717,
    1958.0680688232335, 1963.8324450205071, 1969.4668595837222,
    1974.9295390504624, 1980.2152728731567, 1985.2670264875858,
    1990.075421578382, 1994.5912169342787, 1998.7657365319124,
    2002.5916045868103, 2005.939643213856, 2008.8530492882749,
    2011.1633007464061, 2012.8617070987248, 2013.6959682402264,
    2013.9768744822354, 2013.1205061970122, 2011.5073804678509,
    2008.4532458517656, 2004.2783861671628, 1998.5182542225261,
    1991.1676737858224, 1981.9780283342338, 1970.6312705720022,
    1957.0643834763971, 1940.7671427429802, 1921.6657880001899,
    1899.2295040300398, 1873.1922050502847, 1843.1662689392595,
    1808.5554587929564, 1769.150399710833, 1724.1301321687188,
    1673.3123983174428, 1615.9132533397562, 1551.4985200082538,
    1479.6642338961187, 1399.6242897665022, 1311.4802488336352,
    1214.3563299354723, 1108.6892646341817, 994.10150838696688,
    870.97612776629944, 740.04895823072536, 601.45145757104353,
    457.36631290050394, 307.82710396451432, 152.85165664779652, 0.0,
    -152.85165664779652, -307.82710396451432, -457.36631290050235,
    -601.45145757104353, -740.04895823072684, -870.97612776629944,
    -994.10150838696688, -1108.6892646341817, -1214.3563299354723,
    -1311.4802488336361, -1399.6242897665022, -1479.6642338961187,
    -1551.4985200082538, -1615.9132533397562, -1673.3123983174428,
    -1724.1301321687188, -1769.150399710833, -1808.5554587929564,
    -1843.1662689392595, -1873.1922050502847, -1899.2295040300396,
    -1921.6657880001897, -1940.7671427429802, -1957.0643834763971,
    -1970.6312705720022, -1981.9780283342336, -1991.1676737858224,
    -1998.5182542225261, -2004.2783861671628, -2008.4532458517656,
    -2011.5073804678509, -2013.1205061970122, -2013.9768744822354,
    -2013.6959682402264, -2012.8617070987248, -2011.1633007464061,
    -2008.8530492882749, -2005.939643213856, -2002.5916045868103,
    -1998.7657365319124, -1994.5912169342787, -1990.075421578382,
    -1985.2670264875858, -1980.2152728731567, -1974.9295390504624,
    -1969.4668595837222, -1963.8324450205071, -1958.0680688232335,
    -1952.1882511379717, -1946.2140893654262, -1940.1626424593799,
    -1934.039126114933, -1927.8735282978232, -1921.6698271236785,
    -1915.4429647225159, -1909.2004744560752, -1902.9501948506856,
    -1896.7027584717732, -1890.4613391507596, -1884.2398573558164,
    -1878.0382716931833, -1871.8560133676147, -1865.702658338121,
    -1859.5853797501768, -1853.5078362275451, -1847.4709266146401,
    -1841.4735457336633, -1835.5174780800746, -1829.6070314027747,
    -1823.7452924235326, 1903.0385660071647, 1909.1551632028957,
    1915.322585822687, 1921.5376129394747, 1927.7957495109288,
    1934.0951334548301, 1940.4369180001847, 1946.820165222387,
    1953.2410574270762, 1959.6921095928869, 1966.163329414765,
    1972.6553104181842, 1979.1680957966335, 1985.6871598441937,
    1992.2091907367742, 1998.7230936234951, 2005.2206891725345,
    2011.6941164846853, 2018.1277837721041, 2024.517539957614,
    2030.8320932508798, 2037.066001187449, 2043.2014631198961,
    2049.2164643692249, 2055.0958534786669, 2060.7960407483083,
    2066.3115890850331, 2071.5829841609589, 2076.6004399078774,
    2081.3125741922913, 2085.6685946419957, 2089.6608047862369,
    2093.1544103101105, 2096.1944862138521, 2098.6051833875545,
    2100.3774334943214, 2101.2479668593669, 2101.5410864162454,
    2100.6474847273171, 2098.964223096888, 2095.7773000192337, 2091.42092469617,
    2085.4103522322011, 2077.7401813417277, 2068.1509860878964,
    2056.3108910316546, 2042.1541392797185, 2025.1483228622405,
    2005.2164744349809, 1981.804699857433, 1954.6353444002973,
    1923.3039328061841, 1887.1883048274328, 1846.0699823069563,
    1799.0923118282285, 1746.0651112877667, 1686.1703513110504,
    1618.9549773999172, 1543.9974614568196, 1460.4775197563501,
    1368.5011292177064, 1267.1544312370147, 1156.8931457052331,
    1037.3233130994438, 908.8446550604865, 772.2249998929309, 627.60152094369778,
    477.25180476574337, 321.2108910934063, 159.49738084987456, 0.0,
    -159.49738084987456, -321.2108910934063, -477.25180476574167,
    -627.60152094369778, -772.22499989293237, -908.8446550604865,
    -1037.3233130994438, -1156.8931457052331, -1267.1544312370147,
    -1368.5011292177073, -1460.4775197563501, -1543.9974614568196,
    -1618.9549773999172, -1686.1703513110504, -1746.0651112877667,
    -1799.0923118282285, -1846.0699823069563, -1887.1883048274328,
    -1923.3039328061841, -1954.6353444002973, -1981.804699857433,
    -2005.2164744349809, -2025.1483228622405, -2042.1541392797185,
    -2056.3108910316546, -2068.1509860878964, -2077.7401813417277,
    -2085.4103522322011, -2091.42092469617, -2095.7773000192337,
    -2098.964223096888, -2100.6474847273171, -2101.5410864162454,
    -2101.2479668593669, -2100.3774334943214, -2098.6051833875545,
    -2096.1944862138521, -2093.154410310111, -2089.6608047862369,
    -2085.6685946419957, -2081.3125741922913, -2076.6004399078774,
    -2071.5829841609593, -2066.3115890850331, -2060.7960407483083,
    -2055.0958534786669, -2049.2164643692249, -2043.2014631198961,
    -2037.066001187449, -2030.8320932508796, -2024.517539957614,
    -2018.1277837721041, -2011.6941164846853, -2005.2206891725343,
    -1998.7230936234948, -1992.2091907367744, -1985.687159844194,
    -1979.1680957966332, -1972.6553104181842, -1966.163329414765,
    -1959.6921095928872, -1953.2410574270764, -1946.820165222387,
    -1940.4369180001847, -1934.09513345483, -1927.7957495109288,
    -1921.5376129394747, -1915.322585822687, -1909.1551632028957,
    -1903.0385660071647, 1982.3318395907966, 1988.7032950030161,
    1995.1276935652986, 2001.6016801452861, 2008.1205724072172,
    2014.6824306821145, 2021.2884562501922, 2027.9376721066531,
    2034.6261014865374, 2041.3459474925903, 2048.0868014737134,
    2054.8492816856083, 2061.633433121493, 2068.4241248377016, 2075.217907017473,
    2082.0032225244736, 2088.77155122139, 2095.514704671547, 2102.2164414292752,
    2108.8724374558474, 2115.4500971363327, 2121.9437512369259,
    2128.334857416558, 2134.6004837179426, 2140.7248473736113,
    2146.6625424461545, 2152.4079052969091, 2157.8989418343322,
    2163.1254582373717, 2168.033931450303, 2172.5714527520786,
    2176.7300049856635, 2180.369177406365, 2183.5359231394291,
    2186.0470660287024, 2187.893159889918, 2188.7999654785067,
    2189.1052983502555, 2188.1744632576219, 2186.421065725925,
    2183.1013541867019, 2178.5634632251772, 2172.3024502418762,
    2164.3126888976331, 2154.3239438415585, 2141.9905114913067, 2127.24389508304,
    2109.5295029815, 2088.7671608697715, 2064.3798956848254, 2036.0784837503095,
    2003.4415966731083, 1965.8211508619092, 1922.9895649030793,
    1874.0544914877378, 1818.8178242580902, 1756.4274492823438,
    1686.4114347915804, 1608.3306890175204, 1521.3307497461981,
    1425.5220096017772, 1319.9525325385569, 1205.0970267762843,
    1080.5451178119206, 946.71318235467345, 804.40104155513632,
    653.7515843163518, 497.13729663098263, 334.59467822229817,
    166.14310505195266, 0.0, -166.14310505195266, -334.59467822229817,
    -497.13729663098087, -653.7515843163518, -804.40104155513779,
    -946.71318235467345, -1080.5451178119206, -1205.0970267762843,
    -1319.9525325385569, -1425.5220096017783, -1521.3307497461981,
    -1608.3306890175204, -1686.4114347915804, -1756.4274492823438,
    -1818.8178242580902, -1874.0544914877378, -1922.9895649030793,
    -1965.8211508619092, -2003.4415966731083, -2036.0784837503095,
    -2064.3798956848254, -2088.7671608697715, -2109.5295029815,
    -2127.24389508304, -2141.9905114913067, -2154.323943841558,
    -2164.3126888976326, -2172.3024502418762, -2178.5634632251772,
    -2183.1013541867019, -2186.421065725925, -2188.1744632576215,
    -2189.1052983502555, -2188.7999654785067, -2187.893159889918,
    -2186.0470660287024, -2183.5359231394291, -2180.369177406365,
    -2176.7300049856635, -2172.5714527520786, -2168.033931450303,
    -2163.1254582373717, -2157.8989418343322, -2152.4079052969091,
    -2146.6625424461545, -2140.7248473736113, -2134.6004837179426,
    -2128.334857416558, -2121.9437512369259, -2115.4500971363327,
    -2108.8724374558478, -2102.2164414292752, -2095.514704671547,
    -2088.77155122139, -2082.0032225244736, -2075.217907017473,
    -2068.4241248377016, -2061.633433121493, -2054.8492816856083,
    -2048.0868014737134, -2041.3459474925905, -2034.6261014865377,
    -2027.9376721066531, -2021.2884562501922, -2014.6824306821143,
    -2008.1205724072172, -2001.6016801452861, -1995.1276935652986,
    -1988.7032950030161, -1982.3318395907966, 2061.6251131744284,
    2068.2514268031368, 2074.9328013079103, 2081.6657473510977,
    2088.4453953035063, 2095.2697279093991, 2102.1399945002, 2109.0551789909196,
    2116.0111455459992, 2122.9997853922941, 2130.0102735326623,
    2137.0432529530326, 2144.0987704463528, 2151.16108983121, 2158.2266232981719,
    2165.283351425453, 2172.3224132702458, 2179.335292858409, 2186.3050990864463,
    2193.2273349540819, 2200.0681010217863, 2206.821501286403,
    2213.4682517132205, 2219.9845030666606, 2226.3538412685557,
    2232.5290441440011, 2238.504221508786, 2244.2148995077059,
    2249.6504765668669, 2254.7552887083152, 2259.4743108621619, 2263.79920518509,
    2267.58394450262, 2270.8773600650065, 2273.4889486698507, 2275.4088862855147,
    2276.3519640976474, 2276.6695102842659, 2275.7014417879268,
    2273.8779083549621, 2270.42540835417, 2265.7060017541844, 2259.1945482515512,
    2250.8851964535388, 2240.4969015952211, 2227.6701319509589,
    2212.3336508863617, 2193.9106831007603, 2172.3178473045623,
    2146.955091512219, 2117.5216231003219, 2083.5792605400325,
    2044.4539968963854, 1999.9091474992026, 1949.0166711472475,
    1891.5705372284137, 1826.6845472536377, 1753.8678921832436,
    1672.6639165782215, 1582.1839797360462, 1482.5428899858487,
    1372.7506338400995, 1253.3009078473358, 1123.7669225243976,
    984.5817096488604, 836.57708321734174, 679.90164768900581,
    517.02278849622189, 347.9784653511901, 172.78882925403082, 0.0,
    -172.78882925403082, -347.9784653511901, -517.02278849622007,
    -679.90164768900581, -836.57708321734333, -984.5817096488604,
    -1123.7669225243976, -1253.3009078473358, -1372.7506338400995,
    -1482.5428899858498, -1582.1839797360462, -1672.6639165782215,
    -1753.8678921832436, -1826.6845472536377, -1891.5705372284137,
    -1949.0166711472475, -1999.9091474992026, -2044.4539968963854,
    -2083.5792605400325, -2117.5216231003219, -2146.955091512219,
    -2172.3178473045623, -2193.9106831007603, -2212.3336508863617,
    -2227.6701319509589, -2240.4969015952211, -2250.8851964535384,
    -2259.1945482515512, -2265.7060017541844, -2270.42540835417,
    -2273.8779083549621, -2275.7014417879268, -2276.6695102842659,
    -2276.3519640976474, -2275.4088862855147, -2273.4889486698507,
    -2270.8773600650065, -2267.58394450262, -2263.79920518509,
    -2259.4743108621619, -2254.7552887083152, -2249.6504765668669,
    -2244.2148995077059, -2238.504221508786, -2232.5290441440011,
    -2226.3538412685557, -2219.9845030666606, -2213.4682517132205,
    -2206.821501286403, -2200.0681010217863, -2193.2273349540819,
    -2186.3050990864463, -2179.335292858409, -2172.3224132702458,
    -2165.283351425453, -2158.2266232981724, -2151.16108983121,
    -2144.0987704463528, -2137.0432529530326, -2130.0102735326618,
    -2122.9997853922941, -2116.0111455459992, -2109.0551789909196,
    -2102.1399945002, -2095.2697279093991, -2088.4453953035063,
    -2081.6657473510977, -2074.9328013079103, -2068.2514268031368,
    -2061.6251131744284, 2140.91838675806, 2147.7995586032575,
    2154.7379090505228, 2161.7298145569089, 2168.7702181997947,
    2175.8570251366837, 2182.9915327502076, 2190.1726858751849, 2197.39618960546,
    2204.6536232919975, 2211.93374559161, 2219.2372242204565, 2226.5641077712125,
    2233.8980548247177, 2241.2353395788709, 2248.563480326432,
    2255.8732753191011, 2263.1558810452707, 2270.3937567436169,
    2277.5822324523156, 2284.6861049072395, 2291.69925133588, 2298.6016460098826,
    2305.3685224153778, 2311.9828351635, 2318.3955458418473, 2324.6005377206625,
    2330.5308571810788, 2336.1754948963617, 2341.4766459663269,
    2346.3771689722448, 2350.8684053845163, 2354.7987115988744,
    2358.2187969905835, 2360.9308313109987, 2362.9246126811117,
    2363.9039627167876, 2364.2337222182759, 2363.2284203182317,
    2361.3347509839987, 2357.7494625216377, 2352.8485402831911,
    2346.0866462612262, 2337.4577040094437, 2326.6698593488832,
    2313.349752410611, 2297.4234066896834, 2278.2918632200203,
    2255.8685337393531, 2229.5302873396117, 2198.9647624503341,
    2163.7169244069569, 2123.0868429308616, 2076.8287300953257,
    2023.9788508067568, 1964.3232501987375, 1896.9416452249316,
    1821.3243495749068, 1736.9971441389221, 1643.0372097258939,
    1539.5637703699194, 1425.5487351416416, 1301.504788918387,
    1166.9887272368744, 1022.4502369430472, 868.75312487954716,
    706.05171106165983, 536.90828036146127, 361.362252480082, 179.43455345610886,
    0.0, -179.43455345610886, -361.362252480082, -536.90828036145933,
    -706.05171106165983, -868.75312487954886, -1022.4502369430472,
    -1166.9887272368744, -1301.504788918387, -1425.5487351416416,
    -1539.5637703699208, -1643.0372097258939, -1736.9971441389221,
    -1821.3243495749068, -1896.9416452249316, -1964.3232501987375,
    -2023.9788508067568, -2076.8287300953257, -2123.0868429308616,
    -2163.7169244069569, -2198.9647624503341, -2229.5302873396117,
    -2255.8685337393531, -2278.2918632200203, -2297.4234066896834,
    -2313.349752410611, -2326.6698593488832, -2337.4577040094437,
    -2346.0866462612262, -2352.8485402831911, -2357.7494625216377,
    -2361.3347509839987, -2363.2284203182317, -2364.2337222182759,
    -2363.9039627167876, -2362.9246126811117, -2360.9308313109987,
    -2358.2187969905835, -2354.7987115988744, -2350.8684053845163,
    -2346.3771689722448, -2341.4766459663269, -2336.1754948963617,
    -2330.5308571810792, -2324.6005377206625, -2318.3955458418473,
    -2311.9828351635, -2305.3685224153778, -2298.6016460098826,
    -2291.69925133588, -2284.6861049072395, -2277.5822324523156,
    -2270.3937567436169, -2263.1558810452707, -2255.8732753191011,
    -2248.5634803264315, -2241.2353395788709, -2233.8980548247182,
    -2226.5641077712121, -2219.2372242204565, -2211.93374559161,
    -2204.6536232919975, -2197.3961896054607, -2190.1726858751854,
    -2182.9915327502076, -2175.8570251366837, -2168.7702181997947,
    -2161.7298145569089, -2154.7379090505228, -2147.7995586032575,
    -2140.91838675806, 2220.2116603416921, 2227.3476904033782,
    2234.5430167931345, 2241.7938817627205, 2249.0950410960836,
    2256.4443223639682, 2263.8430710002153, 2271.2901927594512,
    2278.7812336649222, 2286.3074611917013, 2293.8572176505591,
    2301.4311954878813, 2309.0294450960719, 2316.6350198182258, 2324.24405585957,
    2331.843609227411, 2339.424137367957, 2346.9764692321328, 2354.4824144007885,
    2361.9371299505497, 2369.3041087926927, 2376.5770013853571,
    2383.7350403065452, 2390.7525417640959, 2397.6118290584445,
    2404.2620475396934, 2410.6968539325385, 2416.8468148544521,
    2422.7005132258564, 2428.1980032243391, 2433.2800270823282,
    2437.9376055839434, 2442.0134786951294, 2445.5602339161605,
    2448.3727139521466, 2450.4403390767084, 2451.4559613359279,
    2451.7979341522869, 2450.755398848537, 2448.7915936130362,
    2445.0735166891063, 2439.9910788121983, 2432.9787442709016,
    2424.030211565349, 2412.8428171025457, 2399.0293728702636,
    2382.5131624930054, 2362.6730433392804, 2339.4192201741444,
    2312.1054831670049, 2280.4079018003467, 2243.8545882738813,
    2201.7196889653383, 2153.748312691449, 2098.9410304662661, 2037.075963169061,
    1967.1987431962252, 1888.78080696657, 1801.3303716996229, 1703.8904397157419,
    1596.5846507539907, 1478.3468364431837, 1349.7086699894385,
    1210.2105319493512, 1060.3187642372343, 900.92916654175269,
    732.20177443431407, 556.79377222670053, 374.746039608974, 186.08027765818693,
    0.0, -186.08027765818693, -374.746039608974, -556.79377222669859,
    -732.20177443431407, -900.92916654175451, -1060.3187642372343,
    -1210.2105319493512, -1349.7086699894385, -1478.3468364431837,
    -1596.5846507539918, -1703.8904397157419, -1801.3303716996229,
    -1888.78080696657, -1967.1987431962252, -2037.075963169061,
    -2098.9410304662661, -2153.748312691449, -2201.7196889653383,
    -2243.8545882738813, -2280.4079018003467, -2312.1054831670049,
    -2339.4192201741439, -2362.6730433392804, -2382.5131624930054,
    -2399.0293728702636, -2412.8428171025453, -2424.030211565349,
    -2432.9787442709016, -2439.9910788121988, -2445.0735166891063,
    -2448.7915936130362, -2450.755398848537, -2451.7979341522869,
    -2451.4559613359279, -2450.4403390767084, -2448.3727139521466,
    -2445.5602339161605, -2442.0134786951294, -2437.9376055839434,
    -2433.2800270823282, -2428.1980032243396, -2422.7005132258564,
    -2416.8468148544525, -2410.6968539325385, -2404.2620475396934,
    -2397.6118290584445, -2390.7525417640959, -2383.7350403065452,
    -2376.5770013853571, -2369.3041087926927, -2361.9371299505497,
    -2354.4824144007885, -2346.9764692321328, -2339.424137367957,
    -2331.8436092274105, -2324.24405585957, -2316.6350198182258,
    -2309.0294450960719, -2301.4311954878813, -2293.8572176505591,
    -2286.3074611917013, -2278.7812336649222, -2271.2901927594512,
    -2263.8430710002153, -2256.4443223639682, -2249.0950410960836,
    -2241.7938817627205, -2234.5430167931345, -2227.3476904033782,
    -2220.2116603416921, 2297.0210403700389, 2304.40067892282,
    2311.8413765538376, 2319.3394662358264, 2326.8894712118208,
    2334.4891635954909, 2342.1396193021742, 2349.8396752686767,
    2357.5845716605468, 2365.3655119465175, 2373.1707896501716,
    2381.0006681317518, 2388.8550700179435, 2396.7164744408874,
    2404.5809237538683, 2412.4352678604155, 2420.2694008833596,
    2428.073641888328, 2435.8290812601858, 2443.5306665145358,
    2451.1410794094145, 2458.653639248384, 2466.0464315499039,
    2473.2928565650936, 2480.3745131127025, 2487.2390154960108,
    2493.8799361098522, 2500.2250400994162, 2506.2625573142204,
    2511.9303229434718, 2517.1667449560823, 2521.9626060867249,
    2526.1551285515447, 2529.7996480508332, 2532.6828871728617,
    2534.7929581644776, 2535.8027949826956, 2536.1381900298079,
    2535.0274179899661, 2532.9521986597497, 2529.0690165937194,
    2523.7702349753467, 2516.4739832354635, 2507.1718721987236,
    2495.551633037961, 2481.2130451125427, 2464.0761118104365,
    2443.4991113749907, 2419.3890122198191, 2391.0782235896604,
    2358.2316454319184, 2320.3617539572397, 2276.7186510752404,
    2227.0395560349443, 2170.2926006977118, 2106.24844301205, 2033.922240012462,
    1952.7695831752517, 1862.2831568349848, 1761.4755825608452,
    1650.4767547017527, 1528.1876544600491, 1395.1589236742373,
    1250.9176333671005, 1095.946469481579, 931.17203631230586,
    756.76143843766044, 575.45675360269615, 387.30069002800514,
    192.31515635295852, 0.0, -192.31515635295852, -387.30069002800514,
    -575.45675360269422, -756.76143843766044, -931.17203631230768,
    -1095.946469481579, -1250.9176333671005, -1395.1589236742373,
    -1528.1876544600491, -1650.4767547017539, -1761.4755825608452,
    -1862.2831568349848, -1952.7695831752517, -2033.922240012462,
    -2106.24844301205, -2170.2926006977118, -2227.0395560349443,
    -2276.7186510752404, -2320.3617539572397, -2358.2316454319184,
    -2391.0782235896604, -2419.3890122198186, -2443.4991113749907,
    -2464.0761118104365, -2481.2130451125427, -2495.551633037961,
    -2507.1718721987236, -2516.4739832354635, -2523.7702349753467,
    -2529.0690165937194, -2532.9521986597497, -2535.0274179899661,
    -2536.1381900298079, -2535.8027949826956, -2534.7929581644776,
    -2532.6828871728617, -2529.7996480508332, -2526.1551285515447,
    -2521.9626060867249, -2517.1667449560823, -2511.9303229434718,
    -2506.2625573142204, -2500.2250400994162, -2493.8799361098522,
    -2487.2390154960108, -2480.3745131127025, -2473.2928565650936,
    -2466.0464315499039, -2458.653639248384, -2451.1410794094145,
    -2443.5306665145358, -2435.8290812601858, -2428.073641888328,
    -2420.2694008833596, -2412.4352678604155, -2404.5809237538683,
    -2396.7164744408874, -2388.855070017943, -2381.0006681317518,
    -2373.1707896501716, -2365.3655119465175, -2357.5845716605472,
    -2349.8396752686767, -2342.1396193021747, -2334.4891635954909,
    -2326.8894712118208, -2319.3394662358264, -2311.8413765538376,
    -2304.40067892282, -2297.0210403700389, 2373.2321777688976,
    2380.8527153174182, 2388.535989220095, 2396.2784773150524,
    2404.0744594145317, 2411.9216575117866, 2419.8208014908068,
    2427.7706523493439, 2435.7661089893213, 2443.7983706366754,
    2451.8557705243156, 2459.9380335765627, 2468.0449235455676,
    2476.1583527207563, 2484.2742803334968, 2492.3794118349829,
    2500.4630243882984, 2508.5148833754706, 2516.5153430496953,
    2524.4591327849294, 2532.3082416854186, 2540.0556328039775,
    2547.6781469547395, 2555.1482686562204, 2562.4468501121319,
    2569.5200428400794, 2576.3613697596693, 2582.8957162208408,
    2589.1109729923851, 2594.9427373977487, 2600.3270287589507,
    2605.2544170142505, 2609.5566227834943, 2613.291953976795,
    2616.2388582630706, 2618.3837896097907, 2619.3775611114575,
    2619.7019565588812, 2618.5154155651494, 2616.3189694722655,
    2612.2628412387176, 2606.7393343534391, 2599.1510919347834,
    2589.487219067365, 2577.426116038765, 2562.5547222853297, 2544.7896352756575,
    2523.4689344285603, 2498.49635091915, 2469.1833169758347, 2435.18366211124,
    2395.9945191845813, 2350.842396271215, 2299.456919046484, 2240.7745596321347,
    2174.5586283985353, 2099.7946732973214, 2015.9231725763896,
    1922.421767230227, 1818.2736100209579, 1703.6152975127416,
    1577.3162138378357, 1439.9459701077988, 1291.0190715978445,
    1131.034475534891, 960.94930454371774, 780.93805669331664,
    593.82529523488722, 399.65564396077247, 198.451084083629, 0.0,
    -198.451084083629, -399.65564396077247, -593.82529523488517,
    -780.93805669331664, -960.94930454371968, -1131.034475534891,
    -1291.0190715978445, -1439.9459701077988, -1577.3162138378357,
    -1703.6152975127429, -1818.2736100209579, -1922.421767230227,
    -2015.9231725763896, -2099.7946732973214, -2174.5586283985353,
    -2240.7745596321347, -2299.456919046484, -2350.842396271215,
    -2395.9945191845813, -2435.18366211124, -2469.1833169758343,
    -2498.4963509191493, -2523.4689344285603, -2544.7896352756575,
    -2562.5547222853297, -2577.426116038765, -2589.487219067365,
    -2599.1510919347834, -2606.7393343534391, -2612.2628412387176,
    -2616.3189694722655, -2618.5154155651494, -2619.7019565588812,
    -2619.3775611114575, -2618.3837896097907, -2616.2388582630706,
    -2613.291953976795, -2609.5566227834943, -2605.2544170142505,
    -2600.3270287589507, -2594.9427373977487, -2589.1109729923851,
    -2582.8957162208408, -2576.3613697596693, -2569.5200428400794,
    -2562.4468501121319, -2555.1482686562204, -2547.6781469547395,
    -2540.0556328039775, -2532.3082416854186, -2524.45913278493,
    -2516.5153430496953, -2508.5148833754706, -2500.4630243882984,
    -2492.3794118349824, -2484.2742803334968, -2476.1583527207563,
    -2468.0449235455676, -2459.9380335765627, -2451.8557705243152,
    -2443.7983706366754, -2435.7661089893218, -2427.7706523493439,
    -2419.8208014908068, -2411.9216575117866, -2404.0744594145317,
    -2396.2784773150524, -2388.535989220095, -2380.8527153174182,
    -2373.2321777688976, 2449.4433151727503, 2457.3047517036866,
    2465.2306018861964, 2473.2174883946432, 2481.2594476184954,
    2489.3541514374242, 2497.5019836771612, 2505.7016294379555,
    2513.9476463049932, 2522.2312293267241, 2530.5407514154376,
    2538.8753990101959, 2547.2347770867755, 2555.6002309859391,
    2563.967636917288, 2572.3235558294177, 2580.6566478817931,
    2588.9561248945729, 2597.2016047989268, 2605.3875990650754,
    2613.475403981211, 2621.4576263949216, 2629.3098624030458,
    2637.0036806953758, 2644.519187173054, 2651.8010701334679,
    2658.8428036345463, 2665.56639237544, 2671.9593888790773, 2677.9551525320535,
    2683.4873120562734, 2688.5462300967611, 2692.9581178681651,
    2696.7842703996935, 2699.7949011587807, 2701.97466720073, 2702.9522111970482,
    2703.2657196241194, 2702.0033469073246, 2699.6857984727726,
    2695.456668393309, 2689.708443195545, 2681.8281995963334, 2671.8025673140182,
    2659.3006002971183, 2643.8963991099117, 2625.5031597898419,
    2603.4387567646231, 2577.6036901768121, 2547.2884101715945,
    2512.1356787372947, 2471.6272848738745, 2424.9661409150758,
    2371.8742826696785, 2311.256517997776, 2242.8688139690039,
    2165.6671064371681, 2079.0767618130722, 1982.5603781918035,
    1875.0716367603513, 1756.7538410590628, 1626.4447725225898,
    1484.7330169829029, 1331.1205097620987, 1166.1224815649409,
    990.72657325773889, 805.11467488532344, 612.193837240026, 412.01059794022132,
    204.58701248236596, 0.0, -204.58701248236596, -412.01059794022132,
    -612.193837240024, -805.11467488532344, -990.72657325774071,
    -1166.1224815649409, -1331.1205097620987, -1484.7330169829029,
    -1626.4447725225898, -1756.7538410590641, -1875.0716367603513,
    -1982.5603781918035, -2079.0767618130722, -2165.6671064371681,
    -2242.8688139690039, -2311.256517997776, -2371.8742826696785,
    -2424.9661409150758, -2471.6272848738745, -2512.1356787372947,
    -2547.2884101715945, -2577.6036901768121, -2603.4387567646231,
    -2625.5031597898419, -2643.8963991099117, -2659.3006002971179,
    -2671.8025673140182, -2681.8281995963334, -2689.7084431955454,
    -2695.4566683933094, -2699.6857984727726, -2702.0033469073246,
    -2703.2657196241194, -2702.9522111970482, -2701.97466720073,
    -2699.7949011587807, -2696.7842703996935, -2692.9581178681651,
    -2688.5462300967611, -2683.4873120562734, -2677.9551525320535,
    -2671.9593888790778, -2665.56639237544, -2658.8428036345463,
    -2651.8010701334679, -2644.519187173054, -2637.0036806953758,
    -2629.3098624030458, -2621.4576263949216, -2613.475403981211,
    -2605.3875990650754, -2597.2016047989268, -2588.9561248945729,
    -2580.6566478817931, -2572.3235558294173, -2563.9676369172885,
    -2555.6002309859391, -2547.2347770867755, -2538.8753990101959,
    -2530.5407514154376, -2522.2312293267241, -2513.9476463049932,
    -2505.7016294379555, -2497.5019836771612, -2489.3541514374238,
    -2481.2594476184954, -2473.2174883946432, -2465.2306018861964,
    -2457.3047517036866, -2449.4433151727503, 2525.6544525811514,
    2533.756788082369, 2541.925214552155, 2550.1564994745659, 2558.4444358236005,
    2566.7866453715742, 2575.1831658614433, 2583.632606533808,
    2592.1291836087225, 2600.6640880166742, 2609.2257323220419,
    2617.8127644336369, 2626.4246306403766, 2635.0421092377269, 2643.66099350488,
    2652.2676998419947, 2660.8502713648418, 2669.3973664428827,
    2677.8878665113707, 2686.3160653541418, 2694.6425662951169,
    2702.8596200181987, 2710.9415778912112, 2718.859092686956,
    2726.5915242904089, 2734.0820973805012, 2741.3242377160186,
    2748.2370685611022, 2754.8078049575656, 2760.9675682952088,
    2766.6475948877173, 2771.83804518144, 2776.3596137785689, 2780.276596669793,
    2783.3510143332155, 2785.5655896776225, 2786.526748427937,
    2786.8294796837436, 2785.4912207782672, 2783.0526778933445,
    2778.6504975233406, 2772.6775604129957, 2764.5053063283967,
    2754.1179167848004, 2741.1750856852632, 2725.2380756177308,
    2706.2166852486157, 2683.4085784522736, 2656.7110299377587,
    2625.393503195121, 2589.0876953142238, 2547.260050981452, 2499.0898850579238,
    2444.2916468471576, 2381.7384758470407, 2311.1789997058477,
    2231.5395394452707, 2142.2303508995706, 2042.6989896682608,
    1931.8696628435143, 1809.8923852742803, 1675.5733305760416,
    1529.5200642597392, 1371.2219478657548, 1201.2104875734096,
    1020.5038424118418, 829.29129301913417, 630.56237958541362,
    424.36555196225885, 210.72294149059505, 0.0, -210.72294149059505,
    -424.36555196225885, -630.56237958541146, -829.29129301913417,
    -1020.5038424118438, -1201.2104875734096, -1371.2219478657548,
    -1529.5200642597392, -1675.5733305760416, -1809.8923852742819,
    -1931.8696628435143, -2042.6989896682608, -2142.2303508995706,
    -2231.5395394452707, -2311.1789997058477, -2381.7384758470407,
    -2444.2916468471576, -2499.0898850579238, -2547.260050981452,
    -2589.0876953142238, -2625.393503195121, -2656.7110299377587,
    -2683.4085784522736, -2706.2166852486157, -2725.2380756177308,
    -2741.1750856852627, -2754.1179167848, -2764.5053063283967,
    -2772.6775604129957, -2778.6504975233406, -2783.0526778933445,
    -2785.4912207782672, -2786.8294796837436, -2786.526748427937,
    -2785.5655896776225, -2783.3510143332155, -2780.276596669793,
    -2776.3596137785689, -2771.83804518144, -2766.6475948877173,
    -2760.9675682952088, -2754.8078049575656, -2748.2370685611022,
    -2741.3242377160186, -2734.0820973805012, -2726.5915242904089,
    -2718.859092686956, -2710.9415778912112, -2702.8596200181987,
    -2694.6425662951169, -2686.3160653541418, -2677.8878665113707,
    -2669.3973664428827, -2660.8502713648418, -2652.2676998419943,
    -2643.66099350488, -2635.0421092377269, -2626.4246306403766,
    -2617.8127644336369, -2609.2257323220415, -2600.6640880166742,
    -2592.129183608723, -2583.632606533808, -2575.1831658614433,
    -2566.7866453715742, -2558.4444358236005, -2550.1564994745659,
    -2541.925214552155, -2533.756788082369, -2525.6544525811514,
    2601.8655899937071, 2610.2088244541233, 2618.6198272179836,
    2627.0955105547932, 2635.62942402975, 2644.2191393135031, 2652.8643480438336,
    2661.56358363628, 2670.3107209015384, 2679.0969467065343, 2687.9107132428039,
    2696.7501298477609, 2705.6144842053163, 2714.4839874772633,
    2723.354350095949, 2732.2118438711814, 2741.043894838328, 2749.8386080179512,
    2758.5741281901214, 2767.2445316513881, 2775.8097286256452,
    2784.2616136711235, 2792.5732934160123, 2800.7145046348769,
    2808.6638614596782, 2816.363124585027, 2823.805671987589, 2830.9077447758787,
    2837.65622121286, 2843.9799846410374, 2849.8078772889085, 2855.1298621295618,
    2859.7611104874909, 2863.768932189816, 2866.907196278944, 2869.1565558258603,
    2870.101175876845, 2870.3932371185656, 2868.9790444595938, 2866.419601288098,
    2861.844328212977, 2855.6466850776947, 2847.1824122247094,
    2836.4332673478098, 2823.0495720921813, 2806.5797518365962,
    2786.9302115610067, 2763.3783995520121, 2735.8183701539447,
    2703.4985960623508, 2666.0397118457686, 2622.8928174689818,
    2573.2136287447456, 2516.70901152851, 2452.220433226089, 2379.4891855936326,
    2297.4119723333279, 2205.3839398485557, 2102.8376016141951,
    1988.6676883274649, 1863.0309300997269, 1724.7018880528021,
    1574.3071119031426, 1411.3233859140287, 1236.2984935618269,
    1050.2811119683533, 853.4679110995969, 648.93092224206475,
    436.72050602325703, 216.85887105639503, 0.0, -216.85887105639503,
    -436.72050602325703, -648.93092224206259, -853.4679110995969,
    -1050.2811119683556, -1236.2984935618269, -1411.3233859140287,
    -1574.3071119031426, -1724.7018880528021, -1863.0309300997283,
    -1988.6676883274649, -2102.8376016141951, -2205.3839398485557,
    -2297.4119723333279, -2379.4891855936326, -2452.220433226089,
    -2516.70901152851, -2573.2136287447456, -2622.8928174689818,
    -2666.0397118457686, -2703.4985960623508, -2735.8183701539447,
    -2763.3783995520121, -2786.9302115610067, -2806.5797518365962,
    -2823.0495720921808, -2836.4332673478098, -2847.1824122247094,
    -2855.6466850776947, -2861.844328212977, -2866.419601288098,
    -2868.9790444595938, -2870.3932371185656, -2870.101175876845,
    -2869.1565558258603, -2866.907196278944, -2863.768932189816,
    -2859.7611104874909, -2855.1298621295618, -2849.8078772889085,
    -2843.9799846410374, -2837.65622121286, -2830.9077447758787,
    -2823.805671987589, -2816.363124585027, -2808.6638614596782,
    -2800.7145046348769, -2792.5732934160123, -2784.2616136711235,
    -2775.8097286256452, -2767.2445316513881, -2758.5741281901214,
    -2749.8386080179512, -2741.0438948383276, -2732.2118438711814,
    -2723.354350095949, -2714.4839874772633, -2705.6144842053163,
    -2696.7501298477609, -2687.9107132428039, -2679.0969467065343,
    -2670.3107209015384, -2661.56358363628, -2652.8643480438341,
    -2644.2191393135026, -2635.62942402975, -2627.0955105547932,
    -2618.6198272179836, -2610.2088244541233, -2601.8655899937071,
    2678.0767274100676, 2686.6608608195334, 2695.3144398836935,
    2704.034521635298, 2712.8144122368553, 2721.6516332625574,
    2730.5455302244932, 2739.4945607448158, 2748.4922581843512,
    2757.5298053963115, 2766.5956941765448, 2775.6874952533435,
    2784.8043377806548, 2793.9258657055652, 2803.0477066902076,
    2812.155987915613, 2821.237518303039, 2830.2798496175992, 2839.2603898379393,
    2848.1729979561546, 2856.9768909714639, 2865.6636073513005,
    2874.2050089745662, 2882.5699165426354, 2890.7361986768128,
    2898.6441517504782, 2906.2871064344708, 2913.5784210179686,
    2920.5046376314926, 2926.9924015277675, 2932.9681592919355,
    2938.4216808149017, 2943.1626079677835, 2947.2612764097607,
    2950.4634455105779, 2952.7475644739347, 2953.6754965059467,
    2953.9569922476726, 2952.4668240526589, 2949.7865632636936,
    2945.0381601360159, 2938.6158163936057, 2929.8595173668227,
    2918.7486188893554, 2904.9240594209368, 2887.9214277911842,
    2867.643738647359, 2843.3482201170409, 2814.92571078325, 2781.6036887873133,
    2742.9917283353157, 2698.5255843026762, 2647.3373720152977,
    2589.126376669255, 2522.7023901757375, 2447.7993716187739,
    2363.2844051116913, 2268.5375286713138, 2162.9762139893892,
    2045.4657132628017, 1916.1694754834007, 1773.83044500136, 1619.0941598819352,
    1451.4248239115534, 1271.3864995315871, 1080.0583818937814,
    877.64452913103639, 667.29946518419592, 449.07546011998841,
    222.99480113357902, 0.0, -222.99480113357902, -449.07546011998841,
    -667.29946518419365, -877.64452913103639, -1080.0583818937837,
    -1271.3864995315871, -1451.4248239115534, -1619.0941598819352,
    -1773.83044500136, -1916.169475483402, -2045.4657132628017,
    -2162.9762139893892, -2268.5375286713138, -2363.2844051116913,
    -2447.7993716187739, -2522.7023901757375, -2589.126376669255,
    -2647.3373720152977, -2698.5255843026762, -2742.9917283353157,
    -2781.6036887873133, -2814.9257107832495, -2843.3482201170409,
    -2867.643738647359, -2887.9214277911842, -2904.9240594209368,
    -2918.7486188893549, -2929.8595173668227, -2938.6158163936057,
    -2945.0381601360164, -2949.7865632636936, -2952.4668240526585,
    -2953.9569922476726, -2953.6754965059467, -2952.7475644739347,
    -2950.4634455105784, -2947.2612764097607, -2943.1626079677835,
    -2938.4216808149017, -2932.9681592919355, -2926.9924015277679,
    -2920.5046376314931, -2913.5784210179686, -2906.2871064344708,
    -2898.6441517504782, -2890.7361986768128, -2882.5699165426354,
    -2874.2050089745662, -2865.6636073513005, -2856.9768909714639,
    -2848.1729979561546, -2839.2603898379393, -2830.2798496175992,
    -2821.237518303039, -2812.155987915613, -2803.0477066902076,
    -2793.9258657055652, -2784.8043377806548, -2775.6874952533435,
    -2766.5956941765444, -2757.5298053963115, -2748.4922581843512,
    -2739.4945607448158, -2730.5455302244936, -2721.651633262557,
    -2712.8144122368553, -2704.034521635298, -2695.3144398836935,
    -2686.6608608195334, -2678.0767274100676, 2754.28786482992,
    2763.1128971791186, 2772.0090525492928, 2780.9735327160574,
    2789.9994004448381, 2799.0841272181551, 2808.2267124035643,
    2817.4255378589241, 2826.6737954579762, 2835.9626640860124,
    2845.2806751222133, 2854.6248606510776, 2863.9941913655553, 2873.36774392354,
    2882.7410632873994, 2892.1001319740717, 2901.4311417596796,
    2910.7210912398755, 2919.9466514572887, 2929.10146426785, 2938.1440533313794,
    2947.0656010565849, 2955.8367245642821, 2964.4253284133652,
    2972.8085359381735, 2980.9251788799279, 2988.768541043371, 2996.249097285709,
    3003.3530542013305, 3010.0048189175213, 3016.1284409257746,
    3021.7135011223654, 3026.564106192594, 3030.7536288223228,
    3034.0197605669209, 3036.3386144915762, 3037.2497131717973,
    3037.5207453404455, 3035.9545647083728, 3033.1535592731248,
    3028.2319930348231, 3021.5849536740934, 3012.5366218260178,
    3001.0639713109267, 2986.7985475865139, 2969.2631035034647,
    2948.3572664376261, 2923.3180401943314, 2894.0330517885914,
    2859.7087813824073, 2819.9437447859336, 2774.1583514526392,
    2721.4611149048469, 2661.5437422299979, 2593.1843467322124,
    2516.1095577692677, 2429.1568377895569, 2331.6911173779322, 2223.11482675809,
    2102.2637376945831, 1969.3080213790447, 1822.9590014649159,
    1663.8812081683764, 1491.52626186246, 1306.4745054839634, 1109.8356521582496,
    901.8211471173222, 685.66800838879453, 461.43041424957272,
    229.13073168092419, 0.0, -229.13073168092419, -461.43041424957272,
    -685.668008388792, -901.8211471173222, -1109.8356521582518,
    -1306.4745054839634, -1491.52626186246, -1663.8812081683764,
    -1822.9590014649159, -1969.3080213790463, -2102.2637376945831,
    -2223.11482675809, -2331.6911173779322, -2429.1568377895569,
    -2516.1095577692677, -2593.1843467322124, -2661.5437422299979,
    -2721.4611149048469, -2774.1583514526392, -2819.9437447859336,
    -2859.7087813824073, -2894.0330517885914, -2923.3180401943314,
    -2948.3572664376261, -2969.2631035034647, -2986.7985475865139,
    -3001.0639713109267, -3012.5366218260178, -3021.5849536740934,
    -3028.2319930348231, -3033.1535592731248, -3035.9545647083723,
    -3037.5207453404455, -3037.2497131717973, -3036.3386144915762,
    -3034.0197605669209, -3030.7536288223228, -3026.5641061925944,
    -3021.7135011223654, -3016.1284409257746, -3010.0048189175213,
    -3003.3530542013305, -2996.249097285709, -2988.768541043371,
    -2980.9251788799279, -2972.8085359381735, -2964.4253284133652,
    -2955.8367245642821, -2947.0656010565849, -2938.1440533313794,
    -2929.10146426785, -2919.9466514572887, -2910.7210912398755,
    -2901.4311417596796, -2892.1001319740712, -2882.7410632874,
    -2873.36774392354, -2863.9941913655553, -2854.6248606510776,
    -2845.2806751222133, -2835.9626640860124, -2826.6737954579767,
    -2817.4255378589241, -2808.2267124035643, -2799.0841272181551,
    -2789.9994004448381, -2780.9735327160574, -2772.0090525492928,
    -2763.1128971791186, -2754.28786482992, 2830.4990022529882,
    2839.5649335333446, 2848.7036652147926, 2857.9125437970533,
    2867.1843886536294, 2876.5166211797778, 2885.9078945811743,
    2895.356514978163, 2904.8553327231411, 2914.3955227756437, 2923.96565607887,
    2933.562226041583, 2943.1840449592669, 2952.8096221319997,
    2962.4344198872955, 2972.0442760454634, 2981.6247652088778,
    2991.1623328830306, 3000.6329130503796, 3010.0299305859435,
    3019.3112157043192, 3028.4675947850519, 3037.468440182829,
    3046.2807402498806, 3054.8808732404805, 3063.2062059761365,
    3071.2499758023087, 3078.9197735775624, 3086.2014709114123,
    3093.0172367758723, 3099.288722216661, 3105.0053229467908, 3109.965605135536,
    3114.2459889588381, 3117.5761400126407, 3119.929704787985, 3120.82382863,
    3121.0844966258742, 3119.4422708053357, 3116.520585456125,
    3111.4258267046866, 3104.5540963237772, 3095.213725664873,
    3083.3793245267539, 3068.6730365140388, 3050.6047789930562,
    3029.0707948699669, 3003.2878598255111, 2973.1403931371956,
    2937.8138738586326, 2896.89576120041, 2849.79111889232, 2795.5848574447864,
    2733.9611081757243, 2663.6663029277756, 2584.4197440344674,
    2495.0292703751211, 2394.844705977453, 2283.25343988841, 2159.0617616630648,
    2022.4465677453754, 1872.0875574820848, 1708.6682567377031,
    1531.6276997704431, 1341.5625114201193, 1139.6129227350234,
    925.99776506192711, 704.03655183525632, 473.78536840943076,
    235.26666266152296, 0.0, -235.26666266152296, -473.78536840943076,
    -704.03655183525382, -925.99776506192711, -1139.6129227350257,
    -1341.5625114201193, -1531.6276997704431, -1708.6682567377031,
    -1872.0875574820848, -2022.446567745377, -2159.0617616630648,
    -2283.25343988841, -2394.844705977453, -2495.0292703751211,
    -2584.4197440344674, -2663.6663029277756, -2733.9611081757243,
    -2795.5848574447864, -2849.79111889232, -2896.89576120041,
    -2937.8138738586326, -2973.1403931371956, -3003.2878598255111,
    -3029.0707948699669, -3050.6047789930562, -3068.6730365140384,
    -3083.3793245267539, -3095.213725664873, -3104.5540963237772,
    -3111.4258267046866, -3116.5205854561245, -3119.4422708053357,
    -3121.0844966258742, -3120.82382863, -3119.929704787985, -3117.5761400126407,
    -3114.2459889588381, -3109.965605135536, -3105.0053229467908,
    -3099.288722216661, -3093.0172367758723, -3086.2014709114123,
    -3078.9197735775624, -3071.2499758023087, -3063.2062059761365,
    -3054.8808732404805, -3046.2807402498806, -3037.468440182829,
    -3028.4675947850519, -3019.3112157043192, -3010.0299305859439,
    -3000.6329130503796, -2991.1623328830306, -2981.6247652088778,
    -2972.044276045463, -2962.4344198872955, -2952.809622132,
    -2943.1840449592669, -2933.562226041583, -2923.96565607887,
    -2914.3955227756437, -2904.8553327231416, -2895.356514978163,
    -2885.9078945811743, -2876.5166211797773, -2867.1843886536294,
    -2857.9125437970533, -2848.7036652147926, -2839.5649335333446,
    -2830.4990022529882, 2906.71013967902, 2916.0169698826267,
    2925.3982778801992, 2934.8515548782657, 2944.369376863167,
    2953.9491151469583, 2963.5890767574374, 2973.2874921021362,
    2983.036869980499, 2992.8283814652104, 3002.6506370456696,
    3012.4995914254164, 3022.3738985611162, 3032.2515003316748,
    3042.1277764896895, 3051.9884201288087, 3061.818388651202,
    3071.6035745454919, 3081.3191746191992, 3090.9583969099576,
    3100.4783780893185, 3109.8695885349689, 3119.1001558281027, 3128.13615205472,
    3136.9532105807716, 3145.4872330415888, 3153.7314107004554,
    3161.5904498921068, 3169.0498877518121, 3176.02965507146, 3182.4490031884034,
    3188.2971461918987, 3193.3671047708117, 3197.7383563856774,
    3201.1325824395462, 3203.5208343101449, 3204.3978455396255,
    3204.648246299857, 3202.9299460893562, 3199.8876385143503,
    3194.6196609820759, 3187.5232438238731, 3177.8908289385527,
    3165.6946784618171, 3150.5475261373094, 3131.9464542775327,
    3109.7843238895771, 3083.2576790476019, 3052.247734799987, 3015.91896622578,
    2973.8477775812803, 2925.4238865980597, 2869.7085996631527,
    2806.3784744752052, 2734.1482587912542, 2652.7299304048975,
    2560.9017028757121, 2457.9982944780054, 2343.3920533518149,
    2215.8597852043235, 2075.5851145454326, 1921.2161130874888, 1753.45530556774,
    1571.7291376388159, 1376.65051734112, 1169.3901936001068, 950.17438296797741,
    722.40509550507954, 486.14032259724684, 241.40259404223175, 0.0,
    -241.40259404223175, -486.14032259724684, -722.405095505077,
    -950.17438296797741, -1169.3901936001091, -1376.65051734112,
    -1571.7291376388159, -1753.45530556774, -1921.2161130874888,
    -2075.585114545434, -2215.8597852043235, -2343.3920533518149,
    -2457.9982944780054, -2560.9017028757121, -2652.7299304048975,
    -2734.1482587912542, -2806.3784744752052, -2869.7085996631527,
    -2925.4238865980597, -2973.8477775812803, -3015.91896622578,
    -3052.247734799987, -3083.2576790476019, -3109.7843238895771,
    -3131.9464542775327, -3150.5475261373094, -3165.6946784618171,
    -3177.8908289385522, -3187.5232438238736, -3194.6196609820759,
    -3199.8876385143503, -3202.9299460893562, -3204.648246299857,
    -3204.3978455396255, -3203.5208343101449, -3201.1325824395467,
    -3197.7383563856774, -3193.3671047708117, -3188.2971461918987,
    -3182.4490031884034, -3176.02965507146, -3169.0498877518121,
    -3161.5904498921068, -3153.7314107004554, -3145.4872330415888,
    -3136.9532105807716, -3128.13615205472, -3119.1001558281027,
    -3109.8695885349689, -3100.4783780893185, -3090.9583969099581,
    -3081.3191746191992, -3071.6035745454919, -3061.8183886512015,
    -3051.9884201288087, -3042.1277764896895, -3032.2515003316753,
    -3022.3738985611158, -3012.4995914254164, -3002.6506370456696,
    -2992.8283814652104, -2983.036869980499, -2973.2874921021366,
    -2963.5890767574379, -2953.9491151469579, -2944.369376863167,
    -2934.8515548782657, -2925.3982778801992, -2916.0169698826267,
    -2906.71013967902, 2982.9212771077928, 2992.46900622734, 3002.0928905455189,
    3011.7905659596786, 3021.5543650733939, 3031.3816091192775,
    3041.2702589324567, 3051.2184692304891, 3061.2184072306372,
    3071.2612401547171, 3081.335618021853, 3091.4369568030775,
    3101.5637521704962, 3111.6933785232218, 3121.8211330943955,
    3131.9325642232211, 3142.01201208716, 3152.04481622584, 3162.00543616554,
    3171.8868632394606, 3181.6455404855028, 3191.2715823047706,
    3200.7318714981989, 3209.9915638301754, 3219.0255479563634,
    3227.7682600785279, 3236.2128457279996, 3244.2611262280234,
    3251.898304713518, 3259.0420737756585, 3265.6092838626582,
    3271.5889707693773, 3276.7686050733037, 3281.2307307010351,
    3284.6890864675315, 3287.1120020412209, 3287.9717664674035,
    3288.2119945309669, 3286.4175937837772, 3283.25471561281, 3277.8134957357438,
    3270.4923957202732, 3260.5679316958708, 3248.0100330502205,
    3232.4220163975788, 3213.2881293726773, 3190.4978534477154, 3163.22749789364,
    3131.3550767510837, 3094.0240584925941, 3050.7997939308534,
    3001.0566545487072, 2943.8323415850627, 2878.7958411005, 2804.630214348485,
    2721.040116872096, 2626.774135297901, 2521.1518828869166, 2403.5306671226954,
    2272.6578083507843, 2128.7236617460244, 1970.3446683122588,
    1798.2423546385694, 1611.8305754705609, 1411.7385232479419,
    1199.1674647319007, 974.351000838294, 740.77363938160192, 498.49527681093525,
    247.53852579320372, 0.0, -247.53852579320372, -498.49527681093525,
    -740.77363938159942, -974.351000838294, -1199.1674647319032,
    -1411.7385232479419, -1611.8305754705609, -1798.2423546385694,
    -1970.3446683122588, -2128.7236617460262, -2272.6578083507843,
    -2403.5306671226954, -2521.1518828869166, -2626.774135297901,
    -2721.040116872096, -2804.630214348485, -2878.7958411005,
    -2943.8323415850627, -3001.0566545487072, -3050.7997939308534,
    -3094.0240584925941, -3131.3550767510837, -3163.22749789364,
    -3190.4978534477154, -3213.2881293726773, -3232.4220163975788,
    -3248.0100330502205, -3260.5679316958704, -3270.4923957202732,
    -3277.8134957357443, -3283.2547156128094, -3286.4175937837772,
    -3288.2119945309669, -3287.9717664674035, -3287.1120020412209,
    -3284.6890864675315, -3281.2307307010351, -3276.7686050733037,
    -3271.5889707693773, -3265.6092838626582, -3259.0420737756585,
    -3251.8983047135184, -3244.2611262280234, -3236.2128457279996,
    -3227.7682600785279, -3219.0255479563634, -3209.9915638301754,
    -3200.7318714981989, -3191.2715823047706, -3181.6455404855028,
    -3171.8868632394606, -3162.00543616554, -3152.04481622584,
    -3142.0120120871597, -3131.9325642232211, -3121.8211330943955,
    -3111.6933785232218, -3101.5637521704962, -3091.4369568030775,
    -3081.335618021853, -3071.2612401547176, -3061.2184072306372,
    -3051.2184692304895, -3041.2702589324572, -3031.3816091192771,
    -3021.5543650733939, -3011.7905659596786, -3002.0928905455189,
    -2992.46900622734, -2982.9212771077928, 3059.1324145391031,
    3068.921042567822, 3078.7875032107604, 3088.729577041277, 3098.7393532842593,
    3108.814103096357, 3118.9514411063246, 3129.1494463628987,
    3139.3999444740848, 3149.6940988441693, 3160.0205990067338,
    3170.3743221750178, 3180.7536057868588, 3191.1352567072317,
    3201.5144897012456, 3211.8767083279013, 3222.205635517214,
    3232.4860579227916, 3242.6916976910206, 3252.8153295740617,
    3262.8127028920817, 3272.673576093041, 3282.3635871913884,
    3291.8469755783231, 3301.0978853648171, 3310.049287088983,
    3318.6942808760314, 3326.9318025840907, 3334.7467217883323,
    3342.054492862284, 3348.769564259168, 3354.8807965980768, 3360.1701060186397,
    3364.7231115320715, 3368.2456507452462, 3370.703206999041,
    3371.5455938916948, 3371.7757414650569, 3369.9052166774982,
    3366.6218143013252, 3361.0073308599253, 3353.4615516137792,
    3343.2450339801803, 3330.32538823385, 3314.2965072425313, 3294.629804292706,
    3271.211383500889, 3243.197316393198, 3210.4624189673682, 3172.129150666909,
    3127.7518102512367, 3076.6894227252938, 3017.9560832330844,
    2951.2132080265355, 2875.1121696226924, 2789.3503034284859, 2692.6465676476,
    2584.30547121081, 2463.6692811780022, 2329.4558311316737, 2181.8622093172639,
    2019.4732231844657, 1843.0294039322525, 1651.9320132683667,
    1446.8265291414812, 1228.9447361109105, 998.52761867542938,
    759.14218344977871, 510.8502310486129, 253.67445788748853, 0.0,
    -253.67445788748853, -510.8502310486129, -759.142183449776,
    -998.52761867542938, -1228.944736110913, -1446.8265291414812,
    -1651.9320132683667, -1843.0294039322525, -2019.4732231844657,
    -2181.8622093172653, -2329.4558311316737, -2463.6692811780022,
    -2584.30547121081, -2692.6465676476, -2789.3503034284859,
    -2875.1121696226924, -2951.2132080265355, -3017.9560832330844,
    -3076.6894227252938, -3127.7518102512367, -3172.129150666909,
    -3210.4624189673682, -3243.197316393198, -3271.211383500889,
    -3294.629804292706, -3314.2965072425313, -3330.3253882338495,
    -3343.24503398018, -3353.4615516137792, -3361.0073308599253,
    -3366.6218143013252, -3369.9052166774982, -3371.7757414650569,
    -3371.5455938916948, -3370.703206999041, -3368.2456507452462,
    -3364.7231115320715, -3360.1701060186397, -3354.8807965980768,
    -3348.769564259168, -3342.054492862284, -3334.7467217883323,
    -3326.9318025840912, -3318.6942808760314, -3310.049287088983,
    -3301.0978853648171, -3291.8469755783231, -3282.3635871913884,
    -3272.673576093041, -3262.8127028920812, -3252.8153295740622,
    -3242.6916976910206, -3232.4860579227916, -3222.205635517214,
    -3211.8767083279013, -3201.5144897012456, -3191.1352567072322,
    -3180.7536057868583, -3170.3743221750178, -3160.0205990067338,
    -3149.6940988441693, -3139.3999444740853, -3129.1494463628987,
    -3118.9514411063246, -3108.814103096357, -3098.7393532842593,
    -3088.729577041277, -3078.7875032107604, -3068.921042567822,
    -3059.1324145391031, 3135.3435519727677, 3145.3730789043775,
    3155.4821158759269, 3165.6685881230478, 3175.9243414957182,
    3186.2465970778558, 3196.6326232791239, 3207.0804234990746,
    3217.5814817113223, 3228.1269575335696, 3238.705579999692,
    3249.3116875416467, 3259.9434594097079, 3270.5771348842427,
    3281.2078463100875, 3291.8208524421248, 3302.3992589417812,
    3312.9272996351824, 3323.3779591971083, 3333.7437959134063,
    3343.9798653083371, 3354.0755698984958, 3363.9953029061012,
    3373.7023873010485, 3383.1702228039167, 3392.3303140747985, 3401.17571613644,
    3409.6024789591766, 3417.5951389687766, 3425.0669123073403,
    3431.9298443959665, 3438.1726236032969, 3443.5716075832311,
    3448.215498532345, 3451.8022739505236, 3454.2944482346443, 3455.119330206262,
    3455.3394872289618, 3453.3928171957818, 3449.9889324514356,
    3444.201166269092, 3436.430711152057, 3425.9221358301156, 3412.6407439612603,
    3396.1709986254282, 3375.9714790504545, 3351.9249140101656,
    3323.1671345728273, 3289.5697614281303, 3250.2342427557646,
    3204.703826544358, 3152.3221911107626, 3092.0798246275522,
    3023.6305752307462, 2945.5941246348098, 2857.6604900672578,
    2758.518999930141, 2647.4590594556862, 2523.8078954969342,
    2386.2538535734016, 2235.0007572321633, 2068.601777729486, 1887.816453432589,
    1692.0334510346661, 1481.9145350225626, 1258.7220077194972,
    1022.7042364816988, 777.51072769599, 523.205185308575, 259.81039030068951,
    0.0, -259.81039030068951, -523.205185308575, -777.51072769598727,
    -1022.7042364816988, -1258.7220077194997, -1481.9145350225626,
    -1692.0334510346661, -1887.816453432589, -2068.601777729486,
    -2235.0007572321651, -2386.2538535734016, -2523.8078954969342,
    -2647.4590594556862, -2758.518999930141, -2857.6604900672578,
    -2945.5941246348098, -3023.6305752307462, -3092.0798246275522,
    -3152.3221911107626, -3204.703826544358, -3250.2342427557642,
    -3289.5697614281303, -3323.1671345728273, -3351.9249140101656,
    -3375.9714790504545, -3396.1709986254282, -3412.6407439612603,
    -3425.9221358301156, -3436.430711152057, -3444.201166269092,
    -3449.9889324514356, -3453.3928171957818, -3455.3394872289618,
    -3455.119330206262, -3454.2944482346443, -3451.8022739505236,
    -3448.215498532345, -3443.5716075832311, -3438.1726236032969,
    -3431.9298443959665, -3425.0669123073403, -3417.5951389687771,
    -3409.6024789591766, -3401.17571613644, -3392.3303140747985,
    -3383.1702228039167, -3373.7023873010485, -3363.9953029061012,
    -3354.0755698984958, -3343.9798653083367, -3333.7437959134068,
    -3323.3779591971083, -3312.9272996351824, -3302.3992589417808,
    -3291.8208524421248, -3281.2078463100875, -3270.5771348842427,
    -3259.9434594097074, -3249.3116875416467, -3238.705579999692,
    -3228.1269575335696, -3217.5814817113223, -3207.0804234990751,
    -3196.6326232791239, -3186.2465970778553, -3175.9243414957182,
    -3165.6685881230478, -3155.4821158759269, -3145.3730789043775,
    -3135.3435519727677, 3211.5546894086228, 3221.8251152372841,
    3232.1767285410256, 3242.6075992049787, 3253.1093297077282,
    3263.6790910634627, 3274.3138054509313, 3285.0114006387553,
    3295.7630189427846, 3306.559816222923, 3317.3905610001648,
    3328.2490529033348, 3339.1333130385942, 3350.0190130547421,
    3360.9012029207847, 3371.7649965652345, 3382.5928823612403,
    3393.368541361956, 3404.0642206851371, 3414.6722622571738,
    3425.1470277336166, 3435.4775637199668, 3445.6270186409056,
    3455.557799000067, 3465.2425602716385, 3474.6113410376479,
    3483.6571515018268, 3492.2731553522267, 3500.4435562480207,
    3508.0793320887965, 3515.090124289562, 3521.4644517161605,
    3526.9731097442987, 3531.707891379524, 3535.3589547906254,
    3537.8857248309064, 3538.6929777238529, 3538.9032319335042,
    3536.8803974576535, 3533.3560682053121, 3527.395001893884,
    3519.3998740229586, 3508.5992372802179, 3494.956100186751,
    3478.0454905043825, 3457.31315365754, 3432.63844494059, 3403.1369524564343,
    3368.6771041147613, 3328.3393347655024, 3281.6558428119806,
    3227.9549596897295, 3166.2035657868369, 3096.04794269277, 3016.0760794037565,
    2925.9706767822795, 2824.3914321503462, 2710.6126476269947,
    2583.9465100606694, 2443.0518756998945, 2288.1393054662944,
    2117.7303319703187, 1932.6035031249121, 1732.1348887716651,
    1517.0025408919446, 1288.4992795416606, 1046.8808542592071,
    795.87927210787757, 535.56013958927463, 265.9463230106681, 0.0,
    -265.9463230106681, -535.56013958927463, -795.87927210787473,
    -1046.8808542592071, -1288.4992795416631, -1517.0025408919446,
    -1732.1348887716651, -1932.6035031249121, -2117.7303319703187,
    -2288.1393054662963, -2443.0518756998945, -2583.9465100606694,
    -2710.6126476269947, -2824.3914321503462, -2925.9706767822795,
    -3016.0760794037565, -3096.04794269277, -3166.2035657868369,
    -3227.9549596897295, -3281.6558428119806, -3328.3393347655024,
    -3368.6771041147608, -3403.1369524564343, -3432.63844494059,
    -3457.31315365754, -3478.0454905043821, -3494.956100186751,
    -3508.5992372802179, -3519.3998740229586, -3527.395001893884,
    -3533.3560682053121, -3536.8803974576535, -3538.9032319335042,
    -3538.6929777238529, -3537.8857248309064, -3535.3589547906258,
    -3531.707891379524, -3526.9731097442987, -3521.464451716161,
    -3515.090124289562, -3508.0793320887965, -3500.4435562480207,
    -3492.2731553522267, -3483.6571515018268, -3474.6113410376479,
    -3465.2425602716385, -3455.557799000067, -3445.6270186409056,
    -3435.4775637199668, -3425.1470277336166, -3414.6722622571738,
    -3404.0642206851371, -3393.368541361956, -3382.5928823612403,
    -3371.764996565234, -3360.9012029207847, -3350.0190130547421,
    -3339.1333130385942, -3328.2490529033348, -3317.3905610001643,
    -3306.559816222923, -3295.7630189427846, -3285.0114006387553,
    -3274.3138054509313, -3263.6790910634622, -3253.1093297077282,
    -3242.6075992049787, -3232.1767285410256, -3221.8251152372841,
    -3211.5546894086228, 3287.7658268465157, 3298.277151566791,
    3308.8713412060597, 3319.5466102870596, 3330.2943179202525,
    3341.1115850528968, 3351.9949876218143, 3362.9423777816987,
    3373.9445561688653, 3384.9926749122319, 3396.07554200764, 3407.186418260419,
    3418.3231666731085, 3429.4608912191716, 3440.5945595332105,
    3451.7091406966315, 3462.7865057759377, 3473.8097831021496,
    3484.7504821563207, 3495.6007286050685, 3506.3141901673239,
    3516.879557556389, 3527.2587343944929, 3537.4132106769439, 3547.314897766134,
    3556.8923679790591, 3566.1385869654291, 3574.9438317622626,
    3583.2919736198087, 3591.0917521863876, 3598.2504039550922,
    3604.7562808730581, 3610.374612479884, 3615.2002897733269,
    3618.9156920023133, 3621.4770359012241, 3622.2665386795929,
    3622.4669756759372, 3620.3679593227534, 3616.7232199340997,
    3610.5888376779221, 3602.3690399489592, 3591.27633836146, 3577.2714568695837,
    3559.9199828417459, 3538.6548281245041, 3513.3519762606893,
    3483.1067700656022, 3447.7844470104928, 3406.4444267018534,
    3358.607859055724, 3303.5877284482872, 3240.3273067275759,
    3168.4653103941837, 3086.5580339466733, 2994.2808635680112,
    2890.2638643125861, 2773.7662357296967, 2644.0851248521367,
    2499.8498975328803, 2341.2778539974897, 2166.8588859278552,
    1977.390552995909, 1772.2363264813673, 1552.0905467503276, 1318.276551562853,
    1071.0574720098721, 814.2478166742, 547.91509388930479, 272.08225599728837,
    0.0, -272.08225599728837, -547.91509388930479, -814.24781667419711,
    -1071.0574720098721, -1318.2765515628557, -1552.0905467503276,
    -1772.2363264813673, -1977.390552995909, -2166.8588859278552,
    -2341.2778539974915, -2499.8498975328803, -2644.0851248521367,
    -2773.7662357296967, -2890.2638643125861, -2994.2808635680112,
    -3086.5580339466733, -3168.4653103941837, -3240.3273067275759,
    -3303.5877284482872, -3358.607859055724, -3406.4444267018534,
    -3447.7844470104928, -3483.1067700656022, -3513.3519762606893,
    -3538.6548281245041, -3559.9199828417454, -3577.2714568695837,
    -3591.27633836146, -3602.3690399489592, -3610.5888376779221,
    -3616.7232199340997, -3620.3679593227534, -3622.4669756759372,
    -3622.2665386795929, -3621.4770359012241, -3618.9156920023133,
    -3615.2002897733269, -3610.374612479884, -3604.7562808730581,
    -3598.2504039550922, -3591.0917521863876, -3583.2919736198087,
    -3574.9438317622626, -3566.1385869654291, -3556.8923679790591,
    -3547.314897766134, -3537.4132106769439, -3527.2587343944929,
    -3516.879557556389, -3506.3141901673239, -3495.600728605069,
    -3484.7504821563207, -3473.8097831021496, -3462.7865057759373,
    -3451.709140696631, -3440.5945595332105, -3429.4608912191716,
    -3418.3231666731081, -3407.186418260419, -3396.07554200764,
    -3384.9926749122319, -3373.9445561688653, -3362.9423777816987,
    -3351.9949876218147, -3341.1115850528968, -3330.2943179202525,
    -3319.5466102870596, -3308.8713412060597, -3298.277151566791,
    -3287.7658268465157, 3363.9769642863107, 3374.7291878931287,
    3385.5659538710347, 3396.4856213692792, 3407.4793061332557,
    3418.5440790459015, 3429.6761697918359, 3440.8733549276872,
    3452.1260933899243, 3463.425533601499, 3474.7605230216509,
    3486.1237836132063, 3497.5130203128756, 3508.9027693779335, 3520.28791614725,
    3531.6532848357683, 3542.9801291861854, 3554.2510248548829,
    3565.4367436117645, 3576.5291949568232, 3587.4813526089147,
    3598.2815514067893, 3608.8904501656671, 3619.2686223331079,
    3629.3872352857111, 3639.173394900426, 3648.6200225210514,
    3657.6145081883724, 3666.140391078402, 3674.104172581443, 3681.4106834064655,
    3688.0481110151527, 3693.7761157688492, 3698.692693433668,
    3702.4724843517861, 3705.0683805882695, 3705.8400152342165,
    3706.0307185419642, 3703.8555044298491, 3700.0903862037226,
    3693.7826735753019, 3685.3382086824881, 3673.9534391016987,
    3659.5868139733307, 3641.794475603584, 3619.9965024609296,
    3594.0655079420512, 3563.0765874198646, 3526.8917901001764,
    3484.5495185700079, 3435.5598752770729, 3379.2204973738267,
    3314.4510474648723, 3240.8826783182785, 3157.039988279128,
    3062.5910504194362, 2956.1362964208311, 2836.9198237683167,
    2704.2237398558154, 2556.6479190921332, 2394.416402805587,
    2215.9874396211176, 2022.1776030334715, 1812.3377641655982,
    1587.1785525983564, 1348.0538237698188, 1095.2340897354445,
    832.61636138471113, 560.27004820738284, 278.21818924219565, 0.0,
    -278.21818924219565, -560.27004820738284, -832.61636138470817,
    -1095.2340897354445, -1348.0538237698215, -1587.1785525983564,
    -1812.3377641655982, -2022.1776030334715, -2215.9874396211176,
    -2394.4164028055889, -2556.6479190921332, -2704.2237398558154,
    -2836.9198237683167, -2956.1362964208311, -3062.5910504194362,
    -3157.039988279128, -3240.8826783182785, -3314.4510474648723,
    -3379.2204973738267, -3435.5598752770729, -3484.5495185700079,
    -3526.891790100176, -3563.0765874198646, -3594.0655079420512,
    -3619.9965024609296, -3641.7944756035836, -3659.5868139733307,
    -3673.9534391016987, -3685.3382086824881, -3693.7826735753019,
    -3700.0903862037226, -3703.8555044298491, -3706.0307185419642,
    -3705.8400152342165, -3705.0683805882695, -3702.4724843517861,
    -3698.692693433668, -3693.7761157688492, -3688.0481110151527,
    -3681.4106834064655, -3674.104172581443, -3666.140391078402,
    -3657.6145081883724, -3648.6200225210514, -3639.173394900426,
    -3629.3872352857111, -3619.2686223331079, -3608.8904501656671,
    -3598.2815514067893, -3587.4813526089147, -3576.5291949568232,
    -3565.4367436117645, -3554.2510248548829, -3542.9801291861854,
    -3531.6532848357683, -3520.28791614725, -3508.9027693779335,
    -3497.5130203128756, -3486.1237836132063, -3474.7605230216509,
    -3463.425533601499, -3452.1260933899243, -3440.8733549276876,
    -3429.6761697918364, -3418.5440790459015, -3407.4793061332557,
    -3396.4856213692792, -3385.5659538710347, -3374.7291878931287,
    -3363.9769642863107, 3440.1881017278811, 3451.1812242165042,
    3462.2605665359538, 3473.4246324516289, 3484.6642943467064,
    3495.9765730422428, 3507.3573519610541, 3518.8043320765237,
    3530.3076306062908, 3541.8583922907269, 3553.445504041772, 3565.061148961976,
    3576.7028739575562, 3588.3446475313981, 3599.9812727628, 3611.597428982147,
    3623.1737525922722, 3634.6922666193532, 3646.1230050524832,
    3657.4576613121922, 3668.64851505789, 3679.6835452702794, 3690.5221659533308,
    3701.1240339698697, 3711.4595728288159, 3721.4544218030251,
    3731.1014581630106, 3740.2851846297081, 3748.9888086185283,
    3757.1165932567333, 3764.5709626564835, 3771.3399420879441,
    3777.1776195908715, 3782.1851020989939, 3786.0293306345138,
    3788.6597580628036, 3789.4134094771407, 3789.5944606074049,
    3787.3430342286811, 3783.4575657466326, 3776.9765095486073,
    3768.3073800019984, 3756.6305395260556, 3741.9021714653236,
    3723.6689687592348, 3701.3381766755515, 3674.77903995896, 3643.0464045369467,
    3605.9991333700918, 3562.6546103746764, 3512.5118914773957,
    3454.8532664548948, 3388.5747880124718, 3313.3000464498659,
    3227.5219424152888, 3130.901237332002, 3022.0087284786987, 2900.07341174699,
    2764.3623550575644, 2613.4459403956939, 2447.55495187221, 2265.1159930674626,
    2066.9646532265606, 1852.4392018260248, 1622.2665584366296,
    1377.8310961504546, 1119.4107074375265, 850.98490623005114,
    572.62500254233737, 284.35412272862425, 0.0, -284.35412272862425,
    -572.62500254233737, -850.98490623004818, -1119.4107074375265,
    -1377.8310961504574, -1622.2665584366296, -1852.4392018260248,
    -2066.9646532265606, -2265.1159930674626, -2447.5549518722123,
    -2613.4459403956939, -2764.3623550575644, -2900.07341174699,
    -3022.0087284786987, -3130.901237332002, -3227.5219424152888,
    -3313.3000464498659, -3388.5747880124718, -3454.8532664548948,
    -3512.5118914773957, -3562.6546103746764, -3605.9991333700918,
    -3643.0464045369467, -3674.77903995896, -3701.3381766755515,
    -3723.6689687592343, -3741.9021714653236, -3756.6305395260556,
    -3768.3073800019984, -3776.9765095486073, -3783.4575657466326,
    -3787.3430342286811, -3789.5944606074049, -3789.4134094771407,
    -3788.6597580628036, -3786.0293306345138, -3782.1851020989939,
    -3777.1776195908715, -3771.3399420879441, -3764.5709626564835,
    -3757.1165932567333, -3748.9888086185283, -3740.2851846297081,
    -3731.1014581630106, -3721.4544218030251, -3711.4595728288159,
    -3701.1240339698697, -3690.5221659533308, -3679.6835452702794,
    -3668.64851505789, -3657.4576613121926, -3646.1230050524832,
    -3634.6922666193532, -3623.1737525922722, -3611.597428982147,
    -3599.9812727628, -3588.3446475313981, -3576.7028739575562,
    -3565.061148961976, -3553.4455040417715, -3541.8583922907269,
    -3530.3076306062912, -3518.8043320765237, -3507.3573519610541,
    -3495.9765730422423, -3484.6642943467064, -3473.4246324516289,
    -3462.2605665359538, -3451.1812242165042, -3440.1881017278811,
    3516.3992391711145, 3527.6332605371094, 3538.955179200821,
    3550.3636435341009, 3561.8492825605772, 3573.4090670417063,
    3585.0385341295191, 3596.7353092280241, 3608.4891678182653,
    3620.2912509799194, 3632.1304850676147, 3643.9985143069866,
    3655.8927276068384, 3667.7865256799014, 3679.6746293797637,
    3691.541573135311, 3703.3673759944618, 3715.1335083948247, 3726.809266479403,
    3738.38612767095, 3749.8156775137927, 3761.0855391460423, 3772.153881756476,
    3782.97944558843, 3793.5319103940219, 3803.7354486880267, 3813.5828938860814,
    3822.9558610854792, 3831.8372262353332, 3840.1290141963327,
    3847.7312417169474, 3854.6317740408736, 3860.5791239264295,
    3865.677515524771, 3869.5862296749642, 3872.2511675225392,
    3872.9867234293761, 3873.1582019395755, 3870.830550006453,
    3866.8247574383372, 3860.1703455673292, 3851.2765537086352,
    3839.3076396572437, 3824.2175293161777, 3805.5434622809166,
    3782.6798507763447, 3755.4925722880812, 3723.0162214329648,
    3685.1064768077827, 3640.7597021201473, 3589.4639076579529,
    3530.4860356810627, 3462.6985283829081, 3385.7174147751075,
    3298.0038963680831, 3199.2114243015662, 3087.8811604894904,
    2963.2269996695059, 2824.5009704444719, 2670.2439614600489,
    2500.6935011805722, 2314.2445462827582, 2111.7517035650912,
    1892.5406394641709, 1657.3545642656995, 1407.6083686936854,
    1143.5873251175867, 869.3534512016538, 584.97995689309607,
    290.49005644122803, 0.0, -290.49005644122803, -584.97995689309607,
    -869.35345120165084, -1143.5873251175867, -1407.6083686936884,
    -1657.3545642656995, -1892.5406394641709, -2111.7517035650912,
    -2314.2445462827582, -2500.693501180574, -2670.2439614600489,
    -2824.5009704444719, -2963.2269996695059, -3087.8811604894904,
    -3199.2114243015662, -3298.0038963680831, -3385.7174147751075,
    -3462.6985283829081, -3530.4860356810627, -3589.4639076579529,
    -3640.7597021201468, -3685.1064768077822, -3723.0162214329648,
    -3755.4925722880812, -3782.6798507763447, -3805.5434622809162,
    -3824.2175293161777, -3839.3076396572437, -3851.2765537086352,
    -3860.1703455673296, -3866.8247574383372, -3870.830550006453,
    -3873.1582019395755, -3872.9867234293761, -3872.2511675225392,
    -3869.5862296749642, -3865.6775155247715, -3860.5791239264295,
    -3854.6317740408736, -3847.7312417169474, -3840.1290141963327,
    -3831.8372262353332, -3822.9558610854792, -3813.5828938860814,
    -3803.7354486880267, -3793.5319103940219, -3782.97944558843,
    -3772.153881756476, -3761.0855391460423, -3749.8156775137927,
    -3738.3861276709504, -3726.809266479403, -3715.1335083948247,
    -3703.3673759944618, -3691.5415731353105, -3679.6746293797642,
    -3667.7865256799018, -3655.8927276068384, -3643.9985143069866,
    -3632.1304850676142, -3620.2912509799194, -3608.4891678182653,
    -3596.7353092280241, -3585.0385341295191, -3573.4090670417063,
    -3561.8492825605772, -3550.3636435341009, -3538.955179200821,
    -3527.6332605371094, -3516.3992391711145, 3592.6103766159054,
    3604.085296855118, 3615.6497918656387, 3627.3026546166866,
    3639.0342707748405, 3650.8415610440966, 3662.7197162972793,
    3674.6662863820216, 3686.6707050261221, 3698.7241096690773, 3710.81546609882,
    3722.9358796484707, 3735.0825812604353, 3747.228403823754,
    3759.3679859980548, 3771.4857172948396, 3783.5609993929943,
    3795.5747501806195, 3807.4955278933739, 3819.31459403289, 3830.9828399762023,
    3842.4875330333293, 3853.7855975741768, 3864.8348571898928,
    3875.6042479800149, 3886.0164755565052, 3896.06432968545, 3905.6265375549451,
    3914.6856439243393, 3923.1414353854984, 3930.8915205987532,
    3937.9236068269752, 3943.9806287567835, 3949.16993348213, 3953.1431803262622,
    3955.8426081910661, 3956.5599590463112, 3956.7219425984536,
    3954.3180529099905, 3950.1919602777825, 3943.3641816066006,
    3934.2457296234088, 3921.9847395158522, 3906.5328874993929,
    3887.4179561434021, 3864.0215247706055, 3836.2061049081981, 3802.98603812261,
    3764.2138204019138, 3718.86479381033, 3666.4159238199068, 3606.1188050428109,
    3536.8222685876326, 3458.1347832813681, 3368.4858501493241,
    3267.5216113243519, 3153.7535924562239, 3026.3805875393391,
    2884.6395860047232, 2727.0419823002976, 2553.8320507153085,
    2363.3730992815422, 2156.5387540398324, 1932.6420770814329,
    1692.4425700860788, 1437.3856413893584, 1167.7639427769732,
    887.72199629166266, 597.33491125867556, 296.62599036593497, 0.0,
    -296.62599036593497, -597.33491125867556, -887.72199629165948,
    -1167.7639427769732, -1437.3856413893614, -1692.4425700860788,
    -1932.6420770814329, -2156.5387540398324, -2363.3730992815422,
    -2553.8320507153107, -2727.0419823002976, -2884.6395860047232,
    -3026.3805875393391, -3153.7535924562239, -3267.5216113243519,
    -3368.4858501493241, -3458.1347832813681, -3536.8222685876326,
    -3606.1188050428109, -3666.4159238199068, -3718.86479381033,
    -3764.2138204019138, -3802.98603812261, -3836.2061049081981,
    -3864.0215247706055, -3887.4179561434021, -3906.5328874993929,
    -3921.9847395158517, -3934.2457296234088, -3943.3641816066006,
    -3950.1919602777825, -3954.3180529099905, -3956.7219425984536,
    -3956.5599590463112, -3955.8426081910661, -3953.1431803262622,
    -3949.16993348213, -3943.9806287567835, -3937.9236068269752,
    -3930.8915205987532, -3923.1414353854984, -3914.6856439243393,
    -3905.6265375549451, -3896.06432968545, -3886.0164755565052,
    -3875.6042479800149, -3864.8348571898928, -3853.7855975741768,
    -3842.4875330333293, -3830.9828399762023, -3819.3145940328905,
    -3807.4955278933739, -3795.5747501806195, -3783.5609993929943,
    -3771.4857172948396, -3759.3679859980548, -3747.228403823754,
    -3735.0825812604348, -3722.9358796484707, -3710.8154660988193,
    -3698.7241096690773, -3686.6707050261221, -3674.6662863820216,
    -3662.71971629728, -3650.8415610440961, -3639.0342707748405,
    -3627.3026546166866, -3615.6497918656387, -3604.085296855118,
    -3592.6103766159054, 3668.8215140621578, 3680.537333170691,
    3692.3444045304109, 3704.2416656993792, 3716.2192589894721,
    3728.2740550492331, 3740.4008984643792, 3752.5972635383632,
    3764.8522422301148, 3777.1569683582038, 3789.5004471350608,
    3801.8732449866461, 3814.2724349180839, 3826.6702819632383,
    3839.0613426175905, 3851.4298614603472, 3863.7546227880925,
    3876.0159919761177, 3888.1817892951808, 3900.2430603978228,
    3912.1500024447323, 3923.88952693145, 3935.4173134055773, 3946.6902687752754,
    3957.6765855855824, 3968.2975024094508, 3978.5457655566788,
    3988.2972140374159, 3997.5340616814119, 4006.1538568105643,
    4014.0517993119815, 4021.2154404025659, 4027.3821340639606, 4032.66235575663,
    4036.7001814697878, 4039.4340793168212, 4040.1331182203489,
    4040.2856826376478, 4037.8055439643681, 4033.5591733708807,
    4026.5580176461735, 4017.2149075847733, 4004.6618391205843,
    3988.8482459910083, 3969.2924503237305, 3945.363198665023,
    3916.9196377999729, 3882.9558546192989, 3843.32116414215, 3796.9698854487979,
    3743.3679399643315, 3681.7515745314377, 3610.9460086371337, 3530.55215195709,
    3438.967803769835, 3335.8317983969096, 3219.6260243816655,
    3089.5341753596854, 2944.77820172749, 2783.8400029302957, 2606.9706004623313,
    2412.5016520771592, 2201.3258046423175, 1972.7435146790936,
    1727.5305758982433, 1467.1629142281495, 1191.9405604169278,
    906.09054149286044, 609.68986563817259, 302.76192448981595, 0.0,
    -302.76192448981595, -609.68986563817259, -906.09054149285726,
    -1191.9405604169278, -1467.1629142281522, -1727.5305758982433,
    -1972.7435146790936, -2201.3258046423175, -2412.5016520771592,
    -2606.9706004623336, -2783.8400029302957, -2944.77820172749,
    -3089.5341753596854, -3219.6260243816655, -3335.8317983969096,
    -3438.967803769835, -3530.55215195709, -3610.9460086371337,
    -3681.7515745314377, -3743.3679399643315, -3796.9698854487979,
    -3843.32116414215, -3882.9558546192989, -3916.9196377999729,
    -3945.363198665023, -3969.29245032373, -3988.8482459910078,
    -4004.6618391205843, -4017.2149075847733, -4026.5580176461735,
    -4033.5591733708807, -4037.8055439643681, -4040.2856826376478,
    -4040.1331182203489, -4039.4340793168212, -4036.7001814697878,
    -4032.66235575663, -4027.3821340639606, -4021.2154404025659,
    -4014.0517993119811, -4006.1538568105643, -3997.5340616814119,
    -3988.2972140374163, -3978.5457655566788, -3968.2975024094508,
    -3957.6765855855824, -3946.6902687752754, -3935.4173134055773,
    -3923.88952693145, -3912.1500024447323, -3900.2430603978232,
    -3888.1817892951808, -3876.0159919761177, -3863.7546227880921,
    -3851.4298614603472, -3839.061342617591, -3826.6702819632383,
    -3814.2724349180839, -3801.8732449866461, -3789.5004471350608,
    -3777.1569683582043, -3764.8522422301148, -3752.5972635383637,
    -3740.4008984643797, -3728.2740550492326, -3716.2192589894721,
    -3704.2416656993792, -3692.3444045304109, -3680.537333170691,
    -3668.8215140621578, 3745.0326515097831, 3756.9893694839748,
    3769.0390171951403, 3781.1806767821731, 3793.4042472044503, 3805.70654905695,
    3818.0820806308575, 3830.5282406969081, 3843.0337794304751,
    3855.5898270473003, 3868.1854281760357, 3880.810610321711,
    3893.4622885795429, 3906.1121600986162, 3918.7546992382981, 3931.37400563148,
    3943.9482461799607, 3956.4572337807449, 3968.8680506855421,
    3981.1715267655713, 3993.3171649190249, 4005.291520839769,
    4017.0490292498885, 4028.5456803455145, 4039.7489232096041,
    4050.578529247774, 4061.0272014956668, 4070.9678905322467,
    4080.3824795027258, 4089.1662784588416, 4097.2120778659655,
    4104.5072747269587, 4110.7836398307254, 4116.1547821471395,
    4120.2572320147165, 4123.0255801721087, 4123.7062027834227,
    4123.8494221052224, 4121.293024088649, 4116.9263959166, 4109.7518536695961,
    4100.1840874465524, 4087.3389384884726, 4071.163604769305, 4051.166944800957,
    4026.7048724657375, 3997.6331709457413, 3962.92567093531, 3922.4285080190448,
    3875.0749770388225, 3820.3199560922226, 3757.384344138969,
    3685.0697485410315, 3602.9695207916761, 3509.4497572395449,
    3404.1419855160802, 3285.4984562683535, 3152.687763133486,
    3004.9168176028256, 2840.6380233627783, 2660.1091504086953,
    2461.630204681876, 2246.1128553647677, 2012.8449522583321,
    1762.6185817026353, 1496.940187201478, 1216.1171780385928, 924.4590867986044,
    622.04482003075543, 308.897858800972, 0.0, -308.897858800972,
    -622.04482003075543, -924.45908679860111, -1216.1171780385928,
    -1496.940187201481, -1762.6185817026353, -2012.8449522583321,
    -2246.1128553647677, -2461.630204681876, -2660.1091504086976,
    -2840.6380233627783, -3004.9168176028256, -3152.687763133486,
    -3285.4984562683535, -3404.1419855160802, -3509.4497572395449,
    -3602.9695207916761, -3685.0697485410315, -3757.384344138969,
    -3820.3199560922226, -3875.0749770388225, -3922.4285080190448,
    -3962.92567093531, -3997.6331709457413, -4026.7048724657375,
    -4051.166944800957, -4071.163604769305, -4087.3389384884726,
    -4100.1840874465524, -4109.7518536695961, -4116.9263959166,
    -4121.293024088649, -4123.8494221052224, -4123.7062027834227,
    -4123.0255801721087, -4120.2572320147165, -4116.1547821471395,
    -4110.7836398307254, -4104.5072747269587, -4097.2120778659655,
    -4089.1662784588416, -4080.3824795027258, -4070.9678905322467,
    -4061.0272014956668, -4050.578529247774, -4039.7489232096041,
    -4028.5456803455145, -4017.0490292498885, -4005.291520839769,
    -3993.3171649190249, -3981.1715267655718, -3968.8680506855421,
    -3956.4572337807449, -3943.9482461799607, -3931.3740056314796,
    -3918.7546992382986, -3906.1121600986166, -3893.4622885795429,
    -3880.810610321711, -3868.1854281760357, -3855.5898270473008,
    -3843.0337794304751, -3830.5282406969081, -3818.0820806308579,
    -3805.7065490569494, -3793.4042472044503, -3781.1806767821731,
    -3769.0390171951403, -3756.9893694839748, -3745.0326515097831,
    3821.2437889587004, 3833.4414057951062, 3845.7336298598293,
    3858.1196878650617, 3870.5892354197549, 3883.1390430670954,
    3895.7632627967532, 3908.4592178575272, 3921.2153166274184,
    3934.0226857363687, 3946.8704092214657, 3959.7479756538478,
    3972.652142244589, 3985.5540382301292, 3998.448055860109, 4011.3181498079093,
    4024.1418695687871, 4036.8984755939732, 4049.5543120651241,
    4062.0999931359747, 4074.4843273987503, 4086.6935147576987,
    4098.6807451063814, 4110.4010919014772, 4121.8212608510448,
    4132.859556072317, 4143.5086374986186, 4153.6385670388327,
    4163.2308973847375, 4172.1787003185354, 4180.3723562693631,
    4187.7991097622125, 4194.1851460405587, 4199.6472124648217,
    4203.8143308975259, 4206.6171100521688, 4207.2792145093972,
    4207.4131610443974, 4204.7804941092436, 4200.2936271951758,
    4192.9456896635493, 4183.1532690761615, 4170.0160376350605,
    4153.4789638145539, 4133.0414395559383, 4108.0465461784, 4078.3467043293417,
    4042.8954870819011, 4001.53585202395, 3953.1800685834055, 3897.2719722045008,
    3833.0171138580849, 3759.1934883081663, 3675.3868897753973,
    3579.9317105675827, 3472.4521726789662, 3351.370888118624,
    3215.8413508634549, 3065.0554336215791, 2897.4360436094753, 2713.24770054249,
    2510.7587571069939, 2290.8999062000225, 2052.9463898202357,
    1797.7065874996661, 1526.7174603014382, 1240.2937956430246,
    942.82763220277093, 634.39977443565783, 315.03379328843357, 0.0,
    -315.03379328843357, -634.39977443565783, -942.82763220276752,
    -1240.2937956430246, -1526.7174603014414, -1797.7065874996661,
    -2052.9463898202357, -2290.8999062000225, -2510.7587571069939,
    -2713.2477005424921, -2897.4360436094753, -3065.0554336215791,
    -3215.8413508634549, -3351.370888118624, -3472.4521726789662,
    -3579.9317105675827, -3675.3868897753973, -3759.1934883081663,
    -3833.0171138580849, -3897.2719722045008, -3953.180068583405,
    -4001.5358520239497, -4042.8954870819011, -4078.3467043293417,
    -4108.0465461784, -4133.0414395559383, -4153.4789638145539,
    -4170.0160376350605, -4183.1532690761615, -4192.9456896635493,
    -4200.2936271951758, -4204.7804941092436, -4207.4131610443974,
    -4207.2792145093972, -4206.6171100521688, -4203.8143308975259,
    -4199.6472124648217, -4194.1851460405587, -4187.7991097622125,
    -4180.3723562693631, -4172.1787003185354, -4163.2308973847375,
    -4153.6385670388327, -4143.5086374986186, -4132.859556072317,
    -4121.8212608510448, -4110.4010919014772, -4098.6807451063814,
    -4086.6935147576987, -4074.4843273987503, -4062.0999931359747,
    -4049.5543120651241, -4036.8984755939732, -4024.1418695687867,
    -4011.3181498079089, -3998.4480558601094, -3985.5540382301292,
    -3972.6521422445885, -3959.7479756538478, -3946.8704092214657,
    -3934.0226857363687, -3921.2153166274184, -3908.4592178575272,
    -3895.7632627967532, -3883.1390430670949, -3870.5892354197549,
    -3858.1196878650617, -3845.7336298598293, -3833.4414057951062,
    -3821.2437889587004, 3897.4549264088337, 3909.893442104209,
    3922.4282425244796, 3935.0586989480389, 3947.7742236353665,
    3960.5715370795278, 3973.4444449620978, 3986.3901950200989,
    3999.3968538211411, 4012.4555444254111, 4025.5553902710949,
    4038.6853409832256, 4051.8419959130151, 4064.9959163579988,
    4078.1414124829603, 4091.2622939893331, 4104.335492954745,
    4117.3397174153133, 4130.2405734345411, 4143.0284595088833,
    4155.6514898836049, 4168.095508684698, 4180.3124609743782,
    4192.2565034439631, 4203.8935985089438, 4215.1405828838579,
    4225.9900735620167, 4236.3092435566068, 4246.07931532416, 4255.1911223786692,
    4263.5326345302174, 4271.0909454729062, 4277.5866526776308,
    4283.1396465322114, 4287.3714770814722, 4290.2086682742793,
    4290.8521551163476, 4290.9768994941433, 4288.2679547713005,
    4283.6608665580625, 4276.1395256172909, 4266.1224523530555,
    4252.6931365745586, 4235.7943231087884, 4214.9159345711432,
    4189.3882198082165, 4159.0602379359525, 4122.8653030694159,
    4080.6431961489311, 4031.2851600853046, 3974.2239883020211,
    3908.6498836820556, 3833.31722794668, 3747.8042588993026, 3650.4136637623546,
    3540.7623598829055, 3417.2433199346278, 3278.9949385520986,
    3125.1940497753176, 2954.2340636812032, 2766.3862508527327,
    2559.8873093629386, 2335.6869571414809, 2093.0478273658064,
    1832.7945932897185, 1556.4947335207298, 1264.4704132311986,
    961.19617769970512, 646.75472885217187, 321.169727942071, 0.0,
    -321.169727942071, -646.75472885217187, -961.19617769970182,
    -1264.4704132311986, -1556.494733520733, -1832.7945932897185,
    -2093.0478273658064, -2335.6869571414809, -2559.8873093629386,
    -2766.3862508527345, -2954.2340636812032, -3125.1940497753176,
    -3278.9949385520986, -3417.2433199346278, -3540.7623598829055,
    -3650.4136637623546, -3747.8042588993026, -3833.31722794668,
    -3908.6498836820556, -3974.2239883020211, -4031.2851600853046,
    -4080.6431961489307, -4122.8653030694159, -4159.0602379359525,
    -4189.3882198082165, -4214.9159345711423, -4235.7943231087884,
    -4252.6931365745577, -4266.1224523530555, -4276.1395256172909,
    -4283.6608665580616, -4288.2679547713005, -4290.9768994941433,
    -4290.8521551163476, -4290.2086682742793, -4287.3714770814722,
    -4283.1396465322114, -4277.5866526776308, -4271.0909454729062,
    -4263.5326345302174, -4255.1911223786692, -4246.07931532416,
    -4236.3092435566068, -4225.9900735620167, -4215.1405828838579,
    -4203.8935985089438, -4192.2565034439631, -4180.3124609743782,
    -4168.095508684698, -4155.6514898836049, -4143.0284595088833,
    -4130.2405734345411, -4117.3397174153133, -4104.335492954745,
    -4091.2622939893331, -4078.1414124829603, -4064.9959163579992,
    -4051.8419959130147, -4038.6853409832256, -4025.5553902710944,
    -4012.4555444254111, -3999.3968538211411, -3986.3901950200989,
    -3973.4444449620978, -3960.5715370795274, -3947.7742236353665,
    -3935.0586989480389, -3922.4282425244796, -3909.893442104209,
    -3897.4549264088337, 3973.6660638601152, 3986.3454784114006,
    3999.1228551890945, 4011.9977100311007, 4024.9592118512678,
    4038.0040310941185, 4051.1256271269253, 4064.3211721845141,
    4077.5783910118266, 4090.8884031144275, 4104.240371324684,
    4117.6227063100005, 4131.0318495846323, 4144.4377944824319,
    4157.834769106792, 4171.2064381754717, 4184.5291163379979,
    4197.7809592443145, 4210.9268347943607, 4223.9569258841575,
    4236.8186523733048, 4249.4975026202637, 4261.9441768532561,
    4274.1119149737169, 4285.9659361824133, 4297.4216096831187,
    4308.4715096825985, 4318.9799200850375, 4328.9277333179371,
    4338.2035446290092, 4346.692912656009, 4354.3827818259315,
    4360.9881597267768, 4366.6320841823672, 4370.928669556034, 4373.800254176911,
    4374.4250262687337, 4374.5406374896884, 4371.7554067484516,
    4367.0281134193428, 4359.3333615222209, 4349.091637167402,
    4335.3702353199869, 4318.1096826356161, 4296.7904298304829,
    4270.7298933599914, 4239.7737717519576, 4202.83511890737, 4159.7505403866971,
    4109.3902515470609, 4051.1760043855775, 3984.28265360468, 3907.4409674640769,
    3820.2216281551423, 3720.8956168316149, 3609.0725471254482,
    3483.115751718351, 3342.1485262017372, 3185.3326660562575,
    3011.0320835879552, 2819.5248013292821, 2609.0158614593447,
    2380.4740081830473, 2133.149264895972, 1867.8825990731505,
    1586.2720068526046, 1288.6470308040184, 979.56472328417749, 659.109683279643,
    327.30566275251681, 0.0, -327.30566275251681, -659.109683279643,
    -979.56472328417408, -1288.6470308040184, -1586.2720068526078,
    -1867.8825990731505, -2133.149264895972, -2380.4740081830473,
    -2609.0158614593447, -2819.5248013292844, -3011.0320835879552,
    -3185.3326660562575, -3342.1485262017372, -3483.115751718351,
    -3609.0725471254482, -3720.8956168316149, -3820.2216281551423,
    -3907.4409674640769, -3984.28265360468, -4051.1760043855775,
    -4109.39025154706, -4159.7505403866971, -4202.83511890737,
    -4239.7737717519576, -4270.7298933599914, -4296.790429830482,
    -4318.1096826356161, -4335.3702353199869, -4349.091637167402,
    -4359.3333615222209, -4367.0281134193428, -4371.7554067484516,
    -4374.5406374896884, -4374.4250262687337, -4373.800254176911,
    -4370.928669556034, -4366.6320841823672, -4360.9881597267768,
    -4354.3827818259315, -4346.692912656009, -4338.2035446290092,
    -4328.9277333179371, -4318.9799200850375, -4308.4715096825985,
    -4297.4216096831187, -4285.9659361824133, -4274.1119149737169,
    -4261.9441768532561, -4249.4975026202637, -4236.8186523733048,
    -4223.9569258841575, -4210.9268347943607, -4197.7809592443145,
    -4184.5291163379979, -4171.2064381754717, -4157.834769106792,
    -4144.4377944824319, -4131.0318495846323, -4117.6227063100005,
    -4104.240371324684, -4090.8884031144275, -4077.5783910118266,
    -4064.3211721845141, -4051.1256271269253, -4038.0040310941181,
    -4024.9592118512678, -4011.9977100311007, -3999.1228551890945,
    -3986.3454784114006, -3973.6660638601152, 4049.8772013124785,
    4062.7975147167858, 4075.8174678536748, 4088.9367211142417,
    4102.1442000674433, 4115.4365251107456, 4128.8068092912627,
    4142.2521493506683, 4155.7599281996436, 4169.32126180342, 4182.9253523820162,
    4196.5600716343188, 4210.2217032592634, 4223.8796726036171,
    4237.528125731551, 4251.1505823660646, 4264.7227397186907,
    4278.2222010805554, 4291.613096145109, 4304.885392261669, 4317.9858148675876,
    4330.8994965639276, 4343.5758927424295, 4355.9673264914254,
    4368.038273870623, 4379.7026364707681, 4390.9529458573315,
    4401.6505966236282, 4411.7761513632277, 4421.2159670600067,
    4429.8531906537019, 4437.6746187903072, 4444.3896671734692,
    4450.1245252581084, 4454.4859073363477, 4457.3918671189149,
    4457.997829579479, 4458.1043750629588, 4455.2428506511933,
    4450.3953672483522, 4442.5271973715044, 4432.0608234189122, 4418.0473338833,
    4400.4250423800513, 4378.66492531917, 4352.0715668381672, 4320.4873057648319,
    4282.8049346045364, 4238.8578847305325, 4187.4953429710131,
    4128.1280204559089, 4059.9154236202376, 3981.564706867292,
    3892.6389975353018, 3791.3775697825272, 3677.3827344043348,
    3548.9881834716266, 3405.3021138145191, 3245.4712824572002,
    3067.8301033389785, 2872.6633519627621, 2658.144413405128,
    2425.2610593190821, 2173.2507024115903, 1902.9706048502951,
    1616.0492802908122, 1312.8236483623216, 997.93326895134373,
    671.46463771746494, 333.44159771109395, 0.0, -333.44159771109395,
    -671.46463771746494, -997.93326895134032, -1312.8236483623216,
    -1616.0492802908154, -1902.9706048502951, -2173.2507024115903,
    -2425.2610593190821, -2658.144413405128, -2872.6633519627644,
    -3067.8301033389785, -3245.4712824572002, -3405.3021138145191,
    -3548.9881834716266, -3677.3827344043348, -3791.3775697825272,
    -3892.6389975353018, -3981.564706867292, -4059.9154236202376,
    -4128.1280204559089, -4187.4953429710131, -4238.8578847305316,
    -4282.8049346045364, -4320.4873057648319, -4352.0715668381672,
    -4378.664925319169, -4400.4250423800513, -4418.0473338833,
    -4432.0608234189122, -4442.5271973715044, -4450.3953672483512,
    -4455.2428506511924, -4458.1043750629588, -4457.997829579479,
    -4457.3918671189149, -4454.4859073363477, -4450.1245252581084,
    -4444.3896671734692, -4437.6746187903072, -4429.8531906537019,
    -4421.2159670600067, -4411.7761513632277, -4401.6505966236282,
    -4390.9529458573315, -4379.7026364707681, -4368.038273870623,
    -4355.9673264914254, -4343.5758927424295, -4330.8994965639276,
    -4317.9858148675876, -4304.885392261669, -4291.613096145109,
    -4278.2222010805554, -4264.7227397186907, -4251.1505823660646,
    -4237.5281257315519, -4223.8796726036171, -4210.2217032592625,
    -4196.5600716343188, -4182.9253523820153, -4169.32126180342,
    -4155.7599281996436, -4142.2521493506683, -4128.8068092912627,
    -4115.4365251107447, -4102.1442000674433, -4088.9367211142417,
    -4075.8174678536748, -4062.7975147167858, -4049.8772013124785,
    4126.088338765866, 4139.2495510204653, 4152.5120805182223,
    4165.8757321974572, 4179.3291882838757, 4192.8690191292981,
    4206.4879914551384, 4220.1831265184674, 4233.9414653847489,
    4247.7541204923918, 4261.6103334428844, 4275.4974369563115,
    4289.411556936745, 4303.3215507217328, 4317.2214823571867, 4331.094726560872,
    4344.916363096967, 4358.6634429236492, 4372.299357487278, 4385.8138586412979,
    4399.1529773662105, 4412.3014905152595, 4425.20760864136, 4437.82273799773,
    4450.1106115728035, 4461.9836632474253, 4473.4343820833938,
    4484.3212731719095, 4494.6245694573863, 4504.228389662745,
    4513.0134685297926, 4520.9664563370125, 4527.7911750037929,
    4533.616969611312, 4538.0431894626272, 4540.9835064787439, 4541.57056661195,
    4541.6681122429609, 4538.7302870341127, 4533.7626275633165,
    4525.7210331597807, 4515.0300110158305, 4500.724432275485,
    4482.7404023283616, 4460.5394210235872, 4433.4132402468549,
    4401.2008399630258, 4362.7747501690174, 4317.9652291742486,
    4265.6004343593286, 4205.0800365137047, 4135.5481937234426,
    4055.6884461627396, 3965.0563670327419, 3861.8595226217212,
    3745.6929217174788, 3614.860615196154, 3468.4557013924391, 3305.609898971481,
    3124.6281229428414, 2925.8019027444861, 2707.2729652085523,
    2470.0481105443628, 2213.3521399134561, 1938.0586106214641,
    1645.8265538295582, 1337.0002659068864, 1016.3018146967115,
    683.81959216507516, 339.57753280975436, 0.0, -339.57753280975436,
    -683.81959216507516, -1016.3018146967079, -1337.0002659068864,
    -1645.8265538295614, -1938.0586106214641, -2213.3521399134561,
    -2470.0481105443628, -2707.2729652085523, -2925.8019027444884,
    -3124.6281229428414, -3305.609898971481, -3468.4557013924391,
    -3614.860615196154, -3745.6929217174788, -3861.8595226217212,
    -3965.0563670327419, -4055.6884461627396, -4135.5481937234426,
    -4205.0800365137047, -4265.6004343593286, -4317.9652291742486,
    -4362.7747501690174, -4401.2008399630258, -4433.4132402468549,
    -4460.5394210235863, -4482.7404023283616, -4500.724432275485,
    -4515.0300110158305, -4525.7210331597807, -4533.7626275633156,
    -4538.7302870341118, -4541.6681122429609, -4541.57056661195,
    -4540.9835064787439, -4538.0431894626272, -4533.616969611312,
    -4527.7911750037929, -4520.9664563370125, -4513.0134685297926,
    -4504.228389662745, -4494.6245694573863, -4484.3212731719095,
    -4473.4343820833938, -4461.9836632474253, -4450.1106115728035,
    -4437.82273799773, -4425.20760864136, -4412.3014905152595,
    -4399.1529773662105, -4385.8138586412979, -4372.299357487278,
    -4358.6634429236492, -4344.916363096967, -4331.094726560872,
    -4317.2214823571867, -4303.3215507217337, -4289.4115569367441,
    -4275.4974369563115, -4261.6103334428844, -4247.7541204923918,
    -4233.9414653847489, -4220.1831265184674, -4206.4879914551384,
    -4192.8690191292981, -4179.3291882838757, -4165.8757321974572,
    -4152.5120805182223, -4139.2495510204653, -4126.088338765866,
    4202.2994762202225, 4215.7015873225319, 4229.2066931827412,
    4242.8147432807446, 4256.5141765005537, 4270.3015131496732,
    4284.1691736185767, 4298.1141036878244, 4312.1230025672894,
    4326.1869791813415, 4340.2953145071015, 4354.434802276106,
    4368.6014106169241, 4382.7634288369418, 4396.9148389836528, 4411.03887075967,
    4425.1099864729513, 4439.1046847732314, 4452.98561882132, 4466.742325022934,
    4480.3201398689462, 4493.7034844738555, 4506.8393245495417,
    4519.6781494932247, 4532.1829492882371, 4544.2646900136679,
    4555.9158183581549, 4566.9919497294413, 4577.4729875979419,
    4587.2408124288795, 4596.1737462903448, 4604.25829443883, 4611.1926832044128,
    4617.1094171022642, 4621.6005149995735, 4624.5751716537179,
    4625.143238881843, 4625.2318490561, 4622.2177164021441, 4617.12989392585,
    4608.9148688829036, 4597.9991998740434, 4583.4015305066678,
    4565.0557624679477, 4542.4139169311738, 4514.7549135898671,
    4481.9143743358754, 4442.7445656083009, 4397.0725737121265,
    4343.7055257140082, 4282.0320525596053, 4211.1809639094, 4129.8121853563625,
    4037.4737366409445, 3932.3414753553393, 3814.00310906295, 3680.7330468935061,
    3531.60928893735, 3365.7485155929207, 3181.4261424074953, 2978.9404536663969,
    2756.401516877288, 2514.8351618540451, 2253.4535774023097,
    1973.1466163869502, 1675.6038274634607, 1361.1768834384361,
    1034.6703605161074, 696.17454662195144, 345.713468041022, 0.0,
    -345.713468041022, -696.17454662195144, -1034.6703605161038,
    -1361.1768834384361, -1675.6038274634641, -1973.1466163869502,
    -2253.4535774023097, -2514.8351618540451, -2756.401516877288,
    -2978.9404536663992, -3181.4261424074953, -3365.7485155929207,
    -3531.60928893735, -3680.7330468935061, -3814.00310906295,
    -3932.3414753553393, -4037.4737366409445, -4129.8121853563625,
    -4211.1809639094, -4282.0320525596053, -4343.7055257140073,
    -4397.0725737121256, -4442.7445656083009, -4481.9143743358754,
    -4514.7549135898671, -4542.4139169311738, -4565.0557624679477,
    -4583.4015305066678, -4597.9991998740434, -4608.9148688829036,
    -4617.12989392585, -4622.2177164021441, -4625.2318490561, -4625.143238881843,
    -4624.5751716537179, -4621.6005149995735, -4617.1094171022642,
    -4611.1926832044128, -4604.25829443883, -4596.1737462903448,
    -4587.2408124288795, -4577.4729875979419, -4566.9919497294413,
    -4555.9158183581549, -4544.2646900136679, -4532.1829492882371,
    -4519.6781494932247, -4506.8393245495417, -4493.7034844738555,
    -4480.3201398689462, -4466.742325022934, -4452.98561882132,
    -4439.1046847732314, -4425.1099864729513, -4411.03887075967,
    -4396.9148389836528, -4382.7634288369427, -4368.6014106169232,
    -4354.434802276106, -4340.2953145071015, -4326.1869791813415,
    -4312.1230025672894, -4298.1141036878244, -4284.1691736185776,
    -4270.3015131496722, -4256.5141765005537, -4242.8147432807446,
    -4229.2066931827412, -4215.7015873225319, -4202.2994762202225,
    4278.5106136754966, 4292.1536236230695, 4305.901305847231,
    4319.7537543640992, 4333.6991647174646, 4347.7340071717745,
    4361.850355781602, 4376.0450808586547, 4390.3045397473979,
    4404.6198378702711, 4418.98029557449, 4433.372167593815, 4447.7912642996589,
    4462.2053069493986, 4476.6081956109065, 4490.9830149622521,
    4505.3036098467655, 4519.5459266289663, 4533.6718801476572,
    4547.6707914064737, 4561.4873023755845, 4575.1054784393418,
    4588.4710404665047, 4601.5335609784661, 4614.2552870162572,
    4626.5457167700361, 4638.3972546791638, 4649.6626262958071,
    4660.3214057825908, 4670.2532353505994, 4679.3340239410245,
    4687.5501330702145, 4694.5941917625632, 4700.6018675990827,
    4705.1578830357867, 4708.1668620593082, 4708.7158478589863,
    4708.7955855264709, 4705.7051392160074, 4700.4971659361881,
    4692.1087045377435, 4680.968389916301, 4666.0786285861877,
    4647.3711227872209, 4624.2884130303273, 4596.0965868707417,
    4562.6279088735209, 4522.7143809293239, 4476.1799183388739,
    4421.8106170369028, 4358.984068594209, 4286.8137341735764,
    4203.9359244536736, 4109.8911063538662, 4002.823427989083,
    3882.3132964389611, 3746.6054785651459, 3594.7628764509759,
    3425.8871323157805, 3238.2241617403283, 3032.0790047210121,
    2805.5300684184649, 2559.6222132436287, 2293.5550148788366,
    2008.2346221470254, 1705.381101187515, 1385.353500957644, 1053.0389064056499,
    708.529501087608, 351.84940339794429, 0.0, -351.84940339794429,
    -708.529501087608, -1053.038906405646, -1385.353500957644,
    -1705.3811011875184, -2008.2346221470254, -2293.5550148788366,
    -2559.6222132436287, -2805.5300684184649, -3032.0790047210144,
    -3238.2241617403283, -3425.8871323157805, -3594.7628764509759,
    -3746.6054785651459, -3882.3132964389611, -4002.823427989083,
    -4109.8911063538662, -4203.9359244536736, -4286.8137341735764,
    -4358.984068594209, -4421.8106170369019, -4476.1799183388739,
    -4522.7143809293239, -4562.6279088735209, -4596.0965868707417,
    -4624.2884130303264, -4647.3711227872209, -4666.0786285861877,
    -4680.968389916301, -4692.1087045377444, -4700.4971659361881,
    -4705.7051392160074, -4708.7955855264709, -4708.7158478589863,
    -4708.1668620593082, -4705.1578830357867, -4700.6018675990827,
    -4694.5941917625632, -4687.5501330702145, -4679.3340239410245,
    -4670.2532353505994, -4660.3214057825908, -4649.6626262958071,
    -4638.3972546791638, -4626.5457167700361, -4614.2552870162572,
    -4601.5335609784661, -4588.4710404665047, -4575.1054784393418,
    -4561.4873023755845, -4547.6707914064737, -4533.6718801476572,
    -4519.5459266289663, -4505.3036098467646, -4490.9830149622512,
    -4476.6081956109065, -4462.2053069493986, -4447.7912642996589,
    -4433.372167593815, -4418.98029557449, -4404.6198378702711,
    -4390.3045397473988, -4376.0450808586547, -4361.850355781603,
    -4347.7340071717736, -4333.6991647174646, -4319.7537543640992,
    -4305.901305847231, -4292.1536236230695, -4278.5106136754966,
    4354.7217511316376, 4368.6056599221565, 4382.5959185116917,
    4396.6927654475176, 4410.8841529345937, 4425.16650119551, 4439.5315379442345,
    4453.9760580308839, 4468.4860769252036, 4483.0526965591816,
    4497.665276644886, 4512.3095329095495, 4526.98111798482, 4541.6471850592434,
    4556.3015522389051, 4570.927159168421, 4585.49723321852, 4599.9871684905411,
    4614.358141466686, 4628.5992577918187, 4642.6544648859272,
    4656.5074724113674, 4670.1027563918124, 4683.3889724539695,
    4696.327624756238, 4708.8267435170292, 4720.8786910441268,
    4732.3333028706184, 4743.1698240091782, 4753.2656584205852,
    4762.4943014871351, 4770.841972207164, 4777.9957006660088,
    4784.0943209771649, 4788.715292683165, 4791.75857712847, 4792.2883949690668,
    4792.3593216761046, 4789.1925558969388, 4783.8644432290175,
    4775.302540122012, 4763.9375810715374, 4748.7557265226787,
    4729.6864832755136, 4706.1629093103093, 4677.4382600927684,
    4643.3414435668319, 4602.6841961385217, 4555.2872630495922,
    4499.9157083297359, 4435.9360846180762, 4362.4465045117595,
    4278.059663459795, 4182.3084761658947, 4073.3053805282498, 3950.623483843854,
    3812.4779102124312, 3657.9164639349228, 3486.0257491347238,
    3295.0221809482155, 3085.2175559013717, 2854.6586198387167,
    2604.4092647089269, 2333.6564523436755, 2043.3226279019461,
    1735.1583749970619, 1409.5301184651385, 1071.4074523617242,
    720.88445556159218, 357.98533887404574, 0.0, -357.98533887404574,
    -720.88445556159218, -1071.4074523617205, -1409.5301184651385,
    -1735.1583749970655, -2043.3226279019461, -2333.6564523436755,
    -2604.4092647089269, -2854.6586198387167, -3085.217555901374,
    -3295.0221809482155, -3486.0257491347238, -3657.9164639349228,
    -3812.4779102124312, -3950.623483843854, -4073.3053805282498,
    -4182.3084761658947, -4278.059663459795, -4362.4465045117595,
    -4435.9360846180762, -4499.915708329735, -4555.2872630495922,
    -4602.6841961385217, -4643.3414435668319, -4677.4382600927684,
    -4706.1629093103093, -4729.6864832755136, -4748.7557265226787,
    -4763.9375810715374, -4775.302540122012, -4783.8644432290175,
    -4789.1925558969388, -4792.3593216761046, -4792.2883949690668,
    -4791.75857712847, -4788.715292683165, -4784.0943209771649,
    -4777.9957006660088, -4770.841972207164, -4762.4943014871351,
    -4753.2656584205852, -4743.1698240091782, -4732.3333028706184,
    -4720.8786910441268, -4708.8267435170292, -4696.327624756238,
    -4683.3889724539695, -4670.1027563918124, -4656.5074724113674,
    -4642.6544648859272, -4628.5992577918187, -4614.358141466686,
    -4599.9871684905411, -4585.49723321852, -4570.927159168421,
    -4556.301552238906, -4541.6471850592434, -4526.98111798482,
    -4512.3095329095495, -4497.665276644886, -4483.0526965591816,
    -4468.4860769252036, -4453.9760580308848, -4439.5315379442345,
    -4425.1665011955092, -4410.8841529345937, -4396.6927654475176,
    -4382.5959185116917, -4368.6056599221565, -4354.7217511316376,
    4428.7168527709537, 4442.8318718538985, 4457.0546153099858,
    4471.3852667318615, 4485.8117237587685, 4500.330413170258,
    4514.9326074633591, 4529.6150366317524, 4544.3634856061381, 4559.16894985522,
    4574.0207194056338, 4588.9039932788291, 4603.8142559886928,
    4618.7183116335427, 4633.6097920229849, 4648.47094164179, 4663.2747344981217,
    4677.9963741065276, 4692.5959948053332, 4707.0624390996845, 4721.33879558428,
    4735.4084563133893, 4749.2147261898917, 4762.7053270879242,
    4775.8410751067477, 4788.5283250064267, 4800.7594332063381,
    4812.3813675295269, 4823.3730962428253, 4833.6096121875607,
    4842.9621685940683, 4851.4174450664641, 4858.6555351510233, 4864.81936104829,
    4869.4807991644811, 4872.5305678129771, 4873.0014930700972,
    4873.0499736974452, 4869.7790985162865, 4864.2960640274177,
    4855.5328897788586, 4843.9136937688054, 4828.41104441058, 4808.9516071063772,
    4784.9595672243086, 4755.6757516483631, 4720.9256251785609,
    4679.5021200018809, 4631.2226414735242, 4574.8327101076957,
    4509.6882946306869, 4434.873312379782, 4348.9786617130576,
    4251.5303210358088, 4140.6117062964931, 4015.7896633619021,
    3875.2525577435085, 3718.0349542610847, 3543.2107717344347,
    3348.9707289227208, 3135.6337735188804, 2901.2190928170789,
    2646.8094751952553, 2371.5819373248769, 2076.4756083995767,
    1763.2693863646123, 1432.3372088426197, 1088.724283506222,
    732.52700145717847, 363.76911545348764, 0.0, -363.76911545348764,
    -732.52700145717847, -1088.7242835062182, -1432.3372088426197,
    -1763.2693863646157, -2076.4756083995767, -2371.5819373248769,
    -2646.8094751952553, -2901.2190928170789, -3135.6337735188827,
    -3348.9707289227208, -3543.2107717344347, -3718.0349542610847,
    -3875.2525577435085, -4015.7896633619021, -4140.6117062964931,
    -4251.5303210358088, -4348.9786617130576, -4434.873312379782,
    -4509.6882946306869, -4574.8327101076948, -4631.2226414735233,
    -4679.5021200018809, -4720.9256251785609, -4755.6757516483631,
    -4784.9595672243086, -4808.9516071063763, -4828.41104441058,
    -4843.9136937688054, -4855.5328897788586, -4864.2960640274177,
    -4869.7790985162865, -4873.0499736974452, -4873.0014930700972,
    -4872.5305678129771, -4869.4807991644811, -4864.81936104829,
    -4858.6555351510233, -4851.4174450664641, -4842.9621685940683,
    -4833.6096121875617, -4823.3730962428253, -4812.3813675295269,
    -4800.7594332063381, -4788.5283250064267, -4775.8410751067477,
    -4762.7053270879242, -4749.2147261898917, -4735.4084563133893,
    -4721.33879558428, -4707.0624390996845, -4692.5959948053332,
    -4677.9963741065276, -4663.2747344981217, -4648.47094164179,
    -4633.6097920229859, -4618.7183116335427, -4603.8142559886928,
    -4588.9039932788291, -4574.0207194056338, -4559.16894985522,
    -4544.3634856061381, -4529.6150366317524, -4514.9326074633591,
    -4500.330413170258, -4485.8117237587685, -4471.3852667318615,
    -4457.0546153099858, -4442.8318718538985, -4428.7168527709537,
    4501.3058329608348, 4515.6457512955849, 4530.0945763441123,
    4544.6523101785242, 4559.3069156476, 4574.0548620097061, 4588.8868974272955,
    4603.799693815643, 4618.7788761734591, 4633.815268180143, 4648.8980210022746,
    4664.0118310449807, 4679.1520082071547, 4694.2851463807565,
    4709.404624899571, 4724.4916439626868, 4739.5191553589366,
    4754.4624014840665, 4769.280281624965, 4783.9613450949491, 4798.4477171323,
    4812.7224966336926, 4826.7278639852248, 4840.4105965620347,
    4853.7308576203495, 4866.593193970235, 4878.9899803816143,
    4890.7653296926946, 4901.8979678886562, 4912.2603666875111,
    4921.721643941305, 4930.2693311795683, 4937.5757209859185,
    4943.7884399445784, 4948.4751273804914, 4951.5135856491243,
    4951.8997045936694, 4951.9175908888828, 4948.5249300488094,
    4942.864988137303, 4933.88284521939, 4921.990642518962, 4906.1489780492739,
    4886.2812929027459, 4861.8032730649875, 4831.9435739751907,
    4796.5241674526269, 4754.3201015522873, 4705.1453410014419,
    4647.7268016468415, 4581.4101601616976, 4505.2658700206475,
    4417.8641837929317, 4318.7245386114755, 4205.90302921221, 4078.9609038685926,
    3936.0615957711116, 3776.2276111528936, 3598.521677240617,
    3401.1112265612255, 3184.3226139155149, 2946.1500650963621,
    2687.6951852073971, 2408.1267344954804, 2108.4007746451839,
    1790.3231195776395, 1454.2753052555254, 1105.3737798737748,
    743.71750914432585, 369.3294405878753, 0.0, -369.3294405878753,
    -743.71750914432585, -1105.3737798737709, -1454.2753052555254,
    -1790.323119577643, -2108.4007746451839, -2408.1267344954804,
    -2687.6951852073971, -2946.1500650963621, -3184.3226139155176,
    -3401.1112265612255, -3598.521677240617, -3776.2276111528936,
    -3936.0615957711116, -4078.9609038685926, -4205.90302921221,
    -4318.7245386114755, -4417.8641837929317, -4505.2658700206475,
    -4581.4101601616976, -4647.7268016468415, -4705.1453410014419,
    -4754.3201015522873, -4796.5241674526269, -4831.9435739751907,
    -4861.8032730649875, -4886.2812929027459, -4906.1489780492739,
    -4921.990642518962, -4933.88284521939, -4942.8649881373021,
    -4948.5249300488094, -4951.9175908888828, -4951.8997045936694,
    -4951.5135856491243, -4948.4751273804914, -4943.7884399445784,
    -4937.5757209859185, -4930.2693311795683, -4921.721643941305,
    -4912.2603666875111, -4901.8979678886562, -4890.7653296926946,
    -4878.9899803816143, -4866.593193970235, -4853.7308576203495,
    -4840.4105965620347, -4826.7278639852248, -4812.7224966336926,
    -4798.4477171323, -4783.9613450949491, -4769.280281624965,
    -4754.4624014840665, -4739.5191553589366, -4724.4916439626868,
    -4709.404624899571, -4694.2851463807565, -4679.1520082071547,
    -4664.0118310449807, -4648.8980210022746, -4633.8152681801439,
    -4618.7788761734591, -4603.799693815643, -4588.8868974272955,
    -4574.0548620097061, -4559.3069156476, -4544.6523101785242,
    -4530.0945763441123, -4515.6457512955849, -4501.3058329608348,
    4573.8948131537345, 4588.4596307404108, 4603.1345373757513,
    4617.9193536230941, 4632.8021075351853, 4647.7793108601836,
    4662.8411873839195, 4677.9843510050978, 4693.1942667407448,
    4708.4615865015212, 4723.7753226152518, 4739.1196687938073,
    4754.4897604345661, 4769.8519811389233, 4785.1994578015, 4800.5123462608171,
    4815.7635762108357, 4830.9284289118868, 4845.964568405112,
    4860.8602511513263, 4875.5566386651344, 4890.0365370078616,
    4904.2410018382652, 4918.1158659629891, 4931.6206403397064, 4944.65806278434,
    4957.220527964414, 4969.14929193753, 4980.4228399384328, 4990.911122195158,
    5000.4811185551853, 5009.1212235330813, 5016.4959090170923,
    5022.7575460062189, 5027.4699249374007, 5030.4968784330631,
    5030.7972266890674, 5030.7852051928448, 5027.270706369045,
    5021.4339599989689, 5012.2328005864183, 5000.0676004905354,
    4983.8869103322741, 4963.6109804650805, 4938.6469804883527, 4908.21139566876,
    4872.1227111921417, 4829.1380821055682, 4779.0680412737356,
    4720.6208929107343, 4653.1320255694145, 4575.6584283610118,
    4486.7497051233076, 4385.9187570197346, 4271.19435124044, 4142.1321447277423,
    3996.8706335916304, 3834.4202676820018, 3653.8325836465492, 3453.25172323627,
    3233.0114553580365, 2991.0810363870969, 2728.5808957980425,
    2444.671531565989, 2140.325940976345, 1817.3768534280505, 1476.2134015149177,
    1122.0232768075707, 754.90801690234946, 374.88976673658283, 0.0,
    -374.88976673658283, -754.90801690234946, -1122.0232768075668,
    -1476.2134015149177, -1817.3768534280539, -2140.325940976345,
    -2444.671531565989, -2728.5808957980425, -2991.0810363870969,
    -3233.0114553580388, -3453.25172323627, -3653.8325836465492,
    -3834.4202676820018, -3996.8706335916304, -4142.1321447277423,
    -4271.19435124044, -4385.9187570197346, -4486.7497051233076,
    -4575.6584283610118, -4653.1320255694145, -4720.6208929107343,
    -4779.0680412737356, -4829.1380821055682, -4872.1227111921417,
    -4908.21139566876, -4938.6469804883527, -4963.6109804650805,
    -4983.8869103322741, -5000.0676004905354, -5012.2328005864183,
    -5021.4339599989689, -5027.2707063690441, -5030.7852051928448,
    -5030.7972266890674, -5030.4968784330631, -5027.4699249374007,
    -5022.7575460062189, -5016.4959090170923, -5009.1212235330813,
    -5000.4811185551853, -4990.9111221951589, -4980.4228399384328,
    -4969.14929193753, -4957.220527964414, -4944.65806278434,
    -4931.6206403397064, -4918.1158659629891, -4904.2410018382652,
    -4890.0365370078616, -4875.5566386651344, -4860.8602511513263,
    -4845.964568405112, -4830.9284289118868, -4815.7635762108357,
    -4800.5123462608171, -4785.1994578015, -4769.8519811389233,
    -4754.4897604345661, -4739.1196687938073, -4723.7753226152508,
    -4708.4615865015212, -4693.1942667407448, -4677.9843510050978,
    -4662.84118738392, -4647.7793108601827, -4632.8021075351853,
    -4617.9193536230941, -4603.1345373757513, -4588.4596307404108,
    -4573.8948131537345, 4646.4837933495155, 4661.2735101882345,
    4676.1744984050147, 4691.1863970656659, 4706.2972994215806,
    4721.503759721194, 4736.7954773335659, 4752.1690081998686,
    4767.6096573079976, 4783.1079048195106, 4798.6526242438422, 4814.22750652608,
    4829.827512670533, 4845.4188159075693, 4860.9942907276672,
    4876.5330485371869, 4892.0079970542056, 4907.394456387844,
    4922.6488551474786, 4937.7591572662413, 4952.6655601834755,
    4967.3505774336581, 4981.7541397467594, 4995.8211352937815, 5009.51042325678,
    5022.7229314548767, 5035.4510759392779, 5047.5332542622164,
    5058.947712377596, 5069.5618786802133, 5079.2405924616278,
    5087.9731219641026, 5095.4160993039695, 5101.7266788751822,
    5106.4652175854171, 5109.4804600463212, 5109.6940246469048,
    5109.6528168383793, 5106.016431856694, 5100.002975773773, 5090.5827557400507,
    5078.1445670554012, 5061.6248413400281, 5040.940669678188,
    5015.4906894044725, 4984.47921676026, 4947.7212563164967, 4903.95606171372,
    4852.9907422499591, 4793.5149839135256, 4724.8538908588644,
    4646.0509873655437, 4555.63522574063, 4453.1129762190385, 4336.4856724240681,
    4205.30338592143, 4057.6796712149426, 3892.6129238645703, 3709.1434909098725,
    3505.392218991909, 3281.7002977976931, 3036.0120067341963,
    2769.4666069402429, 2481.216328540906, 2172.2511073887381, 1844.430587887452,
    1498.1514976274148, 1138.67277428262, 766.09852472812133, 380.45009385484389,
    0.0, -380.45009385484389, -766.09852472812133, -1138.672774282616,
    -1498.1514976274148, -1844.4305878874559, -2172.2511073887381,
    -2481.216328540906, -2769.4666069402429, -3036.0120067341963,
    -3281.7002977976958, -3505.392218991909, -3709.1434909098725,
    -3892.6129238645703, -4057.6796712149426, -4205.30338592143,
    -4336.4856724240681, -4453.1129762190385, -4555.63522574063,
    -4646.0509873655437, -4724.8538908588644, -4793.5149839135256,
    -4852.9907422499591, -4903.95606171372, -4947.7212563164967,
    -4984.47921676026, -5015.4906894044716, -5040.940669678188,
    -5061.6248413400281, -5078.1445670554012, -5090.5827557400507,
    -5100.0029757737721, -5106.016431856694, -5109.6528168383793,
    -5109.6940246469048, -5109.4804600463212, -5106.4652175854171,
    -5101.7266788751822, -5095.4160993039695, -5087.9731219641026,
    -5079.2405924616278, -5069.5618786802133, -5058.947712377596,
    -5047.5332542622164, -5035.4510759392779, -5022.7229314548767,
    -5009.51042325678, -4995.8211352937815, -4981.7541397467594,
    -4967.3505774336581, -4952.6655601834755, -4937.7591572662423,
    -4922.6488551474786, -4907.394456387844, -4892.0079970542056,
    -4876.5330485371869, -4860.9942907276672, -4845.41881590757,
    -4829.8275126705321, -4814.22750652608, -4798.6526242438422,
    -4783.1079048195106, -4767.6096573079976, -4752.1690081998686,
    -4736.7954773335659, -4721.5037597211931, -4706.2972994215806,
    -4691.1863970656659, -4676.1744984050147, -4661.2735101882345,
    -4646.4837933495155, 4719.07277354805, 4734.0873896389257,
    4749.2144594320107, 4764.4534405063287, 4779.7924913068382,
    4795.2282085922679, 4810.749767276543, 4826.3536653997189,
    4842.0250478752223, 4857.7542231342632, 4873.5299258873656,
    4889.3353442425205, 4905.1652649146845, 4920.98565068625, 4936.7891236770265,
    4952.5537507927411, 4968.25241788941, 4983.8604839099062, 4999.3331418536709,
    5014.6580634372622, 5029.7744816879722, 5044.664617908963,
    5059.2672777085627, 5073.5264045572412, 5087.4002063639437,
    5100.7877999876491, 5113.6816242915156, 5125.91721666497, 5137.4725851922794,
    5148.2126361135643, 5158.0000656853608, 5166.8250263152913,
    5174.3362919016536, 5180.6958381993136, 5185.4610327928212,
    5188.4643453174149, 5188.5900613880913, 5188.5204260309329,
    5184.762110440166, 5178.5720320228584, 5168.9327105670127,
    5156.2215416410108, 5139.3627711467489, 5118.2703604365834,
    5092.3343997300954, 5060.747037278893, 5023.3198027508852,
    4978.7740404251872, 4926.9134438925375, 4866.4090746684069,
    4796.5757560348211, 4716.4435470012531, 4624.5207456790185,
    4520.3071961705618, 4401.77699280326, 4268.4746274329254, 4118.4887086503086,
    3950.8055797158158, 3764.454398990842, 3557.5327138695493,
    3330.3891411887153, 3080.9429761798947, 2810.3523186086977, 2517.76112542447,
    2204.176273878325, 1871.4843229291127, 1520.0895935992594,
    1155.3222722753808, 777.28903261869459, 386.01042190048946, 0.0,
    -386.01042190048946, -777.28903261869459, -1155.3222722753767,
    -1520.0895935992594, -1871.4843229291164, -2204.176273878325,
    -2517.76112542447, -2810.3523186086977, -3080.9429761798947,
    -3330.389141188718, -3557.5327138695493, -3764.454398990842,
    -3950.8055797158158, -4118.4887086503086, -4268.4746274329254,
    -4401.77699280326, -4520.3071961705618, -4624.5207456790185,
    -4716.4435470012531, -4796.5757560348211, -4866.4090746684069,
    -4926.9134438925375, -4978.7740404251872, -5023.3198027508852,
    -5060.747037278893, -5092.3343997300944, -5118.2703604365834,
    -5139.3627711467489, -5156.2215416410118, -5168.9327105670127,
    -5178.5720320228575, -5184.762110440166, -5188.5204260309329,
    -5188.5900613880913, -5188.4643453174149, -5185.4610327928222,
    -5180.6958381993136, -5174.3362919016545, -5166.8250263152913,
    -5158.0000656853608, -5148.2126361135643, -5137.4725851922794,
    -5125.91721666497, -5113.6816242915156, -5100.7877999876491,
    -5087.4002063639437, -5073.5264045572412, -5059.2672777085627,
    -5044.664617908963, -5029.7744816879722, -5014.6580634372622,
    -4999.3331418536709, -4983.8604839099062, -4968.25241788941,
    -4952.5537507927411, -4936.7891236770265, -4920.98565068625,
    -4905.1652649146845, -4889.3353442425205, -4873.5299258873656,
    -4857.7542231342632, -4842.0250478752223, -4826.3536653997189,
    -4810.749767276543, -4795.228208592267, -4779.7924913068382,
    -4764.4534405063287, -4749.2144594320107, -4734.0873896389257,
    -4719.07277354805, 4791.6617537492129, 4806.9012690923546,
    4822.2544204568376, 4837.72048394517, 4853.2876831910107, 4868.9526574729662,
    4884.7040572131436, 4900.5383226044278, 4916.4404384424206,
    4932.4005414459161, 4948.40722754518, 4964.443181943815, 4980.503017166674,
    4996.5524854745418, 5012.5839566485911, 5028.5744530283719,
    5044.4968387167937, 5060.3265114761607, 5076.0174285252078,
    5091.5569696620878, 5106.8834031792367, 5121.9786584317744,
    5136.7804157216442, 5151.2316737560495, 5165.2899896539575,
    5178.8526683881555, 5191.9121730071647, 5204.3011791440358,
    5215.9974583692674, 5226.8633944672229, 5236.7595382499931,
    5245.6769364346383, 5253.2564868611671, 5259.665023632233,
    5264.4573998960732, 5267.44855010409, 5267.4852972580939, 5267.3880329553131,
    5263.5077456532445, 5257.1411256565243, 5247.2826649760536,
    5234.298523724392, 5217.1006998210078, 5195.6000526434937,
    5169.1781113880534, 5137.014857252032, 5098.9183504257908,
    5053.5920182851605, 5000.8361461665236, 4939.3031651876981,
    4868.2976211018158, 4786.8361072372991, 4693.406264970452,
    4587.5014168379739, 4467.068312415674, 4331.645869246594, 4179.2977459064186,
    4008.9982352500811, 3819.7653078521339, 3609.6732079081507,
    3379.0779854880925, 3125.8739447639418, 2851.2380307796288,
    2554.3059222206707, 2236.1014404413258, 1898.5380585278428,
    1542.0276894363469, 1171.9717707636582, 788.47954057129141,
    391.57075083376088, 0.0, -391.57075083376088, -788.47954057129141,
    -1171.9717707636541, -1542.0276894363469, -1898.5380585278467,
    -2236.1014404413258, -2554.3059222206707, -2851.2380307796288,
    -3125.8739447639418, -3379.0779854880952, -3609.6732079081507,
    -3819.7653078521339, -4008.9982352500811, -4179.2977459064186,
    -4331.645869246594, -4467.068312415674, -4587.5014168379739,
    -4693.406264970452, -4786.8361072372991, -4868.2976211018158,
    -4939.3031651876972, -5000.8361461665227, -5053.5920182851605,
    -5098.9183504257908, -5137.014857252032, -5169.1781113880534,
    -5195.6000526434937, -5217.1006998210078, -5234.2985237243929,
    -5247.2826649760545, -5257.1411256565243, -5263.5077456532445,
    -5267.3880329553131, -5267.4852972580939, -5267.44855010409,
    -5264.4573998960732, -5259.665023632233, -5253.2564868611671,
    -5245.6769364346383, -5236.7595382499931, -5226.8633944672229,
    -5215.9974583692683, -5204.3011791440358, -5191.9121730071647,
    -5178.8526683881555, -5165.2899896539575, -5151.2316737560495,
    -5136.7804157216442, -5121.9786584317744, -5106.8834031792367,
    -5091.5569696620878, -5076.0174285252078, -5060.3265114761607,
    -5044.4968387167928, -5028.5744530283719, -5012.5839566485911,
    -4996.5524854745427, -4980.503017166674, -4964.443181943815,
    -4948.40722754518, -4932.400541445917, -4916.4404384424215,
    -4900.5383226044278, -4884.7040572131436, -4868.9526574729653,
    -4853.2876831910107, -4837.72048394517, -4822.2544204568376,
    -4806.9012690923546, -4791.6617537492129, 4864.250733952892,
    4879.7151485484055, 4895.29438147959, 4910.9875273822672, 4926.7828750741437,
    4942.677106362873, 4958.6583471436452, 4974.7229798137869, 4990.855829009598,
    5007.0468597546051, 5023.28452921668, 5039.5510196306059, 5055.8407694261705,
    5072.1193202720506, 5088.378789641436, 5104.5951552449233,
    5120.7412595366814, 5136.7925390847977, 5152.7017151635227,
    5168.4558759385445, 5183.9923246578455, 5199.2926990001952,
    5214.2935537840731, 5228.9369428927484, 5243.1797731199458,
    5256.9175366616018, 5270.14272207294, 5282.6851416976961, 5294.52233189596,
    5305.5141537142763, 5315.5190101780736, 5324.5288521752409,
    5332.1766842296811, 5338.6342348332346, 5343.4375216701128, 5346.42385986216,
    5346.4270621062551, 5346.2413885992064, 5342.2393902809927,
    5335.710253891084, 5325.6326188941821, 5312.3755128269131,
    5294.8386274262575, 5272.9297462099848, 5246.0218243067065,
    5213.2826767053548, 5174.5168992765293, 5128.4099953358445,
    5074.7588490393637, 5012.1972554829163, 4940.0194860641586,
    4857.2286680448151, 4762.2917836449342, 4654.69563818725, 4532.3596312966538,
    4394.8171113478056, 4240.1067829914327, 4067.1908904808947,
    3875.0762174586616, 3661.8137011444023, 3427.7668306553692,
    3170.8049125237858, 2892.1237434306695, 2590.8507189332704,
    2268.0266070742027, 1925.5917946598852, 1563.9657851442469,
    1188.6212697265073, 799.67004858328994, 397.13108061713973, 0.0,
    -397.13108061713973, -799.67004858328994, -1188.6212697265032,
    -1563.9657851442469, -1925.5917946598888, -2268.0266070742027,
    -2590.8507189332704, -2892.1237434306695, -3170.8049125237858,
    -3427.7668306553719, -3661.8137011444023, -3875.0762174586616,
    -4067.1908904808947, -4240.1067829914327, -4394.8171113478056,
    -4532.3596312966538, -4654.69563818725, -4762.2917836449342,
    -4857.2286680448151, -4940.0194860641586, -5012.1972554829163,
    -5074.7588490393628, -5128.4099953358445, -5174.5168992765293,
    -5213.2826767053548, -5246.0218243067065, -5272.9297462099848,
    -5294.8386274262575, -5312.3755128269131, -5325.6326188941821,
    -5335.710253891084, -5342.2393902809927, -5346.2413885992064,
    -5346.4270621062551, -5346.42385986216, -5343.4375216701128,
    -5338.6342348332346, -5332.1766842296811, -5324.5288521752409,
    -5315.5190101780736, -5305.5141537142763, -5294.52233189596,
    -5282.6851416976961, -5270.14272207294, -5256.9175366616018,
    -5243.1797731199458, -5228.9369428927484, -5214.2935537840731,
    -5199.2926990001952, -5183.9923246578455, -5168.4558759385445,
    -5152.7017151635227, -5136.7925390847977, -5120.7412595366814,
    -5104.5951552449233, -5088.378789641436, -5072.1193202720506,
    -5055.8407694261705, -5039.5510196306059, -5023.28452921668,
    -5007.0468597546051, -4990.855829009598, -4974.7229798137878,
    -4958.6583471436452, -4942.677106362873, -4926.7828750741437,
    -4910.9875273822672, -4895.29438147959, -4879.7151485484055,
    -4864.250733952892, 4936.8397141589776, 4952.5290280069657,
    4968.3343425003577, 4984.2545708176958, 5000.2780669562817,
    5016.4015552615974, 5032.6126370683078, 5048.9076370276, 5065.2712195767544,
    5081.6931780604527, 5098.1618309012947, 5114.6588573035024,
    5131.1785216928647, 5147.6861550783979, 5164.1736226546782, 5180.61585744319,
    5196.9856803493813, 5213.2585667341018, 5229.38600176997, 5245.3547822645705,
    5261.1012461243417, 5276.60673961243, 5291.8066918940167, 5306.6422119697481,
    5321.0695567553757, 5334.9824048129321, 5348.3732714761991,
    5361.0691043242623, 5373.0472057603283, 5384.1649138288294,
    5394.2784814911483, 5403.3807733950953, 5411.0968840507321,
    5417.6034714671869, 5422.416076499484, 5425.3983263637965, 5425.37255756268,
    5425.0937900677936, 5420.970065350105, 5414.2794142119556,
    5403.9825722635605, 5390.452508509693, 5372.5765540213042,
    5350.2594410541888, 5322.86553841946, 5289.5504956629729, 5250.1154492428359,
    5203.2279716167041, 5148.6815524807043, 5085.0913455648406,
    5011.7413509259441, 4927.6212293967592, 4831.1773017306405,
    4721.8898601864848, 4597.6509494794036, 4457.9883537228588,
    4300.9158199130279, 4125.38354542103, 3930.3871277774106, 3713.9541936128844,
    3476.4556766524538, 3215.7358794947336, 2933.0094565407585,
    2627.3955155658177, 2299.951773773636, 1952.6455313028137,
    1585.9038807282273, 1205.2707691441485, 810.86055665221443,
    402.69141121519203, 0.0, -402.69141121519203, -810.86055665221443,
    -1205.2707691441442, -1585.9038807282273, -1952.6455313028175,
    -2299.951773773636, -2627.3955155658177, -2933.0094565407585,
    -3215.7358794947336, -3476.4556766524565, -3713.9541936128844,
    -3930.3871277774106, -4125.38354542103, -4300.9158199130279,
    -4457.9883537228588, -4597.6509494794036, -4721.8898601864848,
    -4831.1773017306405, -4927.6212293967592, -5011.7413509259441,
    -5085.0913455648406, -5148.6815524807043, -5203.2279716167041,
    -5250.1154492428359, -5289.5504956629729, -5322.865538419459,
    -5350.2594410541888, -5372.5765540213042, -5390.4525085096939,
    -5403.9825722635605, -5414.2794142119546, -5420.970065350105,
    -5425.0937900677936, -5425.37255756268, -5425.3983263637965,
    -5422.416076499484, -5417.6034714671869, -5411.0968840507321,
    -5403.3807733950953, -5394.2784814911483, -5384.1649138288294,
    -5373.0472057603283, -5361.0691043242623, -5348.3732714761991,
    -5334.9824048129321, -5321.0695567553757, -5306.6422119697481,
    -5291.8066918940167, -5276.60673961243, -5261.1012461243417,
    -5245.3547822645705, -5229.38600176997, -5213.2585667341018,
    -5196.98568034938, -5180.61585744319, -5164.1736226546782,
    -5147.6861550783979, -5131.1785216928638, -5114.6588573035024,
    -5098.1618309012938, -5081.6931780604527, -5065.2712195767544,
    -5048.9076370276007, -5032.6126370683078, -5016.4015552615974,
    -5000.2780669562817, -4984.2545708176958, -4968.3343425003577,
    -4952.5290280069657, -4936.8397141589776, 5009.4286943673687,
    5025.34290746793, 5041.3743035192247, 5057.5216142515292, 5073.7732588374693,
    5090.12600416877, 5106.566926987377, 5123.0922942456818, 5139.6866101438945,
    5156.3394963635783, 5173.039132598482, 5189.7666949630793,
    5206.5162739664593, 5223.252989893228, 5239.9684556874881,
    5256.6365596239239, 5273.2301011551826, 5289.7245944224524,
    5306.0702883458334, 5322.2536886382159, 5338.21016757924, 5353.9207802667752,
    5369.3198300497261, 5384.3474809893332, 5398.9593405540263,
    5413.0472728468285, 5426.6038212048988, 5439.4530670220856,
    5451.5720799508936, 5462.8156747859639, 5473.0379522098183,
    5482.2326999568959, 5490.017086364418, 5496.5727332044316,
    5501.3946009801057, 5504.372792304127, 5504.3174684318319,
    5503.9465328602228, 5499.7010416752473, 5492.8486043419634,
    5482.3325250389471, 5468.5295103695753, 5450.3144796607221,
    5427.589137100621, 5399.7092536643268, 5365.81831414755, 5325.71400026849,
    5278.0459471646773, 5222.6042564622066, 5157.98543544357, 5083.4632156910666,
    4998.01379126777, 4900.06281925406, 4789.0840828057344, 4662.94226699515,
    4521.1595963589061, 4361.7248566784237, 4183.5762000825562,
    3985.6980387772883, 3766.0946853462206, 3525.144523443455,
    3260.6668457101077, 2973.8951700900498, 2663.9403121216637,
    2331.8769405365142, 1979.6992684354436, 1607.8419761932726,
    1221.9202689978842, 822.0510647757244, 408.25174259442815, 0.0,
    -408.25174259442815, -822.0510647757244, -1221.92026899788,
    -1607.8419761932726, -1979.6992684354477, -2331.8769405365142,
    -2663.9403121216637, -2973.8951700900498, -3260.6668457101077,
    -3525.1445234434577, -3766.0946853462206, -3985.6980387772883,
    -4183.5762000825562, -4361.7248566784237, -4521.1595963589061,
    -4662.94226699515, -4789.0840828057344, -4900.06281925406, -4998.01379126777,
    -5083.4632156910666, -5157.98543544357, -5222.6042564622066,
    -5278.0459471646773, -5325.71400026849, -5365.81831414755,
    -5399.7092536643268, -5427.58913710062, -5450.3144796607221,
    -5468.5295103695753, -5482.3325250389471, -5492.8486043419625,
    -5499.7010416752473, -5503.9465328602228, -5504.3174684318319,
    -5504.372792304127, -5501.3946009801057, -5496.5727332044316,
    -5490.017086364418, -5482.2326999568959, -5473.0379522098183,
    -5462.8156747859639, -5451.5720799508936, -5439.4530670220856,
    -5426.6038212048988, -5413.0472728468285, -5398.9593405540263,
    -5384.3474809893332, -5369.3198300497261, -5353.9207802667752,
    -5338.2101675792392, -5322.2536886382159, -5306.0702883458334,
    -5289.7245944224524, -5273.2301011551826, -5256.6365596239239,
    -5239.9684556874881, -5223.2529898932289, -5206.5162739664593,
    -5189.7666949630793, -5173.039132598481, -5156.3394963635783,
    -5139.6866101438945, -5123.0922942456818, -5106.566926987377,
    -5090.1260041687692, -5073.7732588374693, -5057.5216142515292,
    -5041.3743035192247, -5025.34290746793, -5009.4286943673687,
    5082.01767457797, 5098.1567869311993, 5114.414264536269, 5130.7886576838309,
    5147.2684507177428, 5163.85045308404, 5180.5212169010856, 5197.2769514678548,
    5214.10200071102, 5230.9858146640945, 5247.9164343077327, 5264.87453260988,
    5281.8540262466786, 5298.8198247162063, 5315.763288739081,
    5332.6572617878373, 5349.4745219543638, 5366.1906221483132,
    5382.7545748923294, 5399.1525950576288, 5415.3190890230235,
    5431.234820961613, 5446.8329682495432, 5462.0527499536765,
    5476.8491245099849, 5491.1121407677465, 5504.8343712475635,
    5517.837029789549, 5530.0969544566924, 5541.4664365616918,
    5551.7974223537849, 5561.0846317278447, 5568.9372912075978,
    5575.5420197206913, 5580.3730955240617, 5583.3472576907725,
    5583.2618609585788, 5582.799578216629, 5578.43228356246, 5571.4178222140154,
    5560.6824771855827, 5546.606518035569, 5528.0524043952273,
    5504.9188342795733, 5476.5529699835415, 5442.0861321804023,
    5401.3125523009885, 5352.86392201438, 5296.5269609573825, 5230.8795251285737,
    5155.1850803632269, 5068.4063536340327, 4968.9483362401133,
    4856.2783060168658, 4728.2335838732824, 4584.33083924389, 4422.5338932944242,
    4241.7688544768844, 4041.0089504289872, 3818.23517637521, 3573.8333709945186,
    3305.5978112013763, 3014.7808840598241, 2700.4851086039744,
    2363.8021073599116, 2006.7530060377453, 1629.7800715441049, 1238.56976927003,
    833.2415729516066, 413.81207472316692, 0.0, -413.81207472316692,
    -833.2415729516066, -1238.5697692700257, -1629.7800715441049,
    -2006.7530060377492, -2363.8021073599116, -2700.4851086039744,
    -3014.7808840598241, -3305.5978112013763, -3573.8333709945214,
    -3818.23517637521, -4041.0089504289872, -4241.7688544768844,
    -4422.5338932944242, -4584.33083924389, -4728.2335838732824,
    -4856.2783060168658, -4968.9483362401133, -5068.4063536340327,
    -5155.1850803632269, -5230.8795251285737, -5296.5269609573816,
    -5352.86392201438, -5401.3125523009885, -5442.0861321804023,
    -5476.5529699835415, -5504.9188342795733, -5528.0524043952273,
    -5546.606518035569, -5560.6824771855827, -5571.4178222140154,
    -5578.43228356246, -5582.799578216629, -5583.2618609585788,
    -5583.3472576907725, -5580.3730955240617, -5575.5420197206913,
    -5568.9372912075978, -5561.0846317278447, -5551.7974223537849,
    -5541.4664365616918, -5530.0969544566924, -5517.837029789549,
    -5504.8343712475635, -5491.1121407677465, -5476.8491245099849,
    -5462.0527499536765, -5446.8329682495432, -5431.234820961613,
    -5415.3190890230235, -5399.1525950576288, -5382.7545748923294,
    -5366.1906221483132, -5349.4745219543638, -5332.6572617878373,
    -5315.763288739081, -5298.8198247162063, -5281.8540262466786,
    -5264.87453260988, -5247.9164343077327, -5230.9858146640954,
    -5214.10200071102, -5197.2769514678548, -5180.5212169010856,
    -5163.85045308404, -5147.2684507177428, -5130.7886576838309,
    -5114.414264536269, -5098.1567869311993, -5082.01767457797,
    5154.6066547906876, 5170.970666396679, 5187.4542255515653,
    5204.0557011146675, 5220.7636425971432, 5237.5749020070789,
    5254.4755068096529, 5271.461608693955, 5288.517391278132, 5305.6321329621042,
    5322.7937360285614, 5339.9823702444191, 5357.191778533258,
    5374.3866595470108, 5391.55812180871, 5408.6779639356027, 5425.7189427471831,
    5442.6566499102264, 5459.4388614106083, 5476.051501521054,
    5492.4280104561512, 5508.548861695409, 5524.3461064918847,
    5539.7580188648408, 5554.7389086176163, 5569.1770085799117,
    5583.0649215932481, 5596.2209926250707, 5608.621829267242,
    5620.1171991329129, 5630.5568919419047, 5639.936568579471, 5647.857498614062,
    5654.511330696967, 5659.3515605360071, 5662.3217225312146, 5662.20579174303,
    5661.6528930272962, 5657.1637606483637, 5649.9870659474554,
    5639.0324286774194, 5624.6835311657187, 5605.79032827201, 5582.248532526577,
    5553.3966873231957, 5518.3539497815964, 5476.9111052912376,
    5427.6818961982781, 5370.4496659414417, 5303.7736146287425,
    5226.9069449459521, 5138.79891647317, 5037.8338527122733, 4923.47252979342,
    4793.52490014149, 4647.5020823664809, 4483.34292976744, 4299.9615086148115,
    4096.3198627048541, 3870.3756667289567, 3622.5222192736883,
    3350.5287759982853, 3055.6665984324081, 2737.0299050157441,
    2395.7272742410787, 2033.8067440907653, 1651.7181667851985,
    1255.2192699438438, 844.432081177765, 419.37240757141853, 0.0,
    -419.37240757141853, -844.432081177765, -1255.2192699438394,
    -1651.7181667851985, -2033.8067440907691, -2395.7272742410787,
    -2737.0299050157441, -3055.6665984324081, -3350.5287759982853,
    -3622.5222192736915, -3870.3756667289567, -4096.3198627048541,
    -4299.9615086148115, -4483.34292976744, -4647.5020823664809,
    -4793.52490014149, -4923.47252979342, -5037.8338527122733, -5138.79891647317,
    -5226.9069449459521, -5303.7736146287425, -5370.4496659414417,
    -5427.6818961982781, -5476.9111052912376, -5518.3539497815964,
    -5553.3966873231948, -5582.2485325265761, -5605.79032827201,
    -5624.6835311657187, -5639.0324286774194, -5649.9870659474554,
    -5657.1637606483637, -5661.6528930272962, -5662.20579174303,
    -5662.3217225312146, -5659.3515605360071, -5654.511330696967,
    -5647.857498614062, -5639.936568579471, -5630.5568919419047,
    -5620.1171991329129, -5608.621829267242, -5596.2209926250707,
    -5583.0649215932481, -5569.1770085799117, -5554.7389086176163,
    -5539.7580188648408, -5524.3461064918847, -5508.548861695409,
    -5492.4280104561512, -5476.051501521054, -5459.4388614106083,
    -5442.6566499102264, -5425.7189427471831, -5408.6779639356027,
    -5391.5581218087109, -5374.3866595470108, -5357.191778533258,
    -5339.9823702444191, -5322.7937360285614, -5305.6321329621051,
    -5288.517391278132, -5271.461608693955, -5254.4755068096529,
    -5237.5749020070789, -5220.7636425971432, -5204.0557011146675,
    -5187.4542255515653, -5170.970666396679, -5154.6066547906876,
    5227.1956350054379, 5243.7845458642805, 5260.4941865651863,
    5277.3227445440971, 5294.2588344757041, 5311.2993509375738,
    5328.4297967132861, 5345.6462659238223, 5362.932781845233,
    5380.2784512577091, 5397.67103776051, 5415.0902078671825, 5432.5295308259492,
    5449.95349438534, 5467.3529548956694, 5484.6986660678567, 5501.9633635338878,
    5519.1226777068077, 5536.1231479017606, 5552.9504080268243,
    5569.5369318790572, 5585.8629024667052, 5601.8592447752435,
    5617.4632877247868, 5632.6286928715526, 5647.2418762873467,
    5661.2954722315135, 5674.6049555271065, 5687.1467043725252,
    5698.7679624773755, 5709.3163609922276, 5718.7885103874569,
    5726.7777086147116, 5733.4806658194493, 5738.3299964133394,
    5741.2961868328075, 5741.1493094341477, 5740.50644883976, 5735.8954469500313,
    5728.5563338275415, 5717.3823794956661, 5702.7605494443205,
    5683.5282513350412, 5659.5782317819248, 5630.2404056329342,
    5594.6217669700445, 5552.5096591932852, 5502.4998697468618,
    5444.3723713911677, 5376.6677039524329, 5298.6288094425981,
    5209.1914797641339, 5106.7193686926676, 4990.6667541104953,
    4858.8162158258847, 4710.67332571603, 4544.1519661035254, 4358.1541625065638,
    4151.6307755787811, 3922.5161564349846, 3671.2110682507773,
    3395.4597401289752, 3096.5523131911082, 2773.5747013598075,
    2427.652441177429, 2060.8604825765588, 1673.6562619207984,
    1271.8687710034646, 855.6225894522147, 424.93274111077341, 0.0,
    -424.93274111077341, -855.6225894522147, -1271.8687710034603,
    -1673.6562619207984, -2060.8604825765624, -2427.652441177429,
    -2773.5747013598075, -3096.5523131911082, -3395.4597401289752,
    -3671.21106825078, -3922.5161564349846, -4151.6307755787811,
    -4358.1541625065638, -4544.1519661035254, -4710.67332571603,
    -4858.8162158258847, -4990.6667541104953, -5106.7193686926676,
    -5209.1914797641339, -5298.6288094425981, -5376.6677039524329,
    -5444.3723713911677, -5502.4998697468618, -5552.5096591932852,
    -5594.6217669700445, -5630.2404056329333, -5659.5782317819248,
    -5683.5282513350412, -5702.7605494443205, -5717.382379495667,
    -5728.5563338275415, -5735.8954469500313, -5740.50644883976,
    -5741.1493094341477, -5741.2961868328075, -5738.3299964133394,
    -5733.4806658194493, -5726.7777086147125, -5718.7885103874569,
    -5709.3163609922267, -5698.7679624773755, -5687.1467043725252,
    -5674.6049555271065, -5661.2954722315135, -5647.2418762873467,
    -5632.6286928715526, -5617.4632877247868, -5601.8592447752435,
    -5585.8629024667052, -5569.5369318790572, -5552.9504080268243,
    -5536.1231479017606, -5519.1226777068077, -5501.9633635338878,
    -5484.6986660678558, -5467.3529548956694, -5449.95349438534,
    -5432.5295308259483, -5415.0902078671825, -5397.67103776051,
    -5380.2784512577091, -5362.932781845233, -5345.6462659238232,
    -5328.429796713287, -5311.2993509375729, -5294.2588344757041,
    -5277.3227445440971, -5260.4941865651863, -5243.7845458642805,
    -5227.1956350054379, 5299.7846152221364, 5316.5984253339175,
    5333.5341475771975, 5350.589787972177, 5367.7540263534593,
    5385.0237998752273, 5402.3840866121827, 5419.83092315731, 5437.3481724123239,
    5454.9247695510039, 5472.5483395031461, 5490.1980454786335,
    5507.8672831245131, 5525.5203292309052, 5543.14778799929, 5560.7193681852041,
    5578.2077843147135, 5595.5887055367457, 5612.8074343668241,
    5629.8493145733537, 5646.6458532921506, 5663.1769432741166,
    5679.3723830981826, 5695.16855653538, 5710.5184772666753, 5725.306743893876,
    5739.5260231523907, 5752.9889184941467, 5765.6715797629549,
    5777.4187265736373, 5788.0758295220412, 5797.6404570314753,
    5805.6979212377128, 5812.45002477942, 5817.3084035463562, 5820.2706506027662,
    5820.0924560785852, 5819.3602210681156, 5814.6273201100057,
    5807.1256242875725, 5795.7323296275636, 5780.8375725794613, 5761.26617362534,
    5736.9079319902385, 5707.0841248656543, 5670.8895837635782, 5628.10821396407,
    5577.3178426887835, 5518.2950772847844, 5449.5617931075021,
    5370.3506738563592, 5279.5840434871025, 5175.6048842021655,
    5057.8609789446264, 4924.1075309511016, 4773.8445692825071,
    4604.9610023083933, 4416.3468161618312, 4206.9416890260945,
    3974.6566455193392, 3719.89991789724, 3440.3907036200835, 3137.4380283201372,
    2810.1194976388479, 2459.577608166524, 2087.9142214781177,
    1695.5943569549322, 1288.518272433857, 866.81309777307354, 430.493075314295,
    0.0, -430.493075314295, -866.81309777307354, -1288.5182724338524,
    -1695.5943569549322, -2087.9142214781218, -2459.577608166524,
    -2810.1194976388479, -3137.4380283201372, -3440.3907036200835,
    -3719.8999178972431, -3974.6566455193392, -4206.9416890260945,
    -4416.3468161618312, -4604.9610023083933, -4773.8445692825071,
    -4924.1075309511016, -5057.8609789446264, -5175.6048842021655,
    -5279.5840434871025, -5370.3506738563592, -5449.5617931075021,
    -5518.2950772847835, -5577.3178426887835, -5628.10821396407,
    -5670.8895837635782, -5707.0841248656543, -5736.9079319902376,
    -5761.26617362534, -5780.8375725794613, -5795.7323296275636,
    -5807.1256242875725, -5814.6273201100057, -5819.3602210681156,
    -5820.0924560785852, -5820.2706506027662, -5817.3084035463562,
    -5812.45002477942, -5805.6979212377128, -5797.6404570314753,
    -5788.0758295220412, -5777.4187265736373, -5765.6715797629549,
    -5752.9889184941467, -5739.5260231523907, -5725.306743893876,
    -5710.5184772666753, -5695.16855653538, -5679.3723830981826,
    -5663.1769432741166, -5646.6458532921506, -5629.8493145733537,
    -5612.8074343668241, -5595.5887055367457, -5578.2077843147126,
    -5560.7193681852041, -5543.14778799929, -5525.5203292309061,
    -5507.8672831245131, -5490.1980454786335, -5472.5483395031461,
    -5454.9247695510039, -5437.3481724123239, -5419.8309231573112,
    -5402.3840866121836, -5385.0237998752264, -5367.7540263534593,
    -5350.589787972177, -5333.5341475771975, -5316.5984253339175,
    -5299.7846152221364, 5372.3735954407084, 5389.4123048055126,
    5406.5741085876625, 5423.85683139896, 5441.2492182304413, 5458.7482488197593,
    5476.3383765065291, 5494.015580394278, 5511.7635629794086,
    5529.5710878420787, 5547.4256412560562, 5565.30588307921, 5583.2050354287276,
    5601.0871640834357, 5618.9426211189357, 5636.7400702882205,
    5654.452205089884, 5672.0547333987934, 5689.4917208067827,
    5706.7482211591387, 5723.7547746958217, 5740.4909841163226,
    5756.8855214593314, 5772.8738252984, 5788.4082617981039, 5803.3716114031422,
    5817.7565743463629, 5831.3728815247168, 5844.1964554293554,
    5856.069491401031, 5866.8352975479138, 5876.49240839503, 5884.6181365086459,
    5891.4194072731652, 5896.2867823184142, 5899.2451138481829,
    5899.0352682039647, 5898.2141883580953, 5893.3593607914263,
    5885.6949358932752, 5874.0822790653619, 5858.9146003008191,
    5839.0040951812134, 5814.2376331000887, 5783.92784497726, 5747.1574001790268,
    5703.7067695632, 5652.1358150510041, 5592.2177836018545, 5522.4558821013507,
    5442.07253819028, 5349.9766076234027, 5244.4903992604795, 5125.0552042736927,
    4989.3988455404178, 4837.0158130564678, 4665.7700383874444,
    4474.5394695898058, 4262.2526030234621, 4026.7971340066915,
    3768.5887681860704, 3485.321666496849, 3178.323743804558, 2846.6642938554091,
    2491.5027752060678, 2114.9679607793169, 1717.5324518914267,
    1305.1677742207557, 878.003606138556, 436.0534101564316, 0.0,
    -436.0534101564316, -878.003606138556, -1305.1677742207512,
    -1717.5324518914267, -2114.9679607793214, -2491.5027752060678,
    -2846.6642938554091, -3178.323743804558, -3485.321666496849,
    -3768.5887681860736, -4026.7971340066915, -4262.2526030234621,
    -4474.5394695898058, -4665.7700383874444, -4837.0158130564678,
    -4989.3988455404178, -5125.0552042736927, -5244.4903992604795,
    -5349.9766076234027, -5442.07253819028, -5522.4558821013507,
    -5592.2177836018545, -5652.1358150510041, -5703.7067695632,
    -5747.1574001790268, -5783.9278449772592, -5814.2376331000887,
    -5839.0040951812125, -5858.91460030082, -5874.0822790653619,
    -5885.6949358932752, -5893.3593607914263, -5898.2141883580953,
    -5899.0352682039647, -5899.2451138481829, -5896.2867823184142,
    -5891.4194072731652, -5884.6181365086459, -5876.49240839503,
    -5866.8352975479138, -5856.0694914010319, -5844.1964554293554,
    -5831.3728815247168, -5817.7565743463629, -5803.3716114031422,
    -5788.4082617981039, -5772.8738252984, -5756.8855214593314,
    -5740.4909841163226, -5723.7547746958217, -5706.7482211591387,
    -5689.4917208067827, -5672.0547333987934, -5654.4522050898831,
    -5636.7400702882205, -5618.9426211189357, -5601.0871640834357,
    -5583.2050354287267, -5565.30588307921, -5547.4256412560562,
    -5529.5710878420787, -5511.7635629794086, -5494.015580394278,
    -5476.33837650653, -5458.7482488197593, -5441.2492182304413,
    -5423.85683139896, -5406.5741085876625, -5389.4123048055126,
    -5372.3735954407084 };

  static const real_T i[9870] = { 50.9716432977569, 51.1834158980093,
    51.5935405690811, 51.971515367674172, 52.323002147312486, 52.671535371899786,
    53.020965698153994, 53.35058094538136, 53.633101543751089,
    53.842799948704062, 54.01333677206987, 54.186526591116952,
    54.299372608373581, 54.337895583920165, 54.316390747089777,
    54.214576815668586, 54.045928588291709, 53.779560831539136,
    53.43093113720267, 52.934622828232087, 52.285255124313274,
    51.539041120899711, 50.626929924065635, 49.5599598282126, 48.248234912848844,
    46.732231693194095, 44.945597552711504, 42.870211761849895,
    40.53995846388144, 37.783978058826015, 34.784294141441279,
    31.190898617147383, 27.223672615063752, 22.711554489347897,
    17.428947001955905, 11.01159779921942, 4.8485538413501628,
    -2.5020088835418597, -10.736930497323263, -20.292436283679631,
    -31.430410002991465, -43.195615779302408, -57.003097310175072,
    -71.91402560127068, -89.288709625306154, -108.32019503407356,
    -129.8440340392246, -153.90693685307312, -180.59842918669756,
    -210.75470847784865, -243.75319604687155, -281.02933155360125,
    -321.80812708011473, -367.0666374966853, -416.68696257995737,
    -470.50816882157523, -529.62555786603878, -592.38704105929344,
    -660.32274018152759, -731.23471766297155, -805.51286883056434,
    -881.69993130197133, -957.62965890654345, -1033.5353776864429,
    -1104.5763050271366, -1171.8463921532859, -1229.0549796966143,
    -1276.6276243762131, -1323.9767663161178, -1338.3787128891915,
    -1329.1448404156213, -1338.3787128891915, -1323.976766316111,
    -1276.6276243762131, -1229.0549796966275, -1171.8463921532859,
    -1104.5763050271303, -1033.5353776864429, -957.62965890654345,
    -881.69993130197565, -805.51286883056434, -731.23471766296723,
    -660.32274018152759, -592.38704105929344, -529.62555786603878,
    -470.50816882157523, -416.68696257995737, -367.0666374966853,
    -321.80812708011473, -281.02933155360125, -243.75319604687155,
    -210.75470847784723, -180.59842918669756, -153.90693685307454,
    -129.8440340392246, -108.32019503407356, -89.288709625306154,
    -71.91402560127068, -57.003097310175072, -43.195615779302408,
    -31.430410002991465, -20.292436283679631, -10.736930497323263,
    -2.5020088835418597, 4.8485538413501628, 11.01159779921942,
    17.428947001955905, 22.711554489347897, 27.223672615063752,
    31.190898617147383, 34.784294141441279, 37.783978058826015,
    40.53995846388144, 42.870211761849895, 44.945597552711504,
    46.732231693194095, 48.248234912848844, 49.5599598282126, 50.626929924065635,
    51.539041120899711, 52.285255124313274, 52.934622828232087,
    53.43093113720267, 53.779560831539136, 54.04592858829313, 54.214576815668586,
    54.316390747088356, 54.337895583920165, 54.299372608373581,
    54.186526591118373, 54.01333677206987, 53.84279994870122, 53.633101543749667,
    53.350580945382781, 53.020965698155415, 52.671535371899786,
    52.323002147312486, 51.971515367674172, 51.5935405690811, 51.1834158980093,
    50.9716432977569, 101.9432865955138, 102.3668317960186, 103.1870811381622,
    103.94303073534834, 104.64600429462497, 105.34307074379957,
    106.04193139630799, 106.70116189076272, 107.26620308750218,
    107.68559989740812, 108.02667354413974, 108.3730531822339,
    108.59874521674716, 108.67579116784033, 108.63278149417955,
    108.42915363133717, 108.09185717658342, 107.55912166307827,
    106.86186227440534, 105.86924565646417, 104.57051024862655,
    103.07808224179942, 101.25385984813127, 99.1199196564252, 96.496469825697687,
    93.464463386388189, 89.891195105423009, 85.740423523699789,
    81.079916927762881, 75.567956117652031, 69.568588282882558,
    62.381797234294766, 54.4473452301275, 45.423108978695794, 34.857894003911809,
    22.023195598438839, 9.6971076827003255, -5.0040177670837194,
    -21.473860994646525, -40.584872567359263, -62.86082000598293,
    -86.391231558604815, -114.00619462035014, -143.82805120254136,
    -178.57741925061231, -216.64039006814713, -259.68806807844919,
    -307.81387370614624, -361.19685837339512, -421.5094169556973,
    -487.5063920937431, -562.05866310720251, -643.61625416022946,
    -734.13327499337061, -833.37392515991473, -941.01633764315045,
    -1059.2511157320776, -1184.7740821185869, -1320.6454803630552,
    -1462.4694353259431, -1611.0257376611287, -1763.3998626039427,
    -1915.2593178130869, -2067.0707553728857, -2209.1526100542733,
    -2343.6927843065719, -2458.1099593932286, -2553.2552487524263,
    -2647.9535326322357, -2676.7574257783831, -2658.2896808312425,
    -2676.7574257783831, -2647.953532632222, -2553.2552487524263,
    -2458.1099593932549, -2343.6927843065719, -2209.1526100542605,
    -2067.0707553728857, -1915.2593178130869, -1763.3998626039513,
    -1611.0257376611287, -1462.4694353259345, -1320.6454803630552,
    -1184.7740821185869, -1059.2511157320776, -941.01633764315045,
    -833.37392515991473, -734.13327499337061, -643.61625416022946,
    -562.05866310720251, -487.5063920937431, -421.50941695569446,
    -361.19685837339512, -307.81387370614908, -259.68806807844919,
    -216.64039006814713, -178.57741925061231, -143.82805120254136,
    -114.00619462035014, -86.391231558604815, -62.86082000598293,
    -40.584872567359263, -21.473860994646525, -5.0040177670837194,
    9.6971076827003255, 22.023195598438839, 34.857894003911809,
    45.423108978695794, 54.4473452301275, 62.381797234294766, 69.568588282882558,
    75.567956117652031, 81.079916927762881, 85.740423523699789,
    89.891195105423009, 93.464463386388189, 96.496469825697687, 99.1199196564252,
    101.25385984813127, 103.07808224179942, 104.57051024862655,
    105.86924565646417, 106.86186227440534, 107.55912166307827,
    108.09185717658626, 108.42915363133717, 108.63278149417671,
    108.67579116784033, 108.59874521674716, 108.37305318223675,
    108.02667354413974, 107.68559989740244, 107.26620308749933,
    106.70116189076556, 106.04193139631083, 105.34307074379957,
    104.64600429462497, 103.94303073534834, 103.1870811381622, 102.3668317960186,
    101.9432865955138, 152.91492989327352, 153.55024769402789, 154.7806217072376,
    155.9145461030225, 156.96900644194315, 158.01460611569937,
    159.06289709446057, 160.05174283614267, 160.899304631249, 161.52839984611077,
    162.0400103162153, 162.55957977335513, 162.89811782511933,
    163.01368675175908, 162.9491722412665, 162.64373044700434,
    162.13778576487798, 161.33868249461884, 160.29279341160802,
    158.80386848469627, 156.85576537293841, 154.61712336270338,
    151.88078977219831, 148.67987948463494, 144.74470473854225,
    140.19669507957803, 134.83679265813169, 128.61063528555394,
    121.61987539165568, 113.35193417647805, 104.35288242431956,
    93.572695851435043, 81.671017845189837, 68.134663468049382,
    52.286841005866286, 33.03479339765542, 14.545661524050489,
    -7.5060266506227364, -32.210791491968365, -60.877308851041732,
    -94.2912300089744, -129.58684733790722, -171.00929193052806,
    -215.74207680380917, -267.86612887591423, -324.96058510222355,
    -389.53210211767521, -461.72081055921939, -541.79528756009415,
    -632.26412543354456, -731.25958814061039, -843.08799466080507,
    -965.424381240347, -1101.1999124900531, -1250.0608877398679,
    -1411.5245064647256, -1588.8766735981178, -1777.1611231778834,
    -1980.9682205445863, -2193.7041529889125, -2416.5386064916911,
    -2645.0997939059139, -2872.8889767196338, -3100.6061330593297,
    -3313.7289150814081, -3515.5391764598558, -3687.1649390898406,
    -3829.88287312864, -3971.9302989483567, -4015.1361386675753,
    -3987.4345212468606, -4015.1361386675753, -3971.9302989483353,
    -3829.88287312864, -3687.1649390898806, -3515.5391764598558,
    -3313.72891508139, -3100.6061330593297, -2872.8889767196338,
    -2645.0997939059253, -2416.5386064916911, -2193.7041529889011,
    -1980.9682205445863, -1777.1611231778834, -1588.8766735981178,
    -1411.5245064647256, -1250.0608877398679, -1101.1999124900531,
    -965.424381240347, -843.08799466080507, -731.25958814061039,
    -632.26412543354456, -541.79528756009415, -461.72081055921939,
    -389.53210211767521, -324.96058510222355, -267.86612887591423,
    -215.74207680380917, -171.00929193052806, -129.58684733790722,
    -94.2912300089744, -60.877308851041732, -32.210791491968365,
    -7.5060266506227364, 14.545661524050489, 33.03479339765542,
    52.286841005866286, 68.1346634680437, 81.671017845189837, 93.572695851440727,
    104.35288242431956, 113.35193417647805, 121.61987539165, 128.61063528555394,
    134.83679265813737, 140.19669507957803, 144.74470473854225,
    148.67987948463494, 151.88078977219831, 154.61712336270622,
    156.85576537293841, 158.80386848469342, 160.29279341160802,
    161.33868249462168, 162.13778576488082, 162.64373044699866,
    162.94917224126081, 163.01368675176477, 162.89811782512217,
    162.55957977335228, 162.04001031621246, 161.52839984610793,
    160.89930463125185, 160.05174283614551, 159.06289709446341,
    158.01460611569937, 156.96900644194031, 155.9145461030225, 154.7806217072376,
    153.55024769402789, 152.91492989327352, 203.88657319102759,
    204.7336635920372, 206.3741622763244, 207.88606147069669, 209.29200858924995,
    210.68614148759914, 212.08386279261597, 213.40232378152544,
    214.53240617500435, 215.37119979481625, 216.05334708827948,
    216.74610636446781, 217.19749043349432, 217.35158233568066,
    217.26556298835911, 216.85830726267434, 216.18371435316683,
    215.11824332615654, 213.72372454881068, 211.73849131292835,
    209.14102049725309, 206.15616448359884, 202.50771969626254,
    198.23983931285039, 192.99293965139537, 186.92892677277638,
    179.78239021084602, 171.48084704739958, 162.15983385552576,
    151.13591223530406, 139.13717656576512, 124.76359446858953, 108.894690460255,
    90.846217957391588, 69.715788007823619, 44.046391196877678,
    19.394215365400651, -10.008035534167439, -42.947721989293051,
    -81.169745134718525, -125.72164001196586, -172.78246311720963,
    -228.01238924070029, -287.65610240508272, -357.15483850122462,
    -433.28078013629425, -519.37613615689838, -615.62774741229248,
    -722.39371674679023, -843.01883391139461, -975.0127841874862,
    -1124.117326214405, -1287.2325083204589, -1468.2665499867412,
    -1666.7478503198295, -1882.0326752863009, -2118.5022314641551,
    -2369.5481642371738, -2641.2909607261104, -2924.9388706518862,
    -3222.0514753222574, -3526.7997252078853, -3830.5186356261738,
    -4134.1415107457715, -4418.3052201085466, -4687.3855686131437,
    -4916.2199187864571, -5106.5104975048525, -5295.9070652644714,
    -5353.5148515567662, -5316.5793616624851, -5353.5148515567662,
    -5295.9070652644441, -5106.5104975048525, -4916.21991878651,
    -4687.3855686131437, -4418.3052201085211, -4134.1415107457715,
    -3830.5186356261738, -3526.7997252079026, -3222.0514753222574,
    -2924.9388706518689, -2641.2909607261104, -2369.5481642371738,
    -2118.5022314641551, -1882.0326752863009, -1666.7478503198295,
    -1468.2665499867412, -1287.2325083204589, -1124.117326214405,
    -975.0127841874862, -843.01883391138892, -722.39371674679023,
    -615.62774741229816, -519.37613615689838, -433.28078013629425,
    -357.15483850122462, -287.65610240508272, -228.01238924070029,
    -172.78246311720963, -125.72164001196586, -81.169745134718525,
    -42.947721989293051, -10.008035534167439, 19.394215365400651,
    44.046391196877678, 69.715788007823619, 90.846217957391588, 108.894690460255,
    124.76359446858953, 139.13717656576512, 151.13591223530406,
    162.15983385552576, 171.48084704739958, 179.78239021084602,
    186.92892677277638, 192.99293965139537, 198.23983931285039,
    202.50771969626254, 206.15616448359884, 209.14102049725309,
    211.73849131292835, 213.72372454881068, 215.11824332615654,
    216.18371435317252, 216.85830726267434, 217.26556298835342,
    217.35158233568066, 217.19749043349432, 216.74610636447349,
    216.05334708827948, 215.37119979480488, 214.53240617499867,
    213.40232378153112, 212.08386279262166, 210.68614148759914,
    209.29200858924995, 207.88606147069669, 206.3741622763244, 204.7336635920372,
    203.88657319102759, 254.85821648878732, 255.91707949004081,
    257.9677028453998, 259.85757683837369, 261.61501073656245,
    263.35767685949327, 265.10482849077425, 266.75290472691108,
    268.16550771874836, 269.21399974351607, 270.06668386035221,
    270.93263295558904, 271.49686304186935, 271.68947791960227,
    271.58195373544322, 271.07288407833585, 270.22964294146141,
    268.89780415770565, 267.15465568601621, 264.67311414115193,
    261.42627562156213, 257.69520560450565, 253.13464962033527,
    247.79979914106298, 241.24117456424278, 233.66115846596907,
    224.72798776355469, 214.35105880925087, 202.69979231941289,
    188.91989029413008, 173.92147070720497, 155.95449308573265,
    136.11836307532019, 113.55777244674518, 87.14473500977526,
    55.057988996088575, 24.242769206750815, -12.510044417700772,
    -53.684652486617729, -101.462181418401, -157.15205001495164,
    -215.97807889651202, -285.01548655088391, -359.57012800635619,
    -446.44354812652938, -541.600975170365, -649.22017019612156,
    -769.53468426536847, -902.99214593348927, -1053.7735423892448,
    -1218.7659802343535, -1405.1466577680048, -1609.0406354005765,
    -1835.3331874834266, -2083.4348128997854, -2352.540844107873,
    -2648.12778933019, -2961.9352052964673, -3301.613700907646,
    -3656.1735883148594, -4027.5643441528155, -4408.4996565098563,
    -4788.1482945327225, -5167.6768884322155, -5522.8815251356855,
    -5859.2319607664258, -6145.2748984830669, -6383.1381218810666,
    -6619.8838315805942, -6691.8935644459589, -6645.7242020781,
    -6691.8935644459589, -6619.88383158056, -6383.1381218810666,
    -6145.2748984831314, -5859.2319607664258, -5522.8815251356546,
    -5167.6768884322155, -4788.1482945327225, -4408.4996565098791,
    -4027.5643441528155, -3656.1735883148367, -3301.613700907646,
    -2961.9352052964673, -2648.12778933019, -2352.540844107873,
    -2083.4348128997854, -1835.3331874834266, -1609.0406354005765,
    -1405.1466577680048, -1218.7659802343478, -1053.7735423892391,
    -902.992145933495, -769.53468426537415, -649.22017019612156,
    -541.600975170365, -446.44354812652938, -359.57012800635619,
    -285.01548655088391, -215.97807889651202, -157.15205001495164,
    -101.46218141839532, -53.684652486617729, -12.510044417706457,
    24.242769206750815, 55.057988996088575, 87.14473500977526,
    113.55777244674518, 136.11836307532019, 155.95449308573265,
    173.92147070720497, 188.91989029413008, 202.69979231941289,
    214.35105880925087, 224.72798776355469, 233.66115846596907,
    241.24117456424278, 247.79979914106298, 253.13464962033527,
    257.69520560450565, 261.42627562156213, 264.67311414115193,
    267.15465568601621, 268.89780415770565, 270.22964294146141,
    271.07288407833016, 271.58195373544322, 271.68947791960795,
    271.49686304186935, 270.93263295558904, 270.06668386035221,
    269.21399974351039, 268.16550771874836, 266.75290472691108,
    265.10482849077425, 263.35767685949895, 261.61501073656245,
    259.85757683837369, 257.9677028453998, 255.91707949004081,
    254.85821648878732, 305.82985978654705, 307.10049538805578,
    309.5612434144752, 311.829092206045, 313.9380128838863, 316.02921223139873,
    318.12579418892113, 320.10348567228533, 321.798609262498, 323.05679969222155,
    324.0800206324306, 325.11915954671025, 325.79623565023866,
    326.02737350351816, 325.898344482533, 325.28746089400869, 324.27557152975595,
    322.67736498923767, 320.58558682321603, 317.60773696939253,
    313.71153074587681, 309.23424672540676, 303.76157954439662,
    297.35975896926988, 289.48940947708451, 280.39339015915607,
    269.67358531626337, 257.22127057110788, 243.23975078331137,
    226.70386835295611, 208.70576484863912, 187.14539170287009,
    163.34203569037967, 136.26932693609876, 104.57368201173257,
    66.06958679531084, 29.091323048100978, -15.012053301245473,
    -64.42158298393673, -121.75461770208346, -188.58246001794879,
    -259.17369467581443, -342.01858386105613, -431.48415360761834,
    -535.73225775182846, -649.92117020444709, -779.06420423535042,
    -923.44162111843877, -1083.5905751201883, -1264.5282508670891,
    -1462.5191762812208, -1686.1759893216101, -1930.8487624806939,
    -2202.3998249801061, -2500.1217754797358, -2823.0490129294512,
    -3177.7533471962356, -3554.3222463557668, -3961.9364410891726,
    -4387.408305977825, -4833.0772129833822, -5290.1995878118278,
    -5745.7779534392675, -6201.2122661186595, -6627.4578301628162,
    -7031.0783529197115, -7374.3298781796811, -7659.76574625728,
    -7943.8605978967134, -8030.2722773351506, -7974.8690424937213,
    -8030.2722773351506, -7943.8605978966707, -7659.76574625728,
    -7374.3298781797612, -7031.0783529197115, -6627.45783016278,
    -6201.2122661186595, -5745.7779534392675, -5290.1995878118505,
    -4833.0772129833822, -4387.4083059778022, -3961.9364410891726,
    -3554.3222463557668, -3177.7533471962356, -2823.0490129294512,
    -2500.1217754797358, -2202.3998249801061, -1930.8487624806939,
    -1686.1759893216101, -1462.5191762812208, -1264.5282508670891,
    -1083.5905751201883, -923.44162111843877, -779.06420423535042,
    -649.92117020444709, -535.73225775182846, -431.48415360761834,
    -342.01858386105613, -259.17369467581443, -188.58246001794879,
    -121.75461770208346, -64.42158298393673, -15.012053301245473,
    29.091323048100978, 66.06958679531084, 104.57368201173257, 136.2693269360874,
    163.34203569037967, 187.14539170288145, 208.70576484863912,
    226.70386835295611, 243.2397507833, 257.22127057110788, 269.67358531627474,
    280.39339015915607, 289.48940947708451, 297.35975896926988,
    303.76157954439662, 309.23424672541245, 313.71153074587681,
    317.60773696938685, 320.58558682321603, 322.67736498924336,
    324.27557152976163, 325.28746089399732, 325.89834448252162,
    326.02737350352953, 325.79623565024434, 325.11915954670457,
    324.08002063242492, 323.05679969221586, 321.7986092625037, 320.103485672291,
    318.12579418892682, 316.02921223139873, 313.93801288388062, 311.829092206045,
    309.5612434144752, 307.10049538805578, 305.82985978654705,
    356.80150308430677, 358.28391128605938, 361.15478398355629,
    363.80060757372769, 366.2610150311931, 368.70074760329283, 371.1467598870737,
    373.45406661767095, 375.43171080625336, 376.89959964092134,
    378.09335740449762, 379.30568613782009, 380.09560825861365,
    380.36526908745111, 380.21473522962845, 379.50203770967585,
    378.32150011804481, 376.45692582078675, 374.01651796042154,
    370.54235979760472, 365.99678587018582, 360.77328784631356,
    354.38850946846935, 346.91971879748252, 337.73764438993766,
    327.12562185234873, 314.61918286896633, 300.09148233294781,
    283.77970924717579, 264.4878464117935, 243.4900589901074, 218.33629032003026,
    190.56570830542779, 158.9808814254296, 122.00262901369558, 77.0811845945331,
    33.939876889462511, -17.514062184773124, -75.1585134812671,
    -142.04705398576596, -220.01287002094594, -302.36931045511682,
    -399.02168117123404, -503.39817920889755, -625.02096737713316,
    -758.24136523850643, -908.90823827457928, -1077.3485579715261,
    -1264.1890043068872, -1475.2829593449392, -1706.2723723280881,
    -1967.20532087521, -2252.6568895608061, -2569.4664624768029,
    -2916.8087380596976, -3293.5571817510181, -3707.3789050622704,
    -4146.709287415054, -4622.2591812707, -5118.6430236408014,
    -5638.590081813948, -6171.8995191137992, -6703.4076123458071,
    -7234.7476438050981, -7732.034135189956, -8202.9247450729981,
    -8603.3848578762972, -8936.3933706334938, -9267.8373642128317,
    -9368.6509902243415, -9304.0138829093376, -9368.6509902243415,
    -9267.8373642127845, -8936.3933706334938, -8603.38485787639,
    -8202.9247450729981, -7732.0341351899106, -7234.7476438050981,
    -6703.4076123458071, -6171.8995191138274, -5638.590081813948,
    -5118.6430236407732, -4622.2591812707, -4146.709287415054,
    -3707.3789050622704, -3293.5571817510181, -2916.8087380596976,
    -2569.4664624768029, -2252.6568895608061, -1967.20532087521,
    -1706.2723723280881, -1475.2829593449278, -1264.1890043068872,
    -1077.3485579715375, -908.90823827457928, -758.24136523849506,
    -625.02096737713316, -503.39817920890891, -399.0216811712454,
    -302.36931045511682, -220.01287002093457, -142.04705398576596,
    -75.1585134812671, -17.514062184773124, 33.939876889462511, 77.0811845945331,
    122.00262901369558, 158.9808814254296, 190.56570830542779,
    218.33629032003026, 243.49005899009603, 264.4878464117935,
    283.77970924717579, 300.09148233294781, 314.6191828689777,
    327.12562185234873, 337.73764438993766, 346.91971879748252,
    354.38850946846935, 360.77328784631356, 365.99678587018582,
    370.54235979760472, 374.01651796042154, 376.45692582078675,
    378.32150011805618, 379.50203770967585, 380.21473522961708,
    380.36526908745111, 380.09560825861365, 379.30568613782009,
    378.09335740449762, 376.89959964092134, 375.43171080625336,
    373.45406661767095, 371.1467598870737, 368.70074760329283, 366.2610150311931,
    363.80060757372769, 361.15478398355629, 358.28391128605938,
    356.80150308430677, 407.77314638205519, 409.46732718407441,
    412.7483245526488, 415.77212294139338, 418.58401717849989,
    421.37228297519829, 424.16772558523195, 426.80464756305088,
    429.06481235000871, 430.7423995896325, 432.10669417655896,
    433.49221272893561, 434.39498086698865, 434.70316467136132,
    434.53112597671822, 433.71661452534869, 432.36742870633367,
    430.23648665231309, 427.44744909762136, 423.47698262585669,
    418.28204099450619, 412.31232896719769, 405.01543939252508,
    396.47967862570079, 385.98587930279075, 373.85785354555276,
    359.56478042169203, 342.96169409479916, 324.31966771105152,
    302.27182447060812, 278.27435313153023, 249.52718893717906, 217.78938092051,
    181.69243591478318, 139.43157601564724, 88.092782393755357, 38.7884307308013,
    -20.016071068334877, -85.8954439785861, -162.33949026943705,
    -251.44328002393172, -345.56492623441926, -456.02477848140057,
    -575.31220481016544, -714.30967700244923, -866.56156027258851,
    -1038.7522723137968, -1231.255494824585, -1444.7874334935805,
    -1686.0376678227892, -1950.0255683749724, -2248.23465242881,
    -2574.4650166409178, -2936.5330999734824, -3333.4957006396589,
    -3764.0653505726018, -4237.00446292831, -4739.0963284743475,
    -5282.5819214522207, -5849.8777413037724, -6444.1029506445147,
    -7053.5994504157707, -7661.0372712523476, -8268.283021491543,
    -8836.6104402170931, -9374.7711372262875, -9832.4398375729143,
    -10213.020995009705, -10591.814130528943, -10707.029703113532,
    -10633.15872332497, -10707.029703113532, -10591.814130528888,
    -10213.020995009705, -9832.43983757302, -9374.7711372262875,
    -8836.6104402170422, -8268.283021491543, -7661.0372712523476,
    -7053.5994504158052, -6444.1029506445147, -5849.8777413037378,
    -5282.5819214522207, -4739.0963284743475, -4237.00446292831,
    -3764.0653505726018, -3333.4957006396589, -2936.5330999734824,
    -2574.4650166409178, -2248.23465242881, -1950.0255683749724,
    -1686.0376678227778, -1444.7874334935805, -1231.2554948245963,
    -1038.7522723137968, -866.56156027258851, -714.30967700244923,
    -575.31220481016544, -456.02477848140057, -345.56492623441926,
    -251.44328002393172, -162.33949026943705, -85.8954439785861,
    -20.016071068334877, 38.7884307308013, 88.092782393755357,
    139.43157601564724, 181.69243591478318, 217.78938092051, 249.52718893717906,
    278.27435313153023, 302.27182447060812, 324.31966771105152,
    342.96169409479916, 359.56478042169203, 373.85785354555276,
    385.98587930279075, 396.47967862570079, 405.01543939252508,
    412.31232896719769, 418.28204099450619, 423.47698262585669,
    427.44744909762136, 430.23648665231309, 432.36742870634504,
    433.71661452534869, 434.53112597670685, 434.70316467136132,
    434.39498086698865, 433.492212728947, 432.10669417655896, 430.74239958960976,
    429.06481234999734, 426.80464756306225, 424.16772558524332,
    421.37228297519829, 418.58401717849989, 415.77212294139338,
    412.7483245526488, 409.46732718407441, 407.77314638205519,
    458.74478967980355, 460.65074308206664, 464.34186512171851,
    467.74363830908175, 470.90701932581811, 474.04381834708107,
    477.18869128339026, 480.15522850844218, 482.69791389374132,
    484.58519953833229, 486.1200309486544, 487.6787393200625, 488.69435347535227,
    489.0410602552829, 488.84751672379662, 487.93119134099879, 486.4133572946339,
    484.01604748387354, 480.87838023483255, 476.41160545407462,
    470.56729611880388, 463.85137008811586, 455.64236931660349,
    446.03963845390768, 434.23411421563247, 420.59008523873405,
    404.51037797439506, 385.83190585665045, 364.85962617493863,
    340.05580252943417, 313.05864727298712, 280.71808755432789,
    245.0130535355695, 204.40399040413678, 156.86052301759887,
    99.104380192966261, 43.636984572151469, -22.518079951862525,
    -96.6323744759051, -182.63192655313088, -282.8736900269289,
    -388.76054201371028, -513.02787579157848, -647.22623041144459,
    -803.598386627754, -974.88175530665922, -1168.5963063530255,
    -1385.1624316776667, -1625.3858626802853, -1896.7923763006395,
    -2193.7787644218342, -2529.2639839824096, -2896.2731437210296,
    -3303.5997374701624, -3750.1826632196153, -4234.5735193941737,
    -4766.6300207943505, -5331.4833695336411, -5942.9046616337419,
    -6581.112458966737, -7249.6158194750815, -7935.2993817177539,
    -8618.666930158899, -9301.81839917798, -9941.18674524423,
    -10546.617529379573, -11061.494817269524, -11489.648619385918,
    -11915.790896845065, -12045.408416002725, -11962.303563740585,
    -12045.408416002725, -11915.790896845003, -11489.648619385918,
    -11061.494817269642, -10546.617529379573, -9941.1867452441729,
    -9301.81839917798, -8618.666930158899, -7935.2993817177876,
    -7249.6158194750815, -6581.1124589667033, -5942.9046616337419,
    -5331.4833695336411, -4766.6300207943505, -4234.5735193941737,
    -3750.1826632196153, -3303.5997374701624, -2896.2731437210296,
    -2529.2639839824096, -2193.7787644218342, -1896.7923763006395,
    -1625.3858626802853, -1385.1624316776667, -1168.5963063530255,
    -974.88175530665922, -803.598386627754, -647.22623041144459,
    -513.02787579157848, -388.76054201371028, -282.8736900269289,
    -182.63192655313088, -96.6323744759051, -22.518079951862525,
    43.636984572151469, 99.104380192966261, 156.86052301759887,
    204.40399040413678, 245.0130535355695, 280.71808755432789,
    313.05864727297575, 340.05580252943417, 364.85962617493863,
    385.83190585665045, 404.51037797440642, 420.59008523873405,
    434.23411421563247, 446.03963845390768, 455.64236931660349,
    463.85137008811586, 470.56729611880388, 476.41160545407462,
    480.87838023483255, 484.01604748387354, 486.4133572946339,
    487.93119134099879, 488.84751672378525, 489.0410602552829,
    488.69435347536364, 487.6787393200625, 486.12003094864303,
    484.58519953833229, 482.69791389375268, 480.15522850843081,
    477.18869128339026, 474.04381834709244, 470.90701932581811,
    467.74363830908175, 464.34186512171851, 460.65074308206664,
    458.74478967980355, 509.71643297757464, 511.83415898008161,
    515.9354056907996, 519.71515367674738, 523.23002147312491,
    526.71535371898653, 530.20965698154851, 533.50580945382217,
    536.33101543749672, 538.42799948703214, 540.13336772070443,
    541.86526591117808, 542.99372608373869, 543.37895583920454,
    543.16390747088644, 542.14576815667169, 540.45928588292281,
    537.7956083154113, 534.30931137203243, 529.34622828230385,
    522.85255124312425, 515.39041120901129, 506.26929924067053,
    495.59959828212595, 482.48234912848557, 467.32231693193813,
    449.45597552710939, 428.70211761850175, 405.39958463882579,
    377.83978058826017, 347.84294141440995, 311.9089861714653,
    272.23672615064038, 227.11554489349035, 174.28947001955052,
    110.11597799217715, 48.485538413501629, -25.020088835401545,
    -107.36930497323546, -202.924362836802, -314.30410002990328,
    -431.95615779302403, -570.03097310176781, -719.14025601271237,
    -892.88709625305876, -1083.20195034073, -1298.4403403922431,
    -1539.0693685307369, -1805.9842918669785, -2107.5470847784895,
    -2437.531960468707, -2810.2933155360097, -3218.0812708011531,
    -3670.6663749668533, -4166.8696257995707, -4705.081688215746,
    -5296.25557866038, -5923.8704105929346, -6603.2274018152921,
    -7312.3471766297189, -8055.1286883056309, -8816.9993130197126,
    -9576.296589065445, -10335.353776864431, -11045.763050271371,
    -11718.463921532852, -12290.549796966134, -12766.276243762133,
    -13239.767663161188, -13383.787128891918, -13291.4484041562,
    -13383.787128891918, -13239.767663161119, -12766.276243762133,
    -12290.549796966263, -11718.463921532852, -11045.763050271309,
    -10335.353776864431, -9576.296589065445, -8816.9993130197581,
    -8055.1286883056309, -7312.3471766296734, -6603.2274018152921,
    -5923.8704105929346, -5296.25557866038, -4705.081688215746,
    -4166.8696257995707, -3670.6663749668533, -3218.0812708011531,
    -2810.2933155360097, -2437.5319604686956, -2107.5470847784782,
    -1805.98429186699, -1539.0693685307483, -1298.4403403922431,
    -1083.20195034073, -892.88709625305876, -719.14025601271237,
    -570.03097310176781, -431.95615779302403, -314.30410002990328,
    -202.92436283679064, -107.36930497323546, -25.020088835412913,
    48.485538413501629, 110.11597799217715, 174.28947001955052,
    227.11554489349035, 272.23672615064038, 311.9089861714653,
    347.84294141440995, 377.83978058826017, 405.39958463882579,
    428.70211761850175, 449.45597552710939, 467.32231693193813,
    482.48234912848557, 495.59959828212595, 506.26929924067053,
    515.39041120901129, 522.85255124312425, 529.34622828230385,
    534.30931137203243, 537.7956083154113, 540.45928588292281,
    542.14576815666032, 543.16390747088644, 543.37895583921591,
    542.99372608373869, 541.86526591117808, 540.13336772070443,
    538.42799948702077, 536.33101543749672, 533.50580945382217,
    530.20965698154851, 526.7153537189979, 523.23002147312491,
    519.71515367674738, 515.9354056907996, 511.83415898008161,
    509.71643297757464, 560.688076275323, 563.01757487809664, 567.52894625988074,
    571.68666904442443, 575.55302362044313, 579.38688909088057,
    583.23062267969533, 586.856390399202, 589.964116981252, 592.27079943574324,
    594.14670449277708, 596.05179250229355, 597.29309869211363,
    597.71685142312606, 597.48029821797616, 596.36034497233311, 594.505214471223,
    591.575169146949, 587.74024250922082, 582.2808511105444, 575.137806367456,
    566.92945232991815, 556.8962291647149, 545.15955811033291,
    530.73058404133872, 514.054548625108, 494.40157307981235, 471.57232938036447,
    445.93954310271289, 415.62375864708622, 382.62723555585546,
    343.09988478861413, 299.46039876569984, 249.82709938283256,
    191.71841702150215, 121.12757579141078, 53.334092254863158,
    -27.52209771895193, -118.10623547055447, -223.21679912048447,
    -345.73451003291183, -475.15177357231511, -627.03407041192293,
    -791.05428161399163, -982.17580587837483, -1191.5221453748006,
    -1428.2843744314719, -1692.9763053838185, -1986.5827210536718,
    -2318.301793256328, -2681.28515651558, -3091.3226470896207,
    -3539.8893978812648, -4037.7330124635214, -4583.5565883795161,
    -5175.5898570373411, -5825.881136526431, -6516.2574516522172,
    -7263.5501419968068, -8043.58189429269, -8860.6415571362086,
    -9698.6992443216914, -10533.926247971989, -11368.889154550869,
    -12150.339355298502, -12890.310313686143, -13519.604776662751,
    -14042.903868138341, -14563.7444294773, -14722.16584178111,
    -14620.593244571828, -14722.16584178111, -14563.744429477223,
    -14042.903868138341, -13519.604776662902, -12890.310313686143,
    -12150.339355298429, -11368.889154550869, -10533.926247971989,
    -9698.6992443217368, -8860.6415571362086, -8043.5818942926444,
    -7263.5501419968068, -6516.2574516522172, -5825.881136526431,
    -5175.5898570373411, -4583.5565883795161, -4037.7330124635214,
    -3539.8893978812648, -3091.3226470896207, -2681.28515651558,
    -2318.301793256328, -1986.5827210536718, -1692.9763053838185,
    -1428.2843744314719, -1191.5221453748006, -982.17580587836346,
    -791.05428161399163, -627.03407041194566, -475.15177357231511,
    -345.73451003290046, -223.21679912048447, -118.10623547055447,
    -27.52209771895193, 53.334092254863158, 121.12757579141078,
    191.71841702150215, 249.82709938283256, 299.46039876569984,
    343.09988478861413, 382.62723555585546, 415.62375864708622,
    445.93954310271289, 471.57232938036447, 494.40157307981235, 514.054548625108,
    530.73058404133872, 545.15955811033291, 556.8962291647149,
    566.92945232991815, 575.13780636744468, 582.2808511105444,
    587.74024250923219, 591.575169146949, 594.505214471223, 596.36034497233311,
    597.48029821797616, 597.71685142313743, 597.29309869211363,
    596.05179250229355, 594.14670449277708, 592.27079943573187, 589.964116981252,
    586.856390399202, 583.2306226797067, 579.38688909088057, 575.55302362043176,
    571.68666904442443, 567.52894625988074, 563.01757487809664, 560.688076275323,
    611.65971957309409, 614.20099077611155, 619.1224868289504, 623.65818441209,
    627.8760257677726, 632.05842446279746, 636.25158837784227,
    640.20697134457066, 643.597218524996, 646.11359938444309, 648.16004126486121,
    650.2383190934205, 651.59247130047731, 652.05474700703633, 651.796688965066,
    650.57492178801738, 648.5511430595119, 645.35472997847535,
    641.17117364643207, 635.21547393878507, 627.42306149175363,
    618.46849345081353, 607.52315908879325, 594.71951793853975, 578.978818954169,
    560.78678031831214, 539.34717063252674, 514.44254114221576,
    486.47950156662273, 453.40773670591221, 417.41152969727824,
    374.29078340574017, 326.68407138075935, 272.53865387219753,
    209.14736402346514, 132.13917359062168, 58.182646096201957,
    -30.024106602490946, -128.84316596787346, -243.50923540416693,
    -377.16492003589758, -518.34738935162886, -684.03716772211226,
    -862.96830721523668, -1071.4645155036569, -1299.8423404088942,
    -1558.1284084707008, -1846.8832422368775, -2167.1811502403766,
    -2529.0565017341783, -2925.0383525624416, -3372.3519786432203,
    -3861.6975249613879, -4404.7996499602123, -5000.2435509594716,
    -5646.0980258589025, -6355.5066943924712, -7108.6444927115335,
    -7923.8728821783452, -8774.81661195565, -9666.1544259667644,
    -10580.399175623656, -11491.555906878535, -12402.424532237319,
    -13254.915660325632, -14062.156705839423, -14748.659756359362,
    -15319.531492514559, -15887.721195793427, -16060.544554670301,
    -15949.738084987443, -16060.544554670301, -15887.721195793341,
    -15319.531492514559, -14748.659756359522, -14062.156705839423,
    -13254.91566032556, -12402.424532237319, -11491.555906878535,
    -10580.399175623701, -9666.1544259667644, -8774.8166119556045,
    -7923.8728821783452, -7108.6444927115335, -6355.5066943924712,
    -5646.0980258589025, -5000.2435509594716, -4404.7996499602123,
    -3861.6975249613879, -3372.3519786432203, -2925.0383525624416,
    -2529.0565017341783, -2167.1811502403766, -1846.8832422368775,
    -1558.1284084707008, -1299.8423404088942, -1071.4645155036569,
    -862.96830721523668, -684.03716772211226, -518.34738935162886,
    -377.16492003589758, -243.50923540416693, -128.84316596787346,
    -30.024106602490946, 58.182646096201957, 132.13917359062168,
    209.14736402346514, 272.53865387217479, 326.68407138075935,
    374.29078340576291, 417.41152969727824, 453.40773670591221, 486.4795015666,
    514.44254114221576, 539.34717063254948, 560.78678031831214, 578.978818954169,
    594.71951793853975, 607.52315908879325, 618.46849345082489,
    627.42306149175363, 635.2154739387737, 641.17117364643207,
    645.35472997848672, 648.55114305952327, 650.57492178799464,
    651.79668896504324, 652.05474700705906, 651.59247130048868,
    650.23831909340913, 648.16004126484984, 646.11359938443172,
    643.59721852500741, 640.206971344582, 636.25158837785364, 632.05842446279746,
    627.87602576776123, 623.65818441209, 619.1224868289504, 614.20099077611155,
    611.65971957309409, 662.63136287084251, 665.38440667409247,
    670.71602739804291, 675.62969977980117, 680.19902791506809,
    684.72995983468024, 689.27255407602331, 693.557552289962, 697.2303200687287,
    699.95639933315431, 702.1733780369226, 704.4248456845246, 705.891843908875,
    706.39264259095785, 706.11307971214433, 704.78949860369016,
    702.59707164780082, 699.13429081002448, 694.60210478364331, 688.150096767003,
    679.70831661605132, 670.007534571709, 658.15008901288309, 644.27947776675808,
    627.22705386702216, 607.51901201151611, 584.292768185241, 557.31275290404437,
    527.01946003046442, 491.19171476474958, 452.19582383874655,
    405.48168202290037, 353.90774399581881, 295.25020836153971,
    226.57631102540543, 143.15077138983258, 63.031199937563485,
    -32.526115486029965, -139.58009646519247, -263.80167168783805,
    -408.59533003888339, -561.54300513094267, -741.04026503227874,
    -934.88233281650457, -1160.7532251289956, -1408.1625354429648,
    -1687.9724425099296, -2000.7901790899705, -2347.7795794270583,
    -2739.8112102120172, -3168.7915486093261, -3653.3813101968203,
    -4183.5056520414882, -4771.8662874568918, -5416.9305135394388,
    -6116.6061946804866, -6885.1322522585006, -7701.0315337708034,
    -8584.19562235986, -9506.0513296186309, -10471.667294797329,
    -11462.099106925632, -12449.185565785081, -13435.959909923758,
    -14359.491965352781, -15234.003097992716, -15977.714736055977,
    -16596.159116890773, -17211.697962109538, -17398.92326755949,
    -17278.882925403068, -17398.92326755949, -17211.697962109447,
    -16596.159116890773, -15977.714736056148, -15234.003097992716,
    -14359.491965352701, -13435.959909923758, -12449.185565785081,
    -11462.099106925691, -10471.667294797329, -9506.0513296185745,
    -8584.19562235986, -7701.0315337708034, -6885.1322522585006,
    -6116.6061946804866, -5416.9305135394388, -4771.8662874568918,
    -4183.5056520414882, -3653.3813101968203, -3168.7915486093261,
    -2739.8112102120172, -2347.7795794270583, -2000.7901790899705,
    -1687.9724425099296, -1408.1625354429648, -1160.7532251289729,
    -934.88233281650457, -741.04026503230148, -561.54300513094267,
    -408.59533003888339, -263.80167168783805, -139.58009646519247,
    -32.526115486029965, 63.031199937563485, 143.15077138983258,
    226.57631102540543, 295.25020836153971, 353.90774399581881,
    405.48168202290037, 452.19582383874655, 491.19171476474958,
    527.01946003046442, 557.31275290404437, 584.292768185241, 607.51901201151611,
    627.22705386702216, 644.27947776675808, 658.15008901288309, 670.007534571709,
    679.70831661605132, 688.150096767003, 694.60210478364331, 699.13429081002448,
    702.59707164780082, 704.78949860366743, 706.11307971214433,
    706.39264259098059, 705.891843908875, 704.42484568454734, 702.1733780369226,
    699.95639933313157, 697.2303200687287, 693.557552289962, 689.27255407602331,
    684.72995983468024, 680.19902791506809, 675.62969977980117,
    670.71602739804291, 665.38440667409247, 662.63136287084251,
    713.60300616861355, 716.56782257211876, 722.30956796711257,
    727.60121514745538, 732.52203006238619, 737.40149520658565,
    742.2935197741474, 746.90813323534189, 750.86342161250673,
    753.79919928184268, 756.18671480899525, 758.61137227564018,
    760.1912165172273, 760.73053817490222, 760.42947045925689,
    759.00407541935169, 756.64300023608962, 752.9138516415735,
    748.03303592084308, 741.08471959520944, 731.99357174037164,
    721.54657569262713, 708.7770189369387, 693.839437594965, 675.47528877987531,
    654.25124370469746, 629.23836573793267, 600.18296466589561,
    567.55941849435158, 528.975692823587, 486.9801179802148, 436.67258064006052,
    381.13141661085558, 317.9617628508592, 244.00525802739116, 154.1623691890662,
    67.879753778925021, -35.028124369546248, -150.31702696253419,
    -284.09410797153191, -440.02574004189188, -604.73862091023364,
    -798.04336234246807, -1006.7963584177951, -1250.0419347542663,
    -1516.4827304770129, -1817.8164765491586, -2154.6971159430523,
    -2528.3780086137745, -2950.5659186898783, -3412.5447446561761,
    -3934.41064175042, -4505.3137791216122, -5138.9329249536058,
    -5833.6174761193952, -6587.1143635020362, -7414.7578101245408,
    -8293.4185748301079, -9244.5183625414, -10237.286047281603,
    -11277.180163627896, -12343.799038227598, -13406.815224691614,
    -14469.495287610196, -15464.068270379912, -16405.849490145996,
    -17206.769715752594, -17872.786741266988, -18535.674728425663,
    -18737.301980448683, -18608.027765818675, -18737.301980448683,
    -18535.674728425569, -17872.786741266988, -17206.76971575278,
    -16405.849490145996, -15464.068270379821, -14469.495287610196,
    -13406.815224691614, -12343.799038227655, -11277.180163627896,
    -10237.286047281546, -9244.5183625414, -8293.4185748301079,
    -7414.7578101245408, -6587.1143635020362, -5833.6174761193952,
    -5138.9329249536058, -4505.3137791216122, -3934.41064175042,
    -3412.5447446561761, -2950.5659186898556, -2528.3780086137745,
    -2154.697115943075, -1817.8164765491586, -1516.4827304769901,
    -1250.0419347542663, -1006.7963584178178, -798.04336234249081,
    -604.73862091023364, -440.02574004186914, -284.09410797153191,
    -150.31702696253419, -35.028124369546248, 67.879753778925021,
    154.1623691890662, 244.00525802739116, 317.9617628508592, 381.13141661085558,
    436.67258064006052, 486.98011798019206, 528.975692823587, 567.55941849435158,
    600.18296466589561, 629.23836573795541, 654.25124370469746,
    675.47528877987531, 693.839437594965, 708.7770189369387, 721.54657569262713,
    731.99357174037164, 741.08471959520944, 748.03303592084308,
    752.9138516415735, 756.64300023611236, 759.00407541935169,
    760.42947045923415, 760.73053817490222, 760.1912165172273,
    758.61137227564018, 756.18671480899525, 753.79919928184268,
    750.86342161250673, 746.90813323534189, 742.2935197741474,
    737.40149520658565, 732.52203006238619, 727.60121514745538,
    722.30956796711257, 716.56782257211876, 713.60300616861355,
    764.57464946633922, 767.75123847012242, 773.90310853618234,
    779.5727305151097, 784.84503220970441, 790.07303057849117,
    795.31448547233981, 800.25871418074462, 804.49652315623939,
    807.64199923053116, 810.20005158104527, 812.7978988667785,
    814.49058912562509, 815.06843375880112, 814.745861206324, 813.21865223501322,
    810.68892882440127, 806.6934124730999, 801.46396705802022, 794.0193424234842,
    784.27882686469206, 773.08561681349988, 759.40394886101717,
    743.39939742319461, 723.72352369270561, 700.98347539790154,
    674.18396329066979, 643.05317642772422, 608.09937695821588,
    566.75967088240168, 521.76441212163763, 467.86347925722072,
    408.35508922596057, 340.67331734022417, 261.43420502933145,
    165.1739669882771, 72.7283076202638, -37.530133253108, -161.05395745985319,
    -304.386544255203, -471.45615004487769, -647.93423668954745,
    -855.04645965263455, -1078.7103840190402, -1339.3306443795825,
    -1624.8029255111064, -1947.6605105883646, -2308.6040527961109,
    -2708.9764378004907, -3161.32062716774, -3656.2979407030493,
    -4215.4399733039972, -4827.1219062017235, -5505.9995624502972,
    -6250.3044386993624, -7057.6225323236195, -7944.3833679905692,
    -8885.8056158894015, -9904.8411027229267, -10968.520764944562,
    -12082.693032458452, -13225.498969529575, -14364.444883598171,
    -15503.030665296646, -16568.644575407037, -17577.695882299282,
    -18435.82469544921, -19149.414365643192, -19859.651494741775,
    -20075.680693337872, -19937.172606234308, -20075.680693337872,
    -19859.651494741673, -19149.414365643192, -18435.824695449402,
    -17577.695882299282, -16568.644575406946, -15503.030665296646,
    -14364.444883598171, -13225.498969529634, -12082.693032458452,
    -10968.520764944506, -9904.8411027229267, -8885.8056158894015,
    -7944.3833679905692, -7057.6225323236195, -6250.3044386993624,
    -5505.9995624502972, -4827.1219062017235, -4215.4399733039972,
    -3656.2979407030493, -3161.32062716774, -2708.9764378004907,
    -2308.6040527961109, -1947.6605105883646, -1624.8029255110837,
    -1339.3306443795825, -1078.710384019063, -855.04645965263455,
    -647.93423668954745, -471.45615004487769, -304.386544255203,
    -161.05395745985319, -37.530133253108, 72.7283076202638, 165.1739669882771,
    261.43420502933145, 340.67331734022417, 408.35508922596057,
    467.86347925722072, 521.7644121216149, 566.75967088237894,
    608.09937695823862, 643.053176427747, 674.18396329066979, 700.98347539790154,
    723.72352369270561, 743.39939742319461, 759.40394886101717,
    773.08561681352262, 784.27882686466933, 794.01934242346147, 801.463967058043,
    806.6934124730999, 810.68892882440127, 813.21865223501322, 814.745861206324,
    815.06843375880112, 814.49058912562509, 812.7978988667785,
    810.20005158104527, 807.64199923053116, 804.49652315623939,
    800.25871418074462, 795.31448547233981, 790.07303057849117,
    784.84503220970441, 779.5727305151097, 773.90310853618234,
    767.75123847012242, 764.57464946633922, 815.54629276411038,
    818.93465436814881, 825.49664910529759, 831.54424588278675,
    837.16803435699978, 842.74456595039658, 848.3354511704639,
    853.60929512610176, 858.12962470001742, 861.484799179265, 864.21338835311792,
    866.98442545787123, 868.78996173397729, 869.40632934272264,
    869.06225195343643, 867.43322905069738, 864.73485741266734,
    860.47297330462618, 854.89489819524272, 846.95396525171338,
    836.56408198901238, 824.62465793439537, 810.03087878505016,
    792.95935725140157, 771.9717586055815, 747.71570709110551,
    719.12956084338407, 685.92338818959831, 648.639335422103, 604.54364894121625,
    556.54870626306047, 499.05437787435812, 435.57876184102, 363.38487182956635,
    278.86315203129448, 176.18556478751071, 77.5768614616026,
    -40.032142136669755, -171.7908879571722, -324.6789805388741,
    -502.88656004786344, -691.12985246883852, -912.04955696280115,
    -1150.6244096203309, -1428.6193540048985, -1733.123120545177,
    -2077.5045446275935, -2462.51098964917, -2889.5748669871609,
    -3372.0753356455784, -3900.0511367499448, -4496.46930485762,
    -5148.9300332818357, -5873.0661999469648, -6666.9914012793179,
    -7528.1307011452036, -8474.00892585662, -9478.192656948695,
    -10565.163842904441, -11699.755482607545, -12888.205901289029,
    -14107.198900831541, -15322.074542504695, -16536.566042983086,
    -17673.220880434186, -18749.542274452575, -19664.879675145829,
    -20426.04199001941, -21183.628261057886, -21414.059406227065,
    -21266.31744664994, -21414.059406227065, -21183.628261057776,
    -20426.04199001941, -19664.87967514604, -18749.542274452575,
    -17673.220880434084, -16536.566042983086, -15322.074542504695,
    -14107.19890083161, -12888.205901289029, -11699.755482607476,
    -10565.163842904441, -9478.192656948695, -8474.00892585662,
    -7528.1307011452036, -6666.9914012793179, -5873.0661999469648,
    -5148.9300332818357, -4496.46930485762, -3900.0511367499448,
    -3372.0753356455557, -2889.5748669871609, -2462.5109896491927,
    -2077.5045446275935, -1733.123120545177, -1428.6193540048985,
    -1150.6244096203309, -912.04955696280115, -691.12985246883852,
    -502.88656004786344, -324.6789805388741, -171.7908879571722,
    -40.032142136669755, 77.5768614616026, 176.18556478751071,
    278.86315203129448, 363.38487182956635, 435.57876184102, 499.05437787435812,
    556.54870626306047, 604.54364894121625, 648.639335422103, 685.92338818959831,
    719.12956084338407, 747.71570709110551, 771.9717586055815,
    792.95935725140157, 810.03087878505016, 824.62465793439537,
    836.56408198901238, 846.95396525171338, 854.89489819524272,
    860.47297330462618, 864.73485741269008, 867.43322905069738,
    869.06225195341369, 869.40632934272264, 868.78996173397729, 866.984425457894,
    864.21338835311792, 861.48479917921952, 858.12962469999468,
    853.60929512612449, 848.33545117048664, 842.74456595039658,
    837.16803435699978, 831.54424588278675, 825.49664910529759,
    818.93465436814881, 815.54629276411038, 866.51793606188141,
    870.11807026615236, 877.09018967434451, 883.5157612504637,
    889.49103650434074, 895.4161013223021, 901.35641686861084, 906.959876071459,
    911.76272624372734, 915.32759912797621, 918.22672512523616,
    921.17095204898681, 923.08933434232961, 923.74422492664428,
    923.37864270052626, 921.64780586635891, 918.78078600095625,
    914.25253413617531, 908.32582933246533, 899.88858807994268,
    888.84933711331007, 876.16369905531349, 860.65780870912852,
    842.51931707960841, 820.21999351843465, 794.44793878428686,
    764.07515839607572, 728.79359995144955, 689.17929388601294,
    642.32762700005367, 591.33300040448319, 530.24527649147285,
    462.80243445607954, 386.09642631893132, 296.29209903325744,
    187.19716258672162, 82.42541530296414, -42.534151020186037,
    -182.52781845451392, -344.97141682256796, -534.31697005084925,
    -734.32546824812948, -969.05265427299037, -1222.5384352216213,
    -1517.9080636301919, -1841.4433155792478, -2207.3485786668225,
    -2616.417926502229, -3070.1732961738544, -3582.83004412344,
    -4143.8043327967953, -4777.4986364112192, -5470.7381603619706,
    -6240.1328374436562, -7083.6783638592742, -7998.6388699667641,
    -9003.63448372265, -10070.579698008001, -11225.48658308598,
    -12430.990200270504, -13693.718770119585, -14988.898832133518,
    -16279.704201411252, -17570.101420669522, -18777.79718546131,
    -19921.38866660585, -20893.934654842436, -21702.669614395625,
    -22507.605027374018, -22752.438119116254, -22595.462287065537,
    -22752.438119116254, -22507.6050273739, -21702.669614395625,
    -20893.934654842658, -19921.38866660585, -18777.797185461208,
    -17570.101420669522, -16279.704201411252, -14988.898832133598,
    -13693.718770119585, -12430.990200270424, -11225.48658308598,
    -10070.579698008001, -9003.63448372265, -7998.6388699667641,
    -7083.6783638592742, -6240.1328374436562, -5470.7381603619706,
    -4777.4986364112192, -4143.8043327967725, -3582.8300441234173,
    -3070.1732961738771, -2616.4179265022517, -2207.3485786668225,
    -1841.4433155792478, -1517.9080636301919, -1222.5384352215985,
    -969.05265427299037, -734.32546824815222, -534.31697005084925,
    -344.97141682256796, -182.52781845451392, -42.534151020186037,
    82.42541530296414, 187.19716258672162, 296.29209903323471,
    386.09642631890858, 462.80243445610228, 530.24527649149559,
    591.33300040448319, 642.32762700005367, 689.17929388601294,
    728.79359995144955, 764.07515839607572, 794.44793878428686,
    820.21999351843465, 842.51931707960841, 860.65780870912852,
    876.16369905531349, 888.84933711331007, 899.88858807994268,
    908.32582933246533, 914.25253413617531, 918.78078600095625,
    921.64780586633617, 923.37864270050352, 923.744224926667, 923.08933434235234,
    921.17095204898681, 918.22672512521342, 915.32759912797621,
    911.76272624375008, 906.959876071459, 901.35641686861084, 895.4161013223021,
    889.49103650434074, 883.5157612504637, 877.09018967434451,
    870.11807026615236, 866.51793606188141, 917.48957935960709,
    921.30148616413328, 928.683730243437, 935.48727661816349, 941.81403865163622,
    948.08763669416214, 954.37738256678051, 960.31045701688436,
    965.39582778748263, 969.17039907666458, 972.24006189730881, 975.357478640125,
    977.38870695070455, 978.0821205105658, 977.69503344759323,
    975.86238268199759, 972.82671458926779, 968.03209496774707,
    961.7567604696651, 952.82321090814924, 941.13459223760776,
    927.70274017623171, 911.284738633207, 892.07927690781537, 868.468228431265,
    841.1801704774681, 809.02075594879011, 771.6638117133009, 729.71925234987725,
    680.11160505886835, 626.11729454597423, 561.43617510865579, 490.026107071139,
    408.80798080827356, 313.72104603519773, 198.20876038593252,
    87.273969144302939, -45.03615990372505, -193.26474895181019,
    -365.26385310626176, -565.7473800538578, -777.52108402742056,
    -1026.055751583157, -1294.4524608228892, -1607.1967732555081,
    -1949.7635106133184, -2337.192612706051, -2770.3248633553335,
    -3250.7717253605706, -3793.584752601279, -4387.5575288436685,
    -5058.5279679648193, -5792.5462874420591, -6607.1994749403248,
    -7500.3653264392306, -8469.1470387883473, -9533.2600415887009,
    -10662.966739067282, -11885.809323267484, -13162.224917933474,
    -14499.231638950163, -15870.598763435508, -17237.333860317798,
    -18603.636798355961, -19882.373490488459, -21093.235058759146,
    -22122.989634539048, -22979.297238771836, -23831.581793690129,
    -24090.81683200545, -23924.607127481169, -24090.81683200545,
    -23831.581793690006, -22979.297238771836, -22122.989634539284,
    -21093.235058759146, -19882.373490488346, -18603.636798355961,
    -17237.333860317798, -15870.598763435575, -14499.231638950163,
    -13162.224917933407, -11885.809323267484, -10662.966739067282,
    -9533.2600415887009, -8469.1470387883473, -7500.3653264392306,
    -6607.1994749403248, -5792.5462874420591, -5058.5279679648193,
    -4387.5575288436685, -3793.584752601279, -3250.7717253605706,
    -2770.3248633553335, -2337.192612706051, -1949.7635106133184,
    -1607.1967732555081, -1294.4524608228892, -1026.055751583157,
    -777.52108402742056, -565.7473800538578, -365.26385310626176,
    -193.26474895181019, -45.03615990372505, 87.273969144302939,
    198.20876038593252, 313.72104603519773, 408.80798080827356, 490.026107071139,
    561.43617510865579, 626.11729454595149, 680.11160505886835,
    729.71925234987725, 771.6638117133009, 809.02075594881285, 841.1801704774681,
    868.468228431265, 892.07927690781537, 911.284738633207, 927.70274017623171,
    941.13459223760776, 952.82321090814924, 961.7567604696651,
    968.03209496774707, 972.82671458926779, 975.86238268199759,
    977.69503344757049, 978.0821205105658, 977.38870695072728, 975.357478640125,
    972.24006189728607, 969.17039907666458, 965.39582778750537,
    960.31045701686162, 954.37738256678051, 948.08763669418488,
    941.81403865163622, 935.48727661816349, 928.683730243437, 921.30148616413328,
    917.48957935960709, 968.46122265737813, 972.48490206215956,
    980.27727081252942, 987.45879198584043, 994.13704079895433,
    1000.7591720660675, 1007.3983482649273, 1013.6610379622643,
    1019.028929331238, 1023.0131990253531, 1026.2533986693361,
    1029.5440052312406, 1031.6880795591251, 1032.4200160944874,
    1032.0114241946831, 1030.0769594976819, 1026.8726431775567,
    1021.8116557992735, 1015.1876916068422, 1005.7578337363784,
    993.41984736195081, 979.24178129712709, 961.9116685572626,
    941.63923673602233, 916.7164633441181, 887.91240217067218,
    853.96635350150439, 814.53402347515225, 770.25921081376441,
    717.89558311770566, 660.90158868739707, 592.62707372579314,
    517.24977968619851, 431.51953529761573, 331.149993037138, 209.2203581851434,
    92.12252298566446, -47.53816878726407, -204.0016794491292,
    -385.55628938993289, -597.17779005684349, -820.71669980673437,
    -1083.0588488933463, -1366.3664864241343, -1696.4854828808013,
    -2058.0837056473893, -2467.0366467452573, -2924.2318002084148,
    -3431.3701545472636, -4004.3394610791174, -4631.3107248905408,
    -5339.5572995184193, -6114.354414522194, -6974.2661124370379,
    -7917.052289019186, -8939.6552076099324, -10062.88559945473,
    -11255.353780126543, -12546.132063449033, -13893.459635596479,
    -15304.744507780717, -16752.298694737448, -18194.963519224344,
    -19637.172176042412, -20986.949795515582, -22265.081450912421,
    -23352.044614235656, -24255.924863148051, -25155.558560006255,
    -25429.195544894639, -25253.751967896776, -25429.195544894639,
    -25155.558560006124, -24255.924863148051, -23352.0446142359,
    -22265.081450912421, -20986.949795515469, -19637.172176042412,
    -18194.963519224344, -16752.298694737539, -15304.744507780717,
    -13893.459635596388, -12546.132063449033, -11255.353780126543,
    -10062.88559945473, -8939.6552076099324, -7917.052289019186,
    -6974.2661124370379, -6114.354414522194, -5339.5572995184193,
    -4631.3107248905408, -4004.3394610791174, -3431.3701545472636,
    -2924.2318002084148, -2467.0366467452573, -2058.0837056473665,
    -1696.4854828808013, -1366.3664864241571, -1083.0588488933463,
    -820.71669980673437, -597.17779005684349, -385.55628938993289,
    -204.0016794491292, -47.53816878726407, 92.12252298566446, 209.2203581851434,
    331.149993037138, 431.51953529761573, 517.24977968619851, 592.62707372579314,
    660.90158868739707, 717.89558311770566, 770.25921081376441,
    814.53402347515225, 853.96635350150439, 887.91240217067218,
    916.7164633441181, 941.63923673602233, 961.9116685572626, 979.24178129712709,
    993.41984736192808, 1005.7578337363784, 1015.187691606865,
    1021.8116557992735, 1026.8726431775794, 1030.0769594976819,
    1032.0114241946603, 1032.4200160944874, 1031.6880795591251,
    1029.5440052312406, 1026.2533986693361, 1023.0131990253531,
    1019.028929331238, 1013.6610379622416, 1007.3983482649501,
    1000.7591720660903, 994.13704079893159, 987.45879198584043,
    980.27727081252942, 972.48490206215956, 968.46122265737813,
    1019.4328659551493, 1023.6683179601632, 1031.8708113815992,
    1039.4303073534948, 1046.4600429462498, 1053.4307074379731,
    1060.419313963097, 1067.0116189076443, 1072.6620308749934,
    1076.8559989740643, 1080.2667354414089, 1083.7305318223562,
    1085.9874521674774, 1086.7579116784091, 1086.3278149417729,
    1084.2915363133434, 1080.9185717658456, 1075.5912166308226,
    1068.6186227440649, 1058.6924565646077, 1045.7051024862485,
    1030.7808224180226, 1012.5385984813411, 991.19919656425191,
    964.96469825697113, 934.64463386387627, 898.91195105421878,
    857.40423523700349, 810.79916927765157, 755.67956117652034,
    695.6858828288199, 623.8179723429306, 544.47345230128076, 454.2310897869807,
    348.57894003910104, 220.2319559843543, 96.971076827003259,
    -50.040177670803089, -214.73860994647092, -405.848725673604,
    -628.60820005980656, -863.91231558604807, -1140.0619462035356,
    -1438.2805120254247, -1785.7741925061175, -2166.40390068146,
    -2596.8806807844862, -3078.1387370614739, -3611.9685837339571,
    -4215.0941695569791, -4875.063920937414, -5620.5866310720194,
    -6436.1625416023062, -7341.3327499337065, -8333.7392515991414,
    -9410.163376431492, -10592.51115732076, -11847.740821185869,
    -13206.454803630584, -14624.694353259438, -16110.257376611262,
    -17633.998626039425, -19152.59317813089, -20670.707553728862,
    -22091.526100542742, -23436.927843065703, -24581.099593932267,
    -25532.552487524266, -26479.535326322377, -26767.574257783835,
    -26582.8968083124, -26767.574257783835, -26479.535326322239,
    -25532.552487524266, -24581.099593932526, -23436.927843065703,
    -22091.526100542618, -20670.707553728862, -19152.59317813089,
    -17633.998626039516, -16110.257376611262, -14624.694353259347,
    -13206.454803630584, -11847.740821185869, -10592.51115732076,
    -9410.163376431492, -8333.7392515991414, -7341.3327499337065,
    -6436.1625416023062, -5620.5866310720194, -4875.0639209373912,
    -4215.0941695569563, -3611.96858373398, -3078.1387370614966,
    -2596.8806807844862, -2166.40390068146, -1785.7741925061175,
    -1438.2805120254247, -1140.0619462035356, -863.91231558604807,
    -628.60820005980656, -405.84872567358127, -214.73860994647092,
    -50.040177670825827, 96.971076827003259, 220.2319559843543,
    348.57894003910104, 454.2310897869807, 544.47345230128076, 623.8179723429306,
    695.6858828288199, 755.67956117652034, 810.79916927765157,
    857.40423523700349, 898.91195105421878, 934.64463386387627,
    964.96469825697113, 991.19919656425191, 1012.5385984813411,
    1030.7808224180226, 1045.7051024862485, 1058.6924565646077,
    1068.6186227440649, 1075.5912166308226, 1080.9185717658456,
    1084.2915363133206, 1086.3278149417729, 1086.7579116784318,
    1085.9874521674774, 1083.7305318223562, 1080.2667354414089,
    1076.8559989740415, 1072.6620308749934, 1067.0116189076443,
    1060.419313963097, 1053.4307074379958, 1046.4600429462498,
    1039.4303073534948, 1031.8708113815992, 1023.6683179601632,
    1019.4328659551493, 1070.4045092529204, 1074.8517338581896,
    1083.464351950669, 1091.4018227211718, 1098.7830450935908,
    1106.1022428098786, 1113.4402796612212, 1120.3621998530016,
    1126.2951324187488, 1130.6987989227755, 1134.2800722135044,
    1137.9170584134945, 1140.2868247758524, 1141.0958072623307,
    1140.6442056888627, 1138.5061131290049, 1134.9645003541345,
    1129.3707774623263, 1122.049553881242, 1111.6270793928825,
    1097.9903576105689, 1082.3198635388953, 1063.1655284053968,
    1040.7591563924816, 1013.2129331698243, 981.3768655570575,
    943.85754860693316, 900.27444699885484, 851.33912774153862, 793.463539235335,
    730.47017697024262, 655.0088709600908, 571.697124916363, 476.94264427632294,
    366.00788704104127, 231.2435537835652, 101.81963066836479, -52.5421865543421,
    -225.47554044378992, -426.14116195727507, -660.03861006281511,
    -907.10793136533914, -1197.065043513702, -1510.1945376267154,
    -1875.062902131411, -2274.7240957155309, -2726.7247148237152,
    -3232.0456739145329, -3792.5670129206505, -4425.848878034818,
    -5118.8171169842872, -5901.6159626256413, -6757.9706686824175,
    -7708.3993874303742, -8750.426214179075, -9880.6715452530771,
    -11122.136715186834, -12440.127862245174, -13866.77754381211,
    -15355.929070922399, -16915.770245441818, -18515.698557341402,
    -20110.222837037432, -21704.2429314153, -23196.102405569869,
    -24608.774235218993, -25810.154573628883, -26809.180111900467,
    -27803.512092638484, -28105.952970673021, -27912.041648728027,
    -28105.952970673021, -27803.512092638339, -26809.180111900467,
    -25810.154573629166, -24608.774235218993, -23196.102405569731,
    -21704.2429314153, -20110.222837037432, -18515.698557341493,
    -16915.770245441818, -15355.929070922308, -13866.77754381211,
    -12440.127862245174, -11122.136715186834, -9880.6715452530771,
    -8750.426214179075, -7708.3993874303742, -6757.9706686824175,
    -5901.6159626256413, -5118.8171169842872, -4425.848878034818,
    -3792.5670129206505, -3232.0456739145329, -2726.7247148237152,
    -2274.7240957155309, -1875.062902131411, -1510.1945376267154,
    -1197.0650435137247, -907.10793136533914, -660.03861006279237,
    -426.14116195727507, -225.47554044378992, -52.5421865543421,
    101.81963066836479, 231.2435537835652, 366.00788704104127,
    476.94264427632294, 571.69712491634027, 655.0088709600908,
    730.47017697026536, 793.463539235335, 851.33912774151588, 900.27444699885484,
    943.8575486069559, 981.3768655570575, 1013.2129331698243, 1040.7591563924816,
    1063.1655284053968, 1082.3198635388953, 1097.9903576105462,
    1111.6270793928825, 1122.0495538812647, 1129.3707774623263,
    1134.9645003541573, 1138.5061131290049, 1140.64420568884, 1141.0958072623534,
    1140.2868247758524, 1137.9170584134718, 1134.2800722135044,
    1130.6987989227528, 1126.2951324187261, 1120.3621998530243,
    1113.4402796612667, 1106.1022428098786, 1098.783045093568,
    1091.4018227211718, 1083.464351950669, 1074.8517338581896,
    1070.4045092529204, 1121.3761525506461, 1126.0351497561933,
    1135.0578925197615, 1143.3733380888489, 1151.1060472408863,
    1158.7737781817611, 1166.4612453593907, 1173.7127807984041,
    1179.928233962504, 1184.5415988714865, 1188.2934089855542,
    1192.1035850045871, 1194.5861973842273, 1195.4337028462521,
    1194.9605964359523, 1192.7206899446662, 1189.010428942446,
    1183.1503382938979, 1175.4804850184416, 1164.5617022210888,
    1150.2756127349121, 1133.8589046598363, 1113.7924583294298,
    1090.3191162206658, 1061.4611680826774, 1028.1090972502161,
    988.8031461596247, 943.14465876072893, 891.87908620542578,
    831.24751729417244, 765.25447111171093, 686.19976957722827,
    598.92079753139967, 499.65419876566511, 383.4368340430043,
    242.25515158282155, 106.66818450972632, -55.044195437903859,
    -236.21247094110893, -446.43359824096893, -691.46902006582366,
    -950.30354714463022, -1254.0681408238459, -1582.1085632279833,
    -1964.3516117567497, -2383.0442907496013, -2856.5687488629437,
    -3385.952610767637, -3973.1654421073436, -4636.603586512656,
    -5362.57031303116, -6182.6452941792413, -7079.77879576253,
    -8075.4660249270428, -9167.1131767590323, -10351.179714074682,
    -11651.762273052862, -13032.514903304434, -14527.100283993614,
    -16087.16378858538, -17721.283114272417, -19397.398488643383,
    -21067.852495943978, -22737.778309101737, -24300.678710597003,
    -25780.620627372286, -27039.2095533255, -28085.807736276682,
    -29127.4888589546, -29444.331683562221, -29241.186489143656,
    -29444.331683562221, -29127.488858954446, -28085.807736276682,
    -27039.209553325803, -25780.620627372286, -24300.678710596858,
    -22737.778309101737, -21067.852495943978, -19397.398488643474,
    -17721.283114272417, -16087.163788585289, -14527.100283993614,
    -13032.514903304434, -11651.762273052862, -10351.179714074682,
    -9167.1131767590323, -8075.4660249270428, -7079.77879576253,
    -6182.6452941792413, -5362.57031303116, -4636.603586512656,
    -3973.1654421073436, -3385.952610767637, -2856.5687488629437,
    -2383.0442907496013, -1964.3516117567269, -1582.1085632279833,
    -1254.0681408238913, -950.30354714463022, -691.46902006580092,
    -446.43359824096893, -236.21247094110893, -55.044195437903859,
    106.66818450972632, 242.25515158282155, 383.4368340430043,
    499.65419876566511, 598.92079753139967, 686.19976957722827,
    765.25447111171093, 831.24751729417244, 891.87908620542578,
    943.14465876072893, 988.8031461596247, 1028.1090972502161,
    1061.4611680826774, 1090.3191162206658, 1113.7924583294298,
    1133.8589046598363, 1150.2756127348894, 1164.5617022210888,
    1175.4804850184644, 1183.1503382938979, 1189.010428942446,
    1192.7206899446662, 1194.9605964359523, 1195.4337028462749,
    1194.5861973842273, 1192.1035850045871, 1188.2934089855542,
    1184.5415988714637, 1179.928233962504, 1173.7127807984041,
    1166.4612453594134, 1158.7737781817611, 1151.1060472408635,
    1143.3733380888489, 1135.0578925197615, 1126.0351497561933,
    1121.3761525506461, 1172.347795848417, 1177.2185656541967,
    1186.6514330888538, 1195.3448534565484, 1203.4290493882042,
    1211.4453135536667, 1219.4822110575376, 1227.0633617437841,
    1233.5613355062594, 1238.384398820175, 1242.3067457576269,
    1246.2901115957027, 1248.8855699925796, 1249.7715984301738,
    1249.2769871830421, 1246.9352667603505, 1243.0563575307349,
    1236.9298991254243, 1228.9114161556643, 1217.4963250493181,
    1202.5608678591868, 1185.3979457807316, 1164.4193882535308,
    1139.8790760488728, 1109.7094029955306, 1074.8413289434429,
    1033.7487437123391, 986.01487052253469, 932.4190446692902,
    869.03149535303248, 800.0387652531565, 717.39066819436562,
    626.14447014645918, 522.36575325500735, 400.86578104499006,
    253.26674938203246, 111.51673835106511, -57.546204321420142,
    -246.94940143845065, -466.72603452466279, -722.89943006880935,
    -993.49916292394391, -1311.0712381340352, -1654.0225888292284,
    -2053.6403213820204, -2491.3644857836721, -2986.4127829021954,
    -3539.8595476207188, -4153.763871294037, -4847.3582949905176,
    -5606.3235090780336, -6463.6746257328186, -7401.5869228426418,
    -8442.5326624237568, -9583.80013933901, -10821.687882896244,
    -12181.387830918891, -13624.901944363739, -15187.423024175141,
    -16818.398506248341, -18526.795983102973, -20279.098419945334,
    -22025.482154850524, -23771.3136867882, -25405.25501562413,
    -26952.467019525568, -28268.264533022117, -29362.435360652897,
    -30451.465625270717, -30782.710396451406, -30570.331329559278,
    -30782.710396451406, -30451.465625270557, -29362.435360652897,
    -28268.264533022422, -26952.467019525568, -25405.255015623981,
    -23771.3136867882, -22025.482154850524, -20279.098419945425,
    -18526.795983102973, -16818.39850624825, -15187.423024175141,
    -13624.901944363739, -12181.387830918891, -10821.687882896244,
    -9583.80013933901, -8442.5326624237568, -7401.5869228426418,
    -6463.6746257328186, -5606.3235090780108, -4847.3582949904949,
    -4153.76387129406, -3539.8595476207415, -2986.4127829021954,
    -2491.3644857836493, -2053.6403213820204, -1654.0225888292512,
    -1311.0712381340352, -993.49916292394391, -722.89943006880935,
    -466.72603452466279, -246.94940143845065, -57.546204321420142,
    111.51673835106511, 253.26674938203246, 400.86578104499006,
    522.36575325500735, 626.14447014645918, 717.39066819436562,
    800.0387652531565, 869.03149535303248, 932.4190446692902, 986.01487052253469,
    1033.7487437123391, 1074.8413289434429, 1109.7094029955306,
    1139.8790760488728, 1164.4193882535308, 1185.3979457807316,
    1202.5608678591868, 1217.4963250493181, 1228.9114161556643,
    1236.929899125447, 1243.0563575307349, 1246.9352667603277,
    1249.2769871830194, 1249.7715984301965, 1248.8855699926023, 1246.29011159568,
    1242.3067457576269, 1238.384398820175, 1233.5613355062367,
    1227.0633617437841, 1219.4822110575831, 1211.4453135536667,
    1203.4290493881815, 1195.3448534565484, 1186.6514330888538,
    1177.2185656541967, 1172.347795848417, 1223.3194391461882,
    1228.4019815522231, 1238.2449736579008, 1247.31636882418, 1255.7520515355452,
    1264.1168489255949, 1272.5031767556845, 1280.4139426891413,
    1287.1944370499921, 1292.2271987688862, 1296.3200825297224,
    1300.476638186841, 1303.1849426009546, 1304.1094940140727, 1303.593377930132,
    1301.1498435760348, 1297.1022861190238, 1290.7094599569507,
    1282.3423472928641, 1270.4309478775701, 1254.8461229835073,
    1236.9369869016271, 1215.0463181775865, 1189.4390358770795,
    1157.957637908338, 1121.5735606366243, 1078.6943412650535,
    1028.8850822844315, 972.95900313324546, 906.81547341182443,
    834.82305939455648, 748.58156681148034, 653.3681427615187,
    545.07730774439506, 418.29472804693029, 264.27834718124336,
    116.36529219240391, -60.048213204981892, -257.68633193574692,
    -487.01847080833386, -754.32984007179516, -1036.6947787032577,
    -1368.0743354442245, -1725.9366144304734, -2142.9290310073138,
    -2599.6846808177884, -3116.2568169414017, -3693.7664844737551,
    -4334.3623004807532, -5058.1130034683565, -5850.0767051248831,
    -6744.7039572864405, -7723.3950499227758, -8809.5992999204245,
    -10000.487101918943, -11292.196051717805, -12711.013388784942,
    -14217.288985423067, -15847.74576435669, -17549.6332239113,
    -19332.308851933529, -21160.798351247311, -22983.11181375707,
    -24804.849064474638, -26509.831320651265, -28124.313411678846,
    -29497.319512718725, -30639.062985029119, -31775.442391586854,
    -32121.089109340603, -31899.476169974885, -32121.089109340603,
    -31775.442391586683, -30639.062985029119, -29497.319512719045,
    -28124.313411678846, -26509.831320651119, -24804.849064474638,
    -22983.11181375707, -21160.798351247402, -19332.308851933529,
    -17549.633223911209, -15847.74576435669, -14217.288985423067,
    -12711.013388784942, -11292.196051717805, -10000.487101918943,
    -8809.5992999204245, -7723.3950499227758, -6744.7039572864405,
    -5850.0767051248831, -5058.1130034683565, -4334.3623004807532,
    -3693.7664844737551, -3116.2568169414017, -2599.6846808177884,
    -2142.9290310073138, -1725.9366144304734, -1368.0743354442245,
    -1036.6947787032577, -754.32984007179516, -487.01847080833386,
    -257.68633193574692, -60.048213204981892, 116.36529219240391,
    264.27834718124336, 418.29472804693029, 545.07730774434958,
    653.3681427615187, 748.58156681152582, 834.82305939455648,
    906.81547341182443, 972.9590031332, 1028.8850822844315, 1078.694341265099,
    1121.5735606366243, 1157.957637908338, 1189.4390358770795,
    1215.0463181775865, 1236.9369869016498, 1254.8461229835073,
    1270.4309478775474, 1282.3423472928641, 1290.7094599569734,
    1297.1022861190465, 1301.1498435759893, 1303.5933779300865,
    1304.1094940141181, 1303.1849426009774, 1300.4766381868183,
    1296.3200825296997, 1292.2271987688634, 1287.1944370500148,
    1280.4139426891641, 1272.5031767557073, 1264.1168489255949,
    1255.7520515355225, 1247.31636882418, 1238.2449736579008, 1228.4019815522231,
    1223.3194391461882, 1274.2910824439139, 1279.585397450204,
    1289.8385142269933, 1299.2878841918571, 1308.0750536828407,
    1316.7883842975004, 1325.5241424538542, 1333.7645236345213,
    1340.8275385937247, 1346.0699987175974, 1350.3334193017952,
    1354.6631647779566, 1357.4843152093297, 1358.4473895979943,
    1357.9097686771991, 1355.3644203916963, 1351.1482147073355,
    1344.4890207885226, 1335.7732784300413, 1323.365570705754,
    1307.1313781078504, 1288.4760280225225, 1265.673248101665,
    1238.9989957053319, 1206.2058728211912, 1168.3057923297827,
    1123.6399388177679, 1071.7552940462601, 1013.4989615970871,
    944.59945147068458, 869.60735353604753, 779.77246542864054,
    680.59181537655547, 567.78886223373729, 435.72367504889331,
    275.28994498043153, 121.2138460337427, -62.550222088475437,
    -268.42326243304319, -507.310907092005, -785.760250074781,
    -1079.8903944825715, -1425.0774327544136, -1797.850640031764,
    -2232.21774063263, -2708.0048758518365, -3246.1008509806534,
    -3847.6734213268592, -4514.9607296674694, -5268.8677119461954,
    -6093.8299011717108, -7025.7332888400178, -8045.203177002888,
    -9176.66593741714, -10417.174064498899, -11762.704220539388,
    -13240.638946650972, -14809.676026482326, -16508.068504538216,
    -18280.867941574303, -20137.821720764106, -22042.498282549266,
    -23940.741472663605, -25838.384442161067, -27614.407625678403,
    -29296.159803832139, -30726.37449241534, -31915.690609405334,
    -33099.419157902965, -33459.467822229788, -33228.6210103905,
    -33459.467822229788, -33099.41915790279, -31915.690609405334,
    -30726.374492415664, -29296.159803832139, -27614.407625678254,
    -25838.384442161067, -23940.741472663605, -22042.498282549379,
    -20137.821720764106, -18280.86794157419, -16508.068504538216,
    -14809.676026482326, -13240.638946650972, -11762.704220539388,
    -10417.174064498899, -9176.66593741714, -8045.203177002888,
    -7025.7332888400178, -6093.8299011717108, -5268.8677119461954,
    -4514.9607296674694, -3847.6734213268592, -3246.1008509806534,
    -2708.004875851791, -2232.2177406325845, -1797.8506400318095,
    -1425.0774327544591, -1079.8903944825715, -785.760250074781,
    -507.31090709195951, -268.42326243304319, -62.550222088520911,
    121.2138460337427, 275.28994498043153, 435.72367504889331,
    567.78886223373729, 680.59181537655547, 779.77246542864054,
    869.60735353604753, 944.59945147068458, 1013.4989615970871,
    1071.7552940462601, 1123.6399388177679, 1168.3057923297827,
    1206.2058728211912, 1238.9989957053319, 1265.673248101665,
    1288.4760280225225, 1307.1313781078049, 1323.365570705754,
    1335.7732784300867, 1344.4890207885226, 1351.1482147073355,
    1355.3644203916963, 1357.9097686771991, 1358.4473895979943,
    1357.4843152093297, 1354.6631647779566, 1350.3334193017724,
    1346.0699987175747, 1340.8275385937475, 1333.764523634544,
    1325.5241424538769, 1316.7883842975004, 1308.075053682818,
    1299.2878841918571, 1289.8385142269933, 1279.585397450204,
    1274.2910824439139, 1325.262725741685, 1330.7688133481849,
    1341.4320547960858, 1351.2593995596023, 1360.3980558301362,
    1369.4599196693605, 1378.5451081520466, 1387.115104579924,
    1394.4606401374574, 1399.9127986663086, 1404.3467560738452,
    1408.8496913690492, 1411.78368781775, 1412.7852851819157, 1412.2261594242887,
    1409.5789972073803, 1405.1941432956016, 1398.268581620049,
    1389.2042095672866, 1376.300193534006, 1359.4166332321026, 1340.015069143418,
    1316.3001780257662, 1288.5589555335162, 1254.4541077340443,
    1215.0380240230322, 1168.585536370482, 1114.6255058080887,
    1054.0389200609288, 982.38342952949915, 904.3916476774931,
    810.96336404580074, 707.81548799163761, 590.50041672307941,
    453.15262205081086, 286.30154277966517, 126.06239987512697,
    -65.052230972059931, -279.16019293038494, -527.6033433756761,
    -817.19066007776678, -1123.0860102618853, -1482.0805300645575,
    -1869.7646656330091, -2321.5064502579912, -2816.3250708859296,
    -3375.9448850198592, -4001.580358179941, -4695.5591588541165,
    -5479.6224204240343, -6337.5830972186523, -7306.7626203936406,
    -8367.0113040829765, -9543.7325749137835, -10833.861027078878,
    -12233.212389360973, -13770.264504517001, -15402.063067541607,
    -17168.391244719722, -19012.102659237262, -20943.334589594659,
    -22924.198213851265, -24898.371131570162, -26871.919819847517,
    -28718.983930705563, -30468.006195985432, -31955.429472111955,
    -33192.318233781545, -34423.395924219076, -34797.846535118981,
    -34557.765850806136, -34797.846535118981, -34423.395924218894,
    -33192.318233781545, -31955.429472112297, -30468.006195985432,
    -28718.983930705403, -26871.919819847517, -24898.371131570162,
    -22924.198213851381, -20943.334589594659, -19012.102659237149,
    -17168.391244719722, -15402.063067541607, -13770.264504517001,
    -12233.212389360973, -10833.861027078878, -9543.7325749137835,
    -8367.0113040829765, -7306.7626203936406, -6337.5830972186523,
    -5479.6224204240343, -4695.5591588541165, -4001.580358179941,
    -3375.9448850198592, -2816.3250708859296, -2321.5064502579457,
    -1869.7646656330091, -1482.080530064603, -1123.0860102618853,
    -817.19066007776678, -527.6033433756761, -279.16019293038494,
    -65.052230972059931, 126.06239987512697, 286.30154277966517,
    453.15262205081086, 590.50041672307941, 707.81548799163761,
    810.96336404580074, 904.3916476774931, 982.38342952949915,
    1054.0389200609288, 1114.6255058080887, 1168.585536370482,
    1215.0380240230322, 1254.4541077340443, 1288.5589555335162,
    1316.3001780257662, 1340.015069143418, 1359.4166332321026, 1376.300193534006,
    1389.2042095672866, 1398.268581620049, 1405.1941432956016,
    1409.5789972073349, 1412.2261594242887, 1412.7852851819612, 1411.78368781775,
    1408.8496913690947, 1404.3467560738452, 1399.9127986662631,
    1394.4606401374574, 1387.115104579924, 1378.5451081520466,
    1369.4599196693605, 1360.3980558301362, 1351.2593995596023,
    1341.4320547960858, 1330.7688133481849, 1325.262725741685,
    1376.2343690395016, 1381.9522292462796, 1393.0255953651329,
    1403.2309149271885, 1412.7210579774769, 1422.1314550412885,
    1431.5660738501251, 1440.4656855252583, 1448.0937416812581,
    1453.7555986149969, 1458.360092845895, 1463.036217960233, 1466.083060426125,
    1467.1231807658373, 1466.542550171424, 1463.7935740230191,
    1459.2400718838676, 1452.0481424515751, 1442.6351407044863,
    1429.2348163622578, 1411.7018883564456, 1391.5541102643135,
    1366.9271079497764, 1338.1189153617458, 1302.702342646943,
    1261.7702557162363, 1213.5311339231509, 1157.4957175699171,
    1094.578878524816, 1020.1674075883138, 939.17594181893867,
    842.15426266296083, 735.03916060671986, 613.21197121242164,
    470.58156905281936, 297.31314057889875, 130.91095371642029,
    -67.554239855598951, -289.89712342772663, -547.8957796593927,
    -848.62107008075247, -1166.2816260411535, -1539.0836273747468,
    -1941.6786912342995, -2410.7951598832619, -2924.6452659199776,
    -3505.7889190590654, -4155.4872950330227, -4876.1575880408554,
    -5690.377128901895, -6581.33629326548, -7587.7919519472407,
    -8688.8194311631123, -9910.7992124104749, -11250.547989658811,
    -12703.720558182511, -14299.890062383052, -15994.450108600935,
    -17828.713984901271, -19743.337376900246, -21748.847458425214,
    -23805.89814515322, -25856.000790476697, -27905.455197533953,
    -29823.560235732697, -31639.85258813871, -33184.484451808559,
    -34468.945858157749, -35747.372690535209, -36136.225248008173,
    -35886.910691221739, -36136.225248008173, -35747.372690535012,
    -34468.945858157749, -33184.484451808923, -31639.85258813871,
    -29823.56023573253, -27905.455197533953, -25856.000790476697,
    -23805.898145153358, -21748.847458425214, -19743.337376900108,
    -17828.713984901271, -15994.450108600935, -14299.890062383052,
    -12703.720558182511, -11250.547989658811, -9910.7992124104749,
    -8688.8194311631123, -7587.7919519472407, -6581.33629326548,
    -5690.377128901895, -4876.1575880408554, -4155.4872950330227,
    -3505.7889190590654, -2924.6452659199776, -2410.7951598832619,
    -1941.6786912342995, -1539.0836273747468, -1166.2816260411535,
    -848.62107008075247, -547.8957796593927, -289.89712342772663,
    -67.554239855598951, 130.91095371642029, 297.31314057889875,
    470.58156905281936, 613.21197121242164, 735.03916060671986,
    842.15426266296083, 939.17594181893867, 1020.1674075883138,
    1094.5788785247705, 1157.4957175699171, 1213.5311339231964,
    1261.7702557162363, 1302.702342646943, 1338.1189153617458,
    1366.9271079497764, 1391.5541102643135, 1411.7018883564456,
    1429.2348163622578, 1442.6351407044863, 1452.0481424515751,
    1459.2400718839131, 1463.7935740230191, 1466.542550171333,
    1467.1231807658828, 1466.0830604261705, 1463.0362179601875,
    1458.360092845895, 1453.7555986149514, 1448.0937416812126,
    1440.4656855253038, 1431.5660738501706, 1422.1314550412885,
    1412.7210579774769, 1403.2309149271885, 1393.0255953651329,
    1381.9522292462796, 1376.2343690395016, 1427.2060123372271,
    1433.1356451442375, 1444.6191359342251, 1455.2024302949108,
    1465.0440601247724, 1474.8029904131713, 1484.5870395482948,
    1493.8162664706838, 1501.7268432250135, 1507.5983985636854,
    1512.3734296179905, 1517.2227445512804, 1520.3824330344546,
    1521.4610763498044, 1520.8589409185138, 1518.0081508387034,
    1513.2860004721792, 1505.827703283147, 1496.0660718416862,
    1482.1694391904189, 1463.9871434807433, 1443.0931513852543,
    1417.5540378738774, 1387.67887518993, 1350.9505775597506, 1308.5024874093949,
    1258.4767314758653, 1200.3659293317912, 1135.1188369887032,
    1057.951385647174, 973.9602359604296, 873.345161280121, 762.26283322171116,
    635.9235257017184, 488.01051605478233, 308.32473837813239,
    135.75950755785004, -70.0562487390925, -300.63405392506837,
    -568.18821594306382, -880.05148008378376, -1209.4772418204673,
    -1596.0867246849361, -2013.5927168355902, -2500.0838695085326,
    -3032.9654609540257, -3635.6329530983171, -4309.3942318861045,
    -5056.7560172275489, -5901.1318373797567, -6825.0894893123523,
    -7868.82128350084, -9010.6275582432245, -10277.865849907212,
    -11667.23495223879, -13174.228727004072, -14829.515620249082,
    -16586.837149660216, -18489.0367250828, -20474.572094563206,
    -22554.360327255792, -24687.598076455197, -26813.630449383229,
    -28938.990575220392, -30928.136540759824, -32811.698980291992,
    -34413.539431505189, -35745.573482533975, -37071.349456851327,
    -37474.603960897366, -37216.05553163735, -37474.603960897366,
    -37071.349456851138, -35745.573482533975, -34413.53943150556,
    -32811.698980291992, -30928.136540759642, -28938.990575220392,
    -26813.630449383229, -24687.59807645531, -22554.360327255792,
    -20474.572094563093, -18489.0367250828, -16586.837149660216,
    -14829.515620249082, -13174.228727004072, -11667.23495223879,
    -10277.865849907212, -9010.6275582432245, -7868.82128350084,
    -6825.0894893123523, -5901.1318373797112, -5056.7560172275489,
    -4309.39423188615, -3635.6329530983171, -3032.9654609539803,
    -2500.0838695085326, -2013.5927168356357, -1596.0867246849816,
    -1209.4772418204673, -880.05148008373828, -568.18821594306382,
    -300.63405392506837, -70.0562487390925, 135.75950755785004,
    308.32473837813239, 488.01051605478233, 635.9235257017184,
    762.26283322171116, 873.345161280121, 973.96023596038413, 1057.951385647174,
    1135.1188369887032, 1200.3659293317912, 1258.4767314759108,
    1308.5024874093949, 1350.9505775597506, 1387.67887518993, 1417.5540378738774,
    1443.0931513852543, 1463.9871434807433, 1482.1694391904189,
    1496.0660718416862, 1505.827703283147, 1513.2860004722247,
    1518.0081508387034, 1520.8589409184683, 1521.4610763498044,
    1520.3824330344546, 1517.2227445512804, 1512.3734296179905,
    1507.5983985636854, 1501.7268432250135, 1493.8162664706838,
    1484.5870395482948, 1474.8029904131713, 1465.0440601247724,
    1455.2024302949108, 1444.6191359342251, 1433.1356451442375,
    1427.2060123372271, 1475.9277105562419, 1482.0336183798631,
    1493.8787313006274, 1504.8094657983243, 1514.9697359664501,
    1525.0148090353364, 1535.0511673185779, 1544.4952358372561,
    1552.583667784073, 1558.6217989624843, 1563.5156185234323,
    1568.4280367771848, 1571.5806309135573, 1572.5853735924816,
    1571.879341952807, 1568.8477129491262, 1563.8374027912491,
    1555.9680376826223, 1545.7024626207826, 1531.1998149228643,
    1512.2972733848187, 1490.53521404894, 1463.9217316709605, 1432.8081562798602,
    1394.6158930917125, 1350.5422997149697, 1298.6024603405428,
    1238.2621204368195, 1170.5282844055534, 1090.4187641861872,
    1003.2283143253144, 898.83835954624294, 783.704196410826, 652.77586213169286,
    499.33101136443793, 311.99078098338731, 134.52318653303325,
    -77.537699272943357, -318.59913700582155, -595.8401396246694,
    -918.19636844029367, -1259.5033358255921, -1659.8362776623148,
    -2092.2350197502492, -2595.8827086180895, -3147.5521227524468,
    -3771.3933737551965, -4468.70995906174, -5242.0887785330206,
    -6115.7366787900573, -7071.6469632420676, -8151.2994356677991,
    -9332.2197922295254, -10642.605037752846, -12079.111302289437,
    -13637.036068524969, -15347.885983679804, -17163.908317747708,
    -19129.400061440636, -21180.640213323186, -23328.792810079587,
    -25531.783102751524, -27727.002109294834, -29921.245419265797,
    -31974.559705479434, -33918.503104391828, -35571.528270960938,
    -36946.0748409655, -38314.159724973731, -38730.069002800476,
    -38463.031270591673, -38730.069002800476, -38314.159724973535,
    -36946.0748409655, -35571.528270961317, -33918.503104391828,
    -31974.559705479252, -29921.245419265797, -27727.002109294834,
    -25531.783102751637, -23328.792810079587, -21180.640213323073,
    -19129.400061440636, -17163.908317747708, -15347.885983679804,
    -13637.036068524969, -12079.111302289437, -10642.605037752846,
    -9332.2197922295254, -8151.2994356677991, -7071.6469632420676,
    -6115.7366787900119, -5242.0887785330206, -4468.7099590617854,
    -3771.3933737551965, -3147.5521227524468, -2595.8827086180895,
    -2092.2350197502492, -1659.8362776623148, -1259.5033358255921,
    -918.19636844029367, -595.8401396246694, -318.59913700582155,
    -77.537699272943357, 134.52318653303325, 311.99078098338731,
    499.33101136443793, 652.77586213169286, 783.704196410826, 898.83835954624294,
    1003.2283143253144, 1090.4187641861872, 1170.5282844055534,
    1238.2621204368195, 1298.6024603405428, 1350.5422997149697,
    1394.6158930917125, 1432.8081562798602, 1463.9217316709605, 1490.53521404894,
    1512.2972733848187, 1531.1998149228643, 1545.7024626207826,
    1555.9680376826223, 1563.8374027912491, 1568.8477129491262,
    1571.879341952807, 1572.585373592527, 1571.5806309135573, 1568.4280367771394,
    1563.5156185234323, 1558.6217989624388, 1552.583667784073,
    1544.4952358372561, 1535.0511673185779, 1525.0148090353819,
    1514.9697359664501, 1504.8094657983243, 1493.8787313006274,
    1482.0336183798631, 1475.9277105562419, 1524.1075097041162,
    1530.3811451197348, 1542.576199763424, 1553.8470194436727,
    1564.3180196734179, 1574.6342076275128, 1584.8994837557243,
    1594.5307498514453, 1602.7718287331468, 1608.9661534994307,
    1613.9662939887316, 1618.9153021251955, 1622.0319144193568,
    1622.9356787929178, 1622.1059114226578, 1618.8744054801632,
    1613.5471540487729, 1605.2318661396826, 1594.4249409458721,
    1579.2898635723291, 1559.6500019048094, 1536.9905269320939,
    1509.2635852242879, 1476.8703157392324, 1437.1774183859075,
    1391.4519647537406, 1337.5673380761316, 1274.9603232715788,
    1204.7021176907936, 1121.6055766565651, 1031.1679616501797,
    922.95940245435224, 803.753696254443, 668.22354795763147, 509.18356329957487,
    313.87028483868534, 131.81669490904812, -86.21455463080558,
    -338.29870866156824, -625.25743264318351, -957.96351188264373,
    -1311.1749303934164, -1725.2115286074043, -2172.4975896018332,
    -2693.2496782035264, -3263.6480763107529, -3908.5787856769421,
    -4629.3284356507638, -5428.56174527255, -6331.2688807909526,
    -7318.87977912533, -8434.1265840025171, -9653.7600138097241,
    -11006.783663908018, -12489.829064794856, -14097.988633481315,
    -15863.545582214565, -17737.290606709423, -19764.956255543148,
    -21880.646971748527, -24095.7396183122, -26366.932740494256,
    -28629.714223999097, -30891.149457290743, -33006.976705412642,
    -35009.641884157412, -36712.400930883021, -38128.241273254382,
    -39537.421115125791, -39965.564396077214, -39690.21681672577,
    -39965.564396077214, -39537.42111512558, -38128.241273254382,
    -36712.400930883421, -35009.641884157412, -33006.976705412446,
    -30891.149457290743, -28629.714223999097, -26366.932740494394,
    -24095.7396183122, -21880.646971748392, -19764.956255543148,
    -17737.290606709423, -15863.545582214565, -14097.988633481315,
    -12489.829064794856, -11006.783663908018, -9653.7600138097241,
    -8434.1265840025171, -7318.8797791252846, -6331.2688807909071,
    -5428.5617452725955, -4629.3284356508093, -3908.5787856769421,
    -3263.6480763107529, -2693.2496782035264, -2172.4975896018332,
    -1725.2115286074043, -1311.1749303934164, -957.96351188264373,
    -625.25743264318351, -338.29870866156824, -86.21455463080558,
    131.81669490904812, 313.87028483868534, 509.18356329957487,
    668.22354795763147, 803.753696254443, 922.95940245435224, 1031.1679616501797,
    1121.6055766565651, 1204.7021176907936, 1274.9603232715788,
    1337.5673380761316, 1391.4519647537406, 1437.1774183859075,
    1476.8703157392324, 1509.2635852242879, 1536.9905269320939,
    1559.6500019047639, 1579.2898635723291, 1594.4249409459176,
    1605.2318661396826, 1613.5471540488184, 1618.8744054801632,
    1622.1059114226123, 1622.9356787929178, 1622.0319144193568,
    1618.9153021252409, 1613.9662939887316, 1608.9661534993397,
    1602.7718287331468, 1594.5307498514908, 1584.8994837557243,
    1574.6342076275128, 1564.3180196734179, 1553.8470194436727,
    1542.576199763424, 1530.3811451197348, 1524.1075097041162,
    1572.2873061872619, 1578.7286713446051, 1591.2736690956522,
    1602.8845732299019, 1613.6663042781024, 1624.2536058665778,
    1634.7478000531269, 1644.5662627831994, 1652.959988876863,
    1659.3105110444399, 1664.4169683471757, 1669.4025671337824,
    1672.4831975743184, 1673.2859830512537, 1672.3324843478606,
    1668.9010964505071, 1663.2569065155153, 1654.4956917133718,
    1643.1474170502484, 1627.3799182284151, 1607.0027329846184,
    1583.4458421834811, 1554.6054300454202, 1520.9324770008138,
    1479.7389438092055, 1432.3616461492279, 1376.532224197216,
    1311.6585244531041, 1238.8760156613432, 1152.7923177196033,
    1059.1077564707566, 947.08058118917427, 823.80403029323975, 683.678329061558,
    519.03968010365088, 315.73100382674937, 129.10524233893727,
    -94.886428972358686, -357.99211513467492, -654.66785140156333,
    -997.73552772276071, -1362.8468796975528, -1790.5875881526738,
    -2252.7599299215108, -2790.6168204106484, -3379.7440507276374,
    -4045.7642345288568, -4789.9469613029805, -5615.03465930286,
    -6546.8011439517286, -7566.1125297719927, -8716.9537822218826,
    -9975.3002204195946, -11370.962291729973, -12900.546870067445,
    -14558.941156060779, -16379.20521559316, -18310.672824536443,
    -20400.512505272065, -22580.653713274049, -24862.686423776133,
    -27202.082407615966, -29532.426276049089, -31861.053541796166,
    -34039.393650435944, -36100.780667961713, -37853.273601771252,
    -39310.407694510177, -40760.682475765971, -41201.0597940221,
    -40917.402496473158, -41201.0597940221, -40760.682475765767,
    -39310.407694510177, -37853.273601771638, -36100.780667961713,
    -34039.393650435763, -31861.053541796166, -29532.426276049089,
    -27202.0824076161, -24862.686423776133, -22580.65371327391,
    -20400.512505272065, -18310.672824536443, -16379.20521559316,
    -14558.941156060779, -12900.546870067445, -11370.962291729973,
    -9975.3002204195946, -8716.9537822218826, -7566.1125297719927,
    -6546.8011439517286, -5615.03465930286, -4789.9469613029805,
    -4045.7642345288568, -3379.7440507275919, -2790.6168204106484,
    -2252.7599299215562, -1790.5875881527193, -1362.8468796975983,
    -997.73552772271523, -654.66785140151785, -357.99211513467492,
    -94.886428972358686, 129.10524233893727, 315.73100382674937,
    519.03968010365088, 683.678329061558, 823.80403029323975, 947.08058118917427,
    1059.1077564707566, 1152.7923177195578, 1238.8760156613432,
    1311.6585244531495, 1376.532224197216, 1432.3616461492279,
    1479.7389438092055, 1520.9324770008138, 1554.6054300454202,
    1583.4458421834811, 1607.0027329846184, 1627.3799182284151,
    1643.1474170502484, 1654.4956917133718, 1663.2569065155608,
    1668.9010964504616, 1672.3324843478151, 1673.2859830512991,
    1672.4831975743184, 1669.4025671337824, 1664.4169683471757,
    1659.3105110444399, 1652.959988876863, 1644.5662627831994,
    1634.7478000531723, 1624.2536058665778, 1613.6663042780569,
    1602.8845732299019, 1591.2736690956522, 1578.7286713446051,
    1572.2873061872619, 1620.467100243512, 1627.0761971003581,
    1639.9711392196864, 1651.9221271445517, 1663.0145897008319,
    1673.8730037842727, 1684.5961162233818, 1694.6017747279241,
    1703.1481482866168, 1709.6548713319391, 1714.8676416962628,
    1719.8898318334598, 1722.9344804090017, 1723.6362864503446,
    1722.559060426782, 1718.9277859961733, 1712.9666600887942,
    1703.7595146528913, 1691.8698911259055, 1675.4699783746203,
    1654.3554664056942, 1629.9011596094247, 1599.9472668757321,
    1564.9946399197675, 1522.3004693545122, 1473.2713425609732,
    1415.497118060101, 1348.3567241546996, 1273.0499734106604,
    1183.9789930151699, 1087.0476886231236, 971.20188908515865,
    843.85514883529061, 699.1400554646583, 528.89930078294992, 317.5734094721517,
    126.38900061210722, -103.55276496698016, -377.68017903990733,
    -684.072325492661, -1037.5117480348754, -1414.5191194943877,
    -1855.9643628195302, -2333.0220643133521, -2887.9841167069544,
    -3495.8400436647448, -4182.9497165457233, -4950.5655310856991,
    -5801.5075257152548, -6762.3334623534838, -7813.3452213668916,
    -8999.7810256299927, -10296.840413429427, -11735.140921088294,
    -13311.264714130983, -15019.893640176984, -16894.864880627694,
    -18884.05497770098, -21036.068805605606, -23280.660439398027,
    -25629.63322674725, -28037.232101454079, -30435.138271028649,
    -32830.957668632931, -35071.810545391272, -37191.919455427516,
    -38994.146282642781, -40492.5741056875, -41983.943809481818,
    -42436.555196225847, -42144.588298118972, -42436.555196225847,
    -41983.9438094816, -40492.5741056875, -38994.1462826432, -37191.919455427516,
    -35071.810545391068, -32830.957668632931, -30435.138271028649,
    -28037.232101454239, -25629.63322674725, -23280.660439397867,
    -21036.068805605606, -18884.05497770098, -16894.864880627694,
    -15019.893640176984, -13311.264714130983, -11735.140921088294,
    -10296.840413429427, -8999.7810256299927, -7813.3452213668916,
    -6762.3334623534838, -5801.5075257152548, -4950.5655310856991,
    -4182.9497165457233, -3495.8400436646994, -2887.9841167069089,
    -2333.0220643133975, -1855.9643628195756, -1414.5191194943877,
    -1037.5117480348754, -684.072325492661, -377.68017903990733,
    -103.55276496698016, 126.38900061210722, 317.5734094721517,
    528.89930078294992, 699.1400554646583, 843.85514883529061,
    971.20188908515865, 1087.0476886231236, 1183.9789930151699,
    1273.0499734106604, 1348.3567241546996, 1415.497118060101,
    1473.2713425609732, 1522.3004693545122, 1564.9946399197675,
    1599.9472668757321, 1629.9011596094247, 1654.3554664056942,
    1675.4699783746203, 1691.8698911259055, 1703.7595146528913,
    1712.9666600888397, 1718.9277859961733, 1722.5590604267366,
    1723.6362864503446, 1722.9344804090017, 1719.8898318335052,
    1714.8676416962628, 1709.6548713318482, 1703.1481482866168,
    1694.6017747279695, 1684.5961162233818, 1673.8730037842727,
    1663.0145897008319, 1651.9221271445517, 1639.9711392196864,
    1627.0761971003581, 1620.467100243512, 1668.6468920832324,
    1675.4237224276478, 1688.6686100669961, 1700.9596811766626,
    1712.362875870984, 1723.4924014083374, 1734.4444322776765,
    1744.6372857704757, 1753.3363070254366, 1759.9992341265518,
    1765.3183141226675, 1770.3770962512392, 1773.3857629502365,
    1773.9865890632684, 1772.785639391803, 1768.9544742378969,
    1762.6764146769785, 1753.0233351793397, 1740.5923633436926,
    1723.5600435523777, 1701.708201973541, 1676.3564790367111,
    1645.2890963753348, 1609.0568043665812, 1564.8619950150064,
    1514.1810527910807, 1454.462019085166, 1385.0549225271141,
    1307.2239865158724, 1215.16560760483, 1114.9877488524444, 995.32331985824294,
    863.907006025419, 714.60857914530538, 538.76236360442772, 319.39795979010313,
    123.66812927052695, -112.21314172512383, -397.36358304676253,
    -713.47162466167833, -1077.29162104033, -1466.1915988267524,
    -1921.3417729884877, -2413.2840132528122, -2985.3515511213545,
    -3611.9360531174575, -4320.1352284584082, -5111.1841407061956,
    -5987.9803489661244, -6977.8658308176027, -8060.5778593368923,
    -9282.6083101022869, -10618.380594047167, -12099.319551865654,
    -13721.982593487734, -15480.846089276096, -17410.524574507675,
    -19457.437071913257, -21671.625152109053, -23980.667151446803,
    -26396.580027466258, -28872.3818196584, -31337.850213877318,
    -33800.861834131538, -36104.227394567504, -38283.058246222972,
    -40135.018972628823, -41674.740507633949, -43207.205118566933,
    -43672.050602325668, -43371.774211278971, -43672.050602325668,
    -43207.205118566715, -41674.740507633949, -40135.018972629267,
    -38283.058246222972, -36104.227394567271, -33800.861834131538,
    -31337.850213877318, -28872.381819658538, -26396.580027466258,
    -23980.667151446665, -21671.625152109053, -19457.437071913257,
    -17410.524574507675, -15480.846089276096, -13721.982593487734,
    -12099.319551865654, -10618.380594047167, -9282.6083101022869,
    -8060.5778593368923, -6977.8658308176027, -5987.9803489661244,
    -5111.1841407061956, -4320.1352284584082, -3611.936053117412,
    -2985.3515511213545, -2413.2840132528577, -1921.3417729884877,
    -1466.1915988267524, -1077.29162104033, -713.47162466167833,
    -397.36358304676253, -112.21314172512383, 123.66812927052695,
    319.39795979010313, 538.76236360442772, 714.60857914530538, 863.907006025419,
    995.32331985824294, 1114.9877488524444, 1215.16560760483, 1307.2239865158724,
    1385.0549225271141, 1454.462019085166, 1514.1810527910807,
    1564.8619950150064, 1609.0568043665812, 1645.2890963753348,
    1676.3564790367111, 1701.708201973541, 1723.5600435523777,
    1740.5923633436926, 1753.0233351793852, 1762.6764146769785,
    1768.9544742378514, 1772.785639391803, 1773.9865890632684,
    1773.3857629502365, 1770.3770962512392, 1765.3183141226675,
    1759.9992341265518, 1753.3363070254366, 1744.6372857704303,
    1734.4444322777219, 1723.4924014083829, 1712.3628758709385,
    1700.9596811766626, 1688.6686100669961, 1675.4237224276478,
    1668.6468920832324, 1716.8266818931427, 1723.7712473625818,
    1737.3660815764636, 1749.997235316185, 1761.7111627259403,
    1773.1117987637829, 1784.2927482258331, 1794.6727959857965,
    1803.5244651495743, 1810.3435992193665, 1815.7689857031967,
    1820.864360410995, 1823.83704522217, 1824.3368909552812, 1823.0122210047723,
    1818.9811612831347, 1812.3861701986227, 1802.2871534900316,
    1789.3148338555404, 1771.65011335246, 1749.0609395145823, 1722.8118003102265,
    1690.6309191334897, 1653.1189702246579, 1607.4235207842762,
    1555.090775765801, 1493.4269267490422, 1421.7531197021785,
    1341.3980509798864, 1246.3521660442882, 1142.9279287134241,
    1019.4448675847971, 883.9595594859012, 730.08375427943906, 548.6288064174,
    321.20509953688241, 120.94277737378422, -120.86724532878168,
    -417.04289839790323, -742.86639166430109, -1117.0746870087887,
    -1517.8642769193161, -1986.7197504250253, -2493.5457945885878,
    -3082.7191098171143, -3728.032077357781, -4457.3207674143268,
    -5271.8027864108944, -6174.4531329727524, -7193.3982447934277,
    -8307.8104484637079, -9565.43563200179, -10939.920763342107,
    -12463.498183956006, -14132.700505048102, -15941.798506404606,
    -17926.184294745992, -20030.819112230194, -22307.181540851187,
    -24680.673850598829, -27163.526826144152, -29707.531560146523,
    -32240.56210898063, -34770.76603503478, -37136.644201777162,
    -39374.197040055034, -41275.89167095851, -42856.906901104761,
    -44430.466405061648, -44907.5460119988, -44598.960226715761,
    -44907.5460119988, -44430.466405061423, -42856.906901104761,
    -41275.891670958968, -39374.197040055034, -37136.644201776937,
    -34770.76603503478, -32240.56210898063, -29707.531560146657,
    -27163.526826144152, -24680.67385059869, -22307.181540851187,
    -20030.819112230194, -17926.184294745992, -15941.798506404606,
    -14132.700505048102, -12463.498183956006, -10939.920763342107,
    -9565.43563200179, -8307.8104484637079, -7193.3982447933822,
    -6174.4531329727524, -5271.80278641094, -4457.3207674143268,
    -3728.032077357781, -3082.7191098170688, -2493.5457945885878,
    -1986.7197504250707, -1517.8642769193616, -1117.0746870087887,
    -742.86639166421014, -417.04289839790323, -120.86724532882715,
    120.94277737378422, 321.20509953683694, 548.6288064174, 730.08375427948454,
    883.9595594859012, 1019.4448675847971, 1142.9279287133786,
    1246.3521660442427, 1341.3980509799319, 1421.753119702224,
    1493.4269267490422, 1555.090775765801, 1607.4235207842762,
    1653.1189702246579, 1690.6309191334897, 1722.8118003102265,
    1749.0609395145823, 1771.65011335246, 1789.3148338555404, 1802.2871534900316,
    1812.3861701986227, 1818.9811612831347, 1823.0122210047723,
    1824.3368909552812, 1823.83704522217, 1820.8643604110405, 1815.7689857031967,
    1810.343599219321, 1803.5244651495743, 1794.672795985751, 1784.2927482258785,
    1773.1117987638283, 1761.7111627258948, 1749.997235316185,
    1737.3660815764636, 1723.7712473625818, 1716.8266818931427,
    1765.0064698396802, 1772.1187719372649, 1786.0635536938828,
    1799.034789554524, 1811.0594502097667, 1822.7311958726189,
    1834.1410640769011, 1844.7083054411889, 1853.7126227088249,
    1860.6879664237097, 1866.2196565065171, 1871.3516243341912,
    1874.2883272462207, 1874.6871921844088, 1873.2388050531865,
    1869.0078472280204, 1862.095926580376, 1851.5509697609089, 1838.037302797464,
    1819.7401874090685, 1796.4136788734761, 1769.2671232902724,
    1735.9727356780224, 1697.1811373891326, 1649.9850466562734,
    1596.0005105197511, 1532.39184057811, 1458.451315795945, 1375.572163181231,
    1277.5386724444149, 1170.8682204844069, 1043.5665266819333, 904.012769995733,
    745.56543743269617, 558.49856692534513, 322.99526048764136,
    118.21308488692911, -129.51484634245378, -436.71860673207408,
    -772.257167354973, -1156.8605599031332, -1569.5371208805213,
    -2052.0982363166677, -2573.8074239503908, -3180.0867807462027,
    -3844.1281148887774, -4594.5063309133238, -5432.4214649034684,
    -6360.925881192401, -7408.930700265767, -8555.042992976807,
    -9848.2629881086632, -11261.460922264123, -12827.676817263444,
    -14543.418446073007, -16402.750894265529, -18441.844039133532,
    -20604.20110314665, -22942.737968334884, -25380.680537904529,
    -27930.4736229667, -30542.681321066808, -33143.273960245569,
    -35740.670268441267, -38169.060970421, -40465.335836664082,
    -42416.764376945466, -44039.07328677491, -45653.72767078699,
    -46143.041424957228, -45826.146336184793, -46143.041424957228,
    -45653.727670786742, -44039.07328677491, -42416.764376945939,
    -40465.335836664082, -38169.060970420775, -35740.670268441267,
    -33143.273960245569, -30542.681321066968, -27930.4736229667,
    -25380.680537904369, -22942.737968334884, -20604.20110314665,
    -18441.844039133532, -16402.750894265529, -14543.418446073007,
    -12827.676817263444, -11261.460922264123, -9848.2629881086632,
    -8555.042992976807, -7408.930700265767, -6360.925881192401,
    -5432.4214649034684, -4594.5063309133238, -3844.1281148887774,
    -3180.0867807462027, -2573.8074239503908, -2052.0982363166677,
    -1569.5371208805213, -1156.8605599031332, -772.25716735492756,
    -436.71860673207408, -129.51484634249925, 118.21308488692911,
    322.99526048764136, 558.49856692534513, 745.5654374326507, 904.012769995733,
    1043.5665266819788, 1170.8682204844069, 1277.5386724444149,
    1375.572163181231, 1458.451315795945, 1532.39184057811, 1596.0005105197511,
    1649.9850466562734, 1697.1811373891326, 1735.9727356780224,
    1769.2671232902724, 1796.4136788734761, 1819.7401874090685,
    1838.037302797464, 1851.5509697609089, 1862.0959265804215,
    1869.0078472279749, 1873.238805053141, 1874.6871921844543,
    1874.2883272462207, 1871.3516243341912, 1866.2196565065171,
    1860.6879664236642, 1853.7126227088249, 1844.7083054412344,
    1834.1410640769011, 1822.7311958726189, 1811.0594502097667,
    1799.034789554524, 1786.0635536938828, 1772.1187719372649,
    1765.0064698396802, 1813.1862560712746, 1820.4662961804372,
    1834.7610263708686, 1848.072343883676, 1860.4077382724411,
    1872.3505927544904, 1883.9893798385203, 1894.7438141966798,
    1903.900779748072, 1911.0323355728708, 1916.6703265939288,
    1921.8388880396997, 1924.7396090416696, 1925.0374928028559,
    1923.4653913463699, 1919.0345321582283, 1911.8056837567094,
    1900.814784150178, 1886.7597702912901, 1867.8302653939666,
    1843.7664199108424, 1815.7224478509745, 1781.3145464828706,
    1741.2433057651454, 1692.5465726255864, 1636.9102561828172,
    1571.356760142588, 1495.1495109103676, 1409.7463198309911,
    1308.7251305248617, 1198.8086170918439, 1067.6882918874971,
    924.06660120473055, 761.05348771047761, 568.37158291468722,
    324.76886173594693, 115.47918378892054, -138.15578246644679,
    -456.39111697491859, -801.64441006490893, -1196.6489132347749,
    -1621.2101039813647, -2117.477179702335, -2654.0689150834146,
    -3277.4545533697592, -3960.2241644071873, -4731.691916754512,
    -5593.040173277127, -6547.398596687839, -7624.4631936785418,
    -8802.2754966312659, -10131.090375562362, -11583.001071659544,
    -13191.855451701065, -14954.136414125684, -16863.703255265438,
    -18957.503805701417, -21177.583048671095, -23578.294431438804,
    -26080.687214303431, -28697.420418097972, -31377.831100767202,
    -34045.985771164138, -36710.57453175835, -39201.477703541932,
    -41556.474635819184, -43557.63708997667, -45221.239665249595,
    -46876.988917373295, -47378.53684094303, -47053.33253230455,
    -47378.53684094303, -46876.988917373041, -45221.239665249595,
    -43557.63708997715, -41556.474635819184, -39201.477703541706,
    -36710.57453175835, -34045.985771164138, -31377.831100767362,
    -28697.420418097972, -26080.687214303271, -23578.294431438804,
    -21177.583048671095, -18957.503805701417, -16863.703255265438,
    -14954.136414125684, -13191.855451701065, -11583.001071659544,
    -10131.090375562362, -8802.2754966312659, -7624.4631936785418,
    -6547.398596687839, -5593.040173277127, -4731.691916754512,
    -3960.2241644071419, -3277.4545533697592, -2654.06891508346,
    -2117.477179702335, -1621.2101039813647, -1196.6489132347294,
    -801.64441006490893, -456.39111697496406, -138.15578246644679,
    115.47918378892054, 324.76886173594693, 568.37158291468722,
    761.05348771047761, 924.06660120473055, 1067.6882918874971,
    1198.8086170918439, 1308.7251305248617, 1409.7463198309911,
    1495.1495109103676, 1571.356760142588, 1636.9102561828172,
    1692.5465726255864, 1741.2433057651454, 1781.3145464828706,
    1815.7224478509745, 1843.7664199107969, 1867.8302653939666,
    1886.7597702913356, 1900.814784150178, 1911.8056837567549,
    1919.0345321582283, 1923.4653913462789, 1925.0374928028559,
    1924.7396090417151, 1921.8388880396997, 1916.6703265939288,
    1911.0323355728253, 1903.900779748072, 1894.7438141967252,
    1883.9893798385658, 1872.3505927544904, 1860.4077382723956,
    1848.072343883676, 1834.7610263708686, 1820.4662961804372,
    1813.1862560712746, 1861.3660407213486, 1868.8138201179283,
    1883.4584995639018, 1897.1098982967744, 1909.7560268692616,
    1921.9699894270416, 1933.8376955177846, 1944.7793223061562,
    1954.0889363074239, 1961.3767065170559, 1967.1209960205924,
    1972.3261515446648, 1975.1908906258432, 1975.3877928573256,
    1973.6919797133833, 1969.0612161512472, 1961.5154416683235, 1950.07859679972,
    1935.4822364465672, 1915.9203470119321, 1891.1191625011254,
    1862.1777738784187, 1826.6563519750873, 1785.3054752668852,
    1735.1080986868949, 1677.8200119683772, 1610.3216850518024,
    1531.8477051356681, 1443.920517935338, 1339.9115436591262,
    1226.7491120438524, 1091.8101582408317, 944.12101937787077,
    776.54776687345407, 578.24779244674517, 326.5263100079207,
    112.74119897120717, -146.78994502692134, -476.0607785506632,
    -831.02851072803719, -1236.4394690477172, -1672.8832043523182,
    -2182.8565362055979, -2734.3302801243203, -3374.822418428445,
    -4076.3202247732315, -4868.8775229930752, -5753.658908959,
    -6733.8712821821837, -7839.9957218706659, -9049.5079627720243,
    -10413.917791812755, -11904.541212285438, -13556.034087189833,
    -15364.854407030756, -17324.655591554194, -19473.16359268919,
    -21750.964952389702, -24213.850927368163, -26780.693880638202,
    -29464.36721168345, -32212.980897769234, -34948.697544867253,
    -37680.478822661971, -40233.894403870872, -42647.613437314212,
    -44698.509809502691, -46403.406037073015, -48100.250146284736,
    -48614.032259724641, -48280.518808446308, -48614.032259724641,
    -48100.250146284488, -46403.406037073015, -44698.509809503164,
    -42647.613437314212, -40233.894403870647, -37680.478822661971,
    -34948.697544867253, -32212.980897769368, -29464.36721168345,
    -26780.693880638068, -24213.850927368163, -21750.964952389702,
    -19473.16359268919, -17324.655591554194, -15364.854407030756,
    -13556.034087189833, -11904.541212285438, -10413.917791812755,
    -9049.5079627720243, -7839.9957218706659, -6733.8712821821837,
    -5753.658908959, -4868.8775229930752, -4076.3202247732315,
    -3374.822418428445, -2734.3302801242749, -2182.8565362056434,
    -1672.8832043523637, -1236.4394690476718, -831.02851072803719,
    -476.0607785506632, -146.78994502692134, 112.74119897120717,
    326.52631000787522, 578.24779244674517, 776.54776687349954,
    944.12101937787077, 1091.8101582408317, 1226.7491120438524,
    1339.9115436591262, 1443.920517935338, 1531.8477051356681,
    1610.3216850518024, 1677.8200119683772, 1735.1080986868949,
    1785.3054752668852, 1826.6563519750873, 1862.1777738784187, 1891.11916250108,
    1915.9203470119321, 1935.4822364466127, 1950.0785967997654,
    1961.5154416683235, 1969.0612161512017, 1973.6919797133378,
    1975.3877928573711, 1975.1908906258886, 1972.3261515446193,
    1967.1209960205924, 1961.3767065170559, 1954.0889363073784,
    1944.7793223061108, 1933.8376955178755, 1921.9699894270871,
    1909.7560268692162, 1897.1098982967744, 1883.4584995639018,
    1868.8138201179283, 1861.3660407213486, 1909.5458239094098,
    1917.1613437726121, 1932.1559732338737, 1946.147452787498,
    1959.1043159598921, 1971.5893859062799, 1983.6860111211518,
    1994.8148298180495, 2004.2770924228062, 2011.7210791215693,
    2017.5716648360303, 2022.8134148643203, 2025.64217201443, 2025.7380923899273,
    2023.9185699999307, 2019.0878992764719, 2011.225200261877,
    1999.3424078379558, 1984.2047013620668, 1964.0104319963011,
    1938.4719065310019, 1908.6331012696048, 1871.9981525404803,
    1829.3676458164539, 1777.6696248352421, 1718.7297771636152,
    1649.2866149495499, 1568.5458985518367, 1478.0947547635137,
    1371.0979149140246, 1254.6896993718735, 1115.9321210645421,
    964.17599316578071, 792.04813942278565, 588.12713401857707,
    328.26799998720134, 109.99924897459995, -155.41726836263464,
    -495.72789181570397, -860.40980480333849, -1276.2319892536641,
    -1724.5564039872972, -2248.2362670052662, -2814.5915298292016,
    -3472.1903677543164, -4192.4162949863294, -5006.0631479037465,
    -5914.2776696631645, -6920.3439401045607, -8055.5282820230259,
    -9296.74039438868, -10696.745234579057, -12226.081344820694,
    -13920.212723657765, -15775.572422840409, -17785.607905058379,
    -19988.823398517918, -22324.346817520545, -24849.407453613207,
    -27480.700537667075, -30231.314003852523, -33048.13071074547,
    -35851.409284169757, -38650.383139062717, -41266.311073865982,
    -43738.75224096475, -45839.382535029843, -47585.57240273583,
    -49323.51135883978, -49849.527681093481, -49507.705158640696,
    -49849.527681093481, -49323.511358839532, -47585.57240273583,
    -45839.382535030338, -43738.75224096475, -41266.311073865734,
    -38650.383139062717, -35851.409284169757, -33048.130710745652,
    -30231.314003852523, -27480.700537666893, -24849.407453613207,
    -22324.346817520545, -19988.823398517918, -17785.607905058379,
    -15775.572422840409, -13920.212723657765, -12226.081344820694,
    -10696.745234579057, -9296.74039438868, -8055.5282820230259,
    -6920.3439401045607, -5914.2776696631645, -5006.0631479037465,
    -4192.4162949863294, -3472.1903677543164, -2814.5915298291561,
    -2248.2362670052662, -1724.5564039873882, -1276.2319892536186,
    -860.409804803293, -495.72789181574944, -155.41726836263464,
    109.99924897459995, 328.26799998720134, 588.12713401857707,
    792.04813942278565, 964.17599316578071, 1115.9321210645421,
    1254.6896993718735, 1371.0979149139791, 1478.0947547635137,
    1568.5458985518821, 1649.2866149495499, 1718.7297771636152,
    1777.6696248352421, 1829.3676458164539, 1871.9981525404803,
    1908.6331012696048, 1938.4719065310019, 1964.0104319963011,
    1984.2047013620668, 1999.3424078380012, 2011.225200261877,
    2019.0878992764265, 2023.9185699999307, 2025.7380923899273, 2025.64217201443,
    2022.8134148643203, 2017.5716648359848, 2011.7210791215693,
    2004.2770924228062, 1994.814829818004, 1983.6860111212427,
    1971.5893859063253, 1959.1043159598466, 1946.147452787498,
    1932.1559732338737, 1917.1613437726121, 1909.5458239094098,
    1957.7256057437789, 1965.508867165725, 1980.8534473454965, 1995.18500734989,
    2008.4526055079987, 2021.2087822065296, 2033.5343266541695,
    2044.850336776015, 2054.4652481270514, 2062.0654532649023, 2068.022333084853,
    2073.3006780124906, 2076.0934532213905, 2076.0883914386777,
    2074.1451620669504, 2069.1145815968393, 2060.93495948903, 2048.606217380664,
    2032.92716512701, 2012.1005201061034, 1985.8246518979267, 1955.0884299306726,
    1917.3399485282046, 1873.4298173428654, 1820.2311510659895,
    1759.6395511214253, 1688.2515495107766, 1605.2440912300867,
    1512.269027819319, 1402.28424708357, 1282.6303735792851, 1140.0541759471698,
    984.23149339946485, 807.5544726606488, 598.00954669694818,
    329.99431464486378, 107.25344660158943, -164.03772141966314,
    -515.39271637316187, -889.7885817572834, -1316.0262687546026,
    -1776.2296879744993, -2313.6163379929235, -2894.8526737648963,
    -3569.5583941143891, -4308.5123741642255, -5143.2487899507987,
    -6074.8964533520793, -7106.8165726288889, -8271.0608716131374,
    -9543.9727941615183, -10979.572701815223, -12547.62146987581,
    -14284.391361039194, -16186.290459804954, -18246.560197509218,
    -20504.483221767558, -22897.728646959764, -25484.964007913619,
    -28180.7071860738, -30998.260794720769, -33883.280538501109,
    -36754.120991609867, -39620.2874790771, -42298.727715745583,
    -44829.891046605138, -46980.255266113141, -48767.738762681605,
    -50546.772556228971, -51085.023104861248, -50734.891577497663,
    -51085.023104861248, -50546.7725562287, -48767.738762681605,
    -46980.255266113665, -44829.891046605138, -42298.727715745335,
    -39620.2874790771, -36754.120991609867, -33883.280538501247,
    -30998.260794720769, -28180.707186073661, -25484.964007913619,
    -22897.728646959764, -20504.483221767558, -18246.560197509218,
    -16186.290459804954, -14284.391361039194, -12547.62146987581,
    -10979.572701815223, -9543.9727941615183, -8271.0608716131374,
    -7106.8165726288889, -6074.8964533520793, -5143.2487899507987,
    -4308.5123741642255, -3569.5583941143436, -2894.8526737648508,
    -2313.616337992969, -1776.2296879745447, -1316.0262687546026,
    -889.7885817572834, -515.39271637316187, -164.03772141966314,
    107.25344660158943, 329.99431464486378, 598.00954669694818,
    807.5544726606488, 984.23149339946485, 1140.0541759471698,
    1282.6303735792851, 1402.28424708357, 1512.2690278192736, 1605.2440912300867,
    1688.2515495108221, 1759.6395511214253, 1820.2311510659895,
    1873.4298173428654, 1917.3399485282046, 1955.0884299307181,
    1985.8246518978813, 2012.100520106058, 2032.9271651270556, 2048.606217380664,
    2060.93495948903, 2069.1145815968393, 2074.145162066905, 2076.0883914387232,
    2076.093453221436, 2073.3006780124451, 2068.022333084853, 2062.0654532648568,
    2054.4652481270514, 2044.8503367760604, 2033.5343266541695,
    2021.2087822065296, 2008.4526055079987, 1995.18500734989, 1980.8534473454965,
    1965.508867165725, 1957.7256057437789, 2005.9053863219542, 2013.856390315912,
    2029.5509218670286, 2044.2225619791298, 2057.8008954807938,
    2070.8281783405691, 2083.3826421218855, 2094.8858432198431,
    2104.6534034494907, 2112.4098288369605, 2118.4730008077149,
    2123.7879410015903, 2126.5447342595944, 2126.4386900379559,
    2124.3717557882046, 2119.1412631693747, 2110.6447193057629,
    2097.8700255327094, 2081.6496278223876, 2060.1906111228782,
    2033.1773985089494, 2001.543759776403, 1962.6817402552642,
    1917.4919897815455, 1862.7926773749989, 1800.5493332523185,
    1727.2164884378055, 1641.9422832336736, 1546.4433348163752,
    1433.4705427189861, 1310.5711295956542, 1164.1763187264576,
    1004.287492904813, 823.06663672925356, 607.89497022992634,
    331.70562557384045, 104.50389943175641, -172.65130104801742,
    -535.05547775262085, -919.165092668981, -1355.822129937859,
    -1827.903043897639, -2378.9967190796665, -2975.1137204687411,
    -3666.9264910805819, -4424.6084615262553, -5280.4344477627137,
    -6235.5152582035262, -7293.2891817062618, -8486.5934883772225,
    -9791.2051645001975, -11262.400191680572, -12869.161588001623,
    -14648.569999274228, -16597.008516348826, -18707.512470466856,
    -21020.143061157141, -23471.110443320664, -26120.520588228443,
    -28880.713826477058, -31765.207584391526, -34718.4303799574,
    -37656.832669481955, -40590.191841002605, -43331.144331516844,
    -45921.029854086344, -48121.128002350684, -49949.905117312337,
    -51770.03373953, -52320.518530857451, -51962.078060137857,
    -52320.518530857451, -51770.033739529732, -49949.905117312337,
    -48121.128002351208, -45921.029854086344, -43331.144331516596,
    -40590.191841002605, -37656.832669481955, -34718.430379957579,
    -31765.207584391526, -28880.713826476876, -26120.520588228443,
    -23471.110443320664, -21020.143061157141, -18707.512470466856,
    -16597.008516348826, -14648.569999274228, -12869.161588001623,
    -11262.400191680572, -9791.205164500152, -8486.5934883772225,
    -7293.2891817063073, -6235.5152582035262, -5280.4344477627137,
    -4424.6084615262553, -3666.9264910805819, -2975.1137204687411,
    -2378.9967190796665, -1827.903043897639, -1355.822129937859,
    -919.165092668981, -535.05547775262085, -172.65130104801742,
    104.50389943175641, 331.70562557384045, 607.89497022992634,
    823.06663672925356, 1004.287492904813, 1164.1763187264576,
    1310.5711295956542, 1433.4705427189406, 1546.4433348163752,
    1641.9422832337191, 1727.2164884378055, 1800.5493332523185,
    1862.7926773749989, 1917.4919897815455, 1962.6817402552642,
    2001.5437597764485, 2033.1773985089039, 2060.1906111228327,
    2081.6496278224331, 2097.8700255327549, 2110.6447193057629,
    2119.1412631693292, 2124.3717557882046, 2126.4386900380014,
    2126.5447342595944, 2123.7879410015448, 2118.4730008077149,
    2112.4098288369605, 2104.6534034494452, 2094.8858432198431,
    2083.3826421219765, 2070.8281783405691, 2057.8008954807483,
    2044.2225619791298, 2029.5509218670286, 2013.856390315912,
    2005.9053863219542, 2054.0851657322473, 2062.2039132402715,
    2078.248396769457, 2093.2601166702607, 2107.1491858484005,
    2120.4475743203129, 2133.2309575292566, 2144.9213491853225,
    2154.8415584167724, 2162.7542057380178, 2168.9236680411777,
    2174.2752038429426, 2176.9960151407286, 2176.7889882190484,
    2174.5983510492333, 2169.1679440455555, 2160.354479672149, 2147.13383238968,
    2130.3720895217775, 2108.2807048479463, 2080.530146279305,
    2047.9990907288975, 2008.0235280100151, 1961.554163073286,
    1905.3542037580867, 1841.4591230188291, 1766.1814314578789,
    1678.640474619395, 1580.6176736569782, 1464.6568041541273,
    1338.5119627364008, 1188.2985454736615, 1024.3439663363451,
    838.58450463267138, 617.78334513824063, 333.40229332275129,
    101.7507102597846, -181.25802661993458, -554.7163728192113,
    -948.53955637695356, -1395.6194182353545, -1879.5764613666036,
    -2444.3773836207561, -3055.374677583538, -3764.2946529210772,
    -4540.7045563792472, -5417.6201201105823, -6396.13408258287,
    -7479.7617690931866, -8702.1261302780586, -10038.437507577273,
    -11545.227702514365, -13190.701699695945, -15012.748638308027,
    -17007.726591049035, -19168.464725341011, -21535.802915528464,
    -24044.492208967655, -26756.077192709992, -29580.720459437471,
    -32532.154372957546, -35553.5802341382, -38559.544319865323,
    -41560.096223296714, -44363.560923000412, -47012.168663273704,
    -49262.000743378259, -51132.071466993206, -52993.294909720906,
    -53556.013958927419, -53189.264602133575, -53556.013958927419,
    -52993.294909720607, -51132.071466993206, -49262.000743378791,
    -47012.168663273704, -44363.560923000165, -41560.096223296714,
    -38559.544319865323, -35553.580234138382, -32532.154372957546,
    -29580.720459437289, -26756.077192709992, -24044.492208967655,
    -21535.802915528464, -19168.464725341011, -17007.726591049035,
    -15012.748638308027, -13190.701699695945, -11545.227702514365,
    -10038.437507577273, -8702.1261302780131, -7479.7617690931866,
    -6396.1340825829157, -5417.6201201105823, -4540.7045563792017,
    -3764.2946529210772, -3055.3746775835834, -2444.3773836207561,
    -1879.5764613666036, -1395.6194182353545, -948.53955637695356,
    -554.7163728192113, -181.25802661993458, 101.7507102597846,
    333.40229332270582, 617.78334513824063, 838.58450463271686,
    1024.3439663362997, 1188.2985454736615, 1338.5119627364463,
    1464.6568041541273, 1580.6176736569782, 1678.640474619395,
    1766.1814314578789, 1841.4591230188291, 1905.3542037580867,
    1961.554163073286, 2008.0235280100151, 2047.9990907288975, 2080.530146279305,
    2108.2807048479463, 2130.3720895217775, 2147.13383238968, 2160.3544796721944,
    2169.1679440455555, 2174.5983510491878, 2176.7889882190484,
    2176.9960151407286, 2174.275203842988, 2168.9236680411777,
    2162.7542057379724, 2154.8415584167724, 2144.9213491853225,
    2133.230957529302, 2120.4475743203129, 2107.149185848355, 2093.2601166702607,
    2078.248396769457, 2062.2039132402715, 2054.0851657322473,
    2102.2649440550576, 2110.5514359544013, 2126.9458720268613,
    2142.297671419281, 2156.497476583716, 2170.0669701561746, 2183.0792728801935,
    2194.956854705104, 2205.0297130533163, 2213.0985838774432,
    2219.3743348187108, 2224.76246654687, 2227.4472958752522, 2227.1392860101951,
    2224.8249477459904, 2219.1946242727208, 2210.0642405518083,
    2196.3976380382956, 2179.0945502918912, 2156.3708011003182, 2127.88289513205,
    2094.4544227168972, 2053.3653120554827, 2005.6163371641087,
    1947.9157302115236, 1882.3689199295115, 1805.14637832034, 1715.3386654379558,
    1614.7920424124991, 1495.8430335283524, 1366.4528686670553, 1212.42085247918,
    1044.4008900268718, 854.10795224292917, 627.67461278972348,
    335.08466772796027, 98.99397747130925, -189.85793568394894,
    -574.3755741837499, -977.91216448313116, -1435.4179985140477,
    -1931.2499316461963, -2509.7583079375431, -3135.6355519714243,
    -3861.6628745079615, -4656.8006581056534, -5554.805805890187,
    -6556.75292501964, -7666.2343363748669, -8917.6587954768747,
    -10285.669825356617, -11828.055232814802, -13512.241805410336,
    -15376.927278090247, -17418.444682617232, -19629.416963408705,
    -22051.46278383143, -24617.873946044914, -27391.633819681621,
    -30280.72708546467, -33299.101160502476, -36388.730100158034,
    -39462.255944648758, -42530.00062455811, -45395.977491851394,
    -48103.307474045505, -50402.873488865262, -52314.237812056679,
    -54216.556067691112, -54791.509388930426, -54416.451199457624,
    -54791.509388930426, -54216.556067690828, -52314.237812056679,
    -50402.873488865815, -48103.307474045505, -45395.977491851118,
    -42530.00062455811, -39462.255944648758, -36388.730100158216,
    -33299.101160502476, -30280.727085464488, -27391.633819681621,
    -24617.873946044914, -22051.46278383143, -19629.416963408705,
    -17418.444682617232, -15376.927278090247, -13512.241805410336,
    -11828.055232814802, -10285.669825356617, -8917.6587954768747,
    -7666.2343363748669, -6556.75292501964, -5554.805805890187,
    -4656.8006581056079, -3861.6628745079615, -3135.63555197147,
    -2509.7583079375431, -1931.2499316461963, -1435.4179985140477,
    -977.91216448313116, -574.3755741837499, -189.85793568394894,
    98.99397747130925, 335.08466772796027, 627.67461278972348,
    854.10795224292917, 1044.4008900268718, 1212.42085247918, 1366.4528686670553,
    1495.8430335283524, 1614.7920424124991, 1715.3386654379558, 1805.14637832034,
    1882.3689199295115, 1947.9157302115236, 2005.6163371641087,
    2053.3653120554827, 2094.4544227168972, 2127.8828951320047,
    2156.3708011003182, 2179.0945502919367, 2196.397638038341,
    2210.0642405518538, 2219.1946242726754, 2224.8249477459449,
    2227.1392860102405, 2227.4472958752522, 2224.7624665468247,
    2219.3743348187108, 2213.0985838774432, 2205.0297130533163,
    2194.9568547050585, 2183.0792728801935, 2170.06697015622, 2156.497476583716,
    2142.297671419281, 2126.9458720268613, 2110.5514359544013,
    2102.2649440550576, 2150.4447213635995, 2158.8989584723986,
    2175.6433476150487, 2191.3352262220978, 2205.8457676622293,
    2219.6863658580223, 2232.9275881785616, 2244.9923598088371,
    2255.2178673811777, 2263.4429631726543, 2269.8250011707369,
    2275.2497291224681, 2277.8985764727149, 2277.4895834374529,
    2275.051545783479, 2269.2213038935261, 2259.7740019114535, 2245.66144255791,
    2227.8170101940286, 2204.4608997150117, 2175.2356449966082,
    2140.9097556752367, 2098.7070926318647, 2049.6785120044005,
    1990.4772567318087, 1923.2787235340293, 1844.1113287946321,
    1752.0368557350578, 1648.9664393070584, 1527.029232806352,
    1394.3938433709707, 1236.543236238366, 1064.4582418515247,
    869.63685829368762, 637.56871546015589, 336.75308824303983,
    96.233795369471324, -198.45108043673446, -594.03323382416545,
    -1007.2830854547183, -1475.217752123443, -1982.9234473603246,
    -2575.1394709157444, -3215.8963498114617, -3959.0311512401022,
    -4772.8967661532761, -5691.9915041064942, -6717.3717841874741,
    -7852.706884985666, -9133.1914823103416, -10532.902119618111,
    -12110.882781220051, -13833.781905554803, -15741.105918574416,
    -17829.162789884216, -20090.369185829677, -22567.122665111925,
    -25191.25565650154, -28027.190467618333, -30980.733705022813,
    -34066.047947101528, -37223.879977211516, -40364.9675455519,
    -43499.905043511477, -46428.3940395779, -49194.446286291146,
    -51543.746238510721, -53496.404152806121, -55439.817214251496,
    -56027.004820738235, -55643.637848439081, -56027.004820738235,
    -55439.817214251205, -53496.404152806121, -51543.746238511289,
    -49194.446286291146, -46428.394039577623, -43499.905043511477,
    -40364.9675455519, -37223.8799772117, -34066.047947101528,
    -30980.733705022631, -28027.190467618333, -25191.25565650154,
    -22567.122665111925, -20090.369185829677, -17829.162789884216,
    -15741.105918574416, -13833.781905554803, -12110.882781220051,
    -10532.902119618111, -9133.1914823102961, -7852.706884985666,
    -6717.37178418752, -5691.9915041064942, -4772.8967661532306,
    -3959.0311512401022, -3215.8963498115072, -2575.1394709157444,
    -1982.9234473603246, -1475.217752123443, -1007.2830854547183,
    -594.03323382416545, -198.45108043673446, 96.233795369471324,
    336.75308824303983, 637.56871546015589, 869.63685829368762,
    1064.4582418515247, 1236.543236238366, 1394.3938433709707, 1527.029232806352,
    1648.9664393070584, 1752.0368557350578, 1844.1113287946321,
    1923.2787235340293, 1990.4772567318087, 2049.6785120044005,
    2098.7070926318647, 2140.9097556752367, 2175.2356449966082,
    2204.4608997150117, 2227.8170101940286, 2245.66144255791, 2259.7740019114535,
    2269.2213038935261, 2275.051545783479, 2277.4895834374529,
    2277.8985764727149, 2275.2497291224681, 2269.8250011707369,
    2263.4429631726543, 2255.2178673811322, 2244.9923598087917,
    2232.927588178607, 2219.6863658580678, 2205.8457676622293,
    2191.3352262220978, 2175.6433476150487, 2158.8989584723986,
    2150.4447213635995, 2198.6244977246297, 2207.2464808072691,
    2224.3408235124643, 2240.3727810752553, 2255.1940590613849,
    2269.305761434769, 2282.77590342809, 2295.0278645236704, 2305.4060214203196,
    2313.7873435481174, 2320.275667124904, 2325.7369915784216,
    2328.3498569422113, 2327.8398805243773, 2325.2781450748876,
    2319.2479829472154, 2309.483763720616, 2294.925246021101, 2276.5394692838963,
    2252.5510005406868, 2222.5883958087234, 2187.3650895440715,
    2144.0488699590314, 2093.7406875485049, 2033.038783315531,
    1964.1885334194722, 1883.0762826682969, 1788.7350455517646,
    1683.1408627025196, 1558.2154037955193, 1422.3348831210828,
    1260.6656934387945, 1084.5160011049747, 885.17110436423457,
    647.4655963809704, 338.40788426268745, 93.470254460134953,
    -207.0375248459639, -613.68948607723667, -1036.6524680073771,
    -1515.0185744634186, -2034.5970022551664, -2640.5208536674741,
    -3296.1570766820814, -4056.3994789772059, -4888.9928800274856,
    -5829.17721386047, -6877.9906588867952, -8039.1794162270271,
    -9348.7241892696056, -10780.134391978154, -12393.710346492378,
    -14155.322000502871, -16105.284559718288, -18239.880911786378,
    -20551.321393658989, -23082.782558501163, -25764.637342113405,
    -28662.747135129597, -31680.740318535409, -34832.994732823106,
    -38059.029864564909, -41267.679124143739, -44469.809478993062,
    -47460.810567556975, -50285.585099910262, -52684.618992040305,
    -54678.570489518868, -56663.078350142641, -57262.500254233688,
    -56870.8245457248, -57262.500254233688, -56663.078350142343,
    -54678.570489518868, -52684.618992040872, -50285.585099910262,
    -47460.810567556706, -44469.809478993062, -41267.679124143739,
    -38059.029864565142, -34832.994732823106, -31680.74031853518,
    -28662.747135129597, -25764.637342113405, -23082.782558501163,
    -20551.321393658989, -18239.880911786378, -16105.284559718288,
    -14155.322000502871, -12393.710346492378, -10780.134391978154,
    -9348.7241892696056, -8039.1794162270271, -6877.9906588867952,
    -5829.17721386047, -4888.99288002744, -4056.3994789772059,
    -3296.1570766821269, -2640.5208536674741, -2034.5970022551664,
    -1515.0185744634186, -1036.6524680073771, -613.68948607723667,
    -207.0375248459639, 93.470254460134953, 338.40788426268745,
    647.4655963809704, 885.17110436423457, 1084.5160011049747,
    1260.6656934387945, 1422.3348831210828, 1558.2154037955193,
    1683.1408627025196, 1788.7350455517646, 1883.0762826682969,
    1964.1885334194722, 2033.038783315531, 2093.7406875485049,
    2144.0488699590314, 2187.3650895440715, 2222.5883958086779,
    2252.5510005406868, 2276.5394692839418, 2294.925246021101, 2309.483763720616,
    2319.2479829472154, 2325.2781450748876, 2327.8398805243773,
    2328.3498569422113, 2325.736991578467, 2320.275667124904, 2313.7873435480265,
    2305.4060214203196, 2295.0278645237158, 2282.7759034281353,
    2269.305761434769, 2255.1940590613394, 2240.3727810752553,
    2224.3408235124643, 2207.2464808072691, 2198.6244977246297,
    2246.8042731989935, 2255.5940029706544, 2273.0382996991448,
    2289.4103359756155, 2304.5423507605369, 2318.9251568941904,
    2332.6242186317791, 2345.0633688746143, 2355.5941751895239,
    2364.131724934939, 2370.7263327067244, 2376.2242539223712, 2378.801137291473,
    2378.1901772925244, 2375.5047455409544, 2369.2746614698058,
    2359.1935259513752, 2344.1890484941246, 2325.2619276125165,
    2300.6411034389639, 2269.9411475092329, 2233.8204242683314,
    2189.3906442387542, 2137.8028637545849, 2075.6003099596892,
    2005.098349205944, 1922.0412397452474, 1825.4332349251838,
    1717.3153110853475, 1589.4015481614119, 1450.2759844540819,
    1284.7882209482111, 1104.5741483897464, 900.7105748534733,
    657.36519977681326, 340.04937544118519, 90.7034417036356,
    -215.61734229230731, -633.34445012383128, -1066.0204439123836,
    -1554.8203729701968, -2086.2705910085406, -2705.9024392457536,
    -3376.4177376327066, -4153.7678539832959, -5005.0889992835391,
    -5966.36293433798, -7038.6095480298472, -8225.6519312817472,
    -9564.25691498297, -11027.366643908445, -12676.537927504467,
    -14476.86209059551, -16469.463201482478, -18650.59904735411,
    -21012.273587859254, -23598.442463206018, -26338.019004501824,
    -29298.303820945668, -32380.746926389947, -35599.941517729043,
    -38894.179761548061, -42170.390681858691, -45439.713929939127,
    -48493.227077048505, -51376.723914811235, -53825.491749203116,
    -55860.736822449013, -57886.339476042522, -58497.995689309559,
    -58098.011288245558, -58497.995689309559, -57886.339476042231,
    -55860.736822449013, -53825.491749203706, -51376.723914811235,
    -48493.227077048214, -45439.713929939127, -42170.390681858691,
    -38894.179761548243, -35599.941517729043, -32380.746926389766,
    -29298.303820945668, -26338.019004501824, -23598.442463206018,
    -21012.273587859254, -18650.59904735411, -16469.463201482478,
    -14476.86209059551, -12676.537927504467, -11027.366643908399,
    -9564.2569149829251, -8225.6519312817927, -7038.6095480298927,
    -5966.36293433798, -5005.0889992834936, -4153.7678539832959,
    -3376.4177376327521, -2705.9024392457536, -2086.2705910085861,
    -1554.8203729701968, -1066.0204439123381, -633.34445012383128,
    -215.61734229230731, 90.7034417036356, 340.04937544118519,
    657.36519977676778, 900.7105748534733, 1104.5741483897918,
    1284.7882209482111, 1450.2759844540819, 1589.4015481614119,
    1717.3153110853475, 1825.4332349251838, 1922.0412397452474,
    2005.098349205944, 2075.6003099596892, 2137.8028637545849,
    2189.3906442387542, 2233.8204242683314, 2269.9411475091874,
    2300.6411034389639, 2325.261927612562, 2344.1890484941246,
    2359.1935259514207, 2369.2746614697603, 2375.5047455408635, 2378.19017729257,
    2378.8011372915184, 2376.2242539224167, 2370.7263327067244,
    2364.1317249348936, 2355.5941751895239, 2345.0633688746143,
    2332.6242186317791, 2318.9251568941904, 2304.5423507605369,
    2289.4103359756155, 2273.0382996991448, 2255.5940029706544,
    2246.8042731989935, 2294.984047842534, 2303.941524973332, 2321.7357761568542,
    2338.4478909201766, 2353.8906427409961, 2368.5445522438818,
    2382.4725337924951, 2395.0988728842708, 2405.7823287055703,
    2414.4761072697725, 2421.1769979393443, 2426.711516161547,
    2429.2524175283211, 2428.5404737619479, 2425.7313471085558,
    2419.3013394939476, 2408.903288577992, 2393.4528500379633,
    2373.9843852270474, 2348.7312082828316, 2317.2939000439305,
    2280.2757597974487, 2234.7324156563427, 2181.8650405838052,
    2118.1618366612365, 2046.0081705435168, 1961.0061998439942,
    1862.1314238889211, 1751.4897830553293, 1620.5876674413944,
    1478.2171441476735, 1308.9108158030274, 1124.6326655154908,
    916.25515694786293, 667.26747089360231, 341.6778720049021,
    87.933440738743158, -224.190613632072, -652.99823206710187,
    -1095.3871303389851, -1594.6230654373708, -2137.944209074838,
    -2771.2842124015856, -3456.6783372450086, -4251.1362728787353,
    -5121.1851235203949, -6103.5486647995585, -7199.2284506284186,
    -8412.1244312279869, -9779.7896582006979, -11274.598876751896,
    -12959.365523227405, -14798.402176144269, -16833.641843830839,
    -19061.317195701606, -21473.225769309993, -24114.102378501255,
    -26911.400645150046, -29933.860523904124, -33080.753528941445,
    -36366.888301875508, -39729.329667547572, -43073.102220010886,
    -46409.618395375313, -49525.643569207408, -52467.862730910521,
    -54966.364509769526, -57042.903151829712, -59109.600592572715,
    -59733.491125867506, -59325.198073186941, -59733.491125867506,
    -59109.6005925724, -57042.903151829712, -54966.364509770137,
    -52467.862730910521, -49525.643569207117, -46409.618395375313,
    -43073.102220010886, -39729.3296675478, -36366.888301875508,
    -33080.753528941219, -29933.860523904124, -26911.400645150046,
    -24114.102378501255, -21473.225769309993, -19061.317195701606,
    -16833.641843830839, -14798.402176144269, -12959.365523227405,
    -11274.598876751896, -9779.7896582006979, -8412.1244312279869,
    -7199.2284506284186, -6103.5486647995585, -5121.1851235203949,
    -4251.1362728787353, -3456.6783372449631, -2771.2842124015856,
    -2137.9442090748835, -1594.6230654373708, -1095.3871303389851,
    -652.99823206710187, -224.190613632072, 87.933440738743158,
    341.6778720049021, 667.26747089360231, 916.25515694786293,
    1124.6326655154908, 1308.9108158030274, 1478.2171441476735,
    1620.5876674413944, 1751.4897830553293, 1862.1314238889211,
    1961.0061998439942, 2046.0081705435168, 2118.1618366612365,
    2181.8650405838052, 2234.7324156563427, 2280.2757597974487,
    2317.2939000438851, 2348.7312082828316, 2373.9843852270928,
    2393.4528500379633, 2408.903288577992, 2419.3013394939476,
    2425.7313471085558, 2428.5404737619933, 2429.2524175283211,
    2426.711516161547, 2421.1769979393443, 2414.476107269727, 2405.7823287055703,
    2395.0988728842253, 2382.4725337925406, 2368.5445522439272,
    2353.8906427409506, 2338.4478909201766, 2321.7357761568542,
    2303.941524973332, 2294.984047842534, 2343.163821706637, 2352.2890468253058,
    2370.4332528688133, 2387.4854459061203, 2403.2389349853906,
    2418.1639474907092, 2432.3208489130116, 2445.1343765735578,
    2455.9704819840567, 2464.8204904945919, 2471.6276628442279,
    2477.1987783023155, 2479.703697659213, 2478.8907699506558,
    2475.9579497108894, 2469.3280170502, 2458.6130515770469, 2442.7166507088236,
    2422.7068421705076, 2396.821314955148, 2364.646653362704, 2326.7310960844929,
    2280.0741843825544, 2225.9272180005137, 2160.7233634175354,
    2086.9179971096382, 1999.971162796508, 1898.8296124733081,
    1785.6642773148435, 1651.7737630569613, 1506.1583592001612,
    1333.0334751979069, 1144.6915354063995, 931.80474058271932, 677.172356019127,
    343.29367505611089, 85.160332082659735, -232.7574255980833,
    -672.65092667671468, -1124.752631819455, -1634.4265786107358,
    -2189.6178525589203, -2836.6661593764975, -3536.9388796853823,
    -4348.504732598527, -5237.2812523757557, -6240.7344045724076,
    -7359.8473657822915, -8598.5969170500921, -9995.3224177818265,
    -11521.83109173601, -13242.193132719774, -15119.942257434774,
    -17197.820486729855, -19472.035356018005, -21934.177938816927,
    -24629.762303722397, -27484.782265417536, -30569.417242938944,
    -33780.76012651583, -37133.835085313614, -40564.479582001339,
    -43975.813739806523, -47379.522874407376, -50558.06004509436,
    -53559.001548131506, -56107.237273528852, -58225.06947787547,
    -60332.861700304391, -60968.986563817205, -60552.384897963137,
    -60968.986563817205, -60332.861700304071, -58225.06947787547,
    -56107.237273529448, -53559.001548131506, -50558.060045094091,
    -47379.522874407376, -43975.813739806523, -40564.479582001572,
    -37133.835085313614, -33780.760126515604, -30569.417242938944,
    -27484.782265417536, -24629.762303722397, -21934.177938816927,
    -19472.035356018005, -17197.820486729855, -15119.942257434774,
    -13242.193132719774, -11521.83109173601, -9995.3224177818265,
    -8598.5969170500921, -7359.8473657822915, -6240.7344045724076,
    -5237.28125237571, -4348.5047325984815, -3536.9388796854278,
    -2836.666159376543, -2189.6178525589203, -1634.4265786107358,
    -1124.752631819455, -672.65092667671468, -232.7574255980833,
    85.160332082659735, 343.29367505611089, 677.172356019127, 931.80474058271932,
    1144.6915354063995, 1333.0334751979524, 1506.1583592001612,
    1651.7737630569159, 1785.664277314798, 1898.8296124733081,
    1999.9711627965535, 2086.9179971096382, 2160.7233634175354,
    2225.9272180005137, 2280.0741843825544, 2326.7310960844929,
    2364.6466533626585, 2396.821314955148, 2422.706842170553, 2442.7166507088691,
    2458.6130515770469, 2469.3280170501089, 2475.9579497108894,
    2478.8907699507013, 2479.703697659213, 2477.1987783023155,
    2471.6276628441824, 2464.8204904945919, 2455.9704819840567,
    2445.1343765735123, 2432.3208489131025, 2418.1639474907547,
    2403.2389349853452, 2387.4854459061203, 2370.4332528688133,
    2352.2890468253058, 2343.163821706637, 2391.3435948383244,
    2400.6365685357173, 2419.130729819833, 2436.5230009309903, 2452.587227477668,
    2467.783342640721, 2482.1691639958294, 2495.1698799617566,
    2506.1586350392167, 2515.1648745560556, 2522.0783274410655,
    2527.6860403507249, 2530.1549776905154, 2529.2410658755193,
    2526.1845532863822, 2519.3546941662566, 2508.3228149264846,
    2491.9804505581374, 2471.429298482642, 2444.9114233482737, 2411.99940741976,
    2373.186433086355, 2325.4159505745497, 2269.9893959715591,
    2203.2848902259484, 2127.8278286062668, 2038.9361284472652,
    1935.5278007059023, 1819.8387926594917, 1682.9598363239695,
    1534.099626811711, 1357.1561964759883, 1164.7507420180762,
    947.35921839910509, 687.07980249691843, 344.89707687062008,
    82.384193311372584, -241.31786947737032, -692.302618862231,
    -1154.1170419052821, -1674.2308470047631, -2241.2915181123462,
    -2902.0482677247373, -3617.1993687515592, -4445.8732303567522,
    -5353.3773855215668, -6377.9201530427545, -7520.4662926696465,
    -8785.0693896487355, -10210.855192682211, -11769.063289985332,
    -13525.0207551191, -15441.482334729275, -17561.999130148644,
    -19882.753527559573, -22395.130097119116, -25145.4222382594,
    -28058.163866552761, -31204.973977070738, -34480.766719413004,
    -37900.7818680902, -41399.629504392724, -44878.525242354342,
    -48349.4273662132, -51590.476505685365, -54650.1403664042,
    -57248.110040287313, -59407.235800783681, -61556.122799763187,
    -62204.482003075485, -61779.571760194347, -62204.482003075485,
    -61556.122799762852, -59407.235800783681, -57248.110040287938,
    -54650.1403664042, -51590.476505685067, -48349.4273662132,
    -44878.525242354342, -41399.629504392949, -37900.7818680902,
    -34480.766719412772, -31204.973977070738, -28058.163866552761,
    -25145.4222382594, -22395.130097119116, -19882.753527559573,
    -17561.999130148644, -15441.482334729275, -13525.0207551191,
    -11769.063289985332, -10210.855192682211, -8785.0693896487355,
    -7520.4662926696465, -6377.9201530427545, -5353.3773855215668,
    -4445.8732303567522, -3617.1993687515592, -2902.0482677247373,
    -2241.2915181123462, -1674.2308470047631, -1154.1170419052821,
    -692.302618862231, -241.31786947737032, 82.384193311372584,
    344.89707687062008, 687.07980249691843, 947.35921839910509,
    1164.7507420180762, 1357.1561964759883, 1534.099626811711,
    1682.9598363239695, 1819.8387926594917, 1935.5278007059023,
    2038.9361284472652, 2127.8278286062668, 2203.2848902259484,
    2269.9893959715591, 2325.4159505745497, 2373.186433086355,
    2411.9994074197143, 2444.9114233482737, 2471.4292984826875,
    2491.9804505581374, 2508.32281492653, 2519.3546941662112, 2526.1845532862912,
    2529.2410658755648, 2530.1549776905608, 2527.6860403507249, 2522.07832744102,
    2515.1648745560556, 2506.1586350392622, 2495.1698799617111,
    2482.1691639958749, 2467.7833426407665, 2452.5872274776225,
    2436.5230009309903, 2419.130729819833, 2400.6365685357173,
    2391.3435948383244, 2439.5233672811605, 2448.9840901128878,
    2467.8282069955435, 2485.5605559925584, 2501.9355202033671,
    2517.4027376998288, 2532.017479043177, 2545.2053830665113, 2556.346787884147,
    2565.5092594047323, 2572.5289917479108, 2578.1733023123229,
    2580.6062576281397, 2579.591361552, 2576.4111577780091, 2569.3813708678113,
    2558.0325786063872, 2541.2442496336985, 2520.1517542001488,
    2493.0015333626193, 2459.3521621723971, 2419.6417707631076,
    2370.7577143778485, 2314.0515744663367, 2245.8464170839743,
    2168.737664757371, 2077.9010966515652, 1972.2259886118973, 1854.013327970277,
    1714.145888462552, 1562.0409443677077, 1381.2789771195628,
    1184.8102702609128, 962.91848569671765, 696.98975873470715,
    346.48836118712978, 79.605099222862847, -249.87204001536134,
    -711.95338492216183, -1183.4804445694306, -1714.0358119014293,
    -2292.96520284888, -2967.4305261607487, -3697.4598079122156,
    -4543.2417636154205, -5469.47352265965, -6515.10590964985,
    -7681.0852305391491, -8971.5418498495565, -10426.387981944927,
    -12016.295472532045, -13807.848389633442, -15763.022408268747,
    -17926.177774058335, -20293.47170964309, -22856.082244895857,
    -25661.082181551115, -28631.545449704456, -31840.53072539793,
    -35180.7733079089, -38667.7286502481, -42234.779434246695,
    -45781.23672867578, -49319.3318700356, -52622.8929518797,
    -55741.279185664091, -58388.982809866677, -60589.402120736624,
    -62779.383891433681, -63439.977443565724, -63006.75865768666,
    -63439.977443565724, -62779.383891433339, -60589.402120736624,
    -58388.982809867339, -55741.279185664091, -52622.892951879381,
    -49319.3318700356, -45781.23672867578, -42234.779434246921,
    -38667.7286502481, -35180.773307908668, -31840.53072539793,
    -28631.545449704456, -25661.082181551115, -22856.082244895857,
    -20293.47170964309, -17926.177774058335, -15763.022408268747,
    -13807.848389633442, -12016.295472532, -10426.387981944881,
    -8971.5418498496019, -7681.0852305391945, -6515.10590964985,
    -5469.47352265965, -4543.2417636154205, -3697.4598079122156,
    -2967.4305261607487, -2292.96520284888, -1714.0358119014293,
    -1183.4804445694306, -711.95338492216183, -249.87204001536134,
    79.605099222862847, 346.48836118712978, 696.98975873470715,
    962.91848569671765, 1184.8102702609128, 1381.2789771195628,
    1562.0409443677077, 1714.145888462552, 1854.013327970277, 1972.2259886118973,
    2077.9010966515652, 2168.737664757371, 2245.8464170839743,
    2314.0515744663367, 2370.7577143778485, 2419.6417707631076,
    2459.3521621723971, 2493.0015333626193, 2520.1517542001488,
    2541.2442496337439, 2558.0325786064327, 2569.3813708677203,
    2576.4111577779636, 2579.5913615520908, 2580.6062576281397,
    2578.1733023122774, 2572.5289917479108, 2565.5092594047323,
    2556.346787884147, 2545.2053830665113, 2532.0174790432225,
    2517.4027376998288, 2501.9355202033216, 2485.5605559925584,
    2467.8282069955435, 2448.9840901128878, 2439.5233672811605,
    2487.7031390750722, 2497.3316115645935, 2516.5256843829843,
    2534.5981110886873, 2551.2838131488911, 2567.0221326731257,
    2581.8657940571006, 2595.2408859043294, 2606.5349405312168,
    2615.8536449953749, 2622.9796557814529, 2628.660564192021,
    2631.0575374773157, 2629.9416569945129, 2626.6377631334285,
    2619.408047178465, 2607.7423425980191, 2590.5080479796175,
    2568.8742093569977, 2541.0916449063711, 2506.7049175814623,
    2466.0971090773251, 2416.09947592651, 2358.1137534565619, 2288.4079439894758,
    2209.6475053072918, 2116.8660672748938, 2008.9241762143483,
    1888.1878822062374, 1745.3319206057115, 1589.9823094237022,
    1405.4018147413433, 1204.870105930512, 978.48244038414032,
    706.90217420678823, 348.0678034875379, 76.82312198639913,
    -258.42003450470634, -731.60329360807668, -1212.8429154009598,
    -1753.8414205007014, -2344.6389042732312, -3032.8129244267047,
    -3777.7202003415337, -4640.610330057184, -5585.5696635190679,
    -6652.2916738800577, -7841.7041787021317, -9158.0142984111189,
    -10641.920784690992, -12263.52764032489, -14090.676035534112,
    -16084.562478275288, -18290.356418432504, -20704.189901639693,
    -23317.034382772661, -26176.742133080665, -29204.927015931,
    -32476.087487089506, -35880.779892258455, -39434.675431826428,
    -43069.929371125145, -46683.948199713181, -50289.2363851762,
    -53655.309384507607, -56832.418005851941, -59529.85558210242,
    -61771.568437902613, -64002.644975763345, -64675.472885217132,
    -64233.945588414143, -64675.472885217132, -64002.644975763033,
    -61771.568437902613, -59529.855582103068, -56832.418005851941,
    -53655.309384507287, -50289.2363851762, -46683.948199713181,
    -43069.929371125327, -39434.675431826428, -35880.779892258273,
    -32476.087487089506, -29204.927015931, -26176.742133080665,
    -23317.034382772661, -20704.189901639693, -18290.356418432504,
    -16084.562478275288, -14090.676035534112, -12263.52764032489,
    -10641.920784690947, -9158.0142984111189, -7841.7041787021772,
    -6652.2916738800577, -5585.569663518977, -4640.610330057184,
    -3777.7202003415337, -3032.8129244267047, -2344.6389042733222,
    -1753.8414205006104, -1212.8429154009598, -731.60329360816763,
    -258.42003450470634, 76.82312198639913, 348.0678034875379,
    706.90217420678823, 978.48244038414032, 1204.870105930512,
    1405.4018147413433, 1589.9823094237022, 1745.3319206057115,
    1888.1878822062374, 2008.9241762143483, 2116.8660672748938,
    2209.6475053072918, 2288.4079439894758, 2358.1137534565619, 2416.09947592651,
    2466.0971090773251, 2506.7049175814623, 2541.0916449063711,
    2568.8742093569977, 2590.5080479796175, 2607.7423425980191,
    2619.408047178465, 2626.637763133383, 2629.9416569945583, 2631.0575374773612,
    2628.660564192021, 2622.9796557814529, 2615.8536449953294,
    2606.5349405312168, 2595.2408859043294, 2581.8657940571461,
    2567.0221326731257, 2551.2838131488456, 2534.5981110886873,
    2516.5256843829843, 2497.3316115645935, 2487.7031390750722,
    2535.8829102570758, 2545.6791328979284, 2565.2231619700137,
    2583.6356662173307, 2600.63210630178, 2616.6415275657505, 2631.7141090395558,
    2645.2763884901265, 2656.72309299134, 2666.1980312857372, 2673.4303195572897,
    2679.1478259948212, 2681.5088172431365, 2680.2919522159732,
    2676.8643693039826, 2669.4347231205916, 2657.4521068842819,
    2639.7718456362759, 2617.5966639842932, 2589.1817578944006,
    2554.0576736106209, 2512.5524479951287, 2461.4412353453167,
    2402.1759329157226, 2330.9694709401788, 2250.5573500185146,
    2155.831040191877, 2045.6223635338556, 1922.3624543971691,
    1776.5179338071887, 1617.9237196922245, 1429.5247070767787,
    1224.930235643568, 994.05098292572711, 716.81699945438527,
    349.63567126997049, 74.038331277733889, -266.96195202821377,
    -751.25240703455279, -1242.2045226230682, -1793.6476251940787,
    -2396.3126202233957, -3098.1954531785932, -3857.980548950396,
    -4737.9789275624671, -5701.665807852527, -6789.4774452621214,
    -8002.32313652604, -9344.4867360309127, -10857.453600111958,
    -12510.759794238073, -14373.50369215004, -16406.102544953759,
    -18654.535063246185, -21114.908102969392, -23777.98651132637,
    -26692.40209237107, -29778.308566209325, -33111.644261378176,
    -36580.7864726975, -40201.62221286101, -43905.079314623443,
    -47586.65965633723, -51259.140910989641, -54687.7258043367,
    -57923.556826913155, -60670.728356842657, -62953.734752437485,
    -65225.906053166007, -65910.968327964249, -65461.1325505033,
    -65910.968327964249, -65225.906053165672, -62953.734752437485,
    -60670.728356843312, -57923.556826913155, -54687.725804336376,
    -51259.140910989641, -47586.65965633723, -43905.079314623668,
    -40201.62221286101, -36580.786472697277, -33111.644261378176,
    -29778.308566209325, -26692.40209237107, -23777.98651132637,
    -21114.908102969392, -18654.535063246185, -16406.102544953759,
    -14373.50369215004, -12510.759794237982, -10857.453600111958,
    -9344.4867360310036, -8002.32313652604, -6789.4774452621214,
    -5701.665807852436, -4737.9789275624671, -3857.980548950487,
    -3098.1954531785932, -2396.3126202233957, -1793.6476251940787,
    -1242.2045226230682, -751.25240703455279, -266.96195202821377,
    74.038331277733889, 349.63567126997049, 716.81699945438527,
    994.05098292572711, 1224.930235643568, 1429.5247070767787,
    1617.9237196922245, 1776.5179338071887, 1922.3624543971691,
    2045.6223635338556, 2155.831040191877, 2250.5573500185146,
    2330.9694709401788, 2402.1759329157226, 2461.4412353453167,
    2512.5524479951287, 2554.0576736106209, 2589.1817578944006,
    2617.5966639842932, 2639.7718456362759, 2657.4521068842819,
    2669.4347231205916, 2676.8643693039826, 2680.2919522159732,
    2681.5088172431365, 2679.1478259948212, 2673.4303195572897,
    2666.1980312857372, 2656.72309299134, 2645.2763884901265, 2631.7141090396012,
    2616.6415275657505, 2600.6321063017344, 2583.6356662173307,
    2565.2231619700137, 2545.6791328979284, 2535.8829102570758,
    2584.0626808614593, 2594.0266541196229, 2613.9206397455814,
    2632.6732213768514, 2649.980399650392, 2666.2609223819322,
    2681.5624239922704, 2695.3118908380907, 2706.9112452752029,
    2716.5424182372567, 2723.8809830898367, 2729.6350877247255,
    2731.9600969298313, 2730.64224722875, 2727.0909762447423, 2719.4613987139724,
    2707.1618714490774, 2689.0356426418271, 2666.3191181113666,
    2637.2718722478544, 2601.4104302258579, 2559.0077874841859,
    2506.7829927497746, 2446.2381128193533, 2373.5309979342651,
    2291.4671986708508, 2194.7960152860087, 2082.3205505896094,
    1956.5370436378525, 1807.7039290474188, 1645.8651730300503,
    1453.6476519767334, 1244.9906467801145, 1009.6240162878521,
    726.73418608064753, 351.19222431312636, 71.25079440438634,
    -275.49789282857068, -770.90078146065866, -1271.5653279688911,
    -1833.4543829439992, -2447.9863488204478, -3163.5781038860814,
    -3938.240856412991, -4835.3475541884063, -5817.7619554337925,
    -6926.663223363078, -8162.9421034299339, -9530.9591633523178,
    -11072.986427462356, -12757.991935077542, -14656.331358861677,
    -16727.642608493563, -19018.713708476462, -21525.62631309668,
    -24238.938631090037, -27208.062058981544, -30351.690101442611,
    -33747.20104755403, -37280.793049443775, -40968.568993385008,
    -44740.229264367968, -48489.371099353732, -52229.045446878648,
    -55720.142212077757, -59014.6956487973, -61811.601133946795,
    -64135.90106448561, -66449.167124024927, -67146.463771746436,
    -66688.319542218727, -67146.463771746436, -66449.167124024578,
    -64135.90106448561, -61811.601133947457, -59014.6956487973,
    -55720.142212077437, -52229.045446878648, -48489.371099353732,
    -44740.229264368194, -40968.568993385008, -37280.79304944355,
    -33747.20104755403, -30351.690101442611, -27208.062058981544,
    -24238.938631090037, -21525.62631309668, -19018.713708476462,
    -16727.642608493563, -14656.331358861677, -12757.991935077542,
    -11072.986427462265, -9530.9591633523178, -8162.9421034300249,
    -6926.663223363078, -5817.7619554337016, -4835.3475541884063,
    -3938.2408564130819, -3163.5781038860814, -2447.9863488204478,
    -1833.4543829439083, -1271.5653279688001, -770.90078146074961,
    -275.49789282866163, 71.25079440438634, 351.19222431312636,
    726.73418608064753, 1009.6240162878521, 1244.9906467801145,
    1453.6476519767334, 1645.8651730300503, 1807.7039290474188,
    1956.5370436378525, 2082.3205505896094, 2194.7960152860087,
    2291.4671986708508, 2373.5309979342651, 2446.2381128193533,
    2506.7829927497746, 2559.0077874841859, 2601.4104302258579,
    2637.2718722478544, 2666.3191181113666, 2689.0356426418271,
    2707.1618714490774, 2719.4613987138814, 2727.0909762447423,
    2730.6422472289319, 2731.9600969298313, 2729.6350877247255,
    2723.8809830898367, 2716.5424182371657, 2706.9112452752029,
    2695.3118908380907, 2681.5624239923613, 2666.2609223819322,
    2649.980399650301, 2632.6732213768514, 2613.9206397455814,
    2594.0266541196229, 2584.0626808614593, 2632.2424509198731,
    2642.3741752356341, 2662.6181176991827, 2681.7107765653395,
    2699.3286931840862, 2715.8803171262639, 2731.4107389169271,
    2745.3473929610459, 2757.0993973924465, 2766.8868058135536,
    2774.3316463919632, 2780.1223493860539, 2782.4113765421293,
    2780.9925420441664, 2777.3175839139162, 2769.4880739780251,
    2756.8716362777172, 2738.2994390311046, 2715.0415717648661,
    2685.3619878932454, 2648.7631873961595, 2605.4631275149382,
    2552.1247482470221, 2490.300293144353, 2416.0925249695515,
    2332.3770510590271, 2233.7609924484223, 2119.018737399254,
    1990.7116490835488, 1838.8899072406259, 1673.8066674267413,
    1477.7706474000283, 1265.0513274299544, 1025.20144588343, 736.65368674319257,
    352.73771493229981, 68.460576421693929, -284.02795778374616,
    -790.5484679644353, -1300.9253874331978, -1873.2616547486016,
    -2499.6600884295708, -3228.9608687468872, -4018.501125189774,
    -4932.716208150664, -5933.8581060561355, -7063.84900778375,
    -8323.5610788777121, -9717.4315809688687, -11288.51926605438,
    -13005.224063588583, -14939.159035096496, -17049.182669070055,
    -19382.892354101823, -21936.344531526291, -24699.890742556705,
    -27723.722032503949, -30925.071622467265, -34382.757844959742,
    -37980.799622699451, -41735.51577342888, -45575.3792200123,
    -49392.082529509571, -53198.949992289818, -56752.558608389743,
    -60105.834471457718, -62952.473913284608, -65318.067374181068,
    -67672.42818869566, -68381.959216507457, -67915.50656195081,
    -68381.959216507457, -67672.4281886953, -65318.067374181068,
    -62952.473913285292, -60105.834471457718, -56752.558608389423,
    -53198.949992289818, -49392.082529509571, -45575.379220012524,
    -41735.51577342888, -37980.799622699225, -34382.757844959742,
    -30925.071622467265, -27723.722032503949, -24699.890742556705,
    -21936.344531526291, -19382.892354101823, -17049.182669070055,
    -14939.159035096496, -13005.224063588583, -11288.51926605438,
    -9717.4315809688687, -8323.5610788777121, -7063.84900778375,
    -5933.8581060560446, -4932.716208150664, -4018.501125189865,
    -3228.9608687468872, -2499.6600884295708, -1873.2616547485106,
    -1300.9253874331068, -790.54846796452625, -284.02795778383711,
    68.460576421693929, 352.73771493229981, 736.65368674319257, 1025.20144588343,
    1265.0513274299544, 1477.7706474000283, 1673.8066674267413,
    1838.8899072406259, 1990.7116490835488, 2119.018737399254,
    2233.7609924484223, 2332.3770510590271, 2416.0925249695515,
    2490.300293144353, 2552.1247482470221, 2605.4631275149382,
    2648.7631873961595, 2685.3619878932454, 2715.0415717648661,
    2738.2994390311046, 2756.8716362777172, 2769.4880739780251,
    2777.3175839138253, 2780.9925420442573, 2782.4113765422203,
    2780.1223493859629, 2774.3316463919632, 2766.8868058135536,
    2757.0993973924465, 2745.3473929610459, 2731.4107389169271,
    2715.8803171262639, 2699.3286931840862, 2681.7107765653395,
    2662.6181176991827, 2642.3741752356341, 2632.2424509198731,
    2680.4222204618759, 2690.7216962518737, 2711.3155958212678,
    2730.7483317812489, 2748.6769868928582, 2765.4997118022925,
    2781.2590538151176, 2795.3828948712703, 2807.2875493517108,
    2817.2311939812034, 2824.7823094764472, 2830.609610982262,
    2832.8626560835773, 2831.3428366728631, 2827.5441922728505,
    2819.5147489298479, 2806.5814013561044, 2787.5632348368504,
    2763.7640249702577, 2733.4521047626345, 2696.1159450921491,
    2651.9184680595549, 2597.4665019369218, 2534.3624738695303, 2458.65405204431,
    2373.2869069917774, 2272.7259715773453, 2155.7169239787054,
    2024.8862699438159, 1870.0758692402799, 1701.7482009950056,
    1501.8936914068022, 1285.1122663434569, 1040.7831795160737,
    746.57545514537492, 354.27238822694528, 65.667740238222848,
    -292.55224796988813, -810.1955130249728, -1330.2847519240447,
    -1913.0694051807025, -2551.3338376235856, -3294.3437406095627,
    -4098.7613575493888, -5030.0848878080569, -6049.9542595298353,
    -7201.0347981566092, -8484.1800623748823, -9903.9039894292637,
    -11504.052115252114, -13252.45618046082, -15221.986720324263,
    -17370.722726845528, -19747.071000102307, -22347.062757799431,
    -25160.8428461833, -28239.382012559985, -31498.453130058504,
    -35018.314652985435, -38680.806192652344, -42502.462553020683,
    -46410.52918123515, -50294.793947497783, -54168.854546709437,
    -57784.974993884854, -61196.973294851356, -64093.346694735272,
    -66500.2336816484, -68895.689247508475, -69617.454662195087,
    -69142.693608204339, -69617.454662195087, -68895.689247508111,
    -66500.2336816484, -64093.346694735978, -61196.973294851356,
    -57784.974993884513, -54168.854546709437, -50294.793947497783,
    -46410.529181235375, -42502.462553020683, -38680.806192652119,
    -35018.314652985435, -31498.453130058504, -28239.382012559985,
    -25160.8428461833, -22347.062757799431, -19747.071000102307,
    -17370.722726845528, -15221.986720324263, -13252.456180460729,
    -11504.052115252023, -9903.9039894293546, -8484.1800623749732,
    -7201.0347981566092, -6049.9542595298353, -5030.0848878080569,
    -4098.7613575493888, -3294.3437406095627, -2551.3338376235856,
    -1913.0694051807025, -1330.2847519240447, -810.1955130249728,
    -292.55224796988813, 65.667740238222848, 354.27238822694528,
    746.57545514537492, 1040.7831795160737, 1285.1122663434569,
    1501.8936914068022, 1701.7482009950056, 1870.0758692402799,
    2024.8862699438159, 2155.7169239787054, 2272.7259715773453,
    2373.2869069917774, 2458.65405204431, 2534.3624738695303, 2597.4665019369218,
    2651.9184680595549, 2696.1159450921491, 2733.4521047626345,
    2763.7640249702577, 2787.5632348368504, 2806.5814013561044,
    2819.5147489298479, 2827.5441922727596, 2831.342836672954,
    2832.8626560836683, 2830.609610982171, 2824.7823094764472,
    2817.2311939812034, 2807.2875493517108, 2795.3828948711794,
    2781.2590538152085, 2765.4997118023834, 2748.6769868927672,
    2730.7483317812489, 2711.3155958212678, 2690.7216962518737,
    2680.4222204618759, 2728.6019895145705, 2739.0692171734349,
    2760.0130741029693, 2779.7858870233517, 2798.025280767522, 2815.119106413747,
    2831.1073686880236, 2845.4183965795864, 2857.4757011616357,
    2867.5755827091934, 2875.2329723543853, 2881.0968725168977, 2883.31393555836,
    2881.6931311247545, 2877.7708012853482, 2869.5414235859034,
    2856.2911666714144, 2836.8270300891681, 2812.4864777507332,
    2781.5422227927206, 2743.4687032868146, 2698.3738090920247,
    2642.8082539124239, 2578.42465497524, 2501.2155791569944, 2414.1967662906586,
    2311.6909525770984, 2192.4151103426975, 2059.0609054792349,
    1901.2618158433709, 1729.6897719615101, 1526.016782153873,
    1305.1734528868099, 1056.3691273223403, 756.49944602255277,
    355.79648231996509, 62.872346716267145, -301.0708642978895,
    -829.84195902827128, -1359.6434678263893, -1952.87760198871,
    -2603.007595155575, -3359.7267129080105, -4179.0215555860377,
    -5127.4535916479135, -6166.0504156806328, -7338.2205941417787,
    -8644.799053464696, -10090.376389242092, -11719.584974466477,
    -13499.688286332626, -15504.81441405353, -17692.262781971007,
    -20111.249646459037, -22757.780991490497, -25621.794942393695,
    -28755.04199879849, -32071.834624936509, -35653.871471064725,
    -39380.8127594768, -43269.409332186304, -47245.679147738294,
    -51197.505353962792, -55138.759109660277, -58817.391369132107,
    -62288.112118938094, -65234.21947818646, -67682.399987003533,
    -70118.950300770492, -70852.950108760735, -70369.8806795888,
    -70852.950108760735, -70118.9503007701, -67682.399987003533,
    -65234.219478187188, -62288.112118938094, -58817.391369131765,
    -55138.759109660277, -51197.505353962792, -47245.67914773852,
    -43269.409332186304, -39380.812759476576, -35653.871471064725,
    -32071.834624936509, -28755.04199879849, -25621.794942393695,
    -22757.780991490497, -20111.249646459037, -17692.262781971007,
    -15504.81441405353, -13499.688286332535, -11719.584974466477,
    -10090.376389242183, -8644.799053464696, -7338.2205941417787,
    -6166.0504156805418, -5127.4535916479135, -4179.0215555861287,
    -3359.7267129080105, -2603.007595155666, -1952.87760198871,
    -1359.6434678262983, -829.84195902827128, -301.0708642978895,
    62.872346716267145, 355.79648231996509, 756.49944602255277,
    1056.3691273223403, 1305.1734528868099, 1526.016782153873,
    1729.6897719615101, 1901.2618158433709, 2059.0609054792349,
    2192.4151103426975, 2311.6909525770984, 2414.1967662906586,
    2501.2155791569944, 2578.42465497524, 2642.8082539124239, 2698.3738090920247,
    2743.4687032868146, 2781.5422227927206, 2812.4864777507332,
    2836.8270300892591, 2856.2911666715054, 2869.5414235858125,
    2877.7708012852572, 2881.6931311247545, 2883.31393555836, 2881.0968725168977,
    2875.2329723543853, 2867.5755827091025, 2857.4757011616357,
    2845.4183965795864, 2831.1073686881145, 2815.1191064138379,
    2798.025280767431, 2779.7858870233517, 2760.0130741029693,
    2739.0692171734349, 2728.6019895145705, 2776.7817581037866,
    2787.4167380054109, 2808.7105525361017, 2828.8234422901924,
    2847.373574799255, 2864.738500964083, 2880.9556835373742, 2895.4538980969091,
    2907.6638528297708, 2917.9199719682374, 2925.6836350367821,
    2931.5841339934168, 2933.7652149693868, 2932.0434254084803,
    2927.9974109177574, 2919.5680979614708, 2906.0009322120068,
    2886.090824816617, 2861.2089301277565, 2829.6323419241135,
    2790.8214619548721, 2744.8291505885186, 2688.1500042602033,
    2622.4868364425652, 2543.7771063059677, 2455.1066287888693,
    2350.6559353589159, 2229.1132965051456, 2093.2355549966796,
    1932.4477477956843, 1757.6313786578778, 1550.1399178873712,
    1325.2348770000924, 1071.9592017156165, 766.42561513053738,
    357.31022859017651, 60.074454763434858, -309.58390721279983,
    -849.48784470870953, -1389.0015774926712, -1992.6862157480155,
    -2654.6813599333268, -3425.1097796023682, -4259.2817212369446,
    -5224.8223182745232, -6282.1465743477293, -7475.406395424664,
    -8805.4180517239656, -10276.848780878563, -11935.117843151591,
    -13746.920381797632, -15787.642115828097, -18013.802834586462,
    -20475.428293154509, -23168.499232204045, -26082.747031581835,
    -29270.701990893096, -32645.21610777071, -36289.428298670704,
    -40080.81932333517, -44036.356110949833, -48080.829119244438,
    -52100.216749504078, -56108.663680698031, -59849.807734661306,
    -63379.250943680709, -66375.0922635337, -68864.56629035456,
    -71342.211348767785, -72088.44555615916, -71597.067774809082,
    -72088.44555615916, -71342.211348767421, -68864.56629035456,
    -66375.092263534432, -63379.250943680709, -59849.807734660943,
    -56108.663680698031, -52100.216749504078, -48080.829119244663,
    -44036.356110949833, -40080.819323334945, -36289.428298670704,
    -32645.21610777071, -29270.701990893096, -26082.747031581835,
    -23168.499232204045, -20475.428293154509, -18013.802834586462,
    -15787.642115828097, -13746.920381797541, -11935.117843151591,
    -10276.848780878654, -8805.4180517239656, -7475.406395424664,
    -6282.1465743477293, -5224.8223182745232, -4259.2817212369446,
    -3425.1097796023682, -2654.6813599333268, -1992.6862157480155,
    -1389.0015774926712, -849.48784470870953, -309.58390721279983,
    60.074454763434858, 357.31022859017651, 766.42561513053738,
    1071.9592017156165, 1325.2348770000924, 1550.1399178873712,
    1757.6313786578778, 1932.4477477956843, 2093.2355549966796,
    2229.1132965051456, 2350.6559353589159, 2455.1066287888693,
    2543.7771063059677, 2622.4868364425652, 2688.1500042602033,
    2744.8291505885186, 2790.8214619548721, 2829.6323419241135,
    2861.2089301277565, 2886.090824816617, 2906.0009322120068, 2919.56809796138,
    2927.9974109177574, 2932.0434254085712, 2933.7652149693868,
    2931.5841339934168, 2925.6836350367821, 2917.9199719682374, 2907.66385282968,
    2895.4538980969091, 2880.9556835375561, 2864.738500964083,
    2847.3735747991641, 2828.8234422901924, 2808.7105525361017,
    2787.4167380054109, 2776.7817581037866, 2823.0038165889682,
    2833.7762539032128, 2855.3394877962974, 2875.7108448782647,
    2894.514643839645, 2912.0883704590569, 2928.4623461494421,
    2943.0878142778938, 2955.3913223467107, 2965.7233799495743,
    2973.5043423609541, 2979.3536583058967, 2981.431835471355, 2979.55360342921,
    2975.2630008247224, 2966.4942475136713, 2952.5432464737578,
    2932.1260307211533, 2906.6064993156915, 2874.2800778946703, 2834.60172137047,
    2787.5930605611734, 2729.6870774534887, 2662.6348916855909,
    2582.2997918502529, 2491.8358099590455, 2385.3042523100135,
    2261.3663036487178, 2122.8244658033855, 1958.9072351242958,
    1780.7832878903339, 1569.3366556954957, 1340.1915981826266,
    1082.5264013457845, 771.12067646867149, 352.06939056160957,
    51.940588446814175, -322.239455381077, -875.39096700274888,
    -1424.6208737427864, -2038.2370258612336, -2712.1845368278605,
    -3496.208666242816, -4345.1477186271368, -5327.5855458014075,
    -6403.3942045747553, -7617.3631646482072, -8970.2983705036713,
    -10466.940989418517, -12153.434684283719, -13995.939772791358,
    -16070.963291762913, -18334.2991343973, -20836.695541656427,
    -23574.065767390653, -26535.914855298437, -29775.470910081705,
    -33204.178600907348, -36906.422533836361, -40757.6998215554,
    -44775.163610564145, -48882.429832362461, -52963.715549220156,
    -57033.386679567819, -60831.255096026405, -64413.839955695643,
    -67454.510285838958, -69981.020738544059, -72495.516805273379,
    -73252.700145717783, -72753.823090697464, -73252.700145717783,
    -72495.516805272986, -69981.020738544059, -67454.510285839686,
    -64413.839955695643, -60831.255096026063, -57033.386679567819,
    -52963.715549220156, -48882.429832362686, -44775.163610564145,
    -40757.699821555172, -36906.422533836361, -33204.178600907348,
    -29775.470910081705, -26535.914855298437, -23574.065767390653,
    -20836.695541656427, -18334.2991343973, -16070.963291762913,
    -13995.939772791267, -12153.434684283628, -10466.940989418608,
    -8970.2983705037623, -7617.3631646482072, -6403.3942045747553,
    -5327.5855458013166, -4345.1477186271368, -3496.2086662429069,
    -2712.1845368278605, -2038.2370258612336, -1424.6208737427864,
    -875.39096700274888, -322.239455381077, 51.940588446814175,
    352.06939056160957, 771.12067646867149, 1082.5264013457845,
    1340.1915981826266, 1569.3366556954957, 1780.7832878902429,
    1958.9072351242958, 2122.8244658034764, 2261.3663036487178,
    2385.3042523100135, 2491.8358099590455, 2582.2997918502529,
    2662.6348916855909, 2729.6870774534887, 2787.5930605611734, 2834.60172137047,
    2874.2800778946703, 2906.6064993156915, 2932.1260307211533,
    2952.5432464737578, 2966.4942475135804, 2975.2630008247224,
    2979.5536034293009, 2981.431835471355, 2979.3536583058967,
    2973.5043423609541, 2965.7233799495743, 2955.3913223467107,
    2943.0878142778938, 2928.4623461494421, 2912.0883704590569,
    2894.514643839645, 2875.7108448782647, 2855.3394877962974,
    2833.7762539032128, 2823.0038165889682, 2867.9836669500191,
    2878.8743383277479, 2900.6558882939289, 2921.2339303488052,
    2940.2551831181854, 2957.998177969509, 2974.4831805936856,
    2989.1978746163632, 3001.55743645, 3011.9144828815452, 3019.6562864837661,
    3025.3987204880077, 3027.3315335775778, 3025.2616692416241,
    3020.649758193028, 3011.4530459365569, 2997.0757521379683,
    2976.1126266028414, 2949.8943610882607, 2916.7435507334603,
    2876.1151538743406, 2828.0146852925072, 2768.8099928342103,
    2700.2993635124744, 2618.2597408200286, 2525.9122761264712,
    2417.213572245962, 2290.7987507041962, 2149.5036994816455,
    1982.3676052648789, 1800.8964492057187, 1585.4077044613391,
    1351.9108765010049, 1089.9406394572898, 772.514570454586, 342.45772131780512,
    40.400523975858924, -337.47745448599716, -905.260275157979,
    -1464.2084829419205, -2087.4345618341049, -2773.3867170116332,
    -3570.9349616216027, -4434.5704984286349, -5433.771892755517,
    -6527.9105612360527, -7762.347242290336, -9137.88264511849,
    -10659.329990544566, -12373.518083974421, -14246.093162619387,
    -16354.597636876573, -18654.133140917183, -21196.115458072181,
    -23976.363474288271, -26984.143344109791, -30273.329271569874,
    -33753.991853049425, -37511.638459166774, -41419.906332510174,
    -45496.116146486296, -49662.742870811737, -53802.333060088131,
    -57929.441056221272, -61780.361491784031, -65412.546938965796,
    -68494.933970386424, -71055.779611119884, -73604.433928589875,
    -74371.750914432516, -73865.888117575, -74371.750914432516,
    -73604.4339285895, -71055.779611119884, -68494.933970387152,
    -65412.546938965796, -61780.361491783689, -57929.441056221272,
    -53802.333060088131, -49662.742870812006, -45496.116146486296,
    -41419.9063325099, -37511.638459166774, -33753.991853049425,
    -30273.329271569874, -26984.143344109791, -23976.363474288271,
    -21196.115458072181, -18654.133140917183, -16354.597636876573,
    -14246.093162619387, -12373.518083974421, -10659.329990544566,
    -9137.88264511849, -7762.347242290336, -6527.9105612360527,
    -5433.771892755517, -4434.5704984286349, -3570.9349616216027,
    -2773.3867170116332, -2087.4345618340139, -1464.2084829419205,
    -905.26027515806993, -337.47745448599716, 40.400523975858924,
    342.45772131780512, 772.514570454586, 1089.9406394572898, 1351.9108765010049,
    1585.4077044613391, 1800.8964492057187, 1982.3676052648789,
    2149.5036994816455, 2290.7987507041962, 2417.213572245962,
    2525.9122761264712, 2618.2597408200286, 2700.2993635124744,
    2768.8099928342103, 2828.0146852925072, 2876.1151538743406,
    2916.7435507334603, 2949.8943610882607, 2976.1126266028414,
    2997.0757521379683, 3011.4530459365569, 3020.649758193028,
    3025.2616692416241, 3027.3315335775778, 3025.3987204880077,
    3019.6562864836751, 3011.9144828815452, 3001.5574364500908,
    2989.1978746163632, 2974.4831805936856, 2957.998177969509,
    2940.2551831181854, 2921.2339303488052, 2900.6558882939289,
    2878.8743383277479, 2867.9836669500191, 2912.9635173352626,
    2923.9724222016748, 2945.9722882683282, 2966.7570159434008,
    2985.9957237089448, 3003.9079848734191, 3020.5040144914137,
    3035.3079356825192, 3047.7235496423391, 3058.1055874506974,
    3065.8082292286026, 3071.4437819314271, 3073.2312345116015,
    3070.9697366934024, 3066.0365121893819, 3056.4118409335579,
    3041.6082651069673, 3020.0992194276268, 2993.1822239439471,
    2959.2070260022383, 2917.628585653526, 2868.4363173130778,
    2807.9328955127471, 2737.9638501441127, 2654.2196821350421,
    2559.988762470764, 2449.1229153190011, 2320.2311974018789,
    2176.1830257628371, 2005.8278616752414, 1821.0101337923318,
    1601.4790461907055, 1363.6322473137614, 1097.4015920308366,
    773.93324268441506, 332.73017516667068, 28.832675978173913,
    -352.65203200224244, -935.12451938759034, -1503.7905782626681,
    -2136.6359508433543, -2834.5890254144224, -3645.6620025454836,
    -4523.9929843921309, -5539.9584796320551, -6652.4269296211005,
    -7907.3313563191659, -9305.4669918405943, -10851.718919483383,
    -12593.6015704321, -14496.24645497223, -16638.232044610671,
    -18973.967134127706, -21555.535388286789, -24378.661229199202,
    -27432.371764880892, -30771.187704574022, -34303.804994508086,
    -38116.854444573131, -42082.112828851234, -46217.068684917293,
    -50443.055955999356, -54640.950482110748, -58825.4954821697,
    -62729.467813793795, -66411.253946142679, -69535.357662047914,
    -72130.538461256758, -74713.351007098725, -75490.801690234875,
    -74977.953347316492, -75490.801690234875, -74713.351007098332,
    -72130.538461256758, -69535.357662048642, -66411.253946142679,
    -62729.467813793453, -58825.4954821697, -54640.950482110748,
    -50443.055955999582, -46217.068684917293, -42082.112828851,
    -38116.854444573131, -34303.804994508086, -30771.187704574022,
    -27432.371764880892, -24378.661229199202, -21555.535388286789,
    -18973.967134127706, -16638.232044610671, -14496.24645497223,
    -12593.6015704321, -10851.718919483383, -9305.4669918405943,
    -7907.3313563191659, -6652.4269296211005, -5539.9584796320551,
    -4523.9929843921309, -3645.6620025454836, -2834.5890254144224,
    -2136.6359508433543, -1503.7905782625771, -935.12451938759034,
    -352.65203200233339, 28.832675978173913, 332.73017516667068,
    773.93324268441506, 1097.4015920308366, 1363.6322473137614,
    1601.4790461907055, 1821.0101337922408, 2005.8278616752414,
    2176.1830257629281, 2320.2311974018789, 2449.1229153190011,
    2559.988762470764, 2654.2196821350421, 2737.9638501441127,
    2807.9328955127471, 2868.4363173130778, 2917.628585653526,
    2959.2070260022383, 2993.1822239439471, 3020.0992194276268,
    3041.6082651069673, 3056.4118409335579, 3066.0365121893819,
    3070.9697366934024, 3073.2312345116015, 3071.4437819315181,
    3065.8082292286026, 3058.1055874506064, 3047.7235496423391,
    3035.3079356824283, 3020.5040144915047, 3003.90798487351, 2985.9957237088538,
    2966.7570159434008, 2945.9722882683282, 2923.9724222016748,
    2912.9635173352626, 2957.9433677437892, 2969.0705055499138,
    2991.288687743142, 3012.2801016565945, 3031.7362655528059,
    3049.8177911985267, 3066.5248478674557, 3081.4179974431654,
    3093.889661964201, 3104.2966935844534, 3111.9601706569456,
    3117.4888426690786, 3119.1309381489164, 3116.6778057134225,
    3111.4232629617591, 3101.3706326538313, 3086.140785065706,
    3064.0858093272955, 3036.4700878397316, 3001.6705035996865,
    2959.1420167416773, 2908.85795632839, 2847.0557860123308, 2775.6283510020671,
    2690.179616109524, 2594.0652682497762, 2481.0322807339594,
    2349.6636438318069, 2202.8624417996962, 2029.2880084031804,
    1841.1243283889219, 1617.5506842341733, 1375.3556911079602,
    1104.9118281447581, 775.37811711390464, 322.88070614877114,
    17.23567920580534, -367.75927902108344, -964.98410646063257,
    -1543.3676116643242, -2185.84087183717, -2895.7914400022646,
    -3720.389737721322, -4613.4151935555519, -5646.1452917927945,
    -6776.9433087975749, -8052.3155046539541, -9473.0514066537489,
    -11044.107780019467, -12813.685139109464, -14746.399654798175,
    -16921.866511823449, -19293.801114650505, -21914.955331656147,
    -24780.959029760812, -27880.600120912524, -31269.046205685954,
    -34853.618030506972, -38722.0704872661, -42744.319311217907,
    -46938.021225771219, -51223.369085744976, -55479.567819328979,
    -59721.549955150425, -63678.574065345347, -67409.960976132279,
    -70575.781360483146, -73205.29728992928, -75822.268042777534,
    -76609.852472812068, -76090.018770968716, -76609.852472812068,
    -75822.268042777156, -73205.29728992928, -70575.781360483918,
    -67409.960976132279, -63678.574065344961, -59721.549955150425,
    -55479.567819328979, -51223.369085745253, -46938.021225771219,
    -42744.31931121763, -38722.0704872661, -34853.618030506972,
    -31269.046205685954, -27880.600120912524, -24780.959029760812,
    -21914.955331656147, -19293.801114650505, -16921.866511823449,
    -14746.399654798175, -12813.685139109464, -11044.107780019467,
    -9473.0514066537489, -8052.3155046539541, -6776.943308797484,
    -5646.1452917927945, -4613.4151935556429, -3720.389737721322,
    -2895.7914400022646, -2185.8408718370792, -1543.3676116643242,
    -964.98410646072352, -367.75927902108344, 17.23567920580534,
    322.88070614877114, 775.37811711390464, 1104.9118281447581,
    1375.3556911079602, 1617.5506842341733, 1841.1243283889219,
    2029.2880084031804, 2202.8624417996962, 2349.6636438318069,
    2481.0322807339594, 2594.0652682497762, 2690.179616109524,
    2775.6283510020671, 2847.0557860123308, 2908.85795632839, 2959.1420167415863,
    3001.6705035996865, 3036.4700878398226, 3064.0858093272955,
    3086.140785065706, 3101.3706326538313, 3111.4232629616681,
    3116.6778057135134, 3119.1309381490073, 3117.4888426689877,
    3111.9601706569456, 3104.2966935844534, 3093.889661964201,
    3081.4179974431654, 3066.5248478675467, 3049.8177911985267,
    3031.7362655527149, 3012.2801016565945, 2991.288687743142,
    2969.0705055499138, 2957.9433677437892, 3002.923218175235,
    3014.1685883961118, 3036.6050867402892, 3057.8031874827475,
    3077.4768085939259, 3095.7275969704797, 3112.5456807450946,
    3127.5280598679246, 3140.0557734544209, 3150.4878012143281,
    3158.1121108257294, 3163.5339027318851, 3165.0306443729251,
    3162.3858762341997, 3156.81001064913, 3146.3294212383489, 3130.6733117165068,
    3108.0723964260842, 3079.7579527355965, 3044.1339834301261,
    3000.6554471700811, 2949.2796020590476, 2886.1786648278185,
    2813.2928655380942, 2726.1395430407879, 2628.1417927571943,
    2512.9416677320455, 2379.09609007638, 2229.5419448594639, 2052.7480493081366,
    1861.2390201727051, 1633.622621629273, 1387.0811884022248,
    1112.4740891167667, 776.850711810129, 312.90285952700259, 5.6080713517985661,
    -382.79509479252704, -994.83940080744924, -1582.9399873153293,
    -2235.0490381847503, -2956.9939420263809, -3795.1181204427453,
    -4702.8371416653454, -5752.33231576903, -6901.4596979210119,
    -8197.2996853705736, -9640.6358858347539, -11236.49657567802,
    -13033.768785771634, -14996.552766715364, -17205.501035580241,
    -19613.635083069112, -22274.375287575804, -25183.256873763617,
    -28328.828415295149, -31766.904771710932, -35403.430965946623,
    -39327.286584626621, -43406.525780212636, -47658.973768965421,
    -52003.682258001711, -56318.185075542438, -60617.604473037216,
    -64627.680249535646, -68408.6680279065, -71616.205065373128,
    -74280.056098056419, -76931.185037489064, -77728.903261869389,
    -77202.084380097818, -77728.903261869389, -76931.185037488642,
    -74280.056098056419, -71616.205065373913, -68408.6680279065,
    -64627.680249535282, -60617.604473037216, -56318.185075542438,
    -52003.68225800198, -47658.973768965421, -43406.525780212367,
    -39327.286584626621, -35403.430965946623, -31766.904771710932,
    -28328.828415295149, -25183.256873763617, -22274.375287575804,
    -19613.635083069112, -17205.501035580241, -14996.552766715364,
    -13033.768785771634, -11236.49657567802, -9640.6358858347539,
    -8197.2996853705736, -6901.4596979209209, -5752.33231576903,
    -4702.8371416654363, -3795.1181204428362, -2956.9939420263809,
    -2235.0490381845684, -1582.9399873153293, -994.83940080754019,
    -382.79509479252704, 5.6080713517985661, 312.90285952691164,
    776.850711810129, 1112.4740891167667, 1387.0811884022248, 1633.6226216293639,
    1861.2390201727051, 2052.7480493081366, 2229.5419448594639, 2379.09609007638,
    2512.9416677320455, 2628.1417927571943, 2726.1395430407879,
    2813.2928655380942, 2886.1786648278185, 2949.2796020590476,
    3000.6554471700811, 3044.1339834301261, 3079.7579527355965,
    3108.0723964260842, 3130.6733117165068, 3146.3294212383489, 3156.81001064913,
    3162.3858762341997, 3165.0306443729251, 3163.5339027318851,
    3158.1121108257294, 3150.4878012143281, 3140.0557734544209,
    3127.5280598679246, 3112.5456807451856, 3095.7275969704797,
    3077.4768085938349, 3057.8031874827475, 3036.6050867402892,
    3014.1685883961118, 3002.923218175235, 3047.9030686283268,
    3059.2666707624603, 3081.9214852815066, 3103.3262734173122,
    3123.2173527796449, 3141.6374022132886, 3158.5665131461583,
    3173.6381229276931, 3186.2218841488329, 3196.6789102759294,
    3204.2640497898874, 3209.578962149405, 3210.9303530726693,
    3208.0939481917057, 3202.1967553830082, 3191.2882068202607,
    3175.2058447788813, 3152.0589808414088, 3123.0458185927064,
    3086.5974654028805, 3042.16887696866, 2989.701254240751, 2925.3015324275084,
    2850.957393231326, 2762.0994632105953, 2662.2183353207197,
    2544.8510755880284, 2408.5285362102672, 2256.2215323187029,
    2076.2079880725632, 1881.3541967415388, 1649.6948611174034,
    1398.8087197594712, 1120.0913034906071, 778.35264718569238,
    302.78973620206642, -6.0517148776852938, -397.75516048493921,
    -1024.6907298788747, -1622.5080677190804, -2284.2601932132293,
    -3018.1965155045846, -3869.8471080898307, -4792.2588432954353,
    -5858.5195391461584, -7025.9760962262526, -8342.2838966871423,
    -9808.220425926711, -11428.885309746227, -13253.852506470765,
    -15246.705795039894, -17489.135613136372, -19933.469039932497,
    -22633.795255477777, -25585.554759137973, -28777.056650925508,
    -32264.763399651263, -35953.243805428443, -39932.502734192996,
    -44068.7322364041, -48379.926314420845, -52783.995470846319,
    -57156.802254327064, -61513.659033830241, -65576.786369282723,
    -69407.375100497826, -72656.6287764184, -75354.814886505483,
    -78040.101992989657, -78847.954057129071, -78314.150166752108,
    -78847.954057129071, -78040.10199298925, -75354.814886505483,
    -72656.6287764192, -69407.375100497826, -65576.786369282345,
    -61513.659033830241, -57156.802254327064, -52783.995470846596,
    -48379.926314420845, -44068.732236403826, -39932.502734192996,
    -35953.243805428443, -32264.763399651263, -28777.056650925508,
    -25585.554759137973, -22633.795255477777, -19933.469039932497,
    -17489.135613136372, -15246.705795039803, -13253.852506470674,
    -11428.885309746318, -9808.2204259268019, -8342.2838966871423,
    -7025.9760962262526, -5858.5195391461584, -4792.2588432954353,
    -3869.8471080899217, -3018.1965155046755, -2284.2601932131383,
    -1622.5080677189894, -1024.6907298788747, -397.75516048493921,
    -6.0517148776852938, 302.78973620206642, 778.35264718569238,
    1120.0913034906071, 1398.8087197594712, 1649.6948611174034,
    1881.3541967415388, 2076.2079880724723, 2256.2215323187029,
    2408.5285362103582, 2544.8510755880284, 2662.2183353207197,
    2762.0994632105953, 2850.957393231326, 2925.3015324275084, 2989.701254240751,
    3042.16887696866, 3086.5974654028805, 3123.0458185927064, 3152.0589808414998,
    3175.2058447788813, 3191.2882068201698, 3202.1967553829172,
    3208.0939481917057, 3210.93035307276, 3209.578962149405, 3204.2640497897964,
    3196.6789102758385, 3186.2218841489239, 3173.638122927784,
    3158.5665131462492, 3141.6374022132886, 3123.2173527795539,
    3103.3262734173122, 3081.9214852815066, 3059.2666707624603,
    3047.9030686283268, 3092.8829191027007, 3104.3647526697869,
    3127.2378833861667, 3148.8493594553775, 3168.9578980605775,
    3187.5472069501457, 3204.5873450913832, 3219.7481865952768,
    3232.387994081816, 3242.87002070823, 3250.4159876000786, 3255.6240209490143,
    3256.8300641444666, 3253.8020215265506, 3247.5834972872663,
    3236.2469895245313, 3219.7383839874392, 3196.0455626841367,
    3166.3336853746814, 3129.0609494322753, 3083.6823061650621,
    3030.1229126227527, 2964.424389255325, 2888.6219335872711,
    2798.0593768853373, 2696.2948952994316, 2576.7605036094187,
    2437.9609823019541, 2282.9012016580218, 2099.6678282113844,
    1901.4698460964594, 1665.7674051607485, 1410.5382657993673,
    1126.0837440431706, 778.96250289249951, 298.95404361423033,
    -18.247126295318576, -418.76718252624374, -1053.11347081224,
    -1660.6771386810565, -2333.4741064170862, -3079.3991467924543,
    -3944.5766616928231, -4881.6803119550923, -5964.706950463,
    -7150.4925030177155, -8487.2681369510174, -9975.8050237165571,
    -11621.273985292817, -13473.936297520491, -15496.858743810102,
    -17772.77024192243, -20253.302985756527, -22993.215234828018,
    -25987.85268394438, -29225.28483052208, -32762.622086691063,
    -36503.056553277078, -40537.7189336492, -44730.938680329207,
    -49100.878862061611, -53564.308722469919, -57995.419359051484,
    -62409.713635646622, -66525.892427338462, -70406.082192995527,
    -73697.052493337716, -76429.573656095628, -79149.018910936677,
    -79967.004858328917, -79426.216123427876, -79967.004858328917,
    -79149.018910936269, -76429.573656095628, -73697.0524933385,
    -70406.082192995527, -66525.8924273381, -62409.713635646622,
    -57995.419359051484, -53564.308722470196, -49100.878862061611,
    -44730.938680328931, -40537.7189336492, -36503.056553277078,
    -32762.622086691063, -29225.28483052208, -25987.85268394438,
    -22993.215234828018, -20253.302985756527, -17772.77024192243,
    -15496.858743810102, -13473.9362975204, -11621.273985292817,
    -9975.8050237166481, -8487.2681369510174, -7150.4925030177155,
    -5964.706950463, -4881.6803119550923, -3944.5766616928231,
    -3079.3991467924543, -2333.4741064170862, -1660.6771386810565,
    -1053.11347081224, -418.76718252624374, -18.247126295318576,
    298.95404361423033, 778.96250289249951, 1126.0837440431706,
    1410.5382657993673, 1665.7674051607485, 1901.4698460964594,
    2099.6678282113844, 2282.9012016580218, 2437.9609823019541,
    2576.7605036094187, 2696.2948952994316, 2798.0593768853373,
    2888.6219335872711, 2964.424389255325, 3030.1229126227527,
    3083.6823061650621, 3129.0609494322753, 3166.3336853746814,
    3196.0455626841367, 3219.7383839874392, 3236.2469895245313,
    3247.5834972872663, 3253.8020215265506, 3256.8300641444666,
    3255.6240209490143, 3250.4159876000786, 3242.87002070823, 3232.3879940817251,
    3219.7481865952768, 3204.5873450914742, 3187.5472069501457,
    3168.9578980605775, 3148.8493594553775, 3127.2378833861667,
    3104.3647526697869, 3092.8829191027007, 3137.8627695976293,
    3149.4628341380094, 3172.5542810730049, 3194.3724455923957,
    3214.6984443901574, 3233.4570112026058, 3250.6081766002326,
    3265.8582508446643, 3278.5541032852934, 3289.0611324540232,
    3296.5679243049608, 3301.6690791569972, 3302.729777489546, 3299.510096181345,
    3292.9702364792292, 3281.2057694703044, 3264.27092909116, 3240.03214205886,
    3209.62155304687, 3171.5244354371835, 3125.1957347859361, 3070.5445769674925,
    3003.5472357318185, 2926.2864861359021, 2834.0192843183986,
    2730.3714720823314, 2608.669951133013, 2467.3934284129223,
    2309.5809504567092, 2123.127573082, 1921.5859566265844, 1681.8402559583758,
    1422.2698072091575, 1131.9192448751883, 779.48548966096428,
    295.64810631964036, -30.45362960028794, -440.24922125754489,
    -1081.437585583807, -1698.7493086544403, -2382.690570226257,
    -3140.6018242256296, -4019.306745550417, -4971.1015601844292,
    -6070.8945391215766, -7275.0089176623924, -8632.25240462688,
    -10143.389676213146, -11813.662605186335, -13694.020155476015,
    -15747.011616808126, -18056.404919530345, -20573.136921027417,
    -23352.635225123664, -26390.150646362577, -29673.512956637544,
    -33260.480830182831, -37052.8692135617, -41142.935180814544,
    -45393.145112495637, -49821.831411815037, -54344.622011169486,
    -58834.036392891532, -63305.768276712195, -67474.998426300343,
    -71404.789304540813, -74737.476215866453, -77504.3324076012,
    -80257.935792895572, -81086.055665221371, -80538.282243038338,
    -81086.055665221371, -80257.93579289515, -77504.3324076012,
    -74737.476215867267, -71404.789304540813, -67474.998426299964,
    -63305.768276712195, -58834.036392891532, -54344.622011169755,
    -49821.831411815037, -45393.14511249536, -41142.935180814544,
    -37052.8692135617, -33260.480830182831, -29673.512956637544,
    -26390.150646362577, -23352.635225123664, -20573.136921027417,
    -18056.404919530345, -15747.011616808126, -13694.020155476015,
    -11813.662605186335, -10143.389676213146, -8632.25240462688,
    -7275.0089176623014, -6070.8945391215766, -4971.10156018452,
    -4019.3067455505079, -3140.6018242256296, -2382.6905702260751,
    -1698.7493086544403, -1081.437585583898, -440.24922125754489,
    -30.45362960028794, 295.64810631964036, 779.48548966096428,
    1131.9192448751883, 1422.2698072091575, 1681.8402559583758,
    1921.5859566265844, 2123.127573082, 2309.5809504567092, 2467.3934284129223,
    2608.669951133013, 2730.3714720823314, 2834.0192843183986,
    2926.2864861359021, 3003.5472357318185, 3070.5445769674925,
    3125.1957347859361, 3171.5244354371835, 3209.62155304687, 3240.0321420589507,
    3264.27092909116, 3281.2057694702135, 3292.9702364792292, 3299.510096181436,
    3302.729777489546, 3301.6690791569972, 3296.5679243049608,
    3289.0611324539323, 3278.5541032852025, 3265.8582508446643,
    3250.6081766003235, 3233.4570112026058, 3214.6984443901574,
    3194.3724455923957, 3172.5542810730049, 3149.4628341380094,
    3137.8627695976293, 3182.8426201122029, 3194.5609151855906,
    3217.8706783599382, 3239.8955318244562, 3260.4389917240924,
    3279.3668149907689, 3296.6290076911691, 3311.968315651754,
    3324.7202117896422, 3335.2522454587383, 3342.7198599500994,
    3347.7141367977279, 3348.6294930148656, 3345.2181721028833,
    3338.3569730695822, 3326.164546769448, 3308.803479852847, 3284.0187190650768,
    3252.909421576348, 3213.9879233406618, 3166.7091628559292,
    3110.9662470485973, 3042.6700722558026, 2963.9510504300206,
    2869.9791857495229, 2764.4480650872515, 2640.579417525712,
    2496.8258745994694, 2336.2607763878236, 2146.58722589247, 1941.7025170931975,
    1697.913415459969, 1434.0033247535744, 1137.7514615687678, 780.0059099695311,
    292.28674517262306, -42.62594439042001, -461.64267565845836,
    -1109.7928518259314, -1736.8516636300212, -2431.9093972388123,
    -3201.804537822497, -4094.0373268954281, -5060.52259963953,
    -6177.0822953070765, -7399.5253395836635, -8777.23669828728,
    -10310.974380628331, -12006.0511721107, -13914.104077113994,
    -15997.164417579992, -18340.03964370066, -20892.970846203552,
    -23712.055225890959, -26792.4486446828, -30121.741031672602,
    -33758.339627634967, -37602.681790113515, -41748.151473633523,
    -46055.351533383284, -50542.78396361124, -55124.935335340473,
    -59672.653358844349, -64201.8229553535, -68424.104368621949,
    -72403.4964343241, -75777.899943755867, -78579.091141754747,
    -81366.852640345533, -82205.106477572364, -81650.348518885556,
    -82205.106477572364, -81366.852640345111, -78579.091141754747,
    -75777.899943756711, -72403.4964343241, -68424.104368621542,
    -64201.8229553535, -59672.653358844349, -55124.93533534075,
    -50542.78396361124, -46055.351533383015, -41748.151473633523,
    -37602.681790113515, -33758.339627634967, -30121.741031672602,
    -26792.4486446828, -23712.055225890959, -20892.970846203552,
    -18340.03964370066, -15997.164417579992, -13914.104077113994,
    -12006.0511721107, -10310.974380628331, -8777.23669828728,
    -7399.5253395836635, -6177.0822953069855, -5060.52259963953,
    -4094.0373268955191, -3201.804537822497, -2431.9093972387213,
    -1736.8516636300212, -1109.7928518260223, -461.64267565845836,
    -42.62594439042001, 292.28674517262306, 780.0059099695311,
    1137.7514615687678, 1434.0033247535744, 1697.913415459969,
    1941.7025170931975, 2146.58722589247, 2336.2607763878236, 2496.8258745994694,
    2640.579417525712, 2764.4480650872515, 2869.9791857495229,
    2963.9510504300206, 3042.6700722558026, 3110.9662470486883,
    3166.7091628559292, 3213.9879233405709, 3252.909421576348,
    3284.0187190650768, 3308.803479852847, 3326.164546769448, 3338.3569730694912,
    3345.2181721028833, 3348.6294930149566, 3347.7141367978188,
    3342.7198599500994, 3335.2522454586474, 3324.7202117896422,
    3311.968315651754, 3296.62900769126, 3279.3668149907689, 3260.4389917240014,
    3239.8955318244562, 3217.8706783599382, 3194.5609151855906,
    3182.8426201122029, 3227.8224706458759, 3239.6589958299019,
    3263.1870752631557, 3285.4186181473751, 3306.1795400209094, 3325.27661833428,
    3342.6498383814728, 3358.0783809934442, 3370.8863196239658,
    3381.4433596712629, 3388.8717945785143, 3393.7591938945811, 3394.52921063266,
    3390.9262492402345, 3383.7437071630998, 3371.1233215282814,
    3353.3360360475822, 3328.0052937965561, 3296.1972909315564,
    3256.4514130694051, 3208.2225903984154, 3151.3879226519721,
    3081.7928992063544, 3001.6156260441649, 2905.939081406993,
    2798.5246737578541, 2672.488902180246, 2526.2583209128911,
    2362.9406772142806, 2170.0467897092476, 1961.8195166152855,
    1713.9868853812898, 1445.738799284662, 1143.5804316463864, 780.5237970081173,
    288.87654345171512, -54.767947414347823, -482.95773961190162,
    -1138.1756002613647, -1774.9806376877116, -2481.1304178446312,
    -3263.0072790355343, -4168.7683755995713, -5149.9434411685752,
    -6283.2702099170947, -7524.0417682552952, -8922.2210166022633,
    -10478.559134360594, -12198.439688580573, -14134.188059415543,
    -16247.317149454087, -18623.674412311339, -21212.80476171667,
    -24071.475236683069, -27194.746677297528, -30569.969057885803,
    -34256.198476700563, -38152.494286543661, -42353.367810167409,
    -46717.557943446816, -51263.73651738331, -55905.24869346941,
    -60511.270259740144, -65097.87766999119, -69373.210256622842,
    -73402.2035815806, -76818.323676771455, -79653.849859249764,
    -82475.769454686248, -83324.157295160592, -82762.4149446333,
    -83324.157295160592, -82475.769454685811, -79653.849859249764,
    -76818.32367677227, -73402.2035815806, -69373.210256622464,
    -65097.87766999119, -60511.270259740144, -55905.248693469679,
    -51263.73651738331, -46717.55794344654, -42353.367810167409,
    -38152.494286543661, -34256.198476700563, -30569.969057885803,
    -27194.746677297528, -24071.475236683069, -21212.80476171667,
    -18623.674412311339, -16247.317149454087, -14134.188059415452,
    -12198.439688580573, -10478.559134360685, -8922.2210166022633,
    -7524.0417682552952, -6283.2702099170947, -5149.9434411685752,
    -4168.7683755995713, -3263.0072790355343, -2481.1304178446312,
    -1774.9806376877116, -1138.1756002613647, -482.95773961190162,
    -54.767947414347823, 288.87654345171512, 780.5237970081173,
    1143.5804316463864, 1445.738799284662, 1713.9868853812898,
    1961.8195166152855, 2170.0467897092476, 2362.9406772142806,
    2526.2583209128911, 2672.488902180246, 2798.5246737578541, 2905.939081406993,
    3001.6156260441649, 3081.7928992063544, 3151.3879226519721,
    3208.2225903984154, 3256.4514130694051, 3296.1972909315564,
    3328.0052937965561, 3353.3360360475822, 3371.1233215282814,
    3383.7437071630998, 3390.9262492402345, 3394.52921063266, 3393.7591938945811,
    3388.8717945784233, 3381.4433596712629, 3370.8863196240568,
    3358.0783809934442, 3342.6498383814728, 3325.27661833428, 3306.1795400209094,
    3285.4186181473751, 3263.1870752631557, 3239.6589958299019,
    3227.8224706458759, 3272.8023211982845, 3284.7570760877688,
    3308.5034717988465, 3330.941704557787, 3351.9200892411359,
    3371.1864212509649, 3388.6706686876064, 3404.1884468479079,
    3417.0524268149134, 3427.6344750429384, 3435.0237282314961,
    3439.8042504696573, 3440.4289302591646, 3436.634327545195,
    3429.1304388591893, 3416.0820938473048, 3397.8685974623627, 3371.99186634252,
    3339.4851610827541, 3298.9149045542918, 3249.7360174354953,
    3191.8096035733442, 3120.9157169431792, 3039.280212573155,
    2941.8989715070866, 2832.6012975631756, 2704.3984045159027,
    2555.6907673993896, 2389.6206507842157, 2193.5062674662713,
    1981.9369446558067, 1730.0606672157285, 1457.476211749598,
    1149.4061921945095, 781.03918342476322, 285.42312070230741,
    -66.8829503918459, -504.20310946665222, -1166.5827079840699,
    -1813.1331970944286, -2530.3534781736721, -3324.2100405409446,
    -4243.4998639141631, -5239.3640948814163, -6389.45827449806,
    -7648.5582031958011, -9067.2053583318229, -10646.143934979582,
    -12390.828156953547, -14354.272099548949, -16497.469815557255,
    -18907.309223367865, -21532.638667974952, -24430.89525707826,
    -27597.0447426939, -31018.197037404996, -34754.057375166907,
    -38702.306706258569, -42958.584188585439, -47379.764343116542,
    -51984.6890730671, -56685.562084127967, -61349.887098254061,
    -65993.932419132878, -70322.316092497829, -74400.910745587957,
    -77858.747414692087, -80728.608560743276, -83584.686237242451,
    -84443.208117776419, -83874.481514283631, -84443.208117776419,
    -83584.686237242015, -80728.608560743276, -77858.7474146929,
    -74400.910745587957, -70322.316092497436, -65993.932419132878,
    -61349.887098254061, -56685.56208412828, -51984.6890730671,
    -47379.764343116221, -42958.584188585439, -38702.306706258569,
    -34754.057375166907, -31018.197037404996, -27597.0447426939,
    -24430.89525707826, -21532.638667974952, -18907.309223367865,
    -16497.469815557255, -14354.272099548949, -12390.828156953547,
    -10646.143934979582, -9067.2053583318229, -7648.55820319571,
    -6389.4582744979689, -5239.3640948815073, -4243.4998639142541,
    -3324.2100405409446, -2530.3534781736721, -1813.1331970944286,
    -1166.5827079840699, -504.20310946665222, -66.8829503918459,
    285.42312070230741, 781.03918342476322, 1149.4061921945095,
    1457.476211749598, 1730.0606672157285, 1981.9369446558067,
    2193.5062674662713, 2389.6206507842157, 2555.6907673993896,
    2704.3984045159027, 2832.6012975631756, 2941.8989715070866,
    3039.280212573155, 3120.9157169431792, 3191.8096035733442,
    3249.7360174354953, 3298.9149045542918, 3339.4851610827541, 3371.99186634252,
    3397.8685974623627, 3416.0820938472139, 3429.1304388591893,
    3436.6343275452859, 3440.4289302591646, 3439.8042504696573,
    3435.0237282314051, 3427.6344750429384, 3417.0524268150043,
    3404.1884468479079, 3388.6706686876064, 3371.1864212509649,
    3351.9200892411359, 3330.941704557787, 3308.5034717988465,
    3284.7570760877688, 3272.8023211982845, 3317.7821717685192,
    3329.8551559748344, 3353.8198679816528, 3376.464791051782,
    3397.6606393476654, 3417.0962237581957, 3434.6914986248489,
    3450.2985131946812, 3463.2185333886778, 3473.8255915277446,
    3481.1756609473346, 3485.8493065438747, 3486.3286518157079,
    3482.3424069720172, 3474.5171682517107, 3461.0408638218328,
    3442.4011638950983, 3415.9784367872785, 3382.7730320016567,
    3341.3783977296557, 3291.2494439880875, 3232.2312896186277,
    3160.038525808156, 3076.9448096309106, 2977.8588562559862,
    2866.6779359960829, 2736.3079239759804, 2585.1232141011656,
    2416.3006950268914, 2216.9656619702419, 2002.0547910081386,
    1746.1347622484011, 1469.2155431992419, 1155.2287798627719,
    781.55210133581863, 281.93130208082925, -78.973799304731, -525.3862484116321,
    -1195.0115012218691, -1851.3067454365212, -2579.5784383220939,
    -3385.4128160624864, -4318.2317662395653, -5328.7845702106961,
    -6495.6464811880269, -7773.0746439648938, -9212.1897223182641,
    -10813.728780211741, -12583.216579442877, -14574.356194856942,
    -16747.622418829891, -19190.94407499304, -21852.472565363842,
    -24790.315286678266, -27999.342839446464, -31466.424972235898,
    -35251.916320946628, -39252.119052474394, -43563.800607157878,
    -48041.970732800342, -52705.64163060089, -57465.875505966862,
    -62188.503876916722, -66889.987201367869, -71271.4218783248,
    -75399.617925662984, -78899.171157309334, -81803.3672468583,
    -84693.602989269057, -85562.258945221387, -84986.548222154612,
    -85562.258945221387, -84693.60298926862, -81803.3672468583,
    -78899.171157310135, -75399.617925662984, -71271.421878324443,
    -66889.987201367869, -62188.503876916722, -57465.875505967138,
    -52705.64163060089, -48041.970732800066, -43563.800607157878,
    -39252.119052474394, -35251.916320946628, -31466.424972235898,
    -27999.342839446464, -24790.315286678266, -21852.472565363842,
    -19190.94407499304, -16747.622418829891, -14574.356194856942,
    -12583.216579442877, -10813.728780211741, -9212.1897223182641,
    -7773.0746439648028, -6495.6464811880269, -5328.784570210787,
    -4318.2317662395653, -3385.4128160625773, -2579.5784383220939,
    -1851.3067454364302, -1195.0115012218691, -525.3862484116321,
    -78.973799304731, 281.93130208082925, 781.55210133581863, 1155.228779862681,
    1469.2155431992419, 1746.134762248583, 2002.0547910081386,
    2216.9656619701509, 2416.3006950268914, 2585.1232141011656,
    2736.3079239759804, 2866.6779359960829, 2977.8588562559862,
    3076.9448096309106, 3160.038525808156, 3232.2312896186277,
    3291.2494439880875, 3341.3783977296557, 3382.7730320016567,
    3415.9784367872785, 3442.4011638951893, 3461.0408638218328,
    3474.5171682516198, 3482.3424069721082, 3486.3286518157079,
    3485.8493065437838, 3481.1756609473346, 3473.8255915277446,
    3463.2185333885868, 3450.29851319459, 3434.6914986250308, 3417.0962237582867,
    3397.6606393475745, 3376.464791051782, 3353.8198679816528,
    3329.8551559748344, 3317.7821717685192, 3362.7620223562158,
    3374.953235506106, 3399.1362638259457, 3421.9878776261762,
    3443.4011903050273, 3463.0060258723429, 3480.712328208298,
    3496.4085800141188, 3509.3846393693607, 3520.0167090822074,
    3527.3275927629552, 3531.8943621366966, 3532.2283752271655,
    3528.0504874776821, 3519.9038954298853, 3505.99963154236, 3486.9337351541585,
    3459.9650052110487, 3426.0609036607971, 3383.8418925326519,
    3332.7628700762912, 3272.6529806031949, 3199.1613261263383,
    3114.6094168492682, 3013.818735849597, 2900.7545885715417,
    2768.2174600270605, 2614.5556610564176, 2442.980807949059,
    2240.4249759086251, 2022.1730457838003, 1762.2091715671543,
    1480.9567747945025, 1161.0482308643429, 782.06258233458288,
    278.40525322289955, -91.042953465057423, -546.51359685794841,
    -1223.4596780543131, -1889.4990482442138, -2628.8051708111175,
    -3446.6156002223183, -4392.9640589222763, -5418.2048759685995,
    -6601.8348226660182, -7897.5910901583957, -9357.1741074794681,
    -10981.31366792858, -12775.604958128122, -14794.440342842505,
    -16997.774962039952, -19474.57896541935, -22172.306454247591,
    -25149.735325106372, -28401.6409662119, -31914.6528642708,
    -35749.775312067562, -39801.931328229839, -44169.01706424915,
    -48704.177112885423, -53426.594189925527, -58246.188957710219,
    -63027.120598123511, -67786.04201536125, -72220.527616072955,
    -76398.325121159112, -79939.594904426, -82878.125918185789,
    -85802.5197119561, -86681.30977730728, -86098.615062858924,
    -86681.30977730728, -85802.519711955654, -82878.125918185789,
    -79939.594904426864, -76398.325121159112, -72220.527616072533,
    -67786.04201536125, -63027.120598123511, -58246.188957710539,
    -53426.594189925527, -48704.1771128851, -44169.01706424915,
    -39801.931328229839, -35749.775312067562, -31914.6528642708,
    -28401.6409662119, -25149.735325106372, -22172.306454247591,
    -19474.57896541935, -16997.774962039952, -14794.440342842414,
    -12775.604958128122, -10981.313667928671, -9357.1741074794681,
    -7897.5910901583957, -6601.8348226659273, -5418.2048759685995,
    -4392.9640589223673, -3446.6156002223183, -2628.8051708111175,
    -1889.4990482442138, -1223.4596780543131, -546.51359685794841,
    -91.042953465057423, 278.40525322289955, 782.06258233458288,
    1161.0482308643429, 1480.9567747945025, 1762.2091715671543,
    2022.1730457838003, 2240.4249759086251, 2442.980807949059,
    2614.5556610564176, 2768.2174600270605, 2900.7545885715417,
    3013.818735849597, 3114.6094168492682, 3199.1613261263383,
    3272.6529806031949, 3332.7628700762912, 3383.8418925326519,
    3426.0609036607971, 3459.9650052111397, 3486.9337351541585,
    3505.9996315422691, 3519.9038954297944, 3528.0504874776821,
    3532.2283752272565, 3531.8943621366966, 3527.3275927629552,
    3520.0167090822074, 3509.3846393692697, 3496.4085800140278, 3480.71232820848,
    3463.0060258724338, 3443.4011903049363, 3421.9878776261762,
    3399.1362638259457, 3374.953235506106, 3362.7620223562158,
    3407.7418729608294, 3420.0513146954077, 3444.4526593447304,
    3467.5109642778775, 3489.1417420799339, 3508.9158276087769,
    3526.7331574518689, 3542.51864728794, 3555.5507447800633, 3566.207827664763,
    3573.4795237131007, 3577.9394172671314, 3578.1281004225971,
    3573.7585690208075, 3565.2906204784781, 3550.9583970948338,
    3531.4663110572806, 3503.9515716898645, 3469.3487760345274,
    3426.3053889038897, 3374.2762957183882, 3313.0746763509678,
    3238.2841182077727, 3152.2740338772537, 3049.7786104741836,
    2934.8312548258918, 2800.1270121574612, 2643.988108299252,
    2469.6609876314119, 2263.8842118558368, 2042.2916993999006,
    1778.2838960732063, 1492.6998878135223, 1166.8645809768338,
    782.57065750176412, 274.84858855505058, -103.09254900876104,
    -567.59074125384313, -1251.9252464820045, -1927.7081726064334,
    -2678.0335592456117, -3507.81838841485, -4467.6967200730323,
    -5507.6250203953305, -6708.0232921061843, -8022.10754140596,
    -9502.1585128022616, -11148.898596134577, -12967.993294965334,
    -15014.524541157412, -17247.927447794777, -19758.213892980057,
    -22492.140334970991, -25509.155372006149, -28803.939121722462,
    -32362.880715297313, -36247.634346666171, -40351.743536398193,
    -44774.233558311389, -49366.383483739126, -54147.5467509842,
    -59026.502438151183, -63865.737264143936, -68682.096859848971,
    -73169.633307609169, -77397.032331464041, -80980.018655856038,
    -83952.884575287, -86911.436406432331, -87800.360613855533,
    -87210.68203128624, -87800.360613855533, -86911.43640643188,
    -83952.884575287, -80980.018655856955, -77397.032331464041,
    -73169.6333076087, -68682.096859848971, -63865.737264143936,
    -59026.5024381515, -54147.5467509842, -49366.383483738813,
    -44774.233558311389, -40351.743536398193, -36247.634346666171,
    -32362.880715297313, -28803.939121722462, -25509.155372006149,
    -22492.140334970991, -19758.213892980057, -17247.927447794777,
    -15014.524541157412, -12967.993294965334, -11148.898596134577,
    -9502.1585128022616, -8022.1075414058687, -6708.0232921061843,
    -5507.6250203953305, -4467.6967200731233, -3507.8183884149407,
    -2678.0335592455208, -1927.7081726064334, -1251.9252464820045,
    -567.59074125384313, -103.09254900876104, 274.84858855505058,
    782.57065750176412, 1166.8645809768338, 1492.6998878135223,
    1778.2838960732063, 2042.2916993998097, 2263.8842118558368,
    2469.6609876315028, 2643.988108299252, 2800.1270121574612,
    2934.8312548258918, 3049.7786104741836, 3152.2740338772537,
    3238.2841182077727, 3313.0746763509678, 3374.2762957183882,
    3426.3053889038897, 3469.3487760345274, 3503.9515716899555,
    3531.4663110572806, 3550.9583970947428, 3565.2906204784781,
    3573.7585690208984, 3578.1281004225971, 3577.9394172670404,
    3573.4795237131007, 3566.207827664763, 3555.5507447800633, 3542.518647287849,
    3526.7331574518689, 3508.9158276088679, 3489.1417420799339,
    3467.5109642778775, 3444.4526593447304, 3420.0513146954077,
    3407.7418729608294 };

  real_T rtb_Abs;
  real_T rtb_Switch;
  real_T assign_temp_C_aug[54];
  real_T assign_temp_B_aug[324];
  real_T assign_temp_D_aug[324];
  real_T expl_temp[24];
  boolean_T expl_temp_0;
  real_T RefU_0[12];
  real_T F_off_f_data[2];
  real_T tmp[70];
  real_T tmp_0[50];
  int32_T i_0;
  real_T PSI[72];
  real_T PHI[72];
  int32_T i_1;
  real_T u0;
  if (rtmIsMajorTimeStep(pmpc_hil1_M)) {
    /* set solver stop time */
    if (!(pmpc_hil1_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&pmpc_hil1_M->solverInfo,
                            ((pmpc_hil1_M->Timing.clockTickH0 + 1) *
        pmpc_hil1_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&pmpc_hil1_M->solverInfo,
                            ((pmpc_hil1_M->Timing.clockTick0 + 1) *
        pmpc_hil1_M->Timing.stepSize0 + pmpc_hil1_M->Timing.clockTickH0 *
        pmpc_hil1_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(pmpc_hil1_M)) {
    pmpc_hil1_M->Timing.t[0] = rtsiGetT(&pmpc_hil1_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(pmpc_hil1_M) &&
      pmpc_hil1_M->Timing.TaskCounters.TID[2] == 0) {
    /* MATLAB Function: '<Root>/PMPC_MF' */
    VehiclePara = pmpc_hil1_DW.St.VehiclePara;
    pmpc_hil1_B.InitialParams = pmpc_hil1_DW.St.InitialParams;
    memcpy(&WarmStart[0], &pmpc_hil1_DW.St.WarmStart[0], 26U * sizeof(real_T));
    memcpy(&rho[0], &pmpc_hil1_DW.St.rho[0], 9U * sizeof(real_T));
    memset(&pmpc_hil1_B.sys[0], 0, 54U * sizeof(real_T));
    if (pmpc_hil1_DW.St.InitialParams.InitialGapflag == 0.0) {
      pmpc_hil1_B.InitialParams.InitialGapflag = 1.0;
      memcpy(&WarmStart[0], &pmpc_hil1_DW.St.WarmStart[0], 26U * sizeof(real_T));
      memcpy(&rho[0], &pmpc_hil1_DW.St.rho[0], 9U * sizeof(real_T));
      VehiclePara = pmpc_hil1_DW.St.VehiclePara;
      St_Constraints = pmpc_hil1_DW.St.Constraints;
    } else {
      pmpc_hil1_B.InitialParams.InitialGapflag =
        pmpc_hil1_DW.St.InitialParams.InitialGapflag + 1.0;

      /* SignalConversion: '<S2>/TmpSignal ConversionAt SFunction Inport1' */
      tmp_0[0] = pmpc_hil1_B.NIVeriStandIn1;
      tmp_0[1] = pmpc_hil1_B.NIVeriStandIn2;
      tmp_0[2] = pmpc_hil1_B.NIVeriStandIn3;
      tmp_0[3] = pmpc_hil1_B.NIVeriStandIn4;
      tmp_0[4] = pmpc_hil1_B.NIVeriStandIn5;
      tmp_0[5] = pmpc_hil1_B.NIVeriStandIn6;
      tmp_0[6] = pmpc_hil1_B.NIVeriStandIn7;
      tmp_0[7] = pmpc_hil1_B.NIVeriStandIn8;
      tmp_0[8] = pmpc_hil1_B.NIVeriStandIn9;
      tmp_0[9] = pmpc_hil1_B.NIVeriStandIn10;
      tmp_0[10] = pmpc_hil1_B.NIVeriStandIn11;
      tmp_0[11] = pmpc_hil1_B.NIVeriStandIn12;
      tmp_0[12] = pmpc_hil1_B.NIVeriStandIn13;
      tmp_0[13] = pmpc_hil1_B.NIVeriStandIn14;
      tmp_0[14] = pmpc_hil1_B.NIVeriStandIn15;
      tmp_0[15] = pmpc_hil1_B.NIVeriStandIn16;
      tmp_0[16] = pmpc_hil1_B.NIVeriStandIn17;
      tmp_0[17] = pmpc_hil1_B.NIVeriStandIn18;
      tmp_0[18] = pmpc_hil1_B.NIVeriStandIn19;
      tmp_0[19] = pmpc_hil1_B.NIVeriStandIn20;
      tmp_0[20] = pmpc_hil1_B.NIVeriStandIn21;
      tmp_0[21] = pmpc_hil1_B.NIVeriStandIn22;
      tmp_0[22] = pmpc_hil1_B.NIVeriStandIn23;
      tmp_0[23] = pmpc_hil1_B.NIVeriStandIn24;
      tmp_0[24] = pmpc_hil1_B.NIVeriStandIn25;
      tmp_0[25] = pmpc_hil1_B.NIVeriStandIn26;
      tmp_0[26] = pmpc_hil1_B.NIVeriStandIn27;
      tmp_0[27] = pmpc_hil1_B.NIVeriStandIn28;
      tmp_0[28] = pmpc_hil1_B.NIVeriStandIn29;
      tmp_0[29] = pmpc_hil1_B.NIVeriStandIn30;
      tmp_0[30] = pmpc_hil1_B.NIVeriStandIn31;
      tmp_0[31] = pmpc_hil1_B.NIVeriStandIn32;
      tmp_0[32] = pmpc_hil1_B.NIVeriStandIn33;
      tmp_0[33] = pmpc_hil1_B.NIVeriStandIn34;
      tmp_0[34] = pmpc_hil1_B.NIVeriStandIn35;
      tmp_0[35] = pmpc_hil1_B.NIVeriStandIn36;
      tmp_0[36] = pmpc_hil1_B.NIVeriStandIn37;
      tmp_0[37] = pmpc_hil1_B.NIVeriStandIn38;
      tmp_0[38] = pmpc_hil1_B.NIVeriStandIn39;
      tmp_0[39] = pmpc_hil1_B.NIVeriStandIn40;
      tmp_0[40] = pmpc_hil1_B.NIVeriStandIn41;
      tmp_0[41] = pmpc_hil1_B.NIVeriStandIn42;
      tmp_0[42] = pmpc_hil1_B.NIVeriStandIn43;
      tmp_0[43] = pmpc_hil1_B.NIVeriStandIn44;
      tmp_0[44] = pmpc_hil1_B.NIVeriStandIn45;
      tmp_0[45] = pmpc_hil1_B.NIVeriStandIn46;
      tmp_0[46] = pmpc_hil1_B.NIVeriStandIn47;
      tmp_0[47] = pmpc_hil1_B.NIVeriStandIn48;
      tmp_0[48] = pmpc_hil1_B.NIVeriStandIn49;
      tmp_0[49] = pmpc_hil1_B.NIVeriStandIn50;
      pmpc_hil1_func_StateEstimation(tmp_0, &VehStateMeasured, &ParaHAT);
      ab_r = std::abs(VehStateMeasured.x_dot);
      if (ab_r > 1.0) {
        F_off_f = ab_r;
      } else {
        F_off_f = 1.0;
        ab_r = 1.0;
      }

      ab_f = (1.246613 * VehStateMeasured.Yawrate + VehStateMeasured.y_dot) /
        F_off_f - VehStateMeasured.delta_f;
      ab_r = (VehStateMeasured.y_dot - 1.7033870000000002 *
              VehStateMeasured.Yawrate) / ab_r;
      for (i_0 = 0; i_0 < 70; i_0++) {
        tmp[i_0] = 200.0 * (real_T)i_0 + 200.0;
      }

      pmpc_hil1_func_TireTable(g, tmp, h, i, ab_f, ParaHAT.Fzf, &fb_f, &rtb_Abs);
      for (i_0 = 0; i_0 < 70; i_0++) {
        tmp[i_0] = 200.0 * (real_T)i_0 + 200.0;
      }

      pmpc_hil1_func_TireTable(g, tmp, h, i, ab_r, ParaHAT.Fzr, &fb_r, &cb_r);
      rtb_Abs = std::abs(rtb_Abs);
      if (rtb_Abs > 0.0) {
        rtb_Switch = rtb_Abs;
      } else {
        rtb_Switch = 0.0;
      }

      cb_r = std::abs(cb_r);
      if (cb_r > 0.0) {
        b_maxval = cb_r;
      } else {
        b_maxval = 0.0;
      }

      VehiclePara.CbarF = -rtb_Switch;
      VehiclePara.CbarR = -b_maxval;
      VehiclePara.CafTan = -rtb_Switch;
      VehiclePara.CarTan = -b_maxval;
      F_off_f = (fb_f - -rtb_Switch * ab_f) - -rtb_Switch * 0.0;
      F_off_r = fb_r - -b_maxval * ab_r;
      pmpc_func_RefTraj_LocalPlanning
        (pmpc_hil1_DW.St.InitialParams.WayPoints_IndexPre, &VehStateMeasured,
         &WPIndex, RefU, Bezier_SK, &fb_r, &ab_f, &PrjP_Velr, &PrjP_xr, &ab_r,
         &PrjP_psir);
      if (WPIndex > 0.0) {
        pmpc_hil1_B.InitialParams.WayPoints_IndexPre = WPIndex;
      }

      pmpc_hil1_func_Envelope(-rtb_Switch, -b_maxval, &VehStateMeasured,
        Envelope_Henv, Envelope_Genv, Envelope_Hsh, Envelope_Gsh, Envelope_Hr,
        Envelope_Or, Envelope_Gr, &WPIndex);
      func_CostWeightingRegulation_Qu(&ParaHAT, &VehStateMeasured, pmpc_hil1_B.Q,
        R, S, W, zeta, &Flim, &Md_next, &u0, &PrjP_Velr, &PrjP_xr, &PrjP_psir,
        &Mdmin, &Tb_u, Fdu, Fdl, &Cm);
      zeta[0] = VehStateMeasured.y_dot;
      zeta[1] = VehStateMeasured.Yawrate;
      zeta[2] = ParaHAT.Roll;
      zeta[3] = ParaHAT.Rollrate;
      zeta[4] = fb_r;
      zeta[5] = ab_f;
      zeta[6] = pmpc_hil1_DW.St.InitialParams.U[0];
      zeta[7] = pmpc_hil1_DW.St.InitialParams.U[1];
      zeta[8] = pmpc_hil1_DW.St.InitialParams.U[2];
      pmpc_hil1_func_DynamicalModel(-rtb_Switch, -b_maxval, &VehStateMeasured,
        assign_temp_C_aug, pmpc_hil1_B.assign_temp_A_aug, assign_temp_B_aug,
        assign_temp_D_aug, expl_temp, &expl_temp_0);
      F_off_f_data[0] = F_off_f;
      F_off_f_data[1] = F_off_r;
      pmpc_hil1_func_SystemFurture(assign_temp_C_aug,
        pmpc_hil1_B.assign_temp_A_aug, assign_temp_B_aug, assign_temp_D_aug,
        Bezier_SK, F_off_f_data, pmpc_hil1_B.PSI, pmpc_hil1_B.THETA, GAMMA,
        pmpc_hil1_B.PHI);
      pmpc_hil1_kron(&zeta[6], Ut);
      Flim = 0.40612499999999996 * ParaHAT.Fzf;
      Cm = std::abs(-rtb_Switch);
      if (!(Cm > 5000.0)) {
        Cm = 5000.0;
      }

      F_off_f = (F_off_f * std::cos(VehStateMeasured.delta_f) + F_off_r) /
        1860.0 * 0.023882198561098984;
      Envelope_Gr[0] -= F_off_f;
      Envelope_Gr[1] -= -F_off_f;
      for (i_0 = 0; i_0 < 12; i_0++) {
        Bezier_SK[i_0] = RefU[3 * i_0 + 1];
        RefU_0[i_0] = RefU[3 * i_0 + 2];
      }

      pmpc_hil1_func_BuildQPCost(pmpc_hil1_B.PSI, pmpc_hil1_B.THETA,
        pmpc_hil1_B.PHI, GAMMA, pmpc_hil1_B.Q, R, S, W, zeta, d, Ut, Bezier_SK,
        RefU_0, pmpc_hil1_B.H, f);
      F_off_f = Flim + fb_f;
      if (!(F_off_f > 0.0)) {
        F_off_f = 0.0;
      }

      F_off_r = VehStateMeasured.delta_f - F_off_f / Cm;
      if ((-0.24639942381096414 > F_off_r) || rtIsNaN(F_off_r)) {
        F_off_r = -0.24639942381096414;
      }

      F_off_f = Flim - fb_f;
      if (!(F_off_f > 0.0)) {
        F_off_f = 0.0;
      }

      fb_f = F_off_f / Cm + VehStateMeasured.delta_f;
      if ((0.24639942381096414 < fb_f) || rtIsNaN(fb_f)) {
        fb_f = 0.24639942381096414;
      }

      if (!(fb_f > 0.0)) {
        fb_f = 0.0;
      }

      if (!(F_off_r < 0.0)) {
        F_off_r = 0.0;
      }

      pmpc_hi_func_BuildQPConstraints(Envelope_Henv, Envelope_Genv, Envelope_Hsh,
        Envelope_Gsh, Envelope_Hr, Envelope_Or, Envelope_Gr, pmpc_hil1_B.PSI,
        pmpc_hil1_B.THETA, pmpc_hil1_B.PHI, GAMMA, d, Ut, zeta, PrjP_xr,
        PrjP_psir, Mdmin, c, Md_next, u0, fb_f, F_off_r, pmpc_hil1_B.A_cons,
        b_cons, lb, ub, umax, umin);
      pmpc_hil1_func_SolveMPCQP(pmpc_hil1_B.H, f, pmpc_hil1_B.A_cons, b_cons, lb,
        ub, WarmStart, x_opt, &fb_f, umax, umin, epsilon_val);
      if (fb_f == 1.0) {
        pmpc_hil1_diag(umin, rho);
        pmpc_hil1_B.InitialParams.prevstate.b_gamma[0] = umin[0];
        pmpc_hil1_B.InitialParams.prevstate.b_gamma[1] = umin[1];
        pmpc_hil1_B.InitialParams.prevstate.b_gamma[2] = umin[2];
      }

      pmpc_hil1_B.InitialParams.U[0] = pmpc_hil1_DW.St.InitialParams.U[0] +
        umax[0];
      pmpc_hil1_B.InitialParams.U[1] = pmpc_hil1_DW.St.InitialParams.U[1] +
        umax[1];
      pmpc_hil1_B.InitialParams.U[2] = pmpc_hil1_DW.St.InitialParams.U[2] +
        umax[2];
      pmpc_hil1_B.sys[23] = pmpc_hil1_B.InitialParams.U[0];
      pmpc_hil1_B.sys[17] = pmpc_hil1_B.InitialParams.U[1];
      Md_next = pmpc_hil1_B.InitialParams.U[2];
      if (fb_f == 1.0) {
        for (i_0 = 0; i_0 < 72; i_0++) {
          PSI[i_0] = 0.0;
          for (i_1 = 0; i_1 < 9; i_1++) {
            PSI[i_0] += pmpc_hil1_B.PSI[72 * i_1 + i_0] * zeta[i_1];
          }

          PHI[i_0] = 0.0;
          for (i_1 = 0; i_1 < 18; i_1++) {
            PHI[i_0] += pmpc_hil1_B.THETA[72 * i_1 + i_0] * x_opt[i_1];
          }

          u0 = 0.0;
          for (i_1 = 0; i_1 < 36; i_1++) {
            u0 += pmpc_hil1_B.PHI[72 * i_1 + i_0] * GAMMA[i_1];
          }

          Y[i_0] = (PSI[i_0] + PHI[i_0]) + u0;
        }

        umax[0] = x_opt[23];
        umax[1] = x_opt[24];
        umax[2] = x_opt[25];
        pmpc_hil1_diag(umax, rho);
      } else {
        for (i_0 = 0; i_0 < 72; i_0++) {
          PSI[i_0] = 0.0;
          for (i_1 = 0; i_1 < 9; i_1++) {
            PSI[i_0] += pmpc_hil1_B.PSI[72 * i_1 + i_0] * zeta[i_1];
          }

          PHI[i_0] = 0.0;
          for (i_1 = 0; i_1 < 36; i_1++) {
            PHI[i_0] += pmpc_hil1_B.PHI[72 * i_1 + i_0] * GAMMA[i_1];
          }

          Y[i_0] = PSI[i_0] + PHI[i_0];
        }
      }

      u0 = 17.0 * pmpc_hil1_B.InitialParams.U[0];
      if (!(u0 < 12.566370614359172)) {
        u0 = 12.566370614359172;
      }

      pmpc_hil1_func_QPA_DB(pmpc_hil1_DW.St.InitialParams.prevstate.Tb, &ParaHAT,
                            pmpc_hil1_B.InitialParams.U[1],
                            pmpc_hil1_B.InitialParams.U[0], Tb_u, 0.0, &Flim,
                            &Cm, &F_off_f, &F_off_r);
      pmpc_hil1_B.InitialParams.prevstate.Tb[0] = Flim;
      pmpc_hil1_B.InitialParams.prevstate.Tb[1] = F_off_f;
      pmpc_hil1_B.InitialParams.prevstate.Tb[2] = Cm;
      pmpc_hil1_B.InitialParams.prevstate.Tb[3] = F_off_r;
      pmpc_hil1_func_QPA_CDC(pmpc_hil1_DW.St.InitialParams.prevstate.Fd,
        pmpc_hil1_B.InitialParams.U[2], Fdu, Fdl, &Fd_L1, &Fd_L2, &Fd_R1, &Fd_R2,
        &Md_real, &exitflag_Fd);
      pmpc_hil1_B.InitialParams.prevstate.Fd[0] = Fd_L1;
      pmpc_hil1_B.InitialParams.prevstate.Fd[1] = Fd_R1;
      pmpc_hil1_B.InitialParams.prevstate.Fd[2] = Fd_L2;
      pmpc_hil1_B.InitialParams.prevstate.Fd[3] = Fd_R2;
      pmpc_hil1_func_ReportStatus(&pmpc_hil1_B.InitialParams, fb_f, fb_r, ab_f,
        VehStateMeasured.x_dot);
      pmpc_hil1_func_LTRDiagnosis(-rtb_Switch, -b_maxval, &VehStateMeasured,
        &ParaHAT, Y, x_opt, fb_f, d, Ut, Md_next, &pmpc_hil1_B.sys[28], &ab_f,
        &pmpc_hil1_B.sys[29]);
      pmpc_hil1_B.sys[0] = Flim;
      pmpc_hil1_B.sys[1] = Cm;
      pmpc_hil1_B.sys[2] = F_off_f;
      pmpc_hil1_B.sys[3] = F_off_r;
      pmpc_hil1_B.sys[4] = Fd_L1;
      pmpc_hil1_B.sys[5] = Fd_L2;
      pmpc_hil1_B.sys[6] = Fd_R1;
      pmpc_hil1_B.sys[7] = Fd_R2;
      if (!(u0 > -12.566370614359172)) {
        u0 = -12.566370614359172;
      }

      pmpc_hil1_B.sys[8] = 57.295779513082323 * u0;
      pmpc_hil1_B.sys[9] = epsilon_val[0];
      pmpc_hil1_B.sys[10] = epsilon_val[2];
      pmpc_hil1_B.sys[11] = epsilon_val[4];
      pmpc_hil1_B.sys[12] = epsilon_val[6];
      pmpc_hil1_B.sys[13] = umin[0];
      pmpc_hil1_B.sys[14] = umin[1];
      pmpc_hil1_B.sys[15] = umin[2];
      pmpc_hil1_B.sys[16] = PrjP_xr;
      pmpc_hil1_B.sys[18] = -PrjP_xr;
      pmpc_hil1_B.sys[19] = PrjP_psir;
      pmpc_hil1_B.sys[20] = Md_next;
      pmpc_hil1_B.sys[21] = Mdmin;
      pmpc_hil1_B.sys[22] = PrjP_Velr;
      pmpc_hil1_B.sys[24] = -PrjP_Velr;
      pmpc_hil1_B.sys[25] = WPIndex;
      pmpc_hil1_B.sys[26] = VehStateMeasured.Yawrate;
      pmpc_hil1_B.sys[27] = -WPIndex;
      pmpc_hil1_B.sys[30] = VehStateMeasured.x_dot * 3.6;
      pmpc_hil1_B.sys[31] = VehStateMeasured.VxTarget;
      pmpc_hil1_B.sys[32] = ab_r;
      pmpc_hil1_B.sys[33] = std::sqrt(VehStateMeasured.x_dot *
        VehStateMeasured.x_dot + VehStateMeasured.y_dot * VehStateMeasured.y_dot);
      pmpc_hil1_B.sys[34] = ParaHAT.LTR;
      pmpc_hil1_B.sys[35] = (57.295779513082323 * ParaHAT.alpha_l2 +
        57.295779513082323 * ParaHAT.alpha_r2) / 2.0;
      pmpc_hil1_B.sys[36] = 57.295779513082323 * VehStateMeasured.Yaw;
      pmpc_hil1_B.sys[37] = VehStateMeasured.beta;
      if (rtb_Abs > 0.0) {
        pmpc_hil1_B.sys[38] = -rtb_Abs;
      } else {
        pmpc_hil1_B.sys[38] = -0.0;
      }

      if (cb_r > 0.0) {
        pmpc_hil1_B.sys[39] = -cb_r;
      } else {
        pmpc_hil1_B.sys[39] = -0.0;
      }

      pmpc_hil1_B.sys[40] = ParaHAT.Roll;
      pmpc_hil1_B.sys[41] = ParaHAT.Rollrate;
      pmpc_hil1_B.sys[42] = ParaHAT.Fx_l1;
      pmpc_hil1_B.sys[43] = ParaHAT.Fx_l2;
      pmpc_hil1_B.sys[44] = ParaHAT.Fx_r1;
      pmpc_hil1_B.sys[45] = ParaHAT.Fx_r2;
      pmpc_hil1_B.sys[46] = ParaHAT.Fy_l1;
      pmpc_hil1_B.sys[47] = ParaHAT.Fy_l2;
      pmpc_hil1_B.sys[48] = ParaHAT.Fy_r1;
      pmpc_hil1_B.sys[49] = ParaHAT.Fy_r2;
      pmpc_hil1_B.sys[50] = ParaHAT.Fz_l1;
      pmpc_hil1_B.sys[51] = ParaHAT.Fz_l2;
      pmpc_hil1_B.sys[52] = ParaHAT.Fz_r1;
      pmpc_hil1_B.sys[53] = ParaHAT.Fz_r2;
      St_Constraints = pmpc_hil1_DW.St.Constraints;
    }

    pmpc_hil1_DW.St.InitialParams = pmpc_hil1_B.InitialParams;
    memcpy(&pmpc_hil1_DW.St.WarmStart[0], &WarmStart[0], 26U * sizeof(real_T));
    memcpy(&pmpc_hil1_DW.St.rho[0], &rho[0], 9U * sizeof(real_T));
    pmpc_hil1_DW.St.VehiclePara = VehiclePara;
    pmpc_hil1_DW.St.Constraints = St_Constraints;

    /* End of MATLAB Function: '<Root>/PMPC_MF' */
    /* Chart: '<S1>/Chart' */
    if (pmpc_hil1_B.sys[30] < pmpc_hil1_B.sys[31]) {
      pmpc_hil1_B.Fig = -1.0;
    } else {
      if (pmpc_hil1_B.sys[30] >= pmpc_hil1_B.sys[31]) {
        if (pmpc_hil1_B.sys[30] > pmpc_hil1_B.sys[31]) {
          pmpc_hil1_B.Fig = 1.0;
        } else {
          if (pmpc_hil1_B.sys[30] == pmpc_hil1_B.sys[31]) {
            pmpc_hil1_B.Fig = 0.0;
          }
        }
      }
    }

    /* End of Chart: '<S1>/Chart' */

    /* Abs: '<S1>/Abs' incorporates:
     *  Sum: '<S1>/Sum'
     */
    rtb_Abs = std::abs(pmpc_hil1_B.sys[30] - pmpc_hil1_B.sys[31]);

    /* Gain: '<S1>/Gain_P' */
    pmpc_hil1_B.Gain_P = pmpc_hil1_P.Gain_P_Gain * rtb_Abs;
  }

  /* Switch: '<S1>/Switch' incorporates:
   *  Constant: '<S1>/Constant1'
   *  Integrator: '<S1>/Int_I'
   *  Sum: '<S1>/Sum_PI'
   */
  if (pmpc_hil1_B.Fig > pmpc_hil1_P.Switch_Threshold) {
    rtb_Switch = pmpc_hil1_P.Constant1_Value;
  } else {
    rtb_Switch = pmpc_hil1_B.Gain_P + pmpc_hil1_X.Int_I_CSTATE;
  }

  /* End of Switch: '<S1>/Switch' */

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Switch > pmpc_hil1_P.Saturation_UpperSat) {
    pmpc_hil1_B.Saturation = pmpc_hil1_P.Saturation_UpperSat;
  } else if (rtb_Switch < pmpc_hil1_P.Saturation_LowerSat) {
    pmpc_hil1_B.Saturation = pmpc_hil1_P.Saturation_LowerSat;
  } else {
    pmpc_hil1_B.Saturation = rtb_Switch;
  }

  /* End of Saturate: '<S1>/Saturation' */
  if (rtmIsMajorTimeStep(pmpc_hil1_M) &&
      pmpc_hil1_M->Timing.TaskCounters.TID[1] == 0) {
  }

  if (rtmIsMajorTimeStep(pmpc_hil1_M) &&
      pmpc_hil1_M->Timing.TaskCounters.TID[2] == 0) {
    /* RelationalOperator: '<S6>/Compare' incorporates:
     *  Abs: '<S1>/Abs_MFx'
     *  Constant: '<S6>/Constant'
     */
    pmpc_hil1_B.Compare = (std::abs(pmpc_hil1_B.sys[20]) >
      pmpc_hil1_P.DB_on_const);

    /* Switch: '<S1>/Switch_I' incorporates:
     *  Constant: '<S1>/Zero_I'
     *  Gain: '<S1>/Gain_I'
     *  UnitDelay: '<S1>/DB_delay'
     */
    if (pmpc_hil1_DW.DB_delay_DSTATE != 0) {
      pmpc_hil1_B.Switch_I = pmpc_hil1_P.Zero_I_Value;
    } else {
      pmpc_hil1_B.Switch_I = pmpc_hil1_P.Gain_I_Gain * rtb_Abs;
    }

    /* End of Switch: '<S1>/Switch_I' */
  }
}

/* Model update function */
void pmpc_hil1_update(void)
{
  if (rtmIsMajorTimeStep(pmpc_hil1_M) &&
      pmpc_hil1_M->Timing.TaskCounters.TID[2] == 0) {
    /* Update for UnitDelay: '<S1>/DB_delay' */
    pmpc_hil1_DW.DB_delay_DSTATE = pmpc_hil1_B.Compare;
  }

  if (rtmIsMajorTimeStep(pmpc_hil1_M)) {
    rt_ertODEUpdateContinuousStates(&pmpc_hil1_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++pmpc_hil1_M->Timing.clockTick0)) {
    ++pmpc_hil1_M->Timing.clockTickH0;
  }

  pmpc_hil1_M->Timing.t[0] = rtsiGetSolverStopTime(&pmpc_hil1_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++pmpc_hil1_M->Timing.clockTick1)) {
      ++pmpc_hil1_M->Timing.clockTickH1;
    }

    pmpc_hil1_M->Timing.t[1] = pmpc_hil1_M->Timing.clockTick1 *
      pmpc_hil1_M->Timing.stepSize1 + pmpc_hil1_M->Timing.clockTickH1 *
      pmpc_hil1_M->Timing.stepSize1 * 4294967296.0;
  }

  if (rtmIsMajorTimeStep(pmpc_hil1_M) &&
      pmpc_hil1_M->Timing.TaskCounters.TID[2] == 0) {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick2" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick2"
     * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick2 and the high bits
     * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++pmpc_hil1_M->Timing.clockTick2)) {
      ++pmpc_hil1_M->Timing.clockTickH2;
    }

    pmpc_hil1_M->Timing.t[2] = pmpc_hil1_M->Timing.clockTick2 *
      pmpc_hil1_M->Timing.stepSize2 + pmpc_hil1_M->Timing.clockTickH2 *
      pmpc_hil1_M->Timing.stepSize2 * 4294967296.0;
  }

  rate_scheduler();
}

/* Derivatives for root system: '<Root>' */
void pmpc_hil1_derivatives(void)
{
  XDot_pmpc_hil1_T *_rtXdot;
  _rtXdot = ((XDot_pmpc_hil1_T *) pmpc_hil1_M->derivs);

  /* Derivatives for Integrator: '<S1>/Int_I' */
  _rtXdot->Int_I_CSTATE = pmpc_hil1_B.Switch_I;
}

/* Model initialize function */
void pmpc_hil1_initialize(void)
{
  {
    static const real_T b[21] = { -1.05, -0.85, -0.65, -0.5, -0.38, -0.28, -0.19,
      -0.12, -0.06, -0.025, 0.0, 0.025, 0.06, 0.12, 0.19, 0.28, 0.38, 0.5, 0.65,
      0.85, 1.05 };

    static const real_T c[105] = { -1006.1, -797.7, -561.1, -413.7, -304.6,
      -218.4, -164.1, -117.5, -68.8, -33.0, 0.0, 4.5, 53.1, 102.4, 137.8, 186.3,
      269.1, 364.1, 537.4, 761.5, 959.1, -1378.8, -1191.6, -981.2, -865.5,
      -750.9, -682.2, -662.7, -548.4, -412.2, -273.1, 0.0, 216.3, 411.0, 524.9,
      613.2, 685.3, 742.5, 822.4, 954.1, 1166.9, 1329.9, -2088.4, -1904.1,
      -1694.6, -1541.6, -1451.8, -1379.7, -1311.8, -1147.0, -886.2, -346.5, 0.0,
      244.8, 559.7, 1125.3, 1228.4, 1362.9, 1423.6, 1528.0, 1683.6, 1896.1,
      2056.2, -2765.9, -2567.1, -2340.8, -2186.7, -2070.7, -1960.9, -1856.4,
      -1631.5, -1276.2, -412.3, 0.0, 305.8, 696.0, 1208.6, 1810.2, 1960.3,
      2067.5, 2186.9, 2353.1, 2567.1, 2749.3, -3153.1, -2947.6, -2717.9, -2571.0,
      -2454.6, -2344.0, -2167.8, -1928.1, -1048.0, -1.0, 0.0, 1053.3, 1684.1,
      1946.1, 2142.9, 2370.7, 2448.2, 2578.0, 2729.3, 2949.5, 3141.3 };

    static const int8_T g[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

    int32_T i;

    /* InitializeConditions for Integrator: '<S1>/Int_I' */
    pmpc_hil1_X.Int_I_CSTATE = pmpc_hil1_P.Int_I_IC;

    /* InitializeConditions for UnitDelay: '<S1>/DB_delay' */
    pmpc_hil1_DW.DB_delay_DSTATE = pmpc_hil1_P.DB_delay_InitialCondition;

    /* SystemInitialize for MATLAB Function: '<Root>/PMPC_MF' */
    pmpc_hil1_DW.iA_ws_not_empty = false;
    pmpc_hil1_DW.iA_ws.size = 0;

    /* SystemInitialize for MATLAB Function: '<Root>/PMPC_MF' */
    pmpc_hil1_DW.St.InitialParams.InitialGapflag = 0.0;
    pmpc_hil1_DW.St.InitialParams.WayPoints_IndexPre = 1.0;
    pmpc_hil1_DW.St.InitialParams.failed_num.solve = 0.0;
    pmpc_hil1_DW.St.InitialParams.failed_num.conv = 0.0;
    pmpc_hil1_DW.St.InitialParams.failed_num.unsolved = 0.0;
    pmpc_hil1_DW.St.InitialParams.failed_num.NaN_or_Inf = 0.0;
    pmpc_hil1_DW.St.InitialParams.failed_num.b_else = 0.0;
    pmpc_hil1_DW.St.InitialParams.emax.y = 0.0;
    pmpc_hil1_DW.St.InitialParams.emax.psi = 0.0;
    pmpc_hil1_DW.St.InitialParams.U[0] = 0.0;
    pmpc_hil1_DW.St.InitialParams.U[1] = 0.0;
    pmpc_hil1_DW.St.InitialParams.U[2] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.sw = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Fyf = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.MFx = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Md = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.ey = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.epsi = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Tb[0] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Fd[0] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Vd[0] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Tb[1] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Fd[1] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Vd[1] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Tb[2] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Fd[2] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Vd[2] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Tb[3] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Fd[3] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Vd[3] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.b_gamma[0] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.b_gamma[1] = 0.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.b_gamma[2] = 1.0;
    pmpc_hil1_DW.St.InitialParams.prevstate.Vpid = (rtNaN);
    pmpc_hil1_DW.St.InitialParams.dr_prev = (rtNaN);
    pmpc_hil1_DW.St.InitialParams.dr_rate = 0.0;
    pmpc_hil1_DW.St.InitialParams.n_solve = 0.0;
    memset(&pmpc_hil1_DW.St.InitialParams.t_solve[0], 0, 20000U * sizeof(real_T));
    memset(&pmpc_hil1_DW.St.InitialParams.ey_hist[0], 0, 20000U * sizeof(real_T));
    memset(&pmpc_hil1_DW.St.InitialParams.epsi_hist[0], 0, 20000U * sizeof
           (real_T));
    pmpc_hil1_DW.St.InitialParams.BaselineMode = 0.0;
    pmpc_hil1_DW.St.InitialParams.BaselineCurrent = 2.0;
    pmpc_hil1_DW.St.InitialParams.FishhookMode = 0.0;
    memset(&pmpc_hil1_DW.St.WarmStart[0], 0, 26U * sizeof(real_T));
    for (i = 0; i < 9; i++) {
      pmpc_hil1_DW.St.rho[i] = g[i];
    }

    pmpc_hil1_DW.St.VehiclePara.m = 1860.0;
    pmpc_hil1_DW.St.VehiclePara.ms = 1590.0;
    pmpc_hil1_DW.St.VehiclePara.Iz = 3438.54;
    pmpc_hil1_DW.St.VehiclePara.Ix = 894.4;
    pmpc_hil1_DW.St.VehiclePara.h_TL = 0.671694;
    pmpc_hil1_DW.St.VehiclePara.h_SL = 0.72;
    pmpc_hil1_DW.St.VehiclePara.lf = 1.246613;
    pmpc_hil1_DW.St.VehiclePara.L = 2.95;
    pmpc_hil1_DW.St.VehiclePara.lr = 1.7033870000000002;
    pmpc_hil1_DW.St.VehiclePara.BodyLength = 5.0;
    pmpc_hil1_DW.St.VehiclePara.BodyWigdth = 2.0;
    pmpc_hil1_DW.St.VehiclePara.Bodydiagonal = 5.3851648071345037;
    pmpc_hil1_DW.St.VehiclePara.h_RC = 0.15;
    pmpc_hil1_DW.St.VehiclePara.h_S2R = 0.57;
    pmpc_hil1_DW.St.VehiclePara.tf = 1.575;
    pmpc_hil1_DW.St.VehiclePara.tr = 1.575;
    pmpc_hil1_DW.St.VehiclePara.lsf = 1.2;
    pmpc_hil1_DW.St.VehiclePara.lsr = 1.2;
    pmpc_hil1_DW.St.VehiclePara.ldf = 1.1;
    pmpc_hil1_DW.St.VehiclePara.ldr = 1.1;
    pmpc_hil1_DW.St.VehiclePara.If = 1.1;
    pmpc_hil1_DW.St.VehiclePara.Ir = 1.1;
    pmpc_hil1_DW.St.VehiclePara.rt = 0.393;
    pmpc_hil1_DW.St.VehiclePara.isw = 17.0;
    pmpc_hil1_DW.St.VehiclePara.kf = 146000.0;
    pmpc_hil1_DW.St.VehiclePara.kr = 46000.0;
    pmpc_hil1_DW.St.VehiclePara.cf = 0.0;
    pmpc_hil1_DW.St.VehiclePara.cr = 0.0;
    pmpc_hil1_DW.St.VehiclePara.Ct = 0.0;
    pmpc_hil1_DW.St.VehiclePara.kw = 470000.0;
    pmpc_hil1_DW.St.VehiclePara.Kaux_f = 22001.579333023612;
    pmpc_hil1_DW.St.VehiclePara.Kaux_r = 29220.847551671985;
    pmpc_hil1_DW.St.VehiclePara.Kt = 160681.49359924142;
    pmpc_hil1_DW.St.VehiclePara.g = 9.80665;
    pmpc_hil1_DW.St.VehiclePara.mu = 0.5;
    pmpc_hil1_DW.St.VehiclePara.kd = 10000.0;
    pmpc_hil1_DW.St.VehiclePara.k1 = 14000.0;
    pmpc_hil1_DW.St.VehiclePara.k2 = 1230.0;
    pmpc_hil1_DW.St.VehiclePara.b = 1916.0;
    pmpc_hil1_DW.St.VehiclePara.k3 = 830.0;
    pmpc_hil1_DW.St.VehiclePara.v0 = 0.15;
    pmpc_hil1_DW.St.VehiclePara.CbarF = 0.0;
    pmpc_hil1_DW.St.VehiclePara.CbarR = 0.0;
    pmpc_hil1_DW.St.VehiclePara.CafTan = 0.0;
    pmpc_hil1_DW.St.VehiclePara.CarTan = 0.0;
    pmpc_hil1_DW.St.VehiclePara.mu_eff = 0.4275;
    pmpc_hil1_DW.St.VehiclePara.CafHat = -115545.02;
    pmpc_hil1_DW.St.VehiclePara.CarHat = -106969.02;
    pmpc_hil1_DW.St.Constraints.Roadwidth = 3.5;
    pmpc_hil1_DW.St.Constraints.SW_rate_max_deg = 720.0;
    pmpc_hil1_DW.St.Constraints.dlt_rate_max = 0.73919827143289252;
    pmpc_hil1_DW.St.Constraints.SW_max = 4.1887902047863905;
    pmpc_hil1_DW.St.Constraints.AFS_max_deg = 5.73;
    pmpc_hil1_DW.St.Constraints.AFS_max = 0.10000736613927509;
    pmpc_hil1_DW.St.Constraints.tau_MR = 0.015;
    pmpc_hil1_DW.St.Constraints.I_nom = 2.0;
    pmpc_hil1_DW.St.Constraints.ZengRho_on = 0.0;
    pmpc_hil1_DW.St.Constraints.ZengLong_on = 1.0;
    pmpc_hil1_DW.St.Constraints.Zg_rfloor = 0.05;
    pmpc_hil1_DW.St.Constraints.Zg_Vmin = 8.3333333333333339;
    pmpc_hil1_DW.St.Constraints.Zg_tau = 2.5;
    pmpc_hil1_DW.St.Constraints.Zg_tpid = 0.3;
    pmpc_hil1_DW.St.Constraints.Zg_cmax = 3.0;
    pmpc_hil1_DW.St.Constraints.Zg_ayfull = 0.0;
    pmpc_hil1_DW.St.Constraints.Zg_kovs = 1.3;
    pmpc_hil1_DW.St.Constraints.Zg_Npv = 12.0;
    pmpc_hil1_DW.St.Constraints.Zg_apv = 0.0;
    pmpc_hil1_DW.St.Constraints.Zg_dVdb = 0.3;
    pmpc_hil1_DW.St.Constraints.QPA_lamd = 0.003;
    pmpc_hil1_DW.St.Constraints.Gov_lamx = 0.1;
    pmpc_hil1_DW.St.Constraints.gamma_reg = 0.0001;
    pmpc_hil1_DW.St.Constraints.Vel_ref = 25.0;
    pmpc_hil1_DW.St.Constraints.Vd_ref = 0.5;
    pmpc_hil1_DW.St.Constraints.Ctan_floor_frac = 0.0;
    pmpc_hil1_DW.St.Constraints.Tb_max = 3000.0;
    pmpc_hil1_DW.St.Constraints.dTb_rate_max = 20000.0;
    pmpc_hil1_DW.St.Constraints.Vymax = 2.0;
    pmpc_hil1_DW.St.Constraints.arlim = 0.087266462599716474;
    pmpc_hil1_DW.St.Constraints.phimax = 0.069813170079773182;
    pmpc_hil1_DW.St.Constraints.dphimax = 0.87266462599716477;
    pmpc_hil1_DW.St.Constraints.epsimax = 0.13962634015954636;
    pmpc_hil1_DW.St.Constraints.epsilon_r = 0.87266462599716477;
    pmpc_hil1_DW.St.Constraints.epsilon_alpha = 0.87266462599716477;
    pmpc_hil1_DW.St.Constraints.epsilon_LTR = 3.0;
    pmpc_hil1_DW.St.Constraints.epsilon_e = 8.0;
    pmpc_hil1_DW.St.Constraints.eps_ub_scale = 10.0;
    pmpc_hil1_DW.St.Constraints.es = 0.43;
    pmpc_hil1_DW.St.Constraints.emax = 0.5325;
    pmpc_hil1_DW.St.Constraints.LTR_lim = 0.8;
    pmpc_hil1_DW.St.Constraints.Zeng_bL = 0.0;
    pmpc_hil1_DW.St.Constraints.Zeng_bR = 0.0;
    pmpc_hil1_DW.St.Constraints.Zeng_rmax = 0.0;
    memcpy(&pmpc_hil1_DW.VG[0], &b[0], 21U * sizeof(real_T));
    for (i = 0; i < 5; i++) {
      pmpc_hil1_DW.IG[i] = i;
    }

    memcpy(&pmpc_hil1_DW.FT[0], &c[0], 105U * sizeof(real_T));
  }
}

/* Model terminate function */
void pmpc_hil1_terminate(void)
{
  /* (no terminate code required) */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

extern "C" void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

extern "C" void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

extern "C" void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

extern "C" void MdlOutputs(int_T tid)
{
  pmpc_hil1_output();
  UNUSED_PARAMETER(tid);
}

extern "C" void MdlUpdate(int_T tid)
{
  pmpc_hil1_update();
  UNUSED_PARAMETER(tid);
}

extern "C" void MdlInitializeSizes(void)
{
}

extern "C" void MdlInitializeSampleTimes(void)
{
}

extern "C" void MdlInitialize(void)
{
}

extern "C" void MdlStart(void)
{
  pmpc_hil1_initialize();
}

extern "C" void MdlTerminate(void)
{
  pmpc_hil1_terminate();
}

/* Registration function */
extern "C" RT_MODEL_pmpc_hil1_T *pmpc_hil1(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)pmpc_hil1_M, 0,
                sizeof(RT_MODEL_pmpc_hil1_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&pmpc_hil1_M->solverInfo,
                          &pmpc_hil1_M->Timing.simTimeStep);
    rtsiSetTPtr(&pmpc_hil1_M->solverInfo, &rtmGetTPtr(pmpc_hil1_M));
    rtsiSetStepSizePtr(&pmpc_hil1_M->solverInfo, &pmpc_hil1_M->Timing.stepSize0);
    rtsiSetdXPtr(&pmpc_hil1_M->solverInfo, &pmpc_hil1_M->derivs);
    rtsiSetContStatesPtr(&pmpc_hil1_M->solverInfo, (real_T **)
                         &pmpc_hil1_M->contStates);
    rtsiSetNumContStatesPtr(&pmpc_hil1_M->solverInfo,
      &pmpc_hil1_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&pmpc_hil1_M->solverInfo,
      &pmpc_hil1_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&pmpc_hil1_M->solverInfo,
      &pmpc_hil1_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&pmpc_hil1_M->solverInfo,
      &pmpc_hil1_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&pmpc_hil1_M->solverInfo, (&rtmGetErrorStatus
      (pmpc_hil1_M)));
    rtsiSetRTModelPtr(&pmpc_hil1_M->solverInfo, pmpc_hil1_M);
  }

  rtsiSetSimTimeStep(&pmpc_hil1_M->solverInfo, MAJOR_TIME_STEP);
  pmpc_hil1_M->intgData.f[0] = pmpc_hil1_M->odeF[0];
  pmpc_hil1_M->contStates = ((real_T *) &pmpc_hil1_X);
  rtsiSetSolverData(&pmpc_hil1_M->solverInfo, (void *)&pmpc_hil1_M->intgData);
  rtsiSetSolverName(&pmpc_hil1_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = pmpc_hil1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    pmpc_hil1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    pmpc_hil1_M->Timing.sampleTimes = (&pmpc_hil1_M->Timing.sampleTimesArray[0]);
    pmpc_hil1_M->Timing.offsetTimes = (&pmpc_hil1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    pmpc_hil1_M->Timing.sampleTimes[0] = (0.0);
    pmpc_hil1_M->Timing.sampleTimes[1] = (0.001);
    pmpc_hil1_M->Timing.sampleTimes[2] = (0.01);

    /* task offsets */
    pmpc_hil1_M->Timing.offsetTimes[0] = (0.0);
    pmpc_hil1_M->Timing.offsetTimes[1] = (0.0);
    pmpc_hil1_M->Timing.offsetTimes[2] = (0.0);
  }

  rtmSetTPtr(pmpc_hil1_M, &pmpc_hil1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = pmpc_hil1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    mdlSampleHits[2] = 1;
    pmpc_hil1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(pmpc_hil1_M, 10.0);
  pmpc_hil1_M->Timing.stepSize0 = 0.001;
  pmpc_hil1_M->Timing.stepSize1 = 0.001;
  pmpc_hil1_M->Timing.stepSize2 = 0.01;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    pmpc_hil1_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(pmpc_hil1_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(pmpc_hil1_M->rtwLogInfo, (NULL));
    rtliSetLogT(pmpc_hil1_M->rtwLogInfo, "tout");
    rtliSetLogX(pmpc_hil1_M->rtwLogInfo, "");
    rtliSetLogXFinal(pmpc_hil1_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(pmpc_hil1_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(pmpc_hil1_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(pmpc_hil1_M->rtwLogInfo, 0);
    rtliSetLogDecimation(pmpc_hil1_M->rtwLogInfo, 1);
    rtliSetLogY(pmpc_hil1_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(pmpc_hil1_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(pmpc_hil1_M->rtwLogInfo, (NULL));
  }

  pmpc_hil1_M->solverInfoPtr = (&pmpc_hil1_M->solverInfo);
  pmpc_hil1_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&pmpc_hil1_M->solverInfo, 0.001);
  rtsiSetSolverMode(&pmpc_hil1_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  pmpc_hil1_M->blockIO = ((void *) &pmpc_hil1_B);
  (void) memset(((void *) &pmpc_hil1_B), 0,
                sizeof(B_pmpc_hil1_T));

  /* parameters */
  pmpc_hil1_M->defaultParam = ((real_T *)&pmpc_hil1_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &pmpc_hil1_X;
    pmpc_hil1_M->contStates = (x);
    (void) memset((void *)&pmpc_hil1_X, 0,
                  sizeof(X_pmpc_hil1_T));
  }

  /* states (dwork) */
  pmpc_hil1_M->dwork = ((void *) &pmpc_hil1_DW);
  (void) memset((void *)&pmpc_hil1_DW, 0,
                sizeof(DW_pmpc_hil1_T));

  /* Initialize Sizes */
  pmpc_hil1_M->Sizes.numContStates = (1);/* Number of continuous states */
  pmpc_hil1_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  pmpc_hil1_M->Sizes.numY = (0);       /* Number of model outputs */
  pmpc_hil1_M->Sizes.numU = (0);       /* Number of model inputs */
  pmpc_hil1_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  pmpc_hil1_M->Sizes.numSampTimes = (3);/* Number of sample times */
  pmpc_hil1_M->Sizes.numBlocks = (85); /* Number of blocks */
  pmpc_hil1_M->Sizes.numBlockIO = (57);/* Number of block outputs */
  pmpc_hil1_M->Sizes.numBlockPrms = (377);/* Sum of parameter "widths" */
  return pmpc_hil1_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/

/*========================================================================*
 * VeriStand Model Framework code generation
 *
 * Model : pmpc_hil1
 * Model version : 1.1
 * VeriStand Model Framework version : 2020.4.0.0 (2020 R4)
 * Source generated on : Sat Sep 19 13:53:59 2026
 *========================================================================*/

/* This file contains automatically generated code for functions
 * to update the inports and outports of a Simulink/Realtime Workshop
 * model. Calls to these functions should be made before each step is taken
 * (inports, call SetExternalInputs) and after each step is taken
 * (outports, call SetExternalOutputs.)
 */
#ifdef NI_ROOTMODEL_pmpc_hil1
#include "ni_modelframework_ex.h"
#include <stddef.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

unsigned char ReadSideDirtyFlag = 0, WriteSideDirtyFlag = 0;

/*========================================================================*
 * Function: NIRT_GetValueByDataType
 *
 * Abstract:
 *		Converting to and from double and datatypes used in the model
 *
 * Output Parameters
 *      ptr : address to the source
 *      subindex : index value if vector
 *      type   : the source's data type
 *      Complex : true if a complex data type
 *
 * Returns:
 *     Return value: 0 if no error
 *========================================================================*/
extern "C" double NIRT_GetValueByDataType(void* ptr, int32_t subindex, int32_t
  type, int32_t Complex)
{
  switch (type)
  {
   case 0:
    return (double)(((real_T*)ptr)[subindex]);

   case 1:
    return (double)(((real32_T*)ptr)[subindex]);

   case 2:
    return (double)(((int8_T*)ptr)[subindex]);

   case 3:
    return (double)(((uint8_T*)ptr)[subindex]);

   case 4:
    return (double)(((int16_T*)ptr)[subindex]);

   case 5:
    return (double)(((uint16_T*)ptr)[subindex]);

   case 6:
    return (double)(((int32_T*)ptr)[subindex]);

   case 7:
    return (double)(((uint32_T*)ptr)[subindex]);

   case 8:
    return (double)(((boolean_T*)ptr)[subindex]);

   case 10:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 13:
    return NIRT_GetValueByDataType(ptr,subindex,7,Complex);

   case 15:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 16:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 17:
    return NIRT_GetValueByDataType(ptr,subindex,3,Complex);

   case 20:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 21:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 22:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 23:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 24:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 25:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 26:
    return NIRT_GetValueByDataType(ptr,subindex,3,Complex);

   case 27:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 28:
    return (( double *)ptr)[subindex];

   case 30:
    return (( double *)ptr)[subindex];

   case 32:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 33:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 34:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 36:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 37:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 38:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 39:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 40:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 41:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 43:
    return (( double *)ptr)[subindex];

   case 46:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 47:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 48:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 49:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 50:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 51:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 52:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 53:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 54:
    return (( double *)ptr)[subindex];

   case 56:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 58:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 59:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 60:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 61:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 62:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 63:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 64:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 65:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 66:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 67:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 68:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 69:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 70:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 71:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 72:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 73:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 74:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 75:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 76:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 77:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 78:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 79:
    return NIRT_GetValueByDataType(ptr,subindex,6,Complex);

   case 80:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 81:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 82:
    return NIRT_GetValueByDataType(ptr,subindex,4,Complex);

   case 83:
    return NIRT_GetValueByDataType(ptr,subindex,4,Complex);

   case 85:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 86:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 87:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 88:
    return NIRT_GetValueByDataType(ptr,subindex,4,Complex);

   case 89:
    return NIRT_GetValueByDataType(ptr,subindex,8,Complex);

   case 90:
    return (( double *)ptr)[subindex];

   case 91:
    return (( double *)ptr)[subindex];

   case 92:
    return (( double *)ptr)[subindex];

   case 93:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 94:
    return (( double *)ptr)[subindex];

   case 96:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 97:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 98:
    return (( double *)ptr)[subindex];

   case 99:
    return (( double *)ptr)[subindex];

   case 100:
    return (( double *)ptr)[subindex];

   case 101:
    return (( double *)ptr)[subindex];

   case 102:
    return (( double *)ptr)[subindex];

   case 103:
    return (( double *)ptr)[subindex];

   case 104:
    return (( double *)ptr)[subindex];

   case 105:
    return (( double *)ptr)[subindex];

   case 106:
    return (( double *)ptr)[subindex];

   case 107:
    return (( double *)ptr)[subindex];

   case 108:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 109:
    return NIRT_GetValueByDataType(ptr,subindex,0,Complex);

   case 110:
    return NIRT_GetValueByDataType(ptr,subindex,3,Complex);

   case 111:
    return NIRT_GetValueByDataType(ptr,subindex,3,Complex);
  }

  /* return ((double *)ptr)[subindex]; */
  return rtNaN;
}

/*========================================================================*
 * Function: NIRT_SetValueByDataType
 *
 * Abstract:
 *		Converting to and from double and datatypes used in the model
 *
 * Output Parameters
 *      ptr : address to the destination
 *      subindex : index value if vector
 *      value : value to set on the destination
 *      type   : the destination's data type
 *      Complex : true if a complex data type
 *
 * Returns:
 *     Return value: 0 if no error
 *========================================================================*/
extern "C" int32_t NIRT_SetValueByDataType(void* ptr, int32_t subindex, double
  value, int32_t type, int32_t Complex)
{
  /* Complex is only used for R14.3 and down */
  switch (type)
  {
   case 0:
    ((real_T *)ptr)[subindex] = (real_T)value;
    return NI_OK;

   case 1:
    ((real32_T *)ptr)[subindex] = (real32_T)value;
    return NI_OK;

   case 2:
    ((int8_T *)ptr)[subindex] = (int8_T)value;
    return NI_OK;

   case 3:
    ((uint8_T *)ptr)[subindex] = (uint8_T)value;
    return NI_OK;

   case 4:
    ((int16_T *)ptr)[subindex] = (int16_T)value;
    return NI_OK;

   case 5:
    ((uint16_T *)ptr)[subindex] = (uint16_T)value;
    return NI_OK;

   case 6:
    ((int32_T *)ptr)[subindex] = (int32_T)value;
    return NI_OK;

   case 7:
    ((uint32_T *)ptr)[subindex] = (uint32_T)value;
    return NI_OK;

   case 8:
    ((boolean_T *)ptr)[subindex] = (boolean_T)value;
    return NI_OK;

   case 10:
    /* Type is renamed. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 13:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 7, Complex);

   case 15:
    /* Type is enum. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 16:
    /* Type is enum. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 17:
    /* Type is renamed. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 3, Complex);

   case 20:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 21:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 22:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 23:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 24:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 25:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 26:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 3, Complex);

   case 27:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 32:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 33:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 34:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 36:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 37:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 38:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 39:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 40:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 41:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 46:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 47:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 48:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 49:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 50:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 51:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 52:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 53:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 56:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 58:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 59:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 60:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 61:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 62:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 63:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 64:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 65:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 66:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 67:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 68:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 69:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 70:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 71:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 72:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 73:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 74:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 75:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 76:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 77:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 78:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 79:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 6, Complex);

   case 80:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 81:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 82:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 4, Complex);

   case 83:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 4, Complex);

   case 85:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 86:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 87:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 88:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 4, Complex);

   case 89:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 8, Complex);

   case 93:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 96:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 97:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 108:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 109:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 0, Complex);

   case 110:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 3, Complex);

   case 111:
    /* Type is matrix. Call SetValueByDataType on its contained type */
    return NIRT_SetValueByDataType(ptr, subindex, value, 3, Complex);
  }

  /* No matching datatype conversion */
  return NI_ERROR;
}

extern "C"
{
  extern pmpc_hil1_rtModel *S;
  extern _SITexportglobals SITexportglobals;
}
/*========================================================================*
 * Function: SetExternalInputs
 *
 * Abstract:
 *		Set data to model ports on the specified task
 *
 * Input Parameters
 *      data : data to set
 *      TaskSampleHit : task id
 *
 * Returns:
 *     Return value: 0 if no error
 *========================================================================*/
  extern "C" void SetExternalInputs(double* data, int_T* TaskSampleHit)
{
  int index = 0, count = 0;

  /* pmpc_hil1/Subsystem1/NIVeriStand In1 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn1, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In2 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn2, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In3 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn3, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In4 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn4, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In5 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn5, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In6 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn6, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In7 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn7, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In8 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn8, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In9 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn9, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In10 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn10, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In11 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn11, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In12 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn12, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In13 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn13, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In14 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn14, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In15 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn15, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In16 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn16, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In17 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn17, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In18 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn18, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In19 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn19, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In20 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn20, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In21 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn21, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In22 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn22, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In23 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn23, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In24 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn24, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In25 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn25, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In26 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn26, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In27 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn27, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In28 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn28, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In29 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn29, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In30 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn30, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In31 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn31, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In32 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn32, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In33 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn33, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In34 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn34, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In35 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn35, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In36 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn36, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In37 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn37, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In38 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn38, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In39 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn39, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In40 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn40, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In41 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn41, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In42 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn42, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In43 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn43, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In44 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn44, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In45 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn45, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In46 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn46, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In47 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn47, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In48 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn48, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In49 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn49, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem1/NIVeriStand In50 */
  if (TaskSampleHit[2]) {
    NIRT_SetValueByDataType(&pmpc_hil1_B.NIVeriStandIn50, 0, data[index++], 0, 0);
  } else {
    index += 1;
  }

  UNUSED_PARAMETER(count);
}                                      /* of SetExternalInputs */

extern "C" int32_t NumInputPorts(void)
{
  return 50;
}

extern "C" int32_t NumOutputPorts(void)
{
  return 11;
}

double ni_extout[11];

/*========================================================================*
 * Function: SetExternalOutputs
 *
 * Abstract:
 *		Set data to model ports on the specified task
 *
 * Input Parameters
 *      data : data to set
 *      TaskSampleHit : task id
 *
 * Returns:
 *     Return value: 0 if no error
 *========================================================================*/
extern "C" void SetExternalOutputs(double* data, int_T* TaskSampleHit)
{
  int index = 0, count = 0;

  /* pmpc_hil1/Subsystem/NIVeriStand Out1: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 0, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out2: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 1, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out3: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 2, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out4: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 3, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out5: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 4, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out6: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 5, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out7: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 6, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out8: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 7, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out9: Virtual Signal # 0 */
  if (TaskSampleHit[2]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 8, 22, 0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out10: Virtual Signal # 0 */
  if (TaskSampleHit[0]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.Saturation, 0, 0,
      0);
  } else {
    index += 1;
  }

  /* pmpc_hil1/Subsystem/NIVeriStand Out11: Virtual Signal # 0 */
  if (TaskSampleHit[1]) {              /* sample and hold	*/
    ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_P.Constant2_Value, 0,
      0, 0);
  } else {
    index += 1;
  }

  if (data != NULL) {
    memcpy(&data[0], &ni_extout[0], sizeof(ni_extout));
  }

  UNUSED_PARAMETER(count);
}

/*========================================================================*
 * Function: NI_InitExternalOutputs
 *
 * Abstract:
 *		Initialize model ports
 *
 * Output Parameters
 *
 * Returns:
 *     Return value: 0 if no error
 *========================================================================*/
extern "C" int32_t NI_InitExternalOutputs()
{
  int index = 0, count = 0;

  /* pmpc_hil1/Subsystem/NIVeriStand Out1: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 0, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out2: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 1, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out3: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 2, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out4: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 3, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out5: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 4, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out6: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 5, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out7: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 6, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out8: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 7, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out9: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.sys, 8, 22, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out10: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_B.Saturation, 0, 0, 0);

  /* pmpc_hil1/Subsystem/NIVeriStand Out11: Virtual Signal # 0 */
  ni_extout[index++] = NIRT_GetValueByDataType(&pmpc_hil1_P.Constant2_Value, 0,
    0, 0);
  UNUSED_PARAMETER(count);
  return NI_OK;
}

/* Undefine parameter macros. The undef allows us to access the real declarations.
   In the Simulink(R) generated code, the parameters are redefined to be the read-side of rtParameter.*/
#define _NI_UNDEFINE_PARAMS_DBL_BUFFER_
#include "ni_pglobals.h"

/* All elements by default (including scalars) have 2 dimensions [1,1] */
static NI_Parameter NI_ParamList[] DataSection(".NIVS.paramlist") =
{
  { 0, "pmpc_hil1/PID velocity control/DB_on/Constant/Value", offsetof
    (P_pmpc_hil1_T, DB_on_const), 0, 1, 2, 0, 0 },

  { 1, "pmpc_hil1/PID velocity control/Gain_I/Gain", offsetof(P_pmpc_hil1_T,
    Gain_I_Gain), 0, 1, 2, 2, 0 },

  { 2, "pmpc_hil1/PID velocity control/Zero_I/Value", offsetof(P_pmpc_hil1_T,
    Zero_I_Value), 0, 1, 2, 4, 0 },

  { 3, "pmpc_hil1/PID velocity control/Constant1/Value", offsetof(P_pmpc_hil1_T,
    Constant1_Value), 0, 1, 2, 6, 0 },

  { 4, "pmpc_hil1/PID velocity control/Gain_P/Gain", offsetof(P_pmpc_hil1_T,
    Gain_P_Gain), 0, 1, 2, 8, 0 },

  { 5, "pmpc_hil1/PID velocity control/Int_I/InitialCondition", offsetof
    (P_pmpc_hil1_T, Int_I_IC), 0, 1, 2, 10, 0 },

  { 6, "pmpc_hil1/PID velocity control/Switch/Threshold", offsetof(P_pmpc_hil1_T,
    Switch_Threshold), 0, 1, 2, 12, 0 },

  { 7, "pmpc_hil1/PID velocity control/Saturation/UpperLimit", offsetof
    (P_pmpc_hil1_T, Saturation_UpperSat), 0, 1, 2, 14, 0 },

  { 8, "pmpc_hil1/PID velocity control/Saturation/LowerLimit", offsetof
    (P_pmpc_hil1_T, Saturation_LowerSat), 0, 1, 2, 16, 0 },

  { 9, "pmpc_hil1/PID velocity control/Constant2/Value", offsetof(P_pmpc_hil1_T,
    Constant2_Value), 0, 1, 2, 18, 0 },

  { 10, "pmpc_hil1/PID velocity control/DB_delay/InitialCondition", offsetof
    (P_pmpc_hil1_T, DB_delay_InitialCondition), 3, 1, 2, 20, 0 },
};

static int32_t NI_ParamListSize DataSection(".NIVS.paramlistsize") = 11;
static int32_t NI_ParamDimList[] DataSection(".NIVS.paramdimlist") =
{
  1, 1,                                /* Parameter at index 0 */
  1, 1,                                /* Parameter at index 1 */
  1, 1,                                /* Parameter at index 2 */
  1, 1,                                /* Parameter at index 3 */
  1, 1,                                /* Parameter at index 4 */
  1, 1,                                /* Parameter at index 5 */
  1, 1,                                /* Parameter at index 6 */
  1, 1,                                /* Parameter at index 7 */
  1, 1,                                /* Parameter at index 8 */
  1, 1,                                /* Parameter at index 9 */
  1, 1,                                /* Parameter at index 10 */
};

static NI_Signal NI_SigList[] DataSection(".NIVS.siglist") =
{
  { 0, "pmpc_hil1/Subsystem1/NIVeriStand In1", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn1) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 1, "pmpc_hil1/Subsystem1/NIVeriStand In2", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn2) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 2, "pmpc_hil1/Subsystem1/NIVeriStand In3", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn3) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 3, "pmpc_hil1/Subsystem1/NIVeriStand In4", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn4) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 4, "pmpc_hil1/Subsystem1/NIVeriStand In5", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn5) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 5, "pmpc_hil1/Subsystem1/NIVeriStand In6", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn6) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 6, "pmpc_hil1/Subsystem1/NIVeriStand In7", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn7) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 7, "pmpc_hil1/Subsystem1/NIVeriStand In8", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn8) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 8, "pmpc_hil1/Subsystem1/NIVeriStand In9", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn9) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 9, "pmpc_hil1/Subsystem1/NIVeriStand In10", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn10) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 10, "pmpc_hil1/Subsystem1/NIVeriStand In11", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn11) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 11, "pmpc_hil1/Subsystem1/NIVeriStand In12", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn12) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 12, "pmpc_hil1/Subsystem1/NIVeriStand In13", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn13) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 13, "pmpc_hil1/Subsystem1/NIVeriStand In14", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn14) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 14, "pmpc_hil1/Subsystem1/NIVeriStand In15", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn15) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 15, "pmpc_hil1/Subsystem1/NIVeriStand In16", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn16) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 16, "pmpc_hil1/Subsystem1/NIVeriStand In17", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn17) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 17, "pmpc_hil1/Subsystem1/NIVeriStand In18", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn18) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 18, "pmpc_hil1/Subsystem1/NIVeriStand In19", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn19) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 19, "pmpc_hil1/Subsystem1/NIVeriStand In20", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn20) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 20, "pmpc_hil1/Subsystem1/NIVeriStand In21", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn21) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 21, "pmpc_hil1/Subsystem1/NIVeriStand In22", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn22) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 22, "pmpc_hil1/Subsystem1/NIVeriStand In23", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn23) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 23, "pmpc_hil1/Subsystem1/NIVeriStand In24", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn24) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 24, "pmpc_hil1/Subsystem1/NIVeriStand In25", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn25) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 25, "pmpc_hil1/Subsystem1/NIVeriStand In26", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn26) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 26, "pmpc_hil1/Subsystem1/NIVeriStand In27", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn27) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 27, "pmpc_hil1/Subsystem1/NIVeriStand In28", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn28) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 28, "pmpc_hil1/Subsystem1/NIVeriStand In29", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn29) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 29, "pmpc_hil1/Subsystem1/NIVeriStand In30", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn30) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 30, "pmpc_hil1/Subsystem1/NIVeriStand In31", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn31) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 31, "pmpc_hil1/Subsystem1/NIVeriStand In32", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn32) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 32, "pmpc_hil1/Subsystem1/NIVeriStand In33", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn33) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 33, "pmpc_hil1/Subsystem1/NIVeriStand In34", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn34) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 34, "pmpc_hil1/Subsystem1/NIVeriStand In35", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn35) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 35, "pmpc_hil1/Subsystem1/NIVeriStand In36", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn36) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 36, "pmpc_hil1/Subsystem1/NIVeriStand In37", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn37) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 37, "pmpc_hil1/Subsystem1/NIVeriStand In38", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn38) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 38, "pmpc_hil1/Subsystem1/NIVeriStand In39", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn39) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 39, "pmpc_hil1/Subsystem1/NIVeriStand In40", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn40) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 40, "pmpc_hil1/Subsystem1/NIVeriStand In41", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn41) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 41, "pmpc_hil1/Subsystem1/NIVeriStand In42", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn42) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 42, "pmpc_hil1/Subsystem1/NIVeriStand In43", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn43) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 43, "pmpc_hil1/Subsystem1/NIVeriStand In44", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn44) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 44, "pmpc_hil1/Subsystem1/NIVeriStand In45", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn45) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 45, "pmpc_hil1/Subsystem1/NIVeriStand In46", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn46) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 46, "pmpc_hil1/Subsystem1/NIVeriStand In47", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn47) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 47, "pmpc_hil1/Subsystem1/NIVeriStand In48", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn48) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 48, "pmpc_hil1/Subsystem1/NIVeriStand In49", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn49) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 49, "pmpc_hil1/Subsystem1/NIVeriStand In50", 0, "", offsetof(B_pmpc_hil1_T,
    NIVeriStandIn50) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 50, "pmpc_hil1/PID velocity control/Gain_P", 0, "", offsetof(B_pmpc_hil1_T,
    Gain_P) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 51, "pmpc_hil1/PID velocity control/Saturation", 0, "", offsetof
    (B_pmpc_hil1_T, Saturation) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0
  },

  { 52, "pmpc_hil1/PID velocity control/Switch_I", 0, "", offsetof(B_pmpc_hil1_T,
    Switch_I) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 53, "pmpc_hil1/PMPC_MF", 0, "(1, 1)", offsetof(B_pmpc_hil1_T, sys) + (0*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 54, "pmpc_hil1/PMPC_MF", 0, "(1, 2)", offsetof(B_pmpc_hil1_T, sys) + (1*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 55, "pmpc_hil1/PMPC_MF", 0, "(1, 3)", offsetof(B_pmpc_hil1_T, sys) + (2*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 56, "pmpc_hil1/PMPC_MF", 0, "(1, 4)", offsetof(B_pmpc_hil1_T, sys) + (3*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 57, "pmpc_hil1/PMPC_MF", 0, "(1, 5)", offsetof(B_pmpc_hil1_T, sys) + (4*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 58, "pmpc_hil1/PMPC_MF", 0, "(1, 6)", offsetof(B_pmpc_hil1_T, sys) + (5*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 59, "pmpc_hil1/PMPC_MF", 0, "(1, 7)", offsetof(B_pmpc_hil1_T, sys) + (6*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 60, "pmpc_hil1/PMPC_MF", 0, "(1, 8)", offsetof(B_pmpc_hil1_T, sys) + (7*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 61, "pmpc_hil1/PMPC_MF", 0, "(1, 9)", offsetof(B_pmpc_hil1_T, sys) + (8*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 62, "pmpc_hil1/PMPC_MF", 0, "(1, 10)", offsetof(B_pmpc_hil1_T, sys) + (9*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 63, "pmpc_hil1/PMPC_MF", 0, "(1, 11)", offsetof(B_pmpc_hil1_T, sys) + (10*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 64, "pmpc_hil1/PMPC_MF", 0, "(1, 12)", offsetof(B_pmpc_hil1_T, sys) + (11*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 65, "pmpc_hil1/PMPC_MF", 0, "(1, 13)", offsetof(B_pmpc_hil1_T, sys) + (12*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 66, "pmpc_hil1/PMPC_MF", 0, "(1, 14)", offsetof(B_pmpc_hil1_T, sys) + (13*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 67, "pmpc_hil1/PMPC_MF", 0, "(1, 15)", offsetof(B_pmpc_hil1_T, sys) + (14*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 68, "pmpc_hil1/PMPC_MF", 0, "(1, 16)", offsetof(B_pmpc_hil1_T, sys) + (15*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 69, "pmpc_hil1/PMPC_MF", 0, "(1, 17)", offsetof(B_pmpc_hil1_T, sys) + (16*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 70, "pmpc_hil1/PMPC_MF", 0, "(1, 18)", offsetof(B_pmpc_hil1_T, sys) + (17*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 71, "pmpc_hil1/PMPC_MF", 0, "(1, 19)", offsetof(B_pmpc_hil1_T, sys) + (18*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 72, "pmpc_hil1/PMPC_MF", 0, "(1, 20)", offsetof(B_pmpc_hil1_T, sys) + (19*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 73, "pmpc_hil1/PMPC_MF", 0, "(1, 21)", offsetof(B_pmpc_hil1_T, sys) + (20*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 74, "pmpc_hil1/PMPC_MF", 0, "(1, 22)", offsetof(B_pmpc_hil1_T, sys) + (21*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 75, "pmpc_hil1/PMPC_MF", 0, "(1, 23)", offsetof(B_pmpc_hil1_T, sys) + (22*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 76, "pmpc_hil1/PMPC_MF", 0, "(1, 24)", offsetof(B_pmpc_hil1_T, sys) + (23*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 77, "pmpc_hil1/PMPC_MF", 0, "(1, 25)", offsetof(B_pmpc_hil1_T, sys) + (24*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 78, "pmpc_hil1/PMPC_MF", 0, "(1, 26)", offsetof(B_pmpc_hil1_T, sys) + (25*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 79, "pmpc_hil1/PMPC_MF", 0, "(1, 27)", offsetof(B_pmpc_hil1_T, sys) + (26*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 80, "pmpc_hil1/PMPC_MF", 0, "(1, 28)", offsetof(B_pmpc_hil1_T, sys) + (27*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 81, "pmpc_hil1/PMPC_MF", 0, "(1, 29)", offsetof(B_pmpc_hil1_T, sys) + (28*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 82, "pmpc_hil1/PMPC_MF", 0, "(1, 30)", offsetof(B_pmpc_hil1_T, sys) + (29*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 83, "pmpc_hil1/PMPC_MF", 0, "(1, 31)", offsetof(B_pmpc_hil1_T, sys) + (30*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 84, "pmpc_hil1/PMPC_MF", 0, "(1, 32)", offsetof(B_pmpc_hil1_T, sys) + (31*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 85, "pmpc_hil1/PMPC_MF", 0, "(1, 33)", offsetof(B_pmpc_hil1_T, sys) + (32*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 86, "pmpc_hil1/PMPC_MF", 0, "(1, 34)", offsetof(B_pmpc_hil1_T, sys) + (33*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 87, "pmpc_hil1/PMPC_MF", 0, "(1, 35)", offsetof(B_pmpc_hil1_T, sys) + (34*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 88, "pmpc_hil1/PMPC_MF", 0, "(1, 36)", offsetof(B_pmpc_hil1_T, sys) + (35*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 89, "pmpc_hil1/PMPC_MF", 0, "(1, 37)", offsetof(B_pmpc_hil1_T, sys) + (36*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 90, "pmpc_hil1/PMPC_MF", 0, "(1, 38)", offsetof(B_pmpc_hil1_T, sys) + (37*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 91, "pmpc_hil1/PMPC_MF", 0, "(1, 39)", offsetof(B_pmpc_hil1_T, sys) + (38*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 92, "pmpc_hil1/PMPC_MF", 0, "(1, 40)", offsetof(B_pmpc_hil1_T, sys) + (39*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 93, "pmpc_hil1/PMPC_MF", 0, "(1, 41)", offsetof(B_pmpc_hil1_T, sys) + (40*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 94, "pmpc_hil1/PMPC_MF", 0, "(1, 42)", offsetof(B_pmpc_hil1_T, sys) + (41*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 95, "pmpc_hil1/PMPC_MF", 0, "(1, 43)", offsetof(B_pmpc_hil1_T, sys) + (42*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 96, "pmpc_hil1/PMPC_MF", 0, "(1, 44)", offsetof(B_pmpc_hil1_T, sys) + (43*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 97, "pmpc_hil1/PMPC_MF", 0, "(1, 45)", offsetof(B_pmpc_hil1_T, sys) + (44*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 98, "pmpc_hil1/PMPC_MF", 0, "(1, 46)", offsetof(B_pmpc_hil1_T, sys) + (45*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 99, "pmpc_hil1/PMPC_MF", 0, "(1, 47)", offsetof(B_pmpc_hil1_T, sys) + (46*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 100, "pmpc_hil1/PMPC_MF", 0, "(1, 48)", offsetof(B_pmpc_hil1_T, sys) + (47*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 101, "pmpc_hil1/PMPC_MF", 0, "(1, 49)", offsetof(B_pmpc_hil1_T, sys) + (48*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 102, "pmpc_hil1/PMPC_MF", 0, "(1, 50)", offsetof(B_pmpc_hil1_T, sys) + (49*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 103, "pmpc_hil1/PMPC_MF", 0, "(1, 51)", offsetof(B_pmpc_hil1_T, sys) + (50*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 104, "pmpc_hil1/PMPC_MF", 0, "(1, 52)", offsetof(B_pmpc_hil1_T, sys) + (51*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 105, "pmpc_hil1/PMPC_MF", 0, "(1, 53)", offsetof(B_pmpc_hil1_T, sys) + (52*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 106, "pmpc_hil1/PMPC_MF", 0, "(1, 54)", offsetof(B_pmpc_hil1_T, sys) + (53*
    sizeof(real_T)), BLOCKIO_SIG, 22, 1, 2, 0, 0 },

  { 107, "pmpc_hil1/PID velocity control/Chart", 0, "", offsetof(B_pmpc_hil1_T,
    Fig) + (0*sizeof(real_T)), BLOCKIO_SIG, 0, 1, 2, 0, 0 },

  { 108, "pmpc_hil1/PID velocity control/DB_on/Compare", 0, "", offsetof
    (B_pmpc_hil1_T, Compare) + (0*sizeof(uint8_T)), BLOCKIO_SIG, 3, 1, 2, 0, 0 },

  { -1, "", -1, "", 0, 0, 0 }
};

static int32_t NI_SigListSize DataSection(".NIVS.siglistsize") = 109;
static int32_t NI_VirtualBlockSources[1];
static int32_t NI_SigDimList[] DataSection(".NIVS.sigdimlist") =
{ 1, 1
};

static int32_t NI_ExtListSize DataSection(".NIVS.extlistsize") = 61;
static NI_ExternalIO NI_ExtList[] DataSection(".NIVS.extlist") =
{
  { 1, "Subsystem1/NIVeriStand In1", 2, EXT_IN, 1, 1, 1 },

  { 2, "Subsystem1/NIVeriStand In2", 2, EXT_IN, 1, 1, 1 },

  { 3, "Subsystem1/NIVeriStand In3", 2, EXT_IN, 1, 1, 1 },

  { 4, "Subsystem1/NIVeriStand In4", 2, EXT_IN, 1, 1, 1 },

  { 5, "Subsystem1/NIVeriStand In5", 2, EXT_IN, 1, 1, 1 },

  { 6, "Subsystem1/NIVeriStand In6", 2, EXT_IN, 1, 1, 1 },

  { 7, "Subsystem1/NIVeriStand In7", 2, EXT_IN, 1, 1, 1 },

  { 8, "Subsystem1/NIVeriStand In8", 2, EXT_IN, 1, 1, 1 },

  { 9, "Subsystem1/NIVeriStand In9", 2, EXT_IN, 1, 1, 1 },

  { 10, "Subsystem1/NIVeriStand In10", 2, EXT_IN, 1, 1, 1 },

  { 11, "Subsystem1/NIVeriStand In11", 2, EXT_IN, 1, 1, 1 },

  { 12, "Subsystem1/NIVeriStand In12", 2, EXT_IN, 1, 1, 1 },

  { 13, "Subsystem1/NIVeriStand In13", 2, EXT_IN, 1, 1, 1 },

  { 14, "Subsystem1/NIVeriStand In14", 2, EXT_IN, 1, 1, 1 },

  { 15, "Subsystem1/NIVeriStand In15", 2, EXT_IN, 1, 1, 1 },

  { 16, "Subsystem1/NIVeriStand In16", 2, EXT_IN, 1, 1, 1 },

  { 17, "Subsystem1/NIVeriStand In17", 2, EXT_IN, 1, 1, 1 },

  { 18, "Subsystem1/NIVeriStand In18", 2, EXT_IN, 1, 1, 1 },

  { 19, "Subsystem1/NIVeriStand In19", 2, EXT_IN, 1, 1, 1 },

  { 20, "Subsystem1/NIVeriStand In20", 2, EXT_IN, 1, 1, 1 },

  { 21, "Subsystem1/NIVeriStand In21", 2, EXT_IN, 1, 1, 1 },

  { 22, "Subsystem1/NIVeriStand In22", 2, EXT_IN, 1, 1, 1 },

  { 23, "Subsystem1/NIVeriStand In23", 2, EXT_IN, 1, 1, 1 },

  { 24, "Subsystem1/NIVeriStand In24", 2, EXT_IN, 1, 1, 1 },

  { 25, "Subsystem1/NIVeriStand In25", 2, EXT_IN, 1, 1, 1 },

  { 26, "Subsystem1/NIVeriStand In26", 2, EXT_IN, 1, 1, 1 },

  { 27, "Subsystem1/NIVeriStand In27", 2, EXT_IN, 1, 1, 1 },

  { 28, "Subsystem1/NIVeriStand In28", 2, EXT_IN, 1, 1, 1 },

  { 29, "Subsystem1/NIVeriStand In29", 2, EXT_IN, 1, 1, 1 },

  { 30, "Subsystem1/NIVeriStand In30", 2, EXT_IN, 1, 1, 1 },

  { 31, "Subsystem1/NIVeriStand In31", 2, EXT_IN, 1, 1, 1 },

  { 32, "Subsystem1/NIVeriStand In32", 2, EXT_IN, 1, 1, 1 },

  { 33, "Subsystem1/NIVeriStand In33", 2, EXT_IN, 1, 1, 1 },

  { 34, "Subsystem1/NIVeriStand In34", 2, EXT_IN, 1, 1, 1 },

  { 35, "Subsystem1/NIVeriStand In35", 2, EXT_IN, 1, 1, 1 },

  { 36, "Subsystem1/NIVeriStand In36", 2, EXT_IN, 1, 1, 1 },

  { 37, "Subsystem1/NIVeriStand In37", 2, EXT_IN, 1, 1, 1 },

  { 38, "Subsystem1/NIVeriStand In38", 2, EXT_IN, 1, 1, 1 },

  { 39, "Subsystem1/NIVeriStand In39", 2, EXT_IN, 1, 1, 1 },

  { 40, "Subsystem1/NIVeriStand In40", 2, EXT_IN, 1, 1, 1 },

  { 41, "Subsystem1/NIVeriStand In41", 2, EXT_IN, 1, 1, 1 },

  { 42, "Subsystem1/NIVeriStand In42", 2, EXT_IN, 1, 1, 1 },

  { 43, "Subsystem1/NIVeriStand In43", 2, EXT_IN, 1, 1, 1 },

  { 44, "Subsystem1/NIVeriStand In44", 2, EXT_IN, 1, 1, 1 },

  { 45, "Subsystem1/NIVeriStand In45", 2, EXT_IN, 1, 1, 1 },

  { 46, "Subsystem1/NIVeriStand In46", 2, EXT_IN, 1, 1, 1 },

  { 47, "Subsystem1/NIVeriStand In47", 2, EXT_IN, 1, 1, 1 },

  { 48, "Subsystem1/NIVeriStand In48", 2, EXT_IN, 1, 1, 1 },

  { 49, "Subsystem1/NIVeriStand In49", 2, EXT_IN, 1, 1, 1 },

  { 50, "Subsystem1/NIVeriStand In50", 2, EXT_IN, 1, 1, 1 },

  { 1, "Subsystem/NIVeriStand Out1", 2, EXT_OUT, 1, 1, 1 },

  { 2, "Subsystem/NIVeriStand Out2", 2, EXT_OUT, 1, 1, 1 },

  { 3, "Subsystem/NIVeriStand Out3", 2, EXT_OUT, 1, 1, 1 },

  { 4, "Subsystem/NIVeriStand Out4", 2, EXT_OUT, 1, 1, 1 },

  { 5, "Subsystem/NIVeriStand Out5", 2, EXT_OUT, 1, 1, 1 },

  { 6, "Subsystem/NIVeriStand Out6", 2, EXT_OUT, 1, 1, 1 },

  { 7, "Subsystem/NIVeriStand Out7", 2, EXT_OUT, 1, 1, 1 },

  { 8, "Subsystem/NIVeriStand Out8", 2, EXT_OUT, 1, 1, 1 },

  { 9, "Subsystem/NIVeriStand Out9", 2, EXT_OUT, 1, 1, 1 },

  { 10, "Subsystem/NIVeriStand Out10", 0, EXT_OUT, 1, 1, 1 },

  { 11, "Subsystem/NIVeriStand Out11", 1, EXT_OUT, 1, 1, 1 },

  { -1, "", 0, 0, 0, 0, 0 }
};

/* This Task List is generated to allow access to the task specs without
 * initializing the model.
 * 0th entry is for scheduler (base rate)
 * rest for multirate model's tasks.
 */
extern "C" NI_Task NI_TaskList[] DataSection(".NIVS.tasklist") =
{
  { 0, 0.001, 0 }
};

extern "C" int32_t NI_NumTasks DataSection(".NIVS.numtasks") = 1;
static const char* NI_CompiledModelName DataSection(".NIVS.compiledmodelname") =
  "pmpc_hil1";
static const char* NI_CompiledModelVersion = "1.1";
static const char* NI_CompiledModelDateTime = "Sat Sep 19 13:53:59 2026";
static const char* NI_builder DataSection(".NIVS.builder") =
  "NI Model Framework 2020.4.0.0 (2020 R4) for Simulink Coder 8.14 (R2018a)";
static const char* NI_BuilderVersion DataSection(".NIVS.builderversion") =
  "2020.4.0.0";

/*========================================================================*
 * Function: NIRT_GetBuildInfo
 *
 * Abstract:
 *	Get the DLL versioning etc information.
 *
 * Output Parameters:
 *	detail	: String containing model build information.
 *	len		: the build info string length. If a value of "-1" is specified, the minimum buffer size of "detail" is returned as its value.
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetBuildInfo(char* detail, int32_t* len)
{
  int32_t msgLength = 0;
  char *msgBuffer = NULL;

  /* Message */
  const char msg[] =
    "%s\nModel Name: %s\nModel Version: %s\nVeriStand Model Framework Version: %s\nCompiled On: %s";

  /* There are no console properties to set for VxWorks, because the console is simply serial output data.
     Just do printf for VxWorks and ignore all console properties. */
#if ! defined (VXWORKS) && ! defined (kNIOSLinux)

  HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(hStdout, FOREGROUND_INTENSITY | FOREGROUND_BLUE |
    FOREGROUND_GREEN | FOREGROUND_RED);

#endif

  /* Print to screen */
  printf("\n*******************************************************************************\n");
  msgLength = printf(msg, NI_builder, NI_CompiledModelName,
                     NI_CompiledModelVersion, NI_BuilderVersion,
                     NI_CompiledModelDateTime);
  printf("\n*******************************************************************************\n");

#if ! defined (VXWORKS) && ! defined (kNIOSLinux)

  SetConsoleTextAttribute(hStdout, FOREGROUND_BLUE | FOREGROUND_GREEN |
    FOREGROUND_RED);

#endif

  if (*len == -1) {
    /* Return the required minimum buffer size */
    *len = msgLength;
  } else {
    /* allocate the buffer */
    msgBuffer = (char*)calloc(msgLength + 1, sizeof(char));
    sprintf (msgBuffer, msg, NI_builder, NI_CompiledModelName,
             NI_CompiledModelVersion, NI_BuilderVersion,
             NI_CompiledModelDateTime);
    if (*len >= msgLength) {
      *len = msgLength + 1;
    }

    /* Copy into external buffer */
    strncpy(detail, msgBuffer, *len);

    /* Release memory */
    free(msgBuffer);
  }

  return NI_OK;
}

/*========================================================================*
 * Function: NIRT_GetSignalSpec
 *
 * Abstract:
 *	If index == -1, lookup parameter by the ID.
 *	If ID_len == 0 or if ID == null, return number of parameters in model.
 *	Otherwise, lookup parameter by index, and return the information.
 *
 * Input/Output Parameters:
 *	index		: index of the signal (in/out)
 *	ID			: ID of signal to be looked up (in), ID of signal at index (out)
 *	ID_len		: length of input ID(in), length of ID (out)
 *	bnlen		: length of buffer blkname (in), length of output blkname (out)
 *	snlen		: length of buffer signame (in), length of output signame (out)
 *
 * Output Parameters:
 *	blkname		: Name of the source block for the signal
 *	portnum		: port number of the block that is the source of the signal (0 indexed)
 *	signame		: Name of the signal
 *	datatype	: same as with parameters. Currently assuming all data to be double.
 *	dims		: The port's dimension of length 'numdims'.
 *	numdims		: the port's number of dimensions. If a value of "-1" is specified, the minimum buffer size of "dims" is returned as its value.
 *
 * Returns:
 *	NI_OK if no error(if sigidx == -1, number of signals)
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetSignalSpec(int32_t* sidx, char* ID, int32_t* ID_len,
  char* blkname, int32_t *bnlen,
  int32_t *portnum, char* signame, int32_t *snlen, int32_t *dattype, int32_t*
  dims, int32_t* numdim)
{
  int32_t sigidx = *sidx;
  int32_t i = 0;
  char *addr = NULL;
  char *IDblk = 0;
  int32_t IDport = 0;
  if (sigidx < 0) {
    /* check if ID has been specified. */
    if ((ID != NULL) && (ID_len != NULL) && (*ID_len > 0)) {
      /* parse ID into blkname and port */
      addr = strrchr(ID, ':');
      if (addr == NULL) {
        return NI_SigListSize;
      }

      /* Calculate the char offset into the string after the port */
      i = addr - ID;

      /* malformed ID */
      if (i<=0) {
        return NI_SigListSize;
      }

      IDblk = ID;
      IDport = atoi(ID+i+1);

      /* lookup the table for matching ID */
      for (i=0; i<NI_SigListSize; i++) {
        /* 11 to accomodate ':','/', port number and null character */
        char *tempID = (char *)calloc(strlen(NI_SigList[i].blockname)+strlen
          (NI_SigList[i].signalname) + 11, sizeof(char));
        if (strlen(NI_SigList[i].signalname)>0) {
          sprintf(tempID,"%s:%d%s%s",NI_SigList[i].blockname,NI_SigList[i].
                  portno+1,"/",NI_SigList[i].signalname);
        } else {
          sprintf(tempID,"%s:%d",NI_SigList[i].blockname,NI_SigList[i].portno+1);
        }

        if (!strcmp(IDblk,tempID) && IDport==(NI_SigList[i].portno+1)) {
          break;
        }

        free(tempID);
      }

      if (i < NI_SigListSize) {
        sigidx = *sidx = i;
      } else {
        return NI_SigListSize;
      }
    } else {
      /* no index or ID specified. */
      return NI_SigListSize;
    }
  }

  if (sigidx>=0 && sigidx<NI_SigListSize) {
    if (ID != NULL) {
      /*  no need for return string to be null terminated! */
      /* 11 to accomodate ':','/', port number and null character */
      char *tempID = (char *)calloc(strlen(NI_SigList[sigidx].blockname)+strlen
        (NI_SigList[sigidx].signalname)+ 11, sizeof(char));
      if (strlen(NI_SigList[sigidx].signalname)>0) {
        sprintf(tempID,"%s:%d%s%s",NI_SigList[sigidx].blockname,
                NI_SigList[sigidx].portno+1,"/",NI_SigList[sigidx].signalname);
      } else {
        sprintf(tempID,"%s:%d",NI_SigList[sigidx].blockname,NI_SigList[sigidx].
                portno+1);
      }

      if ((int32_t)strlen(tempID)<*ID_len) {
        *ID_len = strlen(tempID);
      }

      strncpy(ID, tempID, *ID_len);
      free(tempID);
    }

    if (blkname != NULL) {
      /*  no need for return string to be null terminated! */
      if ((int32_t)strlen(NI_SigList[sigidx].blockname)<*bnlen) {
        *bnlen = strlen(NI_SigList[sigidx].blockname);
      }

      strncpy(blkname, NI_SigList[sigidx].blockname, *bnlen);
    }

    if (signame != NULL) {
      /* no need for return string to be null terminated! */
      if ((int32_t)strlen(NI_SigList[sigidx].signalname)<*snlen) {
        *snlen = strlen(NI_SigList[sigidx].signalname);
      }

      strncpy(signame, NI_SigList[sigidx].signalname, *snlen);
    }

    if (portnum != NULL) {
      *portnum = NI_SigList[sigidx].portno;
    }

    if (dattype != NULL) {
      *dattype = NI_SigList[sigidx].datatype;
    }

    if (numdim != NULL) {
      if (*numdim == -1) {
        *numdim = NI_SigList[sigidx].numofdims;
      } else if (dims != NULL) {
        for (i=0;i < *numdim; i++) {
          dims[i] = NI_SigDimList[NI_SigList[sigidx].dimListOffset +i];
        }
      }
    }

    return NI_OK;
  }

  return NI_SigListSize;
}

/*========================================================================*
 * Function: NIRT_GetParameterIndices
 *
 * Abstract:
 *	Returns an array of indices to tunable parameters
 *
 * Output Parameters:
 *	indices	: buffer to store the parameter indices of length "len"
 *	len		: returns the number of indices. If a value of "-1" is specified, the minimum buffer size of "indices" is returned as its value.
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetParameterIndices(int32_t* indices, int32_t* len)
{
  int32_t i;
  if ((len == NULL) || (indices == NULL)) {
    return NI_ERROR;
  }

  if (*len == -1) {
    *len = NI_ParamListSize;
  } else {
    for (i=0; (i < NI_ParamListSize) && (i < *len); i++) {
      indices[i] = NI_ParamList[i].idx;
    }

    *len = i;
  }

  return NI_OK;
}

/*========================================================================*
 * Function: NIRT_GetParameterSpec
 *
 * Abstract:
 *	If index == -1, lookup parameter by the ID.
 *	If ID_len == 0 or if ID == null, return number of parameters in model.
 *	Otherwise, lookup parameter by index, and return the information.
 *
 * Input/Output Parameters:
 *	paramidx	: index of the parameter(in/out). If a value of "-1" is specified, the parameter's ID is used instead
 *	ID			: ID of parameter to be looked up (in), ID of parameter at index (out)
 *	ID_len		: length of input ID (in), length of ID (out)
 *	pnlen		: length of buffer paramname(in), length of the returned paramname (out)
 *	numdim		: length of buffer dimension(in), length of output dimension (out). If a value of "-1" is specified, the minimum buffer size of "dims" is returned as its value
 *
 * Output Parameters:
 *	paramname	: Name of the parameter
 *	datatype	: datatype of the parameter (currently assuming 0: double, .. )
 *	dims		: array of dimensions with length 'numdim'
 *
 * Returns:
 *	NI_OK if no error (if paramidx == -1, number of tunable parameters)
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetParameterSpec(int32_t* pidx, char* ID, int32_t*
  ID_len, char* paramname, int32_t *pnlen,
  int32_t *dattype, int32_t* dims, int32_t* numdim)
{
  int32_t i = 0;
  int32_t paramidx = *pidx;
  if (paramidx < 0) {
    /* check if ID has been specified. */
    if ((ID != NULL) && (ID_len != NULL) && (*ID_len > 0) ) {
      /*  lookup the table for matching ID */
      for (i=0; i < NI_ParamListSize; i++) {
        if (strcmp(ID,NI_ParamList[i].paramname) == 0) {
          /* found matching string */
          break;
        }
      }

      if (i < NI_ParamListSize) {
        /* note the index into the rtParamAttribs */
        paramidx = *pidx = i;
      } else {
        return NI_ParamListSize;
      }
    } else {
      /* no index or ID specified. */
      return NI_ParamListSize;
    }
  }

  if ((paramidx >= 0) && (paramidx<NI_ParamListSize)) {
    if (ID != NULL) {
      if ((int32_t)strlen(NI_ParamList[paramidx].paramname) < *ID_len) {
        *ID_len = strlen(NI_ParamList[paramidx].paramname);
      }

      strncpy(ID, NI_ParamList[paramidx].paramname, *ID_len);
    }

    if (paramname != NULL) {
      /* no need for return string to be null terminated! */
      if ((int32_t)strlen(NI_ParamList[paramidx].paramname) < *pnlen) {
        *pnlen = strlen(NI_ParamList[paramidx].paramname);
      }

      strncpy(paramname, NI_ParamList[paramidx].paramname, *pnlen);
    }

    if (dattype != NULL) {
      *dattype = NI_ParamList[paramidx].datatype;
    }

    if (numdim != NULL) {
      if (*numdim == -1) {
        *numdim = NI_ParamList[paramidx].numofdims;
      } else if (dims != NULL) {
        for (i = 0; i < *numdim; i++) {
          dims[i] = NI_ParamDimList[NI_ParamList[paramidx].dimListOffset + i];
        }
      }
    }

    return NI_OK;
  }

  return NI_ParamListSize;
}

/*========================================================================*
 * Function: NIRT_GetExtIOSpec
 *
 * Abstract:
 *	Returns the model's inport or outport specification
 *
 * Input Parameters:
 *	index	: index of the task
 *
 * Output Parameters:
 *	idx		: idx of the IO.
 *	name	: Name of the IO block
 *	tid		: task id
 *	type	: EXT_IN or EXT_OUT
 *	dims	: The port's dimension of length 'numdims'.
 *	numdims : the port's number of dimensions. If a value of "-1" is specified, the minimum buffer size of "dims" is returned as its value.
 *
 * Returns
 *	NI_OK if no error. (if index == -1, return number of tasks in the model)
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetExtIOSpec(int32_t index, int32_t *idx, char* name,
  int32_t* tid, int32_t *type, int32_t *dims, int32_t* numdims)
{
  if (index == -1) {
    return NI_ExtListSize;
  }

  if (idx != NULL) {
    *idx = NI_ExtList[index].idx;
  }

  if (name != NULL) {
    int32_t sz = strlen(name);
    strncpy(name, NI_ExtList[index].name, sz-1);
    name[sz-1]= 0;
  }

  if (tid != NULL) {
    *tid = NI_ExtList[index].TID;
  }

  if (type != NULL) {
    *type = NI_ExtList[index].type;
  }

  if (numdims != NULL) {
    if (*numdims == -1) {
      *numdims = 2;
    } else if (numdims != NULL) {
      /* Return port dimensions */
      dims[0] = NI_ExtList[index].dimX;
      dims[1] = NI_ExtList[index].dimY;
    }
  }

  return NI_OK;
}

/*========================================================================*
 * Function: NI_ProbeOneSignal
 *
 * Abstract:
 *		Helper function to probe one signal. baseaddr must NOT be VIRTUAL_SIG
 *
 * Output Parameters
 *
 * Returns:
 *     Return value: Returns the last index value probed in a vector signal
 *========================================================================*/
static int32_t NI_ProbeOneSignal(int32_t idx, double *value, int32_t len,
  int32_t *count, int32_t vOffset, int32_t vLength)
{
  if (NI_SigList[idx].baseaddr == VIRTUAL_SIG) {
    SetSITErrorMessage("NI_ProbeOneSignal: Received request to probe a virtual signal, but was expecting a ground source. Ignoring virtual signal probe. Report this behavior to NI.",
                       0);
    return 0;
  } else {
    char *ptr = (char*)((NI_SigList[idx].baseaddr == BLOCKIO_SIG) ? S->blockIO :
                        S->inputs) + (uintptr_t)NI_SigList[idx].addr;
    int32_t subindex = (vLength == -1) ? 0 : vOffset;
    int32_t sublength = (vLength == -1) ? NI_SigList[idx].width : (vLength +
      vOffset);
    while ((subindex < sublength) && (*count < len))
      value[(*count)++] = NIRT_GetValueByDataType(ptr, subindex++,
        NI_SigList[idx].datatype, NI_SigList[idx].IsComplex);
    return *count;
  }
}

/*========================================================================*
 * Function: NIRT_ProbeSignals
 *
 * Abstract:
 *	returns the latest signal values.
 *
 * Input Parameters:
 *	sigindices	: list of signal indices to be probed.
 *	numsigs		: length of sigindices array.
 *
 *		NOTE: (Implementation detail) the sigindices array that is passed in is delimited by a value of -1.
 *		Thus the # of valid indices in the sigindices table is min(numsigs, index of value -1) - 1.
 *		Reason for subtracting 1, the first index in the array is used for bookkeeping and should be copied
 *		into the 0th index in the signal values buffer.
 *		Also, the 1st index in the signal values buffer should contain the current timestamp. Hence valid
 *		signal data should be filled in starting from index 2. Any non-scalar signals should be added to the
 *		buffer in row-order.
 *
 * Input/Output Parameters
 *	num			: (in) length of sigvalues buffer (out) number of values returned in the buffer
 *
 * Output Parameters:
 *	value		: array of signal values
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_ProbeSignals(int32_t* sigindices, int32_t numsigs,
  double* value, int32_t* len)
{
  int32_t i = 0;
  int32_t idx = 0;
  int32_t count = 0;
  if (!SITexportglobals.inCriticalSection) {
    SetSITErrorMessage("SignalProbe should only be called between ScheduleTasks and PostOutputs",
                       1);
  }

  /* Get the index to the first signal */
  if ((*len > 1) && (numsigs > 0)) {
    value[count++] = sigindices[0];
    value[count++] = 0;
  }

  /* Get the second and other signals */
  for (i = 1; (i < numsigs) && (count < *len); i++) {
    idx = sigindices[i];
    if (idx < 0) {
      break;
    }

    if (idx < NI_SigListSize) {
      if (NI_SigList[idx].baseaddr == VIRTUAL_SIG) {
        int32_t vidx = NI_VirtualBlockSources[NI_SigList[idx].addr];
        NI_ProbeOneSignal(vidx, value, *len, &count, 0, -1);
      } else {
        NI_ProbeOneSignal(idx, value, *len, &count, 0, -1);
      }
    }
  }

  *len = count;
  return count;
}

extern "C" int32_t NI_InitializeParamStruct()
{
  memcpy(&rtParameter[0], &pmpc_hil1_P, sizeof(P_pmpc_hil1_T));
  return NI_OK;
}

/*  After the model has initialized and updated the parameters in
   rtParameter[0] (aka pmpc_hil1_P) we make a copy to rtParameter[1] so
   that it is double buffered. We also do a memcpy to each task's copy.
 */
extern "C" int32_t NI_InitParamDoubleBuf()
{
  int32_t idx = 1;

#ifdef MULTITASKING

  for (; idx <= NUMST - TID01EQ; idx++)
#endif

    memcpy(&rtParameter[idx], &rtParameter[0], sizeof(P_pmpc_hil1_T));
  return NI_OK;
}

static int32_t NI_SetParamTxStatus = NI_OK;

/*========================================================================*
 * Function: NIRT_SetParameter
 *
 * Abstract:
 *	Set parameter value. Called either in scheduler loop or a background loop.
 *
 * Input Parameters:
 *	index	: index of the parameter (as specified in Parameter Information)
 *	subindex: index in the flattened array, if parameter is n-D array
 *	val		: Value to set the parameter to
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_SetParameter(int32_t index, int32_t subindex, double
  value)
{
  char* ptr = NULL;

  /* Check bounds */
  if (index >= NI_ParamListSize) {
    SetSITErrorMessage("Parameter index is out of bounds.", 1);
    return NI_SetParamTxStatus= NI_ERROR;
  }

  /* Commit parameter values */
  if (index < 0) {
    if (ReadSideDirtyFlag == 1) {
      memcpy(&rtParameter[1-READSIDE], &rtParameter[READSIDE], sizeof
             (P_pmpc_hil1_T));
      ReadSideDirtyFlag = 0;
      if (WriteSideDirtyFlag == 0) {
        /* No values to commit */
        return NI_OK;
      } else {
        SetSITErrorMessage("Parameters have been set inline and from the background loop at the same time. Parameters written from the background loop since the last commit have been lost.",
                           1);
        WriteSideDirtyFlag = 0;
        return NI_ERROR;
      }
    }

    /* If an error occurred and we have values to commit, then save to the write side and return error */
    if (NI_SetParamTxStatus == NI_ERROR) {
      /* fail the transaction.
         copy old list of parameters to the failed TX buffer */
      if (WriteSideDirtyFlag == 1) {
        memcpy(&rtParameter[READSIDE], &rtParameter[1-READSIDE], sizeof
               (P_pmpc_hil1_T));
      }

      /* reset the status. */
      NI_SetParamTxStatus = NI_OK;
      WriteSideDirtyFlag = 0;
      return NI_ERROR;
    }

    /* If we have values to commit, then save to the write-side */
    if (WriteSideDirtyFlag == 1) {
      S->defaultParam = (double *)&rtParameter[1-READSIDE];
      WaitForSingleObject(SITexportglobals.flipCriticalSection, INFINITE);
      READSIDE = 1 - READSIDE;
      SITexportglobals.copyTaskBitfield = 0xFFFFFFFF;
      ReleaseSemaphore(SITexportglobals.flipCriticalSection, 1, NULL);

      /* Copy back the newly set parameters to the writeside. */
      memcpy(&rtParameter[1-READSIDE], &rtParameter[READSIDE], sizeof
             (P_pmpc_hil1_T));
      WriteSideDirtyFlag = 0;
    }

    return NI_OK;
  }

  /* verify that subindex is within bounds. */
  if (subindex >= NI_ParamList[index].width) {
    SetSITErrorMessage("Parameter subindex is out of bounds.",1);
    return NI_SetParamTxStatus = NI_ERROR;
  }

  if (ReadSideDirtyFlag == 1) {
    memcpy(&rtParameter[1-READSIDE], &rtParameter[READSIDE], sizeof
           (P_pmpc_hil1_T));
    ReadSideDirtyFlag = 0;
  }

  /* Get the parameter's address into the Parameter struct
     casting to char to perform pointer arithmetic using the byte offset */
  ptr = (char *)(&rtParameter[1-READSIDE]) + NI_ParamList[index].addr;
  WriteSideDirtyFlag = 1;

  /* Convert the incoming double datatype to the parameter's internal datatype and update value */
  return NIRT_SetValueByDataType(ptr, subindex, value, NI_ParamList[index].
    datatype, NI_ParamList[index].IsComplex);
}

/*========================================================================*
 * Function: NIRT_SetVectorParameter
 *
 * Abstract:
 *	Sets the value to a parameter array.
 *
 * Input Parameters:
 *	index		: index of the parameter as returned by NIRT_GetParameterSpec()
 *	paramvalues	: array of values to set
 *	paramlength	: Length of parameter values.
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_SetVectorParameter( uint32_t index, const double
  * paramvalues, uint32_t paramlength)
{
  uint32_t i = 0;
  int32_t retval = NI_OK;
  char* ptr = NULL;

  /* verify that index is within bounds*/
  if (index >= (uint32_t)NI_ParamListSize) {
    SetSITErrorMessage("Parameter index is out of bounds.", 1);
    return NI_SetParamTxStatus = NI_ERROR;
  }

  /* verify that subindex is within bounds. */
  if (paramlength != (uint32_t)NI_ParamList[index].width) {
    SetSITErrorMessage("Parameter length is incorrect.", 1);
    return NI_SetParamTxStatus = NI_ERROR;
  }

  /* If we have pending modified parameters, then copy to write-side */
  if (ReadSideDirtyFlag == 1) {
    memcpy(&rtParameter[1-READSIDE], &rtParameter[READSIDE], sizeof
           (P_pmpc_hil1_T));
    ReadSideDirtyFlag = 0;
  }

  /* Get the parameter's address into the Parameter struct
     casting to char to perform pointer arithmetic using the byte offset */
  ptr = (char*)(&rtParameter[1-READSIDE]) + NI_ParamList[index].addr;
  while (i < paramlength) {
    /* Convert the incoming double datatype to the parameter's internal datatype and update value */
    retval = retval & NIRT_SetValueByDataType(ptr, i, paramvalues[i],
      NI_ParamList[index].datatype, NI_ParamList[index].IsComplex);
    i++;
  }

  WriteSideDirtyFlag = 1;
  return retval;
}

/*========================================================================*
 * Function: NIRT_SetScalarParameterInline
 *
 * Abstract:
 *	Sets the value to a parameter immediately without the need of a commit request.
 *
 * Input Parameters:
 *	index		: index of the parameter as returned by NIRT_GetParameterSpec()
 *	subindex	: offset of the element within the parameter
 *	paramvalue	: Value to set the parameter to
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_SetScalarParameterInline( uint32_t index, uint32_t
  subindex, double paramvalue)
{
  char* ptr = NULL;
  if (index >= (uint32_t)NI_ParamListSize) {
    SetSITErrorMessage("Parameter index is out of bounds.", 1);
    return NI_SetParamTxStatus = NI_ERROR;
  }

  /* verify that subindex is within bounds. */
  if (subindex >= (uint32_t)NI_ParamList[index].width) {
    SetSITErrorMessage("Parameter subindex is out of bounds.", 1);
    return NI_SetParamTxStatus = NI_ERROR;
  }

  /* Get the parameter's address into the Parameter struct
     casting to char to perform pointer arithmetic using the byte offset */
  ptr = (char *)(&rtParameter[READSIDE]) + NI_ParamList[index].addr;
  ReadSideDirtyFlag = 1;

  /* Convert the incoming double datatype to the parameter's internal datatype and update value */
  return NIRT_SetValueByDataType(ptr, subindex, paramvalue, NI_ParamList[index].
    datatype, NI_ParamList[index].IsComplex);
}

/*========================================================================*
 * Function: NIRT_GetParameter
 *
 * Abstract:
 *	Get the current value of a parameter.
 *
 * Input Parameters:
 *	index	: index of the parameter
 *	subindex: element index into the flattened array if an array
 *
 * Output Parameters:
 *	val		: value of the parameter
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetParameter(int32_t index, int32_t subindex, double
  *value)
{
  char* ptr = NULL;

  /* Check index boundaries */
  if (index >= NI_ParamListSize || index < 0 || (subindex>=NI_ParamList[index].
       width)) {
    return NI_ERROR;
  }

  /* Get the parameter's address into the Parameter struct
     casting to char to perform pointer arithmetic using the byte offset */
  ptr = (char *)(&rtParameter[READSIDE]) + NI_ParamList[index].addr;

  /* Convert the parameter's internal datatype to double and return its value */
  *value = NIRT_GetValueByDataType(ptr, subindex, NI_ParamList[index].datatype,
    NI_ParamList[index].IsComplex);
  return NI_OK;
}

/*========================================================================*
 * Function: NIRT_GetVectorParameter
 *
 * Abstract:
 *	Get the current value of a vector parameter.
 *
 * Input Parameters:
 *	index: index of the parameter
 *	paramLength: length of the parameter
 *
 * Output Parameters:
 *	paramValues: an array of the parameter's value
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetVectorParameter(uint32_t index, double* paramvalues,
  uint32_t paramlength)
{
  char* ptr = NULL;
  uint32_t i = 0;
  if (index >= (uint32_t)NI_ParamListSize || index < 0 || (paramlength !=
       (uint32_t)NI_ParamList[index].width)) {
    return NI_ERROR;
  }

  /* Get the parameter's address into the Parameter struct
     casting to char to perform pointer arithmetic using the byte offset */
  ptr = (char *)(&rtParameter[READSIDE]) + NI_ParamList[index].addr;
  while (i<paramlength) {
    /* Convert the parameter's internal datatype to double and return its value */
    paramvalues[i] = NIRT_GetValueByDataType(ptr, i, NI_ParamList[index].
      datatype, NI_ParamList[index].IsComplex);
    i++;
  }

  return NI_OK;
}

/*========================================================================*
 * Function: NIRT_GetSimState
 *
 * Abstract:
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_GetSimState(int32_t* numContStates, char
  * contStatesNames, double* contStates, int32_t* numDiscStates, char
  * discStatesNames, double* discStates, int32_t* numClockTicks, char
  * clockTicksNames, int32_t* clockTicks)
{
  int32_t count = 0;
  int32_t idx = 0;
  if ((numContStates != NULL) && (numDiscStates != NULL) && (numClockTicks !=
       NULL)) {
    if (*numContStates < 0 || *numDiscStates < 0 || *numClockTicks < 0) {
      *numContStates = 1;
      *numDiscStates = 806;
      *numClockTicks = NUMST - TID01EQ;
      return NI_OK;
    }
  }

  if ((contStates != NULL) && (contStatesNames != NULL)) {
    idx = 0;
    contStates[idx] = NIRT_GetValueByDataType(&(pmpc_hil1_X.Int_I_CSTATE), 0, 0,
      0);
    strcpy(contStatesNames + (idx++ * 100), "Int_I_CSTATE");
  }

  if ((discStates != NULL) && (discStatesNames != NULL)) {
    idx = 0;
    discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.St, 0, 18, 0);
    strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.St");
    discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.iA_ws, 0, 19, 0);
    strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.iA_ws");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn1_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn1_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn2_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn2_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn3_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn3_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn4_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn4_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn5_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn5_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn6_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn6_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn7_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn7_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn8_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn8_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn9_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn9_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn10_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn10_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn11_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn11_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn12_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn12_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn13_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn13_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn14_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn14_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn15_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn15_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn16_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn16_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn17_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn17_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn18_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn18_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn19_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn19_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn20_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn20_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn21_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn21_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn22_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn22_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn23_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn23_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn24_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn24_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn25_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn25_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn26_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn26_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn27_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn27_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn28_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn28_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn29_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn29_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn30_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn30_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn31_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn31_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn32_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn32_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn33_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn33_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn34_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn34_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn35_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn35_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn36_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn36_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn37_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn37_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn38_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn38_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn39_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn39_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn40_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn40_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn41_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn41_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn42_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn42_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn43_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn43_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn44_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn44_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn45_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn45_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn46_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn46_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn47_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn47_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn48_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn48_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn49_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn49_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandIn50_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandIn50_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut1_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut1_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut2_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut2_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut3_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut3_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut4_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut4_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut5_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut5_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut6_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut6_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut7_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut7_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut8_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut8_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut9_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut9_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut10_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut10_DWORK1");
    discStates[idx] = NIRT_GetValueByDataType
      (&pmpc_hil1_DW.NIVeriStandOut11_DWORK1, 0, 0, 0);
    strcpy(discStatesNames + (idx++ * 100),
           "&pmpc_hil1_DW.NIVeriStandOut11_DWORK1");
    for (count = 0; count < 21; count++) {
      discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.VG, count, 23, 0);
      strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.VG");
    }

    for (count = 0; count < 5; count++) {
      discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.IG, count, 24, 0);
      strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.IG");
    }

    for (count = 0; count < 105; count++) {
      discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.FT, count, 25, 0);
      strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.FT");
    }

    discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.DB_delay_DSTATE, 0,
      3, 0);
    strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.DB_delay_DSTATE");
    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn1_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn1_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn2_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn2_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn3_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn3_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn4_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn4_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn5_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn5_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn6_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn6_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn7_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn7_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn8_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn8_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn9_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn9_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn10_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn10_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn11_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn11_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn12_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn12_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn13_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn13_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn14_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn14_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn15_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn15_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn16_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn16_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn17_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn17_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn18_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn18_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn19_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn19_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn20_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn20_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn21_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn21_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn22_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn22_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn23_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn23_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn24_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn24_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn25_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn25_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn26_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn26_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn27_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn27_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn28_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn28_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn29_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn29_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn30_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn30_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn31_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn31_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn32_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn32_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn33_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn33_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn34_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn34_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn35_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn35_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn36_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn36_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn37_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn37_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn38_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn38_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn39_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn39_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn40_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn40_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn41_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn41_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn42_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn42_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn43_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn43_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn44_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn44_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn45_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn45_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn46_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn46_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn47_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn47_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn48_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn48_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn49_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn49_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandIn50_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandIn50_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut1_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut1_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut2_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut2_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut3_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut3_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut4_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut4_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut5_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut5_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut6_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut6_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut7_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut7_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut8_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut8_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut9_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut9_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut10_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut10_DWORK2");
    }

    for (count = 0; count < 10; count++) {
      discStates[idx] = NIRT_GetValueByDataType
        (&pmpc_hil1_DW.NIVeriStandOut11_DWORK2, count, 26, 0);
      strcpy(discStatesNames + (idx++ * 100),
             "&pmpc_hil1_DW.NIVeriStandOut11_DWORK2");
    }

    discStates[idx] = NIRT_GetValueByDataType(&pmpc_hil1_DW.iA_ws_not_empty, 0,
      8, 0);
    strcpy(discStatesNames + (idx++ * 100), "&pmpc_hil1_DW.iA_ws_not_empty");
  }

  if ((clockTicks != NULL) && (clockTicksNames != NULL)) {
    clockTicks[0] = S->Timing.clockTick0;
    strcpy(clockTicksNames, "clockTick0");
    clockTicks[1] = S->Timing.clockTick2;
    strcpy(clockTicksNames + (1 * 100), "clockTick2");
  }

  return NI_OK;
}

/*========================================================================*
 * Function: NIRT_SetSimState
 *
 * Abstract:
 *
 * Returns:
 *	NI_OK if no error
 *========================================================================*/
DLL_EXPORT int32_t NIRT_SetSimState(double* contStates, double* discStates,
  int32_t* clockTicks)
{
  int32_t count = 0;
  int32_t idx = 0;
  if (contStates != NULL) {
    idx = 0;
    NIRT_SetValueByDataType(&(pmpc_hil1_X.Int_I_CSTATE), 0, contStates[idx++], 0,
      0);
  }

  if (discStates != NULL) {
    idx = 0;
    NIRT_SetValueByDataType(&pmpc_hil1_DW.St, 0, discStates[idx++], 18, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.iA_ws, 0, discStates[idx++], 19, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn1_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn2_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn3_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn4_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn5_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn6_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn7_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn8_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn9_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn10_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn11_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn12_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn13_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn14_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn15_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn16_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn17_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn18_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn19_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn20_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn21_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn22_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn23_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn24_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn25_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn26_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn27_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn28_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn29_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn30_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn31_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn32_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn33_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn34_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn35_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn36_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn37_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn38_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn39_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn40_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn41_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn42_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn43_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn44_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn45_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn46_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn47_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn48_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn49_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn50_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut1_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut2_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut3_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut4_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut5_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut6_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut7_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut8_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut9_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut10_DWORK1, 0,
      discStates[idx++], 0, 0);
    NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut11_DWORK1, 0,
      discStates[idx++], 0, 0);
    for (count = 0; count < 21; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.VG, count, discStates[idx++], 23, 0);
    }

    for (count = 0; count < 5; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.IG, count, discStates[idx++], 24, 0);
    }

    for (count = 0; count < 105; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.FT, count, discStates[idx++], 25, 0);
    }

    NIRT_SetValueByDataType(&pmpc_hil1_DW.DB_delay_DSTATE, 0, discStates[idx++],
      3, 0);
    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn1_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn2_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn3_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn4_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn5_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn6_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn7_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn8_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn9_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn10_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn11_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn12_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn13_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn14_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn15_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn16_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn17_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn18_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn19_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn20_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn21_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn22_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn23_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn24_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn25_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn26_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn27_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn28_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn29_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn30_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn31_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn32_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn33_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn34_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn35_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn36_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn37_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn38_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn39_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn40_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn41_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn42_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn43_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn44_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn45_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn46_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn47_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn48_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn49_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandIn50_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut1_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut2_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut3_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut4_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut5_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut6_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut7_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut8_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut9_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut10_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    for (count = 0; count < 10; count++) {
      NIRT_SetValueByDataType(&pmpc_hil1_DW.NIVeriStandOut11_DWORK2, count,
        discStates[idx++], 26, 0);
    }

    NIRT_SetValueByDataType(&pmpc_hil1_DW.iA_ws_not_empty, 0, discStates[idx++],
      8, 0);
  }

  if (clockTicks != NULL) {
    S->Timing.clockTick0 = clockTicks[0];
    S->Timing.clockTick1 = clockTicks[0];
    S->Timing.clockTick2 = clockTicks[1];
  }

  return NI_OK;
}

#endif                                 /* of NI_ROOTMODEL_pmpc_hil1 */
