function C0 = func_Fz_Calpha(x)
%FUNC_FZ_CALPHA  Cornering stiffness as a function of vertical load.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
       p1 =  -0.0001646;
       p2 =       14.64;
       p3 =      -417.9;

     C0 = p1*x^2 + p2*x + p3;
end
