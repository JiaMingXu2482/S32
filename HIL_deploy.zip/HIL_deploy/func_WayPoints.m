function [WayPoints_Collect] = func_WayPoints(maneuverType)
%FUNC_WAYPOINTS  Generate the reference path waypoints.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
if nargin < 1
    maneuverType = 1;
end

switch maneuverType
    case 1
        Afit = 3.5564696255156258;
        Lf1  = 27.85220278516676;
        Lf2  = 24.007795423319223;
        xc1  = 80.058689040522395;
        xc2  = 132.35698740891445;
        X = (0:0.5:200)';
        Y = Afit/2*(1+tanh(4/Lf1*(X-xc1))) - Afit/2*(1+tanh(4/Lf2*(X-xc2)));

    case 2
        ds = 0.5;
        L1 = 20;
        a  = 1.2;
        b  = 0.15;
        L3 = 40;

        X_str1 = (0:ds:L1).';
        Y_str1 = zeros(size(X_str1));

        L2 = 6*pi / b;
        X_sin = (L1:ds:(L1 + L2)).';
        Y_sin = a * sin( b * (X_sin - L1) );

        X_end = X_sin(end);
        X_str3 = (X_end:ds:(X_end + L3)).';
        Y_str3 = zeros(size(X_str3));

        X = [X_str1; X_sin(2:end); X_str3(2:end)];
        Y = [Y_str1; Y_sin(2:end); Y_str3(2:end)];

    case 3
        ds    = 0.25;
        Rroad = 60;
        L1    = 20;
        L_exit = 60;

        X_str1 = (0:ds:L1)';
        Y_str1 = zeros(size(X_str1));

        arc_len = pi * Rroad;
        n_arc   = ceil(arc_len/ds) + 1;
        theta   = linspace(-pi/2, +pi/2, n_arc)';

        centerX = L1;
        centerY = Rroad;

        X_arc = centerX + Rroad * cos(theta);
        Y_arc = centerY + Rroad * sin(theta);

        X_end = X_arc(end);
        Y_end = Y_arc(end);

        X_str3 = (X_end:-ds:(X_end - L_exit))';
        Y_str3 = Y_end * ones(size(X_str3));

        X = [X_str1; X_arc(2:end); X_str3(2:end)];
        Y = [Y_str1; Y_arc(2:end); Y_str3(2:end)];
case 4
        x1  = 50;
        x2  = 102.5;
        dy1 = 1.75;
        dy2 = 1.75;
        dx  = 15.2;
        c   = 0;

        ds_dlc = 0.5;
        X_dlc = (0:ds_dlc:140)';
        z1 = (2.4/dx) * (X_dlc - x1) + c;
        z2 = (2.4/dx) * (X_dlc - x2) + c;
        Y_dlc = dy1 * (1 + tanh(z1)) - dy2 * (1 + tanh(z2));

        Y_dlc(X_dlc <= 20) = 0;

        X0 = X_dlc(end);
        Y0 = Y_dlc(end);

        ds_ut   = 0.25;
        Rroad   = 60;
        L1      = 100;
        L_exit  = 60;

        X_str1 = (0:ds_ut:L1)';
        Y_str1 = zeros(size(X_str1));

        arc_len = pi * Rroad;
        n_arc   = ceil(arc_len/ds_ut) + 1;
        theta   = linspace(-pi/2, +pi/2, n_arc)';

        centerX = L1;
        centerY = Rroad;

        X_arc = centerX + Rroad * cos(theta);
        Y_arc = centerY + Rroad * sin(theta);

        X_end_local = X_arc(end);
        Y_end_local = Y_arc(end);

        X_str3 = (X_end_local:-ds_ut:(X_end_local - L_exit))';
        Y_str3 = Y_end_local * ones(size(X_str3));

        X_ut_local = [X_str1; X_arc(2:end); X_str3(2:end)];
        Y_ut_local = [Y_str1; Y_arc(2:end); Y_str3(2:end)];

        X_ut = X_ut_local + X0;
        Y_ut = Y_ut_local + Y0;

        X = [X_dlc; X_ut(2:end)];
        Y = [Y_dlc; Y_ut(2:end)];
    otherwise
        error('Maneuver Type unknown. Use 1 (DLC), 2 (Slalom), or 3 (U-Turn).');
end

numPoints = length(X);
WayPoints_Collect = zeros(numPoints, 9);

WayPoints_Collect(:,1) = (1:numPoints)';
WayPoints_Collect(:,2) = X;
WayPoints_Collect(:,3) = Y;

dX = gradient(X);
dY = gradient(Y);

psi_ref = atan2(dY, dX);

if maneuverType == 1
    psi_ref(X <= 20) = 0;
    Y(X <= 20) = 0;
    WayPoints_Collect(:,3) = Y;
end

WayPoints_Collect(:,4) = psi_ref;

s = zeros(numPoints, 1);
for i = 2:numPoints
    dist = sqrt((X(i)-X(i-1))^2 + (Y(i)-Y(i-1))^2);
    s(i) = s(i-1) + dist;
end
WayPoints_Collect(:,7) = s;

K = zeros(numPoints, 1);
psi_unwrap = unwrap(psi_ref);

for i = 2:numPoints-1
    d_psi = psi_unwrap(i+1) - psi_unwrap(i-1);
    ds_Local = s(i+1) - s(i-1);

    if abs(ds_Local) < 1e-6
        K(i) = 0;
    else
        K(i) = d_psi / ds_Local;
    end
end
K(1) = K(2);
K(end) = K(end-1);

WayPoints_Collect(:,5) = K;

filename = sprintf('WayPoints_Type%d.mat', maneuverType);
save(filename, 'WayPoints_Collect');

end
