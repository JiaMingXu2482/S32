function [WPIndex,RefU,Bezier_K,PrjP] = func_RefTraj_LocalPlanning( ...
    MPCParameters, VehiclePara, WayPoints_Index, WayPoints_Collect, ...
    VehStateMeasured, ParaHAT)
%FUNC_REFTRAJ_LOCALPLANNING  Local reference path planning and projection onto the path.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

L   = VehiclePara.L;
m   = VehiclePara.m;
Lf  = VehiclePara.lf;
Lr  = VehiclePara.lr;
mu  = VehiclePara.mu;
g   = VehiclePara.g;

CafHat = VehiclePara.CafHat;
CarHat = VehiclePara.CarHat;

K = -1*(m/(2*L^2)) * (Lf/CarHat - Lr/CafHat);

Np = MPCParameters.Np;
Ts = MPCParameters.Ts;

Tk = Ts * ones(Np,1);

Cf = CafHat;
Cr = CarHat;

Vel    = VehStateMeasured.x_dot;
PosX   = VehStateMeasured.X;
PosY   = VehStateMeasured.Y;
PosPsi = VehStateMeasured.Yaw;

WPIndex  = -1;
Bezier_K = zeros(Np,1);
RefU     = repmat([0;0;0], Np, 1);

PrjP = struct('ey',0,'epsi',0,'Velr',Vel,'xr',PosX,'yr',PosY,'psir',PosPsi);

ds = 0.1;
WPNum = length(WayPoints_Collect(:,1));

Dist_MIN  = 1000;
index_min = 0;

WayPoints_Index = max(1, min(WayPoints_Index, WPNum));
for i = WayPoints_Index:1:WPNum
    deltax0 = WayPoints_Collect(i,2) - PosX;
    deltay0 = WayPoints_Collect(i,3) - PosY;
    Dist = sqrt(deltax0.^2 + deltay0.^2);
    if Dist < Dist_MIN
        Dist_MIN  = Dist;
        index_min = i;
    end
end

if (index_min < 1)
    WPIndex = -1;
    return;
else
    if (index_min >= WPNum)
        WPIndex = -2;
        return;
    else
        WPIndex = index_min;
    end
end

if (WPIndex > 0)

    [PPx, PPy, Psi0, ey, epsi] = func_error(WayPoints_Collect, PosX, PosY, PosPsi);
    PrjP.ey   = -ey;
    PrjP.epsi = -epsi;
    PrjP.Velr = Vel;
    PrjP.xr   = PPx;
    PrjP.yr   = PPy;
    PrjP.psir = Psi0;

    StepLength_S = 0;
    for i = 1:Np
        StepLength_S = StepLength_S + Vel * Tk(i);
    end

    tempDx = WayPoints_Collect(index_min+1,2) - PPx;
    tempDy = WayPoints_Collect(index_min+1,3) - PPy;
    Dist_1 = sqrt(tempDx.^2 + tempDy.^2);

    Global_x = [];
    Global_y = [];
    Global_S = [];
    Global_K = [];

    Local_x  = [];
    Local_y  = [];
    Local_S  = [];

    Dist_SumS = 0;

    for i = index_min:1:WPNum
        Global_x = [Global_x; WayPoints_Collect(i,2)];
        Global_y = [Global_y; WayPoints_Collect(i,3)];
        Global_K = [Global_K; WayPoints_Collect(i,5)];
        Global_S = [Global_S; WayPoints_Collect(i,7)];

        deltax = WayPoints_Collect(i,2) - PosX;
        deltay = WayPoints_Collect(i,3) - PosY;

        CarCoord_x = deltax*cos(PosPsi) + deltay*sin(PosPsi);
        CarCoord_y = deltay*cos(PosPsi) - deltax*sin(PosPsi);

        Local_x = [Local_x; CarCoord_x];
        Local_y = [Local_y; CarCoord_y];
        Local_S = [Local_S; WayPoints_Collect(i,7)];

        Dist_SumS = Dist_1 + WayPoints_Collect(i,7) - WayPoints_Collect(index_min+1,7);
        if (Dist_SumS >= StepLength_S)
            break;
        end
    end

    if Dist_SumS < StepLength_S
        WPIndex = 0;
    else
        Mat_Local = [Local_x, Local_y];

        [ps0, ps1, ps2, ps3, ~] = func_FindBezierControlPointsND(Mat_Local, 'u');

        Scale = zeros(Np,1);
        for i = 1:Np
            Scale_i = round(Vel * Tk(i) / ds);
            Scale_i = max(1, Scale_i);
            Scale(i) = Scale_i;
        end

        Scale_0 = Scale(1);
        N_Scale = sum(Scale);
        N_Scale = Scale_0 + N_Scale;

        tlocS = linspace(0, 1, N_Scale+1);
        MatLocalInterp = func_bezierInterp(ps0, ps1, ps2, ps3, tlocS);

        Bezier_x   = zeros(Np,1);
        Bezier_y   = zeros(Np,1);
        Bezier_psi = zeros(Np,1);
        Bezier_K   = zeros(Np,1);

        Num_Scale = 0;
        for i = 1:Np
            Num_Scale = Num_Scale + Scale(i);
            Total_Num_Scale = Num_Scale + Scale_0;

            Bezier_x(i) = MatLocalInterp(Total_Num_Scale,1);
            Bezier_y(i) = MatLocalInterp(Total_Num_Scale,2);

            tempDx = MatLocalInterp(Total_Num_Scale+1,1) - MatLocalInterp(Total_Num_Scale,1);
            tempDy = MatLocalInterp(Total_Num_Scale+1,2) - MatLocalInterp(Total_Num_Scale,2);
            Bezier_psi(i) = atan2(tempDy, tempDx);

            Bezier_K(i) = func_CalPathCurve_Patent( ...
                MatLocalInterp(Total_Num_Scale-1,1), MatLocalInterp(Total_Num_Scale-1,2), ...
                MatLocalInterp(Total_Num_Scale  ,1), MatLocalInterp(Total_Num_Scale  ,2), ...
                MatLocalInterp(Total_Num_Scale+1,1), MatLocalInterp(Total_Num_Scale+1,2));
        end
    end

    RefU = zeros(3*Np, 1);
    for i = 1:Np
        delta_des = L * Bezier_K(i) * (1 + K * Vel^2);

        numerator_vy   = (1 - (m*Lf*Vel^2)/(2*L*Cf*Lr)) * Lr * Vel * delta_des;
        denominator_vy = L * (1 + K*Vel^2);
        vy_ref_unconstrained = numerator_vy / max(1e-6, denominator_vy);

        vy_friction_limit = Vel * atan(0.02*mu*g);
        Vyr = min(abs(vy_ref_unconstrained), vy_friction_limit) * sign(delta_des);

        numerator_psi   = Vel * delta_des;
        denominator_psi = L * (1 + K*Vel^2);
        psi_dot_ref_unconstrained = numerator_psi / max(1e-6, denominator_psi);

        psi_dot_friction_limit = min(abs(psi_dot_ref_unconstrained), mu*g / max(1e-3, Vel));
        Psidotr = psi_dot_friction_limit * sign(delta_des);

        RefU(3*i-2 : 3*i) = [delta_des; Vyr; Psidotr];
    end

end

end

function K = GetPathHeading(Xb,Yb,Xn,Yn)
AngleY = Yn - Yb;
AngleX = Xn - Xb;
K = atan2(AngleY, AngleX);
end

function [PPx,PPy,de] = func_GetProjectPoint(Xb,Yb,Xn,Yn,Xc,Yc)
if Xn==Xb
    x=Xn; y=Yc; de=Xc-Xn;
else
    if Yb==Yn
        x=Xc; y=Yn; de=Yn-Yc;
    else
        DifX=Xn-Xb; DifY=Yn-Yb;
        Kindex=DifY/DifX;
        bindex=Yn-Kindex*Xn;
        K=(-1)/Kindex;
        b=Yc-K*Xc;
        x=(bindex-b)/(K-Kindex);
        y=K*x+b;
        de=(Kindex*Xc+bindex-Yc)/sqrt(1+Kindex*Kindex);
    end
end
PPx=x; PPy=y;
end

function K = func_CalPathCurve(XA,YA,XB,YB,XC,YC)
if XB==XA
    mr=inf;
else
    mr=(YB-YA)/(XB-XA);
end
if XC==XB
    mt=inf;
else
    mt=(YC-YB)/(XC-XB);
end

if mr==mt
    Rff=inf;
else
    if mt==0
        if mr==inf
            Rff=sqrt((XA-XC)^2+(YA-YC)^2)/2;
        else
            mrsubmt=1/(2*(mr-mt));
            Xff=(mr*mt*(YC-YA)+mr*(XB+XC)-mt*mrsubmt*(XA+XB));
            Yff=(YB+YA)/2-(Xff-(XB+XA)/2)/mr;
            Rff=sqrt((XA-Xff)^2+(YA-Yff)^2);
        end
    elseif mt==inf
        if mr==0
            Rff=sqrt((XA-XC)^2+(YA-YC)^2)/2;
        else
            Yff=(YB+YC)/2;
            Xff=(XA+XB)/2-mr*(YC-YA)/2;
            Rff=sqrt((XA-Xff)^2+(YA-Yff)^2);
        end
    else
        mtdao=1/mt;
        if mr==0
            mrsubmt=1/(2*(mr-mt));
            Xff=(mr*mt*(YC-YA)+mr*(XB+XC)-mt*mrsubmt*(XA+XB));
            Yff=(YB+YC)/2-mtdao*(Xff-(XB+XC)/2);
            Rff=sqrt((XA-Xff)^2+(YA-Yff)^2);
        elseif mr==inf
            Yff=(YA+YB)/2;
            Xff=(XB+XC)/2+mt*(YA-YC)/2;
            Rff=sqrt((XA-Xff)^2+(YA-Yff)^2);
        else
            mrsubmt=1/(2*(mr-mt));
            Xff=(mr*mt*(YC-YA)+mr*(XB+XC)-mt*mrsubmt*(XA+XB));
            Yff=(YB+YC)/2-mtdao*(Xff-(XB+XC)/2);
            Rff=sqrt((XA-Xff)^2+(YA-Yff)^2);
        end
    end
end

K1=GetPathHeading(XA,YA,XB,YB);
K2=GetPathHeading(XB,YB,XC,YC);
if K2 > K1
    Rff=Rff;
else
    Rff=-1*Rff;
end
K=1/Rff;
end

function K = func_CalPathCurve_Patent(XA,YA,XB,YB,XC,YC)
x_dot    = XC - XA;
y_dot    = YC - YA;
x_dotdot = XC + XA - 2*XB;
y_dotdot = YC + YA - 2*YB;
temp = x_dot*x_dot + y_dot*y_dot;
K = 4*(x_dot*y_dotdot - x_dotdot*y_dot) / (temp^(1.5) + 1e-12);
end

function curvature = func_CalPathCurve_YU(X1,Y1,X2,Y2,X3,Y3)
delta_x = X2 - X1; delta_y = Y2 - Y1;
a = sqrt(delta_x.^2 + delta_y.^2);
delta_x = X3 - X2; delta_y = Y3 - Y2;
b = sqrt(delta_x.^2 + delta_y.^2);
delta_x = X1 - X3; delta_y = Y1 - Y3;
c = sqrt(delta_x.^2 + delta_y.^2);

CLOSE_TO_ZERO = 0.01;
if (a < CLOSE_TO_ZERO || b < CLOSE_TO_ZERO || c < CLOSE_TO_ZERO)
    curvature = 0;
    return;
end

s = (a + b + c)/2.0;
K = sqrt(abs(s*(s-a)*(s-b)*(s-c)));
curvature = 4*K/(a*b*c);

rotate_direction = (X2 - X1)*(Y3 - Y2) - (Y2 - Y1)*(X3 - X2);
if (rotate_direction < 0)
    curvature = -curvature;
end
end

function [PPx,PPy,Psi0,e_y,e_psi] = func_error(WayPoints_Collect, PosX, PosY, PosPsi)
xo = PosX; yo = PosY; psi = PosPsi;

interp_points = 1500;
window_size   = 15;

X_ref   = WayPoints_Collect(:,2);
Y_ref   = WayPoints_Collect(:,3);
psi_ref = WayPoints_Collect(:,4);

dists = sqrt((X_ref - xo).^2 + (Y_ref - yo).^2);
[~, idx_nearest_] = min(dists(:));
idx_nearest = idx_nearest_(1);

start_idx = max(1, idx_nearest - floor(window_size/2));
end_idx   = min(length(X_ref), start_idx + window_size);

if end_idx - start_idx < 5
    start_idx = max(1, end_idx - 5);
end

local_X   = X_ref(start_idx:end_idx);
local_Y   = Y_ref(start_idx:end_idx);
local_psi = psi_ref(start_idx:end_idx);

interp_idx = linspace(1, length(local_X), interp_points);

X_interp   = spline(1:length(local_X), local_X, interp_idx);
Y_interp   = spline(1:length(local_Y), local_Y, interp_idx);
psi_interp = spline(1:length(local_psi), local_psi, interp_idx);

interp_dists = sqrt((X_interp - xo).^2 + (Y_interp - yo).^2);
[~, idx_interp_] = min(interp_dists(:));
idx_interp = idx_interp_(1);

PPx = X_interp(idx_interp);
PPy = Y_interp(idx_interp);

dx = X_interp(idx_interp) - xo;
dy = Y_interp(idx_interp) - yo;
Psi0 = atan2(dy, dx);

e_y = -dx*sin(psi) + dy*cos(psi);

e_psi = local_wrapToPi(psi_interp(idx_interp) - psi);
end

function ang = local_wrapToPi(ang)
for k = 1:numel(ang)
    a = ang(k);
    if a < -pi || a > pi
        ang(k) = mod(a + pi, 2*pi) - pi;
    end
end
end
