function [x_opt, exitflag, delta_U_first, rho_val, epsilon_val, WarmStart] = ...
        func_SolveMPCQP(H, f, A_cons, b_cons, lb, ub, WarmStart, MPCParameters)
%FUNC_SOLVEMPCQP  Solve the upper-level MPC QP.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

if isfield(MPCParameters,'QPSolver'), qsel = MPCParameters.QPSolver; else, qsel = 0; end
Nu = MPCParameters.Nu;  Nc = MPCParameters.Nc;
Ne = MPCParameters.Ne;  Nr = MPCParameters.Nr;
nvars = Nu*Nc + Ne + Nr;

if numel(WarmStart) ~= nvars || ~all(isfinite(WarmStart(:)))
    if MPCParameters.Verbose
        fprintf(2, 'func_SolveMPCQP: WarmStart size invalid or non-finite; reset to zero.\n');
    end
    WarmStart = zeros(nvars,1);
else
    WarmStart = WarmStart(:);
end

bad = '';
if ~all(isfinite(H(:))),      bad = [bad 'H ']; end
if ~all(isfinite(f(:))),      bad = [bad 'f ']; end
if ~all(isfinite(A_cons(:))), bad = [bad 'A_cons ']; end
if ~all(isfinite(b_cons(:))), bad = [bad 'b_cons ']; end
if ~all(isfinite(lb(:))),     bad = [bad 'lb ']; end
if any(isnan(ub(:))),         bad = [bad 'ub(NaN) ']; end
if ~isempty(bad)
    if MPCParameters.Verbose
        fprintf(2, 'func_SolveMPCQP: QP matrices contain Inf/NaN: %s-> holding previous control\n', bad);
    end
    x_opt         = zeros(nvars,1);
    exitflag      = -3;
    delta_U_first = zeros(Nu,1);
    rho_val       = [0; 0; 0];
    epsilon_val   = zeros(Ne,1);
    WarmStart     = zeros(nvars,1);
    return;
end

Hx0 = H*WarmStart;
Ax0 = A_cons*WarmStart;
if ~all(isfinite(Hx0)) || ~isfinite(WarmStart'*Hx0) || ...
        ~isfinite(f'*WarmStart) || ~all(isfinite(Ax0))
    if MPCParameters.Verbose
        fprintf(2, 'func_SolveMPCQP: WarmStart produced Inf/NaN in QP; reset to zero.\n');
    end
    WarmStart = zeros(nvars,1);
end

dH = max(diag(H), eps*max(diag(H)));
sc = 1 ./ sqrt(dH);
Hs = (sc*sc.') .* H;
Hs = (Hs+Hs.')/2;
fs = sc .* f;
As = bsxfun(@times, A_cons, sc.');
lbs = lb ./ sc;   ubs = ub ./ sc;
x0s = WarmStart ./ sc;
x0s = min(max(x0s, lbs), ubs);

if qsel == 1
    [xs, st, ~] = func_QPKwik(Hs, fs, As, b_cons, lbs, ubs, 2500, true);
    if st > 0, exitflag = 1; else, exitflag = st - 10; end
elseif coder.target('MATLAB')
    options = optimoptions('quadprog', ...
        'MaxIterations',        2500, ...
        'Algorithm',            'active-set', ...
        'OptimalityTolerance',  1e-6, ...
        'ConstraintTolerance',  1e-6);
    [xs, ~, exitflag] = quadprog(Hs, fs, As, b_cons, [], [], lbs, ubs, x0s, options);
else
    xs = zeros(nvars,1);  exitflag = -9;
end
x_opt = zeros(nvars,1);
if numel(xs) == nvars, x_opt = sc .* xs; end

if exitflag == 1
    WarmStart     = func_WarmStart_shiftHorizon(x_opt, MPCParameters);
    delta_U_opt   = x_opt(1:Nu*Nc);
    delta_U_first = delta_U_opt(1:Nu);

    rho_val = [1; 1; 1];
    if Nr == 3
        rho_val = x_opt(nvars-2:nvars);
    end

    epsilon_val = x_opt(Nu*Nc+1 : Nu*Nc+Ne);
else
    delta_U_first = zeros(Nu,1);
    rho_val       = [0; 0; 0];
    epsilon_val   = zeros(Ne,1);
end

end
