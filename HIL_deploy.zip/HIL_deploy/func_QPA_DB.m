function [Tb_L1,Tb_L2,Tb_R1,Tb_R2] = func_QPA_DB(VehiclePara,InitialParams,Constraints,ParaHAT,MFx,delta_wheel,Tb_u,Fx_dem,verbose)
%FUNC_QPA_DB  Lower-level allocation QP for differential braking.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
if nargin < 8 || isempty(Fx_dem), Fx_dem = 0; end

    lf          = VehiclePara.lf;
    mu          = VehiclePara.mu;
    tf          = VehiclePara.tf;
    tr          = VehiclePara.tr;
    rt          = VehiclePara.rt;
    Fz_L1       = ParaHAT.Fz_l1;
    Fz_L2       = ParaHAT.Fz_l2;
    Fz_R1       = ParaHAT.Fz_r1;
    Fz_R2       = ParaHAT.Fz_r2;

    rho    =  0.1;
    Tb_max = Constraints.Tb_max;
    Tb_fl_max = min(Tb_u.Tb_L1,Tb_max);
    Tb_rl_max = min(Tb_u.Tb_L2,Tb_max);
    Tb_fr_max = min(Tb_u.Tb_R1,Tb_max);
    Tb_rr_max = min(Tb_u.Tb_R2,Tb_max);
    Bb = (1/rt) * [   (tf/2)*cos(delta_wheel)-lf*sin(delta_wheel),...
                    -(tf/2)*cos(delta_wheel)-lf*sin(delta_wheel), ...
                      tr/2, -tr/2 ];
    Fz_eff = max([Fz_L1, Fz_R1, Fz_L2, Fz_R2], 1);
    Gamma_u = diag((1./(rt*mu*Fz_eff)).^2);

    H = 2 * (Bb'*Bb + rho*Gamma_u);
    f = -2 * Bb' * MFx;

    Fz_tot = Fz_L1 + Fz_R1 + Fz_L2 + Fz_R2;
    T_ref  = max(rt*mu*Fz_tot/4, 1);
    M_ref  = max(mu*Fz_tot*tf/4,  1);
    lam_d  = Constraints.QPA_lamd;
    if lam_d > 0
        Tb_pre = InitialParams.prevstate.Tb(:);
        if numel(Tb_pre) ~= 4 || any(~isfinite(Tb_pre)), Tb_pre = zeros(4,1); end
        kd = lam_d * (M_ref/T_ref)^2;
        H  = H + 2*kd*eye(4);
        f  = f - 2*kd*Tb_pre;
    end

    if Fx_dem > 0
        Bx = (1/rt) * [cos(delta_wheel), cos(delta_wheel), 1, 1];
        F_ref  = max(mu*Fz_tot, 1);
        lam_x  = Constraints.Gov_lamx;
        kx     = lam_x * (M_ref/F_ref)^2;
        H = H + 2*kx*(Bx'*Bx);
        f = f - 2*kx*(Bx'*Fx_dem);
    end

    ub = [ Tb_fl_max;Tb_fr_max;Tb_rl_max;Tb_rr_max;];
    lb = zeros(4, 1);

    x0 = InitialParams.prevstate.Tb(:);
    if numel(x0) ~= 4 || any(~isfinite(x0))
        x0 = zeros(4,1);
    end
    x0 = min(max(x0, lb), ub);

    [Tb, st_, ~] = func_QPKwik(H, f, zeros(0,4), zeros(0,1), lb, ub, 200, false);
    if st_ > 0, exitflag_DB = 1; else, exitflag_DB = st_ - 10; end

    if exitflag_DB <= 0
        if verbose
            fprintf(2, 'func_QPA_DB: brake torque allocation QP failed, exitflag_DB=%.0f\n', exitflag_DB);
        end
        Tb = zeros(4, 1);
    end

    Tb_L1 = Tb(1);
    Tb_L2 = Tb(3);
    Tb_R1 = Tb(2);
    Tb_R2 = Tb(4);
end
