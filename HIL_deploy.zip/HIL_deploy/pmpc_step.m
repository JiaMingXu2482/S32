function [sys, St] = pmpc_step(u, Pm, St) %#codegen
%PMPC_STEP  One control step: state estimation, reference, upper-level MPC, lower-level allocation.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   The two early-return paths must write the cross-step state back into St.
%   They used to rely on globals; after the refactor a missing write-back
%   left the controller inert with no visible error.

MPCParameters = Pm.MPCParameters;
CostWeights = Pm.CostWeights;
DiscreteModle = Pm.DiscreteModle;
ContrlMode = Pm.ContrlMode;
Reftraj = Pm.Reftraj;
Cf0 = Pm.Cf0;
Cr0 = Pm.Cr0;
C_table = Pm.C_table;
TireF = Pm.TireF;
TireR = Pm.TireR;

VehiclePara = St.VehiclePara;
Constraints = St.Constraints;

InitialParams = St.InitialParams;
WarmStart = St.WarmStart;
rho = St.rho;

sys = zeros(54,1);
if InitialParams.InitialGapflag == 0
    InitialParams.InitialGapflag = InitialParams.InitialGapflag + 1;
    St.InitialParams = InitialParams;
    St.WarmStart = WarmStart;
    St.rho = rho;
    St.VehiclePara = VehiclePara;
    St.Constraints = Constraints;
    return;
end
InitialParams.InitialGapflag = InitialParams.InitialGapflag + 1;

[VehStateMeasured, ParaHAT] = func_StateEstimation(u,VehiclePara);
Vel = VehStateMeasured.x_dot;
Vy  = VehStateMeasured.y_dot;
yawrate = VehStateMeasured.Yawrate;
LTR = ParaHAT.LTR;
alpha_l2=ParaHAT.alpha_l2;
alpha_r2=ParaHAT.alpha_r2;
Roll = ParaHAT.Roll; Rollrate = ParaHAT.Rollrate;

if MPCParameters.FishhookMode
    delta_robot = VehStateMeasured.delta_f - InitialParams.U(1);
else
    delta_robot = 0;
end

dr_seq = delta_robot;
if MPCParameters.LTV_on
if isnan(InitialParams.dr_prev)
    InitialParams.dr_prev = delta_robot;
    InitialParams.dr_rate = 0;
end
dr_raw  = (delta_robot - InitialParams.dr_prev) / MPCParameters.Ts_exec;
dr_raw  = max(min(dr_raw, Constraints.dlt_rate_max), -Constraints.dlt_rate_max);
a_lp    = 0.3;
InitialParams.dr_rate = (1-a_lp)*InitialParams.dr_rate + a_lp*dr_raw;
InitialParams.dr_prev = delta_robot;
dr_seq  = delta_robot + InitialParams.dr_rate * (1:MPCParameters.Np).' * MPCParameters.Ts;
dr_seq  = max(min(dr_seq, deg2rad(30)), -deg2rad(30));
end
ab_f = (Vy + VehiclePara.lf*yawrate)/max(abs(Vel),1) - VehStateMeasured.delta_f;
ab_r = (Vy - VehiclePara.lr*yawrate)/max(abs(Vel),1);
[fb_f, cb_f] = func_TireTable('eval', TireF, ab_f, ParaHAT.Fzf);
[fb_r, cb_r] = func_TireTable('eval', TireR, ab_r, ParaHAT.Fzr);
kap  = Constraints.Ctan_floor_frac;
cb_f = -max(abs(cb_f), kap*TireF.C0);
cb_r = -max(abs(cb_r), kap*TireR.C0);
VehiclePara.CbarF = cb_f;   VehiclePara.CbarR = cb_r;
VehiclePara.CafTan = cb_f;  VehiclePara.CarTan = cb_r;
F_off_f = fb_f - cb_f*ab_f - cb_f*delta_robot;
F_off_r = fb_r - cb_r*ab_r;

if InitialParams.BaselineMode
    Ib = InitialParams.BaselineCurrent;
    sys(5) = func_MRDamper(VehStateMeasured.V_l1, Ib);
    sys(6) = func_MRDamper(VehStateMeasured.V_l2, Ib);
    sys(7) = func_MRDamper(VehStateMeasured.V_r1, Ib);
    sys(8) = func_MRDamper(VehStateMeasured.V_r2, Ib);
    sys(9) = 0;
    sys(29) = LTR;      sys(31) = Vel*3.6;
    sys(32) = VehStateMeasured.VxTarget;
    sys(34) = sqrt(Vel^2 + Vy^2);   sys(35) = LTR;
    sys(36) = (rad2deg(alpha_l2)+rad2deg(alpha_r2))/2;
    sys(37) = rad2deg(VehStateMeasured.Yaw);
    sys(38) = VehStateMeasured.beta;
    sys(39) = cb_f;     sys(40) = cb_r;
    sys(41) = Roll;     sys(42) = Rollrate;
    sys(43:46) = [ParaHAT.Fx_l1;ParaHAT.Fx_l2;ParaHAT.Fx_r1;ParaHAT.Fx_r2];
    sys(47:50) = [ParaHAT.Fy_l1;ParaHAT.Fy_l2;ParaHAT.Fy_r1;ParaHAT.Fy_r2];
    sys(51:54) = [ParaHAT.Fz_l1;ParaHAT.Fz_l2;ParaHAT.Fz_r1;ParaHAT.Fz_r2];
    St.InitialParams = InitialParams;
    St.WarmStart = WarmStart;
    St.rho = rho;
    St.VehiclePara = VehiclePara;
    St.Constraints = Constraints;
    return
end

if MPCParameters.FishhookMode
    Bezier_SK = [];
    PrjP   = struct('ey',0,'epsi',0,'Velr',Vel,'xr',VehStateMeasured.X, ...
                    'yr',VehStateMeasured.Y,'psir',VehStateMeasured.Yaw);
    ref_Vy = zeros(MPCParameters.Np,1);
    ref_r  = zeros(MPCParameters.Np,1);
else
    [WPIndex,RefU,Bezier_SK,PrjP] = func_RefTraj_LocalPlanning(MPCParameters,VehiclePara,InitialParams.WayPoints_IndexPre,Reftraj,VehStateMeasured,ParaHAT);
    if WPIndex > 0, InitialParams.WayPoints_IndexPre = WPIndex; end
    ref_Vy = RefU(2:3:end);
    ref_r  = RefU(3:3:end);
end

LTVin = struct('TireF',TireF, 'TireR',TireR, ...
                   'delta_robot',dr_seq, ...
                   'Fzf',ParaHAT.Fzf, 'Fzr',ParaHAT.Fzr, ...
                   'kap',Bezier_SK, ...
                   'x0',[Vy; yawrate; Roll; Rollrate; PrjP.ey; PrjP.epsi], ...
                   'u0',[VehStateMeasured.delta_f - delta_robot; ...
                         InitialParams.U(2); InitialParams.U(3)], ...
                   'dU',reshape(WarmStart(1:MPCParameters.Nc*MPCParameters.Nu), ...
                                MPCParameters.Nu, MPCParameters.Nc), ...
               'Ctan_floor_frac',Constraints.Ctan_floor_frac);
if MPCParameters.LTV_on
    [StateSpaceModel] = func_DynamicalModel(VehiclePara, MPCParameters, VehStateMeasured, DiscreteModle, LTVin);
else
    [StateSpaceModel] = func_DynamicalModel(VehiclePara, MPCParameters, VehStateMeasured, DiscreteModle);
end
rho_zeng = 1;  Iind_zeng = 0;  Ib_zeng = 0;  Ir_zeng = 0;
if Constraints.ZengRho_on
    [rho_zeng, Iind_zeng, Ib_zeng, Ir_zeng, bL_z, bR_z, rmax_z] = func_ZengRho( ...
        Vel, VehiclePara.mu, VehStateMeasured.delta_f, ...
        VehStateMeasured.beta, yawrate, VehiclePara.g);
    Constraints.Zeng_bL = bL_z;  Constraints.Zeng_bR = bR_z;  Constraints.Zeng_rmax = rmax_z;
    if Constraints.ZengRho_on == 2, rho_zeng = 1; end
end

[Envelope,r_ssmax] = func_Envelope(VehiclePara,Constraints,VehStateMeasured);
CW = CostWeights;
if Constraints.ZengRho_on
    CW.W1 = CostWeights.W1 * rho_zeng;
    CW.W2 = CostWeights.W2 * rho_zeng;
end
[Q,R,S,W,V,dFyfmax,dMFxmax,dMdmax,Fyfmax,MFxmax,Mdmax,Mdmin,Tb_u,Fdu,Fdl,Mdnom] = func_CostWeightingRegulation_QuadSlacks(MPCParameters,CW,Constraints,r_ssmax,ParaHAT,VehiclePara,VehStateMeasured);

Nu=MPCParameters.Nu; Nx=MPCParameters.Nx; Ny=MPCParameters.Ny;
Nc=MPCParameters.Nc; Np=MPCParameters.Np; Ne=MPCParameters.Ne;
Nr=MPCParameters.Nr;

Fyf_0 = InitialParams.U(1); MFx_0 = InitialParams.U(2); Md_0 = InitialParams.U(3);

zeta = [Vy; yawrate; Roll; Rollrate; PrjP.ey; PrjP.epsi; Fyf_0; MFx_0; Md_0];

if ~StateSpaceModel.off_valid
    distIn = [F_off_f; F_off_r];
else
    distIn = StateSpaceModel.off;
end
[PSI, THETA, GAMMA, PHI] = func_SystemFurture(MPCParameters, StateSpaceModel, Bezier_SK, distIn);

A_t = tril(ones(Nc));
AI  = kron(A_t, eye(Nu));
Ut  = kron(ones(Nc,1), zeta(7:9));

Pred = struct('PSI',PSI, 'THETA',THETA, 'PHI',PHI, 'GAMMA',GAMMA);
Wts  = struct('Q',Q, 'R',R, 'S',S, 'W',W, 'V',V);
Flim    = 0.95*VehiclePara.mu_eff*ParaHAT.Fzf;
Cm      = max(abs(cb_f), 5e3);
if MPCParameters.FishhookMode
    dlt_mec = Constraints.AFS_max;
else
    dlt_mec = min(Constraints.SW_max/VehiclePara.isw, deg2rad(20));
end
u_op    = VehStateMeasured.delta_f - delta_robot;
head_up = max(Flim - fb_f, 0)/Cm;
head_dn = max(Flim + fb_f, 0)/Cm;
dlt_ub  = min( dlt_mec, u_op + head_up);
dlt_lb  = max(-dlt_mec, u_op - head_dn);
dlt_ub  = max(dlt_ub, 0);
dlt_lb  = min(dlt_lb, 0);

bta_l  = 2/(VehiclePara.m*VehiclePara.g*VehiclePara.tf);
kap_g  = VehiclePara.m*VehiclePara.h_TL - VehiclePara.ms*VehiclePara.h_S2R;
ay_off = (F_off_f*cos(VehStateMeasured.delta_f) + F_off_r)/VehiclePara.m;
Envelope.Gr = Envelope.Gr - bta_l*kap_g*ay_off*[1; -1];

Fy_f_avg = 0.5*(abs(ParaHAT.Fy_l1) + abs(ParaHAT.Fy_r1));
Fz_f_avg = 0.5*(ParaHAT.Fz_l1 + ParaHAT.Fz_r1);
Fxu_f    = sqrt(max((VehiclePara.mu*Fz_f_avg)^2 - Fy_f_avg^2, 1));
kappa_fx = (VehiclePara.tf/2) * (Fy_f_avg/Fxu_f) * abs(cb_f)/2;

Lim  = struct('Fyfmax',Fyfmax,   'MFxmax',MFxmax,   'Mdmax',Mdmax, 'Mdmin',Mdmin, ...
              'Mdnom',Mdnom, ...
              'eps_ub', Constraints.eps_ub_scale * ...
                        [Constraints.epsilon_r*ones(2,1);   Constraints.epsilon_alpha*ones(2,1); ...
                         Constraints.epsilon_LTR*ones(2,1); Constraints.epsilon_e*ones(2,1)], ...
              'sigma_budget',MPCParameters.sigma_budget, ...
              'gamma_prev',InitialParams.prevstate.gamma, ...
              'kappa_fx',kappa_fx, 'u_op',u_op, ...
              'fx_couple',MPCParameters.fx_couple, ...
              'dFyfmax',dFyfmax, 'dMFxmax',dMFxmax, 'dMdmax',dMdmax, ...
              'dlt_ub',dlt_ub,   'dlt_lb',dlt_lb);

lambda_L1 = 1.0;

gamma_prev = InitialParams.prevstate.gamma;
if isfield(CostWeights,'tau_gamma') && ~isempty(CostWeights.tau_gamma) && CostWeights.tau_gamma > 0
    rho_g = exp(-MPCParameters.Ts_exec / CostWeights.tau_gamma);
    Wdg_v = rho_g/(1-rho_g) * MPCParameters.Nc * ...
            [CostWeights.V1, CostWeights.V2, CostWeights.V3];
else
    Wdg_v = CostWeights.Wdg;
end
W_dgamma   = diag(Wdg_v);

[H, f] = func_BuildQPCost(MPCParameters, Constraints, Pred, Wts, ...
                          zeta, AI, Ut, ref_Vy, ref_r, lambda_L1, ...
                          gamma_prev, W_dgamma);

[A_cons, b_cons, lb, ub, umax, umin] = func_BuildQPConstraints( ...
                          MPCParameters, Envelope, Pred, AI, Ut, zeta, Lim);

[x_opt, exitflag, delta_U_first, rho_val, epsilon_val, WarmStart] = ...
    func_SolveMPCQP(H, f, A_cons, b_cons, lb, ub, WarmStart, MPCParameters);

if exitflag == 1
    rho = diag(rho_val);
    InitialParams.prevstate.gamma = rho_val(:);
end

InitialParams.U(1) = zeta(7) + delta_U_first(1);
InitialParams.U(2) = zeta(8) + delta_U_first(2);
InitialParams.U(3) = zeta(9) + delta_U_first(3);

Fyf_next = InitialParams.U(1);
MFx_next = InitialParams.U(2);
Md_next  = InitialParams.U(3);

if exitflag == 1
    Y   = PSI*zeta + THETA*x_opt(1:Nu*Nc) + PHI*GAMMA;
    rho = diag([x_opt(end-2) x_opt(end-1) x_opt(end)]);
else
    Y   = PSI*zeta + PHI*GAMMA;
end

Fx_dem = 0;   Vset_zg = VehStateMeasured.VxTarget;   Vset_pid = Vset_zg;
if Constraints.ZengRho_on && Constraints.ZengLong_on && exitflag == 1
    ay_meas = ( (ParaHAT.Fy_l1 + ParaHAT.Fy_r1)*cos(VehStateMeasured.delta_f) ...
              + (ParaHAT.Fy_l2 + ParaHAT.Fy_r2) ) / VehiclePara.m;
    ax_bar  = VehiclePara.mu_eff*VehiclePara.g;
    ay_bar  = ax_bar;
    ax_av   = ax_bar * max(1 - abs(ay_meas)/ay_bar, 0);

    r_pv   = max(abs(Y(2:Ny:end)), Constraints.Zg_rfloor);
    r_pv   = r_pv(1:min(MPCParameters.Zg_Npv, numel(r_pv)));
    r_att  = Constraints.Zg_kovs * VehiclePara.mu_eff*VehiclePara.g / max(Vel,1);
    r_pv   = min(r_pv, r_att);

    c_pv = ones(size(r_pv));
    if MPCParameters.Zg_ayfull
        vy_pv = Y(1:Ny:end);  rs_pv = Y(2:Ny:end);
        dvy   = [ (vy_pv(1)-Vy)/MPCParameters.Ts ; diff(vy_pv)/MPCParameters.Ts ];
        ay_pv = dvy + Vel*rs_pv;
        cc    = abs(Vel*rs_pv) ./ max(abs(ay_pv), 0.1);
        cc    = min(max(cc, 0.5), Constraints.Zg_cmax);
        c_pv  = cc(1:numel(r_pv));
        c_now = min(max(abs(Vel*yawrate)/max(abs(ay_meas),0.1), 0.5), Constraints.Zg_cmax);
    else
        c_now = 1;
    end
    t_pv   = (1:numel(r_pv))' * MPCParameters.Ts;
    a_brk  = Constraints.Zg_apv * ax_av;
    V_cand = [ c_now*VehiclePara.mu*VehiclePara.g / max(abs(yawrate), Constraints.Zg_rfloor); ...
               c_pv.*(VehiclePara.mu*VehiclePara.g) ./ r_pv + a_brk*t_pv ];
    Vx_lim = max(min(V_cand(:)), Constraints.Zg_Vmin);
    Vset_zg = min(VehStateMeasured.VxTarget, Vx_lim*3.6);
    dV = Vel - Vset_zg/3.6;
    if dV > Constraints.Zg_dVdb
        Fx_dem = VehiclePara.m * min(dV/Constraints.Zg_tau, ax_av);
    end

    Vset_pid = Vset_zg;
    if Constraints.Zg_tpid > 0
        if isnan(InitialParams.prevstate.Vpid)
            InitialParams.prevstate.Vpid = Vset_zg;
        end
        kf = min(MPCParameters.Ts_exec / Constraints.Zg_tpid, 1);
        Vset_pid = InitialParams.prevstate.Vpid + kf*(Vset_zg - InitialParams.prevstate.Vpid);
        InitialParams.prevstate.Vpid = Vset_pid;
    end
end

if MPCParameters.FishhookMode
    [Steer_Wheel, delta_wheel] = func_AFS(VehiclePara,VehStateMeasured,MPCParameters,ParaHAT, Fyf_next);
    delta_wheel = delta_robot + Fyf_next;
else
    [Steer_Wheel, delta_wheel] = func_AFS(VehiclePara,VehStateMeasured,MPCParameters,ParaHAT, delta_robot + Fyf_next);
end
[Tb_L1,Tb_L2,Tb_R1,Tb_R2]  = func_QPA_DB(VehiclePara,InitialParams,Constraints,ParaHAT,MFx_next,delta_wheel,Tb_u,Fx_dem,MPCParameters.Verbose);
InitialParams.prevstate.Tb = [Tb_L1;Tb_R1;Tb_L2;Tb_R2];
[Fd_L1,Fd_L2,Fd_R1,Fd_R2,Md_real,exitflag_Fd]  = func_QPA_CDC(VehiclePara,InitialParams,VehStateMeasured,Md_next,Fdu,Fdl,MPCParameters.Verbose);
InitialParams.prevstate.Fd = [Fd_L1;Fd_R1;Fd_L2;Fd_R2];
t_Elapsed = 0;

InitialParams = func_ReportStatus(InitialParams, exitflag, PrjP, Vel, t_Elapsed, MPCParameters.Verbose);

eps_out = zeros(4,1);
if length(epsilon_val) >= 8
    eps_out(1) = epsilon_val(1);
    eps_out(2) = epsilon_val(3);
    eps_out(3) = epsilon_val(5);
    eps_out(4) = epsilon_val(7);
end

Npdc = 6;
[LTR_real, LTR_calc, LTR_Npdc] = func_LTRDiagnosis( ...
        VehiclePara, MPCParameters, VehStateMeasured, ParaHAT, ...
        Y, x_opt, exitflag, AI, Ut, Md_next, Npdc);

sys = [ Tb_L1;  Tb_L2;  Tb_R1;  Tb_R2;
        Fd_L1;  Fd_L2;  Fd_R1;  Fd_R2;
        Steer_Wheel;
        eps_out(1);
        eps_out(2);
        eps_out(3);
        eps_out(4);
        rho_val(1);
        rho_val(2);
        rho_val(3);
        MFxmax; MFx_next; -MFxmax;
        Mdmax;  Md_next;   Mdmin;
        Fyfmax; Fyf_next; -Fyfmax;
        r_ssmax; yawrate; -r_ssmax;
        LTR_real;
        LTR_Npdc;
        Vel*3.6;
        Vset_pid;
        PrjP.yr;sqrt(Vel^2+Vy^2);LTR;(rad2deg(alpha_l2)+rad2deg(alpha_r2))/2;rad2deg(VehStateMeasured.Yaw);VehStateMeasured.beta;
        VehiclePara.CafTan;
        VehiclePara.CarTan;
        ParaHAT.Roll;
        ParaHAT.Rollrate;
        ParaHAT.Fx_l1;ParaHAT.Fx_l2;ParaHAT.Fx_r1;ParaHAT.Fx_r2;
        ParaHAT.Fy_l1;ParaHAT.Fy_l2;ParaHAT.Fy_r1;ParaHAT.Fy_r2;
        ParaHAT.Fz_l1;ParaHAT.Fz_l2;ParaHAT.Fz_r1;ParaHAT.Fz_r2;
        ];

St.InitialParams = InitialParams;
St.WarmStart = WarmStart;
St.rho = rho;
St.VehiclePara = VehiclePara;
St.Constraints = Constraints;
end
