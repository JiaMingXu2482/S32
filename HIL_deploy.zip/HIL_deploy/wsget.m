function v = wsget(name, dflt)
%WSGET  Read one run-configuration value (CarSim dataset > base workspace > default).
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
runall = '';
try
    par = fullfile(func_CarSimResDir(), 'Run_all.par');
    if exist(par,'file') == 2
        runall = fileread(par);
    end
catch
end
if ~isempty(runall)
    tok = regexp(runall, ['(?m)^\s*(?:DEFINE_PARAMETER\s+)?' name '\s*=\s*([-\d.eE+]+)'], ...
                 'tokens', 'once');
    if ~isempty(tok)
        v = str2double(tok{1});
        if ~isnan(v), return; end
    end
end
if evalin('base', ['exist(''' name ''',''var'')'])
    v = evalin('base', name);
else
    v = dflt;
end
