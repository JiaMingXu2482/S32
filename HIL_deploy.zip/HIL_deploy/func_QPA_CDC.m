function [Fd_L1,Fd_L2,Fd_R1,Fd_R2,Md_real,exitflag_Fd] = func_QPA_CDC( ...
    VehiclePara,InitialParams,VehStateMeasured,MFd,Fdu,Fdl,verbose)
%FUNC_QPA_CDC  Lower-level allocation QP for the MR semi-active suspension.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

    df = VehiclePara.ldf;
    dr = VehiclePara.ldr;

    Vd_L1 = VehStateMeasured.V_l1;
    Vd_R1 = VehStateMeasured.V_r1;
    Vd_L2 = VehStateMeasured.V_l2;
    Vd_R2 = VehStateMeasured.V_r2;

    rho = 0.005;

    Bd = 0.5 * [ -df,  df,  -dr,  dr ];

    Fdu = Fdu(:);
    Fdl = Fdl(:);
    lb = min(Fdl, Fdu);
    ub = max(Fdl, Fdu);

    if isfield(InitialParams, 'prevstate') && isfield(InitialParams.prevstate, 'Fd') ...
            && ~isempty(InitialParams.prevstate.Fd)
        x0 = InitialParams.prevstate.Fd(:);
        if numel(x0) ~= 4
            x0 = zeros(4,1);
        end
    else
        x0 = zeros(4,1);
    end
    x0 = min(max(x0, lb), ub);

    spn = max(ub - lb, 1);
    Wd  = (mean(spn) ./ spn).^2;
    Wd  = Wd / mean(Wd);
    Gamma_d = diag(Wd);

    rho_c = 0.05;

    H = 2 * (Bd' * Bd + rho * Gamma_d + rho_c * eye(4));
    f = -2 * (Bd' * MFd + rho_c * x0);

    [Fd, st_, ~] = func_QPKwik(H, f, zeros(0,4), zeros(0,1), lb, ub, 200, false);
    if st_ > 0, exitflag_Fd = 1; else, exitflag_Fd = st_ - 10; end

    if exitflag_Fd <= 0 || any(~isfinite(Fd))
        if verbose
            fprintf(2, 'func_QPA_CDC: MR damper allocation QP failed; returning zeros\n');
        end
        Fd = zeros(4,1);
        exitflag_Fd = -1;
    end

    Fd_L1 = Fd(1);
    Fd_R1 = Fd(2);
    Fd_L2 = Fd(3);
    Fd_R2 = Fd(4);

    Md_real = Bd * Fd;

end
