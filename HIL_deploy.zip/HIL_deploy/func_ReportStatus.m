function InitialParams = func_ReportStatus(InitialParams, exitflag, PrjP, Vel, t_Elapsed, verbose)
%FUNC_REPORTSTATUS  QP status counters and error tracking; optional per-step printing.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
%
%   verbose = 0 keeps the counters but prints nothing. Required for codegen:
%   the flag comes from MPCParameters, which is a compile-time constant, so
%   the whole printing branch is folded away when it is 0.

switch exitflag
    case  1, InitialParams.failed_num.solve      = InitialParams.failed_num.solve      + 1;
    case  0, InitialParams.failed_num.conv       = InitialParams.failed_num.conv       + 1;
    case -2, InitialParams.failed_num.unsolved   = InitialParams.failed_num.unsolved   + 1;
    case -3, InitialParams.failed_num.NaN_or_Inf = InitialParams.failed_num.NaN_or_Inf + 1;
    otherwise
             InitialParams.failed_num.else       = InitialParams.failed_num.else       + 1;
end

InitialParams.n_solve = InitialParams.n_solve + 1;
if InitialParams.n_solve <= numel(InitialParams.t_solve)
    InitialParams.t_solve(InitialParams.n_solve) = t_Elapsed;
end

if InitialParams.n_solve <= numel(InitialParams.ey_hist)
    InitialParams.ey_hist(InitialParams.n_solve)   = PrjP.ey;
    InitialParams.epsi_hist(InitialParams.n_solve) = PrjP.epsi;
end

if abs(PrjP.ey)   >= abs(InitialParams.emax.y)
    InitialParams.emax.y   = abs(PrjP.ey);
end
if abs(PrjP.epsi) >= abs(InitialParams.emax.psi)
    InitialParams.emax.psi = abs(PrjP.epsi);
end

if verbose
    fprintf(['Vel: %.0f\nMPC solve %.0f ms, sim %.2f s\n' ...
             'max ey: %.2f m, max epsi: %.2f deg\n' ...
             'solved:%.0f notconv:%.0f infeas:%.0f NaNInf:%.0f other:%.0f\n'], ...
             Vel*3.6, t_Elapsed, InitialParams.InitialGapflag*0.01, ...
             InitialParams.emax.y, rad2deg(InitialParams.emax.psi), ...
             InitialParams.failed_num.solve, InitialParams.failed_num.conv, ...
             InitialParams.failed_num.unsolved, InitialParams.failed_num.NaN_or_Inf, ...
             InitialParams.failed_num.else);
end

end
