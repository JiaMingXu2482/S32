function [delta_out, delta_wheel] = func_AFS(VehiclePara, VehStateMeasured, MPCParameters, ParaHAT, delta_total)
%FUNC_AFS  Active front steering command from the upper-level MPC solution.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
isw = VehiclePara.isw;
delta_wheel = delta_total;
delta_sw    = max(min(isw*delta_wheel, deg2rad(720)), -deg2rad(720));
delta_out   = rad2deg(delta_sw);
end
