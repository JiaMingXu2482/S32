# HIL 部署包 (R2018a + NI VeriStand)

整个文件夹拷到部署机任意目录即可, 没有对路径的依赖。

## 步骤

### 1. 初始化(必须第一步)

在 MATLAB R2018a 里 `cd` 到本目录, 然后:

```
hil_init
```

它会把控制器设成 ③ 本文 PMPC、关掉每拍打印、跑 `setup_pmpc` 生成工作区变量
`PMPC_P`, 最后打一份核对清单。**确认打印的是"③ 本文 PMPC"再往下走。**

> ⚠️ 不要直接跑 `setup_pmpc`。它靠读 CarSim 的 `simfile.sim` 认数据集名来选
> 控制器, 部署机没有 CarSim, 读不到就**静默退回 baseline MPC**, 不是本文方法。

### 2. 打开模型

```
open_system('pmpc_hil')
```

结构:

```
In_* x50 (标量 Inport) --> Mux(50) --> PMPC_MF --> Selector(18) --> Demux
                                                                          |
                                                     Out_* x18 <----------+
                                                                        +--> PID vel --> Out_* x2
```

> ⚠️ **如果你手上已经有一份换好 NI In 的旧 pmpc_hil.slx**(2026-09-18 之前
> 生成的, 喂给 PMPC_MF 的 Mux 是 62 口 + 一个常数 0), **不要用本包里这份覆盖它**,
> 否则 50 个 NI In 要重换一遍。把本包的 .m 拷过去, 然后在那份旧模型上跑一次:

```
hil50
```

它顺着连线找 NI In(**不看块名**), 把 Mux(62)+常数 0 换成 Mux(50), 上游一个不动。
重复跑没事, 已经是 50 口就直接返回。

### 3. 换 NI In / NI Out

50 个 Inport 和 20 个 Outport 都是**独立标量端口**, 逐个换成 NI VeriStand
模块库里的 `NI In` / `NI Out` 即可。对应关系见 `PORTMAP_HIL.md`,
或直接用 `portmap_hil_in.csv` / `portmap_hil_out.csv`。

**端口号即映射顺序** —— `In_*` 的 Port 属性是 1..50, `Out_*` 是 1..20,
和两个 csv 的行号一一对应。换的时候保持端口号不变就不会错位。

端口名带 `In_` / `Out_` 前缀是因为 Simulink 要求同层块名唯一, 而
`Fd_L1..R2`(减振器实测力 vs MR 指令力)和 `Vx` 在输入输出里都重名。

### 4. 配代码生成

| 项 | 值 |
|---|---|
| System target file | `NIVeriStand.tlc` |
| Language | `C++` |
| Template makefile | `NIVeriStand_vc.tmf` |
| Make command | `make_rtw` |

本机(R2024b)没装 NI 目标, 所以包里的模型是 `ode1` + `TargetLang=C++`,
系统目标文件还是默认的, 需要你在部署机上改。

### 5. 生成代码

Ctrl+B 或 `rtwbuild('pmpc_hil')`。

---

## 已知问题

### 求解器: 目前是 ode1, 不是 FixedStepDiscrete

`PID velocity control` 子系统里的 `Int_I` 是**连续** Integrator, 有连续状态,
`FixedStepDiscrete` 会直接拒绝:

```
Simulink:Engine:InvalidSolver
"FixedStepDiscrete" 求解器不能用于仿真模块图, 因为它包含连续状态
```

`ode1`(定步长显式欧拉)能生成代码也能上实时目标, 且行为与桌面模型
(ode3 @1ms)最接近。若要对齐纯离散, 把 `Int_I` 换成 Discrete-Time Integrator
(Forward Euler, T=0.001) —— 那会改变纵向 PID 的数值, 需要单独验收。

### R2018a 的类型推断比 R2024b 弱

所有 codegen 结论都是在 R2024b 上得到的。若 `PMPC_MF` 报
**"无法确定输出大小和/或类型"**, 先查块里数据对象 `PMPC_P` 的
**`Tunable` 是不是 `false`** —— 这是块层面的 `coder.Constant`,
不设的话 `nvars = Nu*Nc+Ne+Nr` 这类维度会退回运行时值, 数组尺寸就推不出来。
(开发阶段踩过一次。)

其他类型推断报错请把信息发回来。

---

## 时序

| | |
|---|---|
| 模型基频 `FixedStep` | 0.001 s (= VeriStand 1000 Hz) |
| `PMPC_MF` 采样时间 | 0.01 s (= 10 ms 控制周期) |

`PMPC_MF` 的采样时间**必须显式设**, 不能继承: 它内部用 `persistent` 保存跨拍
状态, 而带 `persistent` 的 MATLAB Function 块在连续采样时间下非法
(`Stateflow:Runtime:IllegalPersistentVarInContinuousTimeChart`)。
它是 chart 对象的属性(`ChartUpdate`/`SampleTime`), 不是块参数。

实时性预算: 一拍全部运算(含两个分配 QP)必须 < 10 ms。开发机上解释执行是
22~29 ms/拍, 生成 C++ 后应该快一个量级, 但**生成代码后要实测**。
