function [VehStatemeasured, HATParameter] = func_StateEstimation(ModelInput,VehiclePara)
%FUNC_STATEESTIMATION  Unpack the 50 plant measurements into the state structs (index = CarSim export channel).
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    g = 9.81;
VehStatemeasured = struct('V_l1',0, 'V_l2',0, 'V_r1',0, 'V_r2',0, 'X',0, 'Y',0, 'x_dot',0, 'y_dot',0, 'Yaw',0, 'Yawrate',0, 'Yawaccel',0, 'beta',0, 'delta_l',0, 'delta_r',0, 'Steer_SW',0, 'Ax',0, 'Ay',0, 'omega_L1',0, 'omega_L2',0, 'omega_R1',0, 'omega_R2',0, 'VxTarget',0, 'delta_f',0);
HATParameter = struct('Roll',0, 'Rollrate',0, 'Rollaccel',0, 'alpha_l1',0, 'alpha_l2',0, 'alpha_r1',0, 'alpha_r2',0, 'Fx_l1',0, 'Fx_l2',0, 'Fx_r1',0, 'Fx_r2',0, 'Fy_l1',0, 'Fy_l2',0, 'Fy_r1',0, 'Fy_r2',0, 'Fz_l1',0, 'Fz_l2',0, 'Fz_r1',0, 'Fz_r2',0, 'Fd_L1',0, 'Fd_L2',0, 'Fd_R1',0, 'Fd_R2',0, 'Td_L1',0, 'Td_L2',0, 'Td_R1',0, 'Td_R2',0, 'LTR',0, 'MFx',0, 'Fyf',0, 'Fyr',0, 'Md',0, 'alphaf',0, 'alphar',0, 'Fzf',0, 'Fzr',0, 'Fxf',0, 'Fxr',0);
    VehStatemeasured.V_l1       = ModelInput(1)/1000;
    VehStatemeasured.V_l2       = ModelInput(2)/1000;
    VehStatemeasured.V_r1       = ModelInput(3)/1000;
    VehStatemeasured.V_r2       = ModelInput(4)/1000;
    VehStatemeasured.X       = ModelInput(40);
    VehStatemeasured.Y       = ModelInput(41);
    VehStatemeasured.x_dot   = ModelInput(42)/3.6;
    VehStatemeasured.y_dot   = ModelInput(43)/3.6;
    VehStatemeasured.Yaw     = ModelInput(39)*pi/180;
    VehStatemeasured.Yawrate = ModelInput(34)*pi/180;
    VehStatemeasured.Yawaccel= ModelInput(45);
    HATParameter.Roll        = ModelInput(38)*pi/180;
    HATParameter.Rollrate    = ModelInput(33)*pi/180;
    HATParameter.Rollaccel   = ModelInput(44);
    VehStatemeasured.beta    = ModelInput(37)*pi/180;
    VehStatemeasured.delta_l = ModelInput(46)*pi/180;
    VehStatemeasured.delta_r = ModelInput(47)*pi/180;
    VehStatemeasured.Steer_SW= ModelInput(48);
    VehStatemeasured.Ax      = g*ModelInput(35);
    VehStatemeasured.Ay      = g*ModelInput(36);
    HATParameter.alpha_l1   = ModelInput(5)*pi/180;
    HATParameter.alpha_l2   = ModelInput(6)*pi/180;
    HATParameter.alpha_r1   = ModelInput(7)*pi/180;
    HATParameter.alpha_r2   = ModelInput(8)*pi/180;
    HATParameter.Fx_l1      = round(1000*ModelInput(9))/1000;
    HATParameter.Fx_l2      = round(1000*ModelInput(10))/1000;
    HATParameter.Fx_r1      = round(1000*ModelInput(11))/1000;
    HATParameter.Fx_r2      = round(1000*ModelInput(12))/1000;
    HATParameter.Fy_l1      = round(1000*ModelInput(13))/1000;
    HATParameter.Fy_l2      = round(1000*ModelInput(14))/1000;
    HATParameter.Fy_r1      = round(1000*ModelInput(15))/1000;
    HATParameter.Fy_r2      = round(1000*ModelInput(16))/1000;
    HATParameter.Fz_l1      = round(1000*ModelInput(17))/1000;
    HATParameter.Fz_l2      = round(1000*ModelInput(18))/1000;
    HATParameter.Fz_r1      = round(1000*ModelInput(19))/1000;
    HATParameter.Fz_r2      = round(1000*ModelInput(20))/1000;
    HATParameter.Fd_L1      = round(1000*ModelInput(21))/1000;
    HATParameter.Fd_L2      = round(1000*ModelInput(22))/1000;
    HATParameter.Fd_R1      = round(1000*ModelInput(23))/1000;
    HATParameter.Fd_R2      = round(1000*ModelInput(24))/1000;
    HATParameter.Td_L1      = ModelInput(29);
    HATParameter.Td_L2      = ModelInput(30);
    HATParameter.Td_R1      = ModelInput(31);
    HATParameter.Td_R2      = ModelInput(32);
    VehStatemeasured.omega_L1   = ModelInput(25)*pi/30;
    VehStatemeasured.omega_L2   = ModelInput(26)*pi/30;
    VehStatemeasured.omega_R1   = ModelInput(27)*pi/30;
    VehStatemeasured.omega_R2   = ModelInput(28)*pi/30;
    VehStatemeasured.VxTarget    = ModelInput(49);
    HATParameter.LTR            = ModelInput(50);
    VehStatemeasured.delta_f = 0.5*(ModelInput(46)+ ModelInput(47))*pi/180;
    HATParameter.MFx  = HATParameter.Fx_r1 + HATParameter.Fx_r2 - HATParameter.Fx_l1 - HATParameter.Fx_l2;
    HATParameter.Fyf  = HATParameter.Fy_l1 + HATParameter.Fy_r1;
    HATParameter.Fyr  = HATParameter.Fy_l2 + HATParameter.Fy_r2;
    HATParameter.Md   = (HATParameter.Fd_R1- HATParameter.Fd_L1)*VehiclePara.ldf + (HATParameter.Fd_R2  - HATParameter.Fd_L2 )*VehiclePara.ldr;
    HATParameter.alphaf   = (HATParameter.alpha_l1 + HATParameter.alpha_r1)/2;
    HATParameter.alphar   = (HATParameter.alpha_l2 + HATParameter.alpha_r2)/2;
    HATParameter.Fzf = HATParameter.Fz_l1+HATParameter.Fz_r1;
    HATParameter.Fzr = HATParameter.Fz_l2+HATParameter.Fz_r2;
    HATParameter.Fxf = HATParameter.Fx_l1+HATParameter.Fx_r1;
    HATParameter.Fxr = HATParameter.Fx_l2+HATParameter.Fx_r2;

end

function [alpha] = func_lamda_alpha(VehStatemeasured,VehiclePara)

    vx          = VehStatemeasured.x_dot;
    vy          = VehStatemeasured.y_dot;
    psidot      = VehStatemeasured.phi_dot;
    delta_l     = VehStatemeasured.delta_l;
    delta_r     = VehStatemeasured.delta_r;
    g           = VehiclePara.g;
    lf          = VehiclePara.lf;
    tf          = VehiclePara.tf;
    tr          = VehiclePara.tr;
    lr          = VehiclePara.lr;
    rt          = VehiclePara.rt;

    alpha_fl = atan((vy + psidot * lf) / (vx - tf * psidot / 2)) - delta_l;
    alpha_rl = atan((vy - psidot * lr) / (vx - tr * psidot / 2));
    alpha_fr = atan((vy + psidot * lf) / (vx + tf * psidot / 2)) - delta_r;
    alpha_rr = atan((vy - psidot * lr) / (vx + tr * psidot / 2));
    alpha(1) = alpha_fl; alpha(2) = alpha_rl;
    alpha(4) = alpha_fr; alpha(5) = alpha_rr;

end

function [Fz] = func_Fz(VehStatemeasured,VehiclePara)
    ax      = VehStatemeasured.Ax;
    ay      = VehStatemeasured.Ay;
    m       = VehiclePara.m;
    ms      = VehiclePara.ms;
    g       = VehiclePara.g;
    lf      = VehiclePara.lf;
    L       = VehiclePara.L;
    lr1     = VehiclePara.lr1;
    lm      = VehiclePara.lm;
    lr      = VehiclePara.lr;
    hg      = VehiclePara.hg;
    rt      = VehiclePara.rt;
    Kf      = VehiclePara.Kt;
    kf      = VehiclePara.kf;
    km      = VehiclePara.km;
    kr      = VehiclePara.kr;
    kw      = VehiclePara.kw;
    cf      = VehiclePara.cf;
    cm      = VehiclePara.cm;
    cr      = VehiclePara.cr;
    lsf     = VehiclePara.lsf;
    lsm     = VehiclePara.lsm;
    lsr     = VehiclePara.lsr;
    ldf     = VehiclePara.ldf;
    ldm     = VehiclePara.ldm;
    ldr     = VehiclePara.ldr;
    omega   = VehiclePara.omega;

    h_a1    = 0.432;
    h_a2    = 0.725;
    h_a3    = h_a2;
    h_ar    = (h_a2+h_a3)/2;
    hr      = lf/L*(h_ar-h_a1)+h_a1;
    hs      = hg-hr;
    tf      = 2.07;
    tm      = 2.07;
    tr      = 2.07;

    kef=(kw*cf^2*omega^2+kf*kw*(kw+kf))/(cf^2*omega^2+(kf+kw)^2);
    kem=(kw*cm^2*omega^2+km*kw*(kw+km))/(cm^2*omega^2+(km+kw)^2);
    ker=(kw*cr^2*omega^2+kr*kw*(kw+kr))/(cr^2*omega^2+(kr+kw)^2);

    Kf=kef*lsf^2;
    Km=kem*lsm^2;
    Kr=ker*lsr^2;
    Kt=Kf+Km+Kr;
    Cf=cf*ldf^2;
    Cm=cm*ldm^2;
    Cr=cr*ldr^2;
    Ct=Cf+Cm+Cr;

    Fz_fl_static = m*g*lr1/(2*L);
    Fz_fr_static = Fz_fl_static;
    Fz_ml_static = m*g*lf/(4*L);
    Fz_mr_static = Fz_ml_static;
    Fz_rl_static = m*g*lf/(4*L);
    Fz_rr_static = Fz_rl_static;

    delta_Fz_x_fl = -m*ax*hg/(2*L);
    delta_Fz_x_fr =  delta_Fz_x_fl;
    delta_Fz_x_ml =  m*ax*hg/(4*L);
    delta_Fz_x_mr =  delta_Fz_x_ml;
    delta_Fz_x_rl =  m*ax*hg/(4*L);
    delta_Fz_x_rr =  delta_Fz_x_rl;

    delta_Fz_y_fl = -ay*m/tf*(Kf*hs/(Kt-m*g*hs)+lr1*h_a1/L);
    delta_Fz_y_fr = -delta_Fz_y_fl;
    delta_Fz_y_ml = -(lf*m*ay*h_a2/L+(2*Km*ms*ay*hr)/(Kt-ms*g*hr))/tm;
    delta_Fz_y_mr = -delta_Fz_y_ml;
    delta_Fz_y_rl = -(lf*m*ay*h_a2/L+(2*Kr*ms*ay*hr)/(Kt-ms*g*hr))/tr;
    delta_Fz_y_rr = -delta_Fz_y_rl;

    Fz(1) = Fz_fl_static+delta_Fz_x_fl+delta_Fz_y_fl;
    Fz(2) = Fz_fr_static+delta_Fz_x_fr+delta_Fz_y_fr;
    Fz(3) = Fz_ml_static+delta_Fz_x_ml+delta_Fz_y_ml;
    Fz(4) = Fz_mr_static+delta_Fz_x_mr+delta_Fz_y_mr;
    Fz(5) = Fz_rl_static+delta_Fz_x_rl+delta_Fz_y_rl;
    Fz(6) = Fz_rr_static+delta_Fz_x_rr+delta_Fz_y_rr;
    for i=1:6
        if Fz(i)<0
            Fz(i)=0;
        end
    end

end

function [fx, fy] = func_Tire_force(lambda, alpha, fz)

    fz = fz / 1000;

    b0  =   1.6859;
    b1  =  -0.0017;
    b2  =   0.7591;
    b3  =   0.0126;
    b4  =   6.4557;
    b5  =   0.0017;
    b6  =  -0.0000;
    b7  =   0.0126;
    b8  =  -2.4489;
    b9  =   0;
    b10 =   0;
    A0  =   1.6791;
    A1  =  -0.0030;
    A2  =   0.7194;
    A3  = 358.6829;
    A4  =  98.1203;
    A5  =  -0.2264;
    A6  =  -0.0002;
    A7  =   0.3548;
    A8 = 0;
    A9 = 0;
    A10 = 0;
    A11 = 0;
    A12 = 0;

    C_x = b0 * ones(size(fz));
    D_x = b1 * fz.^2 + b2 * fz;
    B_numerator = b3 * fz.^2 + b4 * fz;
    B_denominator = C_x .* D_x .* exp(b5 * fz);
    B_x = B_numerator ./ B_denominator;
    E_x = b6 * fz.^2 + b7 * fz + b8;
    S_h_x = 0;
    S_v_x = -0.03;
    x_x = abs(lambda) + S_h_x;

    fx_kN_pos = D_x .* sin(C_x .* atan(B_x .* x_x - E_x .* (B_x .* x_x - atan(B_x .* x_x)))) + S_v_x;
    fx_kN = fx_kN_pos .* sign(lambda);

    gamma_rad = 2 * pi / 180 * ones(size(fz));

    alpha_rad = abs(alpha) * pi / 180;

    C_y = A0 * ones(size(fz));
    D_y = A1 * fz.^2 + A2 * fz;
    B_y = A3 * sin(2 * atan(fz ./ A4)) .* (1 - A5 * abs(gamma_rad)) ./ (C_y .* D_y);
    E_y = A6 * fz.^2 + A7;
    S_h_y = 0;
    S_v_y =0;
    x_y = alpha_rad + S_h_y;

    fy_kN_pos = D_y .* sin(C_y .* atan(B_y .* x_y - E_y .* (B_y .* x_y - atan(B_y .* x_y)))) + S_v_y;
    fy_kN = -fy_kN_pos .* sign(alpha);

    fx = fx_kN * 1000;
    fy = fy_kN * 1000;
end
