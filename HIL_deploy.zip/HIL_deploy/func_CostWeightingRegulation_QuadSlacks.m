function [Q,R,S,Wshl,Wact,dFyfmax,dMFxmax,dMdmax,Fyfmax,MFxmax,Mdmax,Mdmin,Tb_u,Fdu,Fdl,Mdnom] = func_CostWeightingRegulation_QuadSlacks(MPCParameters,CostWeights,Constraints,r_ssmax,ParaHAT,VehiclePara,VehStateMeasured)
%FUNC_COSTWEIGHTINGREGULATION_QUADSLACKS  Cost weights and quadratic slack penalties, including the priority variables.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

    Np  = MPCParameters.Np;
    Ny  = MPCParameters.Ny;
    Nu  = MPCParameters.Nu;
    Nc  = MPCParameters.Nc;
    Ts  = MPCParameters.Ts;

    Lf  = VehiclePara.lf;
    Lr  = VehiclePara.lr;
    tf  = VehiclePara.tf;
    tr  = VehiclePara.tr;
    rt  = VehiclePara.rt;
    mu  = VehiclePara.mu;
    isw = VehiclePara.isw;
    d_f = VehiclePara.ldf;
    d_r = VehiclePara.ldr;
    k1  = VehiclePara.k1;
    k2  = VehiclePara.k2;
    b   = VehiclePara.b;
    k3  = VehiclePara.k3;
    v0  = VehiclePara.v0;
    CafHat = VehiclePara.CafHat;
    Fzf = ParaHAT.Fzf;

    Vym     = Constraints.Vymax;
    pm      = Constraints.phimax;
    dpm     = Constraints.dphimax;
    em      = Constraints.emax;
    epm     = Constraints.epsimax;
    ep_r   = max(Constraints.epsilon_alpha, 1e-8);
    ep_ar  = max(Constraints.epsilon_alpha,1e-8);
    ep_ltr = max(Constraints.epsilon_LTR, 1e-8);
    ep_e   = max(Constraints.epsilon_e,   1e-8);

    g_  = VehiclePara.g;
    m_  = VehiclePara.m;
    L_  = Lf + Lr;

    Fzf_st  = m_*g_*Lr/L_;
    Fyf_ref = mu * Fzf_st;

    MFx_ref = min( mu*m_*g_/2, 2*Constraints.Tb_max/rt ) * (tf/2);

    if isfield(Constraints,'Vd_ref') && ~isempty(Constraints.Vd_ref)
        Vd_ref = Constraints.Vd_ref;
    else
        Vd_ref = 0.5;
    end
    dF_ref  = (k2*Vd_ref + b) - k3*Vd_ref;
    Md_ref  = 0.5*(d_f + d_r) * dF_ref;

    if isfield(Constraints,'Vel_ref') && ~isempty(Constraints.Vel_ref)
        Vel_ref = Constraints.Vel_ref;
    else
        Vel_ref = 25;
    end
    r_ref   = mu*g_/Vel_ref;

    Fy_L1 = ParaHAT.Fy_l1;  Fy_R1 = ParaHAT.Fy_r1;
    Fy_L2 = ParaHAT.Fy_l2;  Fy_R2 = ParaHAT.Fy_r2;
    Fz_L1 = ParaHAT.Fz_l1;  Fz_R1 = ParaHAT.Fz_r1;
    Fz_L2 = ParaHAT.Fz_l2;  Fz_R2 = ParaHAT.Fz_r2;

    Td_L1 = ParaHAT.Td_L1;  Td_R1 = ParaHAT.Td_R1;
    Td_L2 = ParaHAT.Td_L2;  Td_R2 = ParaHAT.Td_R2;

    V_fl = VehStateMeasured.V_l1;
    V_fr = VehStateMeasured.V_r1;
    V_rl = VehStateMeasured.V_l2;
    V_rr = VehStateMeasured.V_r2;

    clip = @(x) max(0, x);

    FxfL_u = sqrt( clip((mu*Fz_L1)^2 - Fy_L1^2) );
    FxfR_u = sqrt( clip((mu*Fz_R1)^2 - Fy_R1^2) );
    FxrL_u = sqrt( clip((mu*Fz_L2)^2 - Fy_L2^2) );
    FxrR_u = sqrt( clip((mu*Fz_R2)^2 - Fy_R2^2) );

    Tb_fl_u_fric = FxfL_u * rt;
    Tb_fr_u_fric = FxfR_u * rt;
    Tb_rl_u_fric = FxrL_u * rt;
    Tb_rr_u_fric = FxrR_u * rt;

    Tb_act_cap = Constraints.Tb_max;
    Tb_fl_u_act = Tb_act_cap;
    Tb_fr_u_act = Tb_act_cap;
    Tb_rl_u_act = Tb_act_cap;
    Tb_rr_u_act = Tb_act_cap;

    Tb_fl_u_raw = min(Tb_fl_u_fric, Tb_fl_u_act);
    Tb_fr_u_raw = min(Tb_fr_u_fric, Tb_fr_u_act);
    Tb_rl_u_raw = min(Tb_rl_u_fric, Tb_rl_u_act);
    Tb_rr_u_raw = min(Tb_rr_u_fric, Tb_rr_u_act);

    Tb_fl_max = max(0, Tb_fl_u_raw - max(0, Td_L1));
    Tb_fr_max = max(0, Tb_fr_u_raw - max(0, Td_R1));
    Tb_rl_max = max(0, Tb_rl_u_raw - max(0, Td_L2));
    Tb_rr_max = max(0, Tb_rr_u_raw - max(0, Td_R2));

    Tb_u.Tb_L1 = Tb_fl_max;
    Tb_u.Tb_R1 = Tb_fr_max;
    Tb_u.Tb_L2 = Tb_rl_max;
    Tb_u.Tb_R2 = Tb_rr_max;

    delta  = VehStateMeasured.delta_f;
    if abs(delta) < 0.15
        MFxmax_pos = (tf/(2*rt)) * ( Tb_fl_max + Tb_rl_max );
        MFxmax_neg = (tf/(2*rt)) * ( -Tb_fr_max - Tb_rr_max );
    else
        MFxmax_pos = (tf/(2*rt)) * ( Tb_fl_max*cos(delta) + Tb_rl_max ) ...
                   - (Lf*sin(delta)/rt) * (Tb_fl_max + 0);
        MFxmax_neg = (tf/(2*rt)) * ( -Tb_fr_max*cos(delta) - Tb_rr_max ) ...
                   - (Lf*sin(delta)/rt) * (0 + Tb_fr_max);
    end
    MFxmax = min(abs(MFxmax_pos), abs(MFxmax_neg));
    dMFxmax = MFx_ref * Ts / 0.2;

    Fyfmax  = Constraints.SW_max / isw;
    if isfield(Constraints,'dlt_rate_max') && ~isempty(Constraints.dlt_rate_max)
        dlt_rate = Constraints.dlt_rate_max;
    else
        dlt_rate = deg2rad(300);
    end
    if isfield(MPCParameters,'Ts_exec') && ~isempty(MPCParameters.Ts_exec)
        Ts_r = MPCParameters.Ts_exec;
    else
        Ts_r = Ts;
    end
    dFyfmax = dlt_rate * Ts_r;

    Gu = @(v) sign(v) .* ( (abs(v) <= v0) .* (k1.*abs(v)) + ...
                           (abs(v) >  v0) .* (k2.*abs(v) + b) );
    Gl = @(v) k3 .* v;
    Fdu=zeros(4,1);Fdl=zeros(4,1);
    Fdu(1) = Gu(V_fl);  Fdl(1) = Gl(V_fl);
    Fdu(2) = Gu(V_fr);  Fdl(2) = Gl(V_fr);
    Fdu(3) = Gu(V_rl);  Fdl(3) = Gl(V_rl);
    Fdu(4) = Gu(V_rr);  Fdl(4) = Gl(V_rr);

    Bd_v  = 0.5*[-d_f; d_f; -d_r; d_r];
    Fd_lo = min(Fdl, Fdu);
    Fd_hi = max(Fdl, Fdu);
    Mdmax = sum( max(Bd_v.*Fd_lo, Bd_v.*Fd_hi) );
    Mdmin = sum( min(Bd_v.*Fd_lo, Bd_v.*Fd_hi) );

    if isfield(Constraints,'I_nom') && ~isempty(Constraints.I_nom)
        I_nom = Constraints.I_nom;
    else
        I_nom = 2.0;
    end
    Fd_nom = [func_MRDamper(V_fl, I_nom); func_MRDamper(V_fr, I_nom); ...
              func_MRDamper(V_rl, I_nom); func_MRDamper(V_rr, I_nom)];
    Mdnom  = Bd_v.' * Fd_nom;
    Mdnom  = min(max(Mdnom, min(Mdmin,Mdmax)), max(Mdmin,Mdmax));

    dMdmax = (Md_ref / Constraints.tau_MR) * Ts_r;

    Q1 = CostWeights.Q1/(Vym^2);
    Q2 = CostWeights.Q2/(r_ref^2);
    Q3 = CostWeights.Q3/(pm^2);
    Q4 = CostWeights.Q4/(dpm^2);
    Q5 = CostWeights.Q5/(em^2);
    Q6 = CostWeights.Q6/(epm^2);
    R1 = CostWeights.R1/(dFyfmax^2);
    R2 = CostWeights.R2/(dMFxmax^2);
    R3 = CostWeights.R3/(dMdmax^2);
    S1 = CostWeights.S1/(Fyf_ref^2);
    S2 = CostWeights.S2/(MFx_ref^2);
    S3 = CostWeights.S3/(Md_ref^2);
    W1 = CostWeights.W1/(ep_r^2);
    W2 = CostWeights.W2/(ep_ar^2);
    W3 = CostWeights.W3/(ep_ltr^2);
    W4 = CostWeights.W4/(ep_e^2);
    V1 = CostWeights.V1/1;
    V2 = CostWeights.V2/1;
    V3 = CostWeights.V3/1;

    if isfield(CostWeights,'Qf_scale') && ~isempty(CostWeights.Qf_scale)
        qf = CostWeights.Qf_scale;
    else
        qf = 1;
    end
    Q = zeros(Np*Ny, Np*Ny);
    for i = 1:Np
        r = (i-1)*Ny + (1:Ny);
        if i == Np
            Q(r,r) = qf * diag([Q1, Q2, Q3, Q4, Q5, Q6]);
        else
            Q(r,r) = diag([Q1, Q2, Q3, Q4, Q5, Q6]);
        end
    end
    R = zeros(Nc*Nu, Nc*Nu);
    for i = 1:Nc
        r = (i-1)*Nu + (1:Nu);
        R(r,r) = diag([R1, R2, R3]);
    end
    S = zeros(Nc*Nu, Nc*Nu);
    for i = 1:Nc
        r = (i-1)*Nu + (1:Nu);
        S(r,r) = diag([S1, S2, S3]);
    end

    Wshl =diag([W1, W1, W2, W2, W3, W3, W4, W4]);
    Wact  = diag([V1 V2 V3]);
end
