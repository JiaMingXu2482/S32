function [PSI,THETA,GAMMA,PHI] = func_SystemFurture(MPCParameters, StateSpaceModel, Bezier_SK, dist)
%FUNC_SYSTEMFURTURE  Build the prediction matrices PSI / THETA / PHI.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

Nu = MPCParameters.Nu;
Nc = MPCParameters.Nc;
Np = MPCParameters.Np;
Ny = MPCParameters.Ny;

A_aug_cell = StateSpaceModel.A_aug;
B_aug_cell = StateSpaceModel.B_aug;
D_aug_cell = StateSpaceModel.D_aug;
C_aug      = StateSpaceModel.C_aug;

na = size(A_aug_cell,1);
nd = size(D_aug_cell,2);
PSI   = zeros(Ny*Np, na);
THETA = zeros(Ny*Np, Nu*Nc);
PHI   = zeros(Ny*Np, nd*Np);

Aprod = zeros(na, na, Np);
for p = 1:Np
    if p == 1
        Aprod(:,:,p) = A_aug_cell(:,:,p);
    else
        Aprod(:,:,p) = A_aug_cell(:,:,p) * Aprod(:,:,p-1);
    end
end

for p = 1:Np
    rp = (p-1)*Ny + (1:Ny);
    PSI(rp,:) = C_aug * Aprod(:,:,p);

    for k = 1:Nc
        ck = (k-1)*Nu + (1:Nu);
        if k <= p
            A_pk = eye(na);
            for jj = (k+1):p
                A_pk = A_aug_cell(:,:,jj) * A_pk;
            end
            THETA(rp,ck) = C_aug * A_pk * B_aug_cell(:,:,k);
        end
    end

    for j = 1:Np
        cj = (j-1)*nd + (1:nd);
        if j <= p
            A_pj = eye(na);
            for jj = (j+1):p
                A_pj = A_aug_cell(:,:,jj) * A_pj;
            end
            PHI(rp,cj) = C_aug * A_pj * D_aug_cell(:,:,j);
        end
    end
end

if nargin < 4 || isempty(dist), dist = [0;0]; end
if isempty(Bezier_SK)
    kap = zeros(Np,1);
else
    Bezier_SK = Bezier_SK(:);
    if length(Bezier_SK) >= Np
        kap = Bezier_SK(1:Np);
    else
        kap = [Bezier_SK; zeros(Np-length(Bezier_SK),1)];
    end
end
if nd >= 3
    dist_p = zeros(2, Np);
    nc_ = size(dist,2);
    for q_ = 1:Np
        if nc_ == 1
            dist_p(:,q_) = dist(:,1);
        elseif q_ <= nc_
            dist_p(:,q_) = dist(:,q_);
        else
            dist_p(:,q_) = dist(:,nc_);
        end
    end
    GAMMA = reshape([kap.'; dist_p(1,:); dist_p(2,:)], [], 1);
else
    GAMMA = kap;
end

end
