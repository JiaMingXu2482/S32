function [Pa]=func_VehicleParams(cargo)
%FUNC_VEHICLEPARAMS  Vehicle parameters.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    Pa = struct();
    if nargin < 1 || isempty(cargo)
        cargo = 0;
        if evalin('base', 'exist(''PMPC_CARGO'',''var'')')
            cargo = evalin('base', 'PMPC_CARGO');
        end
    end

    if cargo > 0
        Pa.m    = 2030;
        Pa.ms   = 1760;
        Pa.Iz   = 3742.62;
        Pa.Ix   = 1403.80;
        Pa.h_TL = 0.826076;
        Pa.h_SL = 0.891932;
        Pa.lf   = 1.351444;
    else
        Pa.m    = 1860;
        Pa.ms   = 1590;
        Pa.Iz   = 3438.54;
        Pa.Ix   = 894.4;
        Pa.h_TL = 0.671694;
        Pa.h_SL = 0.720;
        Pa.lf   = 1.246613;
    end
    Pa.L    = 2.95;
    Pa.lr   = Pa.L - Pa.lf;
    Pa.BodyLength = 5;
    Pa.BodyWigdth = 2;
    Pa.Bodydiagonal=sqrt(Pa.BodyLength^2+Pa.BodyWigdth^2);
    Pa.h_RC  = 0.15;
    Pa.h_S2R = Pa.h_SL - Pa.h_RC;
    Pa.tf =1.575;
    Pa.tr = 1.575;
    Pa.lsf = 1.2;
    Pa.lsr = 1.2;
    Pa.ldf = 1.1;
    Pa.ldr = 1.1;
    Pa.If = 1.1;
    Pa.Ir = 1.1;
    Pa.rt = 0.393;
    Pa.isw = 17;
    Pa.kf = 146e3;
    Pa.kr = 46e3;
    Pa.cf = 0;
    Pa.cr = 0;
    Pa.Ct  = Pa.ldf^2*Pa.cf + Pa.ldr^2*Pa.cr;

    Pa.kw = 470e3;

    Pa.Kaux_f = 384*180/pi;
    Pa.Kaux_r = 510*180/pi;
    Kf_susp   = 0.5*Pa.kf*Pa.lsf^2 + Pa.Kaux_f;
    Kr_susp   = 0.5*Pa.kr*Pa.lsr^2 + Pa.Kaux_r;
    Kt_axle   = 0.5*Pa.kw*Pa.tf^2;
    Pa.Kt     = 1/(1/Kf_susp + 1/Kt_axle) ...
              + 1/(1/Kr_susp + 1/Kt_axle);

    Pa.Ct  = 0;
    Pa.g = 9.80665;
    Pa.mu  = 0.4;
    Pa.kd  = 10000;

    Pa.k1 = 14e3;
    Pa.k2 = 1.23e3;
    Pa.b  = 1916;
    Pa.k3 = 8.3e2;
    Pa.v0 = 0.15;
Pa.CbarF  = 0;
Pa.CbarR  = 0;
Pa.CafTan = 0;
Pa.CarTan = 0;

end
