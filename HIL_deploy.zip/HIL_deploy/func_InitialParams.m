function [Pa]=func_InitialParams
%FUNC_INITIALPARAMS  Initial values of all cross-step controller state.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
    Pa = struct();
    Pa.InitialGapflag = 0;
    Pa.WayPoints_IndexPre = 1;

    Pa.failed_num = struct();
    Pa.failed_num.solve = 0;
    Pa.failed_num.conv = 0;
    Pa.failed_num.unsolved = 0;
    Pa.failed_num.NaN_or_Inf = 0;
    Pa.failed_num.else = 0;

    Pa.emax = struct();
    Pa.emax.y = 0;
    Pa.emax.psi = 0;

    Pa.U = zeros(3,1);

    Pa.prevstate = struct();
    Pa.prevstate.sw = 0;
    Pa.prevstate.Fyf = 0;
    Pa.prevstate.MFx = 0;
    Pa.prevstate.Md = 0;
    Pa.prevstate.ey = 0;
    Pa.prevstate.epsi = 0;
    Pa.prevstate.Tb = zeros(4,1);
    Pa.prevstate.Fd = zeros(4,1);
    Pa.prevstate.Vd = zeros(4,1);

    Pa.dr_prev = NaN;
    Pa.dr_rate = 0;
    Pa.prevstate.gamma = [0; 0; 1];
    Pa.prevstate.Vpid  = NaN;
    Pa.prevstate.iA    = false(0,1);
    Pa.t_solve   = zeros(1,20000);
    Pa.n_solve   = 0;
    Pa.ey_hist   = zeros(1,20000);
    Pa.epsi_hist = zeros(1,20000);
end
