function [StateSpaceModel] = func_DynamicalModel(VehiclePara, MPCParameters, VehStateMeasured, Mode, LTV)
%FUNC_DYNAMICALMODEL  Linear time-varying prediction model: augmented A/B/D over the horizon.
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.

P.M   = VehiclePara.m;
P.Ms  = VehiclePara.ms;
P.g   = VehiclePara.g;
P.lf  = VehiclePara.lf;
P.lr  = VehiclePara.lr;
P.Ix  = VehiclePara.Ix;
P.Iz  = VehiclePara.Iz;
P.h_S2R = VehiclePara.h_S2R;
P.Kt  = VehiclePara.Kt;

CbF = VehiclePara.CbarF;
CbR = VehiclePara.CbarR;

Vel     = VehStateMeasured.x_dot;
delta_f = VehStateMeasured.delta_f;

Np = MPCParameters.Np;
Nx = MPCParameters.Nx;
Nu = MPCParameters.Nu;
Ts = MPCParameters.Ts;

Vel_eff = max(abs(Vel), 0.5) * sign(Vel + 1e-6);

C_aug = [eye(Nx) zeros(Nx,Nu)];
StateSpaceModel.C_aug = C_aug;
na_ = Nx + Nu;
StateSpaceModel.A_aug = zeros(na_, na_, Np);
StateSpaceModel.B_aug = zeros(na_, Nu,  Np);
StateSpaceModel.D_aug = zeros(na_, 3,   Np);
StateSpaceModel.off   = zeros(2, Np);
StateSpaceModel.off_valid = false;

if nargin < 5 || isempty(LTV)
    [A,B,D] = local_ABD(P, CbF, CbR, Vel_eff, cos(delta_f));
    [~,~,~, Aa,Ba,Da] = local_disc(A,B,D,Ts,Mode,Nx,Nu);
    for i = 1:Np
        StateSpaceModel.A_aug(:,:,i) = Aa;
        StateSpaceModel.B_aug(:,:,i) = Ba;
        StateSpaceModel.D_aug(:,:,i) = Da;
    end
    return
end

lf = P.lf;  lr = P.lr;
x   = LTV.x0(:);
u   = LTV.u0(:);
off = zeros(2, Np);
kap = LTV.kap(:);
if numel(kap) < Np, kap = [kap; zeros(Np-numel(kap),1)]; end
nDU = size(LTV.dU, 2);
kf  = LTV.Ctan_floor_frac;
dr  = LTV.delta_robot(:);
if numel(dr) == 1
    dr = repmat(dr, Np, 1);
elseif numel(dr) < Np
    dr = [dr; repmat(dr(end), Np-numel(dr), 1)];
end

for i = 1:Np
    if i <= nDU
        u = u + LTV.dU(:,i);
    end
    dtot = dr(i) + u(1);

    af = (x(1) + lf*x(2))/Vel_eff - dtot;
    ar = (x(1) - lr*x(2))/Vel_eff;

    [fbf, cbf] = func_TireTable('eval', LTV.TireF, af, LTV.Fzf);
    [fbr, cbr] = func_TireTable('eval', LTV.TireR, ar, LTV.Fzr);
    cbf = -max(abs(cbf), kf*LTV.TireF.C0);
    cbr = -max(abs(cbr), kf*LTV.TireR.C0);

    off(1,i) = fbf - cbf*af - cbf*dr(i);
    off(2,i) = fbr - cbr*ar;

    [A,B,D] = local_ABD(P, cbf, cbr, Vel_eff, cos(dtot));
    [Ad,Bd,Dd, Aa,Ba,Da] = local_disc(A,B,D,Ts,Mode,Nx,Nu);
    StateSpaceModel.A_aug(:,:,i) = Aa;
    StateSpaceModel.B_aug(:,:,i) = Ba;
    StateSpaceModel.D_aug(:,:,i) = Da;

    x = Ad*x + Bd*u + Dd*[kap(i); off(1,i); off(2,i)];
end
StateSpaceModel.off = off;
StateSpaceModel.off_valid = true;

end

function [A,B,D] = local_ABD(P, CbF, CbR, Ve, cd)
M=P.M; Ms=P.Ms; g=P.g; lf=P.lf; lr=P.lr; Ix=P.Ix; Iz=P.Iz;
h=P.h_S2R; Kt=P.Kt;

A11 = (CbF*cd + CbR)/(M*Ve);
A12 = (CbF*lf*cd - CbR*lr)/(M*Ve) - Ve;
A21 = (lf*CbF*cd - lr*CbR)/(Iz*Ve);
A22 = (lf^2*CbF*cd + lr^2*CbR)/(Iz*Ve);
A41 = (Ms*h*(CbF*cd + CbR))/(M*Ix*Ve);
A42 = (Ms*h*(CbF*lf*cd - CbR*lr))/(M*Ix*Ve);
A43 = (Ms*g*h - Kt)/Ix;

A = [ A11  A12  0    0  0   0;
      A21  A22  0    0  0   0;
      0    0    0    1  0   0;
      A41  A42  A43  0  0   0;
      1    0    0    0  0   Ve;
      0    1    0    0  0   0 ];

B = [ -CbF*cd/M        0       0;
      -lf*CbF*cd/Iz    1/Iz    0;
       0               0       0;
      -(Ms*h*CbF*cd)/(M*Ix)  0  -1/Ix;
       0               0       0;
       0               0       0 ];

D = [ 0,     cd/M,               1/M;
      0,     lf*cd/Iz,          -lr/Iz;
      0,     0,                  0;
      0,     Ms*h*cd/(M*Ix),     Ms*h/(M*Ix);
      0,     0,                  0;
     -Ve,    0,                  0 ];
end

function [Ad,Bd,Dd, Aa,Ba,Da] = local_disc(A,B,D,T,Mode,Nx,Nu)
switch Mode
    case 1
        Ad = eye(Nx) + T*A;   Bd = T*B;   Dd = T*D;
        Aa = [Ad Bd; zeros(Nu,Nx) eye(Nu)];
        Ba = [Bd; eye(Nu)];
        Da = [Dd; zeros(Nu,size(D,2))];
    case 2
        A2 = A*A;  A3 = A2*A;  A4 = A3*A;
        c2 = T^2/2;  c3 = T^3/6;  c4 = T^4/24;
        Ad = eye(Nx) + T*A + c2*A2 + c3*A3 + c4*A4;
        Bd = T*B + c2*(A*B) + c3*(A2*B) + c4*(A3*B);
        Dd = T*D + c2*(A*D) + c3*(A2*D) + c4*(A3*D);
        Aa = [Ad Bd; zeros(Nu,Nx) eye(Nu)];
        Ba = [Bd; eye(Nu)];
        Da = [Dd; zeros(Nu,size(D,2))];
    case 3
        Af  = eye(Nx) + T*A + (T^2/2)*A^2;
        Bf1 = B*T + A*B*T^2/2;
        Bf2 = B*T/2;
        Bf  = Bf1 - Bf2;
        Df  = D*T + A*D*T^2/2;
        Ad = Af;  Bd = Bf + Bf2;  Dd = Df;
        Aa = [Af (Bf + Bf2); zeros(Nu,Nx) eye(Nu)];
        Ba = [(Bf + 2*Bf2); eye(Nu)];
        Da = [Df; zeros(Nu,size(D,2))];
    otherwise
        error('func_DynamicalModel: invalid Mode=%d. Use 1(Euler),2(Taylor4),3(FOH).', Mode);
end
end
