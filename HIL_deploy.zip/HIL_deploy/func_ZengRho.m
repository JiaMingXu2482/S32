function [rho, I_ind, I_beta, I_r, bL, bR, r_max] = func_ZengRho(Vx, mu, delta_f, beta, r, g)
%FUNC_ZENGRHO  Zeng 2025 stability indicator rho (comparison method).
%
%   Part of the PMPC HIL deployment package (MATLAB R2018a + NI VeriStand).
%   Comments were stripped when this package was generated; the full design
%   notes live in the development copy of the project.
persistent DB
if isempty(DB)
    DB = coder.load('ZengSaddleDB_SUV.mat');
end

Vx = max(abs(Vx), 1);
bL = local_interp3(DB, DB.betaL, mu, Vx*3.6, rad2deg(delta_f));
bR = local_interp3(DB, DB.betaR, mu, Vx*3.6, rad2deg(delta_f));

r_max = mu*g/Vx;   r_min = -r_max;
I_r   = local_idx(r, r_min, r_max);

if (bR - bL) <= 1e-8
    I_beta = Inf;
else
    I_beta = local_idx(beta, bL, bR);
end

I_ind = max(I_beta, I_r);
if     I_ind <= 0.7,  rho = 0;
elseif I_ind >= 1.0,  rho = 1;
else,                 rho = 0.5*(1 - cos(pi*(I_ind - 0.7)/0.3));
end
end

function I = local_idx(x, lo, hi)
w = hi - lo;
if w <= 1e-12, I = Inf; return; end
d1 = hi - x;  d2 = x - lo;
I = 1 - 2*sign(d1*d2)*min(abs(d1), abs(d2))/w;
end

function v = local_interp3(DB, A, mu, Vkmh, ddeg)
[i1,i2,t1] = local_ax(DB.mu_grid,       mu);
[j1,j2,t2] = local_ax(DB.V_grid_kmh,    Vkmh);
[k1,k2,t3] = local_ax(DB.delta_grid_deg,ddeg);
v = 0;
for a = 0:1
    for b = 0:1
        for c = 0:1
            ii = i1*(1-a) + i2*a;   wa = (1-t1)*(1-a) + t1*a;
            jj = j1*(1-b) + j2*b;   wb = (1-t2)*(1-b) + t2*b;
            kk = k1*(1-c) + k2*c;   wc = (1-t3)*(1-c) + t3*c;
            v = v + wa*wb*wc*A(ii,jj,kk);
        end
    end
end
end

function [i1,i2,t] = local_ax(gr, x)
n = numel(gr);
if x <= gr(1),   i1=1;   i2=1;   t=0; return; end
if x >= gr(n),   i1=n;   i2=n;   t=0; return; end
idx_ = find(gr <= x, 1, 'last');
if isempty(idx_), i1 = 1; else, i1 = idx_(1); end
i2 = min(i1+1, n);
if i2 == i1, t = 0; else, t = (x - gr(i1))/(gr(i2) - gr(i1)); end
end
