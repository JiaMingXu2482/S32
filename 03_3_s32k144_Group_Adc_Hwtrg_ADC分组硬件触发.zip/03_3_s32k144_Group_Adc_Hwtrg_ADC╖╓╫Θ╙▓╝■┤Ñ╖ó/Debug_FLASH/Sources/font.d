Sources/font.o: ../Sources/font.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/include/font.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/include/font.h:
