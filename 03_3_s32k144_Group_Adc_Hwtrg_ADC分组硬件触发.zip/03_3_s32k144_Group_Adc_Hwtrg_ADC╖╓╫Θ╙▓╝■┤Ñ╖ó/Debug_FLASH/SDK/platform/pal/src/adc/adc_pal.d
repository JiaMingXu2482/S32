SDK/platform/pal/src/adc/adc_pal.o: ../SDK/platform/pal/src/adc/adc_pal.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/Generated_Code/adc_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/adc_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/src/adc/adc_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/trgmux_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pdb_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/callbacks.h \
 ../SDK/platform/pal/src/adc/adc_irq.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/rtos/osif/osif.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/Generated_Code/adc_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/adc_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/src/adc/adc_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/trgmux_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pdb_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/callbacks.h:

../SDK/platform/pal/src/adc/adc_irq.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/pal/inc/adc_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/rtos/osif/osif.h:
