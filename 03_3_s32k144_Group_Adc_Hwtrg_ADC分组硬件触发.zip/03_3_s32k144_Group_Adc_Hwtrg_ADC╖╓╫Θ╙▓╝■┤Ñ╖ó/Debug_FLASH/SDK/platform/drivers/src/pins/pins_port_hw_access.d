SDK/platform/drivers/src/pins/pins_port_hw_access.o: \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.c \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h

../SDK/platform/drivers/src/pins/pins_port_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h:
