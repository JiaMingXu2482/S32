SDK/platform/drivers/src/pdb/pdb_hw_access.o: \
 ../SDK/platform/drivers/src/pdb/pdb_hw_access.c \
 ../SDK/platform/drivers/src/pdb/pdb_hw_access.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pdb_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/platform/drivers/src/pdb/pdb_hw_access.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/pdb_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/drivers/inc/clock.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Group_Adc_Hwtrg/SDK/platform/devices/status.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_group_adc_hwtrg\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
