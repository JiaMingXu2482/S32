SDK/platform/pal/src/ic/ic_irq.o: ../SDK/platform/pal/src/ic/ic_irq.c \
 ../SDK/platform/pal/src/ic/ic_irq.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/pal/inc/ic_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/Generated_Code/ic_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_ic_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_common.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/callbacks.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_mc_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/pal/src/ic/ic_irq.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/pal/inc/ic_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/Generated_Code/ic_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_ic_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_common.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/devices/callbacks.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/ftm_mc_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_reva3_Demo_IC_DUTYCYCLE/SDK/platform/drivers/inc/interrupt_manager.h:
