SDK/platform/pal/src/spi/spi_pal.o: ../SDK/platform/pal/src/spi/spi_pal.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/pal/inc/spi_pal.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/Generated_Code/spi_pal_cfg.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/pal/inc/spi_pal_mapping.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/callbacks.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_master_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_shared_function.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/clock.h \
 c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_spi\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_slave_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio_spi_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/pal/inc/spi_pal.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/Generated_Code/spi_pal_cfg.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/pal/inc/spi_pal_mapping.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/devices/callbacks.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_master_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_shared_function.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/clock.h:

c:\users\administrator\workspaces32ds.arm.2.2\s32k144_demo_spi\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/lpspi_slave_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio_spi_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_SPI/SDK/platform/drivers/inc/flexio.h:
