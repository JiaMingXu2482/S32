Sources/font.o: ../Sources/font.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_ClockManager/include/font.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_ClockManager/include/font.h:
