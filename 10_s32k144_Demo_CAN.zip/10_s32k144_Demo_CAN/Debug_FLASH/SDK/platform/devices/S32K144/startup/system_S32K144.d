SDK/platform/devices/S32K144/startup/system_S32K144.o: \
 ../SDK/platform/devices/S32K144/startup/system_S32K144.c \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h \
 ../SDK/platform/devices/S32K144/startup/system_S32K144.h

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h:

../SDK/platform/devices/S32K144/startup/system_S32K144.h:
