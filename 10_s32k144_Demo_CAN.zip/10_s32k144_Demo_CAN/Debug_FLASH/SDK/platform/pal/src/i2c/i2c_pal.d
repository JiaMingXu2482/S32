SDK/platform/pal/src/i2c/i2c_pal.o: ../SDK/platform/pal/src/i2c/i2c_pal.c \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c_pal_cfg.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal_mapping.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpi2c_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/rtos/osif/osif.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/callbacks.h

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c_pal_cfg.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal_mapping.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpi2c_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/rtos/osif/osif.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/callbacks.h:
