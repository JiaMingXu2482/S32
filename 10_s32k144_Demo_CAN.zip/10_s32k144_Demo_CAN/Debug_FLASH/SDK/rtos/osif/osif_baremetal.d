SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock_manager.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock.h \
 d:\s32\10_s32k144_demo_can\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock_manager.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock.h:

d:\s32\10_s32k144_demo_can\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
