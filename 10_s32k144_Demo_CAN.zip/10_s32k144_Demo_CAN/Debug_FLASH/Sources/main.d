Sources/main.o: ../Sources/main.c \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/Cpu.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h \
 d:\s32\10_s32k144_demo_can\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/rtos/osif/osif.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpuart_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/callbacks.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c_pal_cfg.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal_mapping.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpi2c_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/can_pal.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal_cfg.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/can_pal_mapping.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/flexcan_driver.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/pin_mux.h \
 D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/pins_driver.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/clockMan1.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/Cpu.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/dmaController1.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/lpuart1.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c1.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal0.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal1.h \
 D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal2.h \
 D:/S32/10_s32k144_Demo_CAN/include/uart.h \
 D:/S32/10_s32k144_Demo_CAN/include/delay.h \
 D:/S32/10_s32k144_Demo_CAN/include/app.h \
 D:/S32/10_s32k144_Demo_CAN/include/wdog.h \
 D:/S32/10_s32k144_Demo_CAN/include/hil_timer.h

D:/S32/10_s32k144_Demo_CAN/Generated_Code/Cpu.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/device_registers.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/common/s32_core_cm4.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/devassert.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/clock.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/status.h:

d:\s32\10_s32k144_demo_can\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/rtos/osif/osif.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpuart_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/interrupt_manager.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/edma_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/callbacks.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c_pal_cfg.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/i2c_pal_mapping.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/lpi2c_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/can_pal.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal_cfg.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/pal/inc/can_pal_mapping.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/flexcan_driver.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/devices/S32K144/startup/system_S32K144.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/pin_mux.h:

D:/S32/10_s32k144_Demo_CAN/SDK/platform/drivers/inc/pins_driver.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/clockMan1.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/Cpu.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/dmaController1.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/lpuart1.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/i2c1.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal0.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal1.h:

D:/S32/10_s32k144_Demo_CAN/Generated_Code/can_pal2.h:

D:/S32/10_s32k144_Demo_CAN/include/uart.h:

D:/S32/10_s32k144_Demo_CAN/include/delay.h:

D:/S32/10_s32k144_Demo_CAN/include/app.h:

D:/S32/10_s32k144_Demo_CAN/include/wdog.h:

D:/S32/10_s32k144_Demo_CAN/include/hil_timer.h:
