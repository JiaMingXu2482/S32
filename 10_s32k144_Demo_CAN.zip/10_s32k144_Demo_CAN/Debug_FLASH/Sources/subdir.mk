################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Sources/app.c \
../Sources/can_cmd.c \
../Sources/delay.c \
../Sources/font.c \
../Sources/hil_timer.c \
../Sources/key.c \
../Sources/main.c \
../Sources/oled.c \
../Sources/sys_cfg.c \
../Sources/uart.c \
../Sources/wdog.c 

OBJS += \
./Sources/app.o \
./Sources/can_cmd.o \
./Sources/delay.o \
./Sources/font.o \
./Sources/hil_timer.o \
./Sources/key.o \
./Sources/main.o \
./Sources/oled.o \
./Sources/sys_cfg.o \
./Sources/uart.o \
./Sources/wdog.o 

C_DEPS += \
./Sources/app.d \
./Sources/can_cmd.d \
./Sources/delay.d \
./Sources/font.d \
./Sources/hil_timer.d \
./Sources/key.d \
./Sources/main.d \
./Sources/oled.d \
./Sources/sys_cfg.d \
./Sources/uart.d \
./Sources/wdog.d 


# Each subdirectory must supply rules for building sources it contributes
Sources/%.o: ../Sources/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@Sources/app.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


