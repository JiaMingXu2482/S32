/*
 * hil_timer.h
 * 100Hz控制节拍: LPIT0通道0, 10ms周期中断 (寄存器级配置, 不依赖SDK定时器驱动)
 */
#ifndef HIL_TIMER_H
#define HIL_TIMER_H

#include <stdint.h>

/* 节拍标志与计数, 在 LPIT0_Ch0_IRQHandler 里更新, 主循环里消费 */
extern volatile uint8_t  g_hil_tick;
extern volatile uint32_t g_hil_tick_cnt;

/* 初始化LPIT0通道0。
 * 时钟源选 FIRC 48MHz (clockMan1配置里FIRC已使能),
 * 若你的时钟配置不同, 改 HIL_TIMER_SRC_PCS / HIL_TIMER_TVAL。 */
void HIL_TimerInit(void);

#endif /* HIL_TIMER_H */
