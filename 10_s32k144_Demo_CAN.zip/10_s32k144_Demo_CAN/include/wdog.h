/*
 * wdog.h
 * S32K144 硬件看门狗 (WDOG) 应用层封装
 *
 * 为什么需要看门狗:
 *   程序跑飞/死循环/某拍计算卡住时, 主循环不再喂狗,
 *   看门狗超时后直接复位MCU, 让控制器回到已知安全状态。
 *   这是控制器应用层的标配, 不是可选项。
 */
#ifndef WDOG_H
#define WDOG_H

#include <stdint.h>

/* 配置并使能看门狗。
 * timeout_ms: 超时时间(毫秒)。超时前必须调一次 WDOG_Feed()。
 * 时钟源固定用 LPO 128kHz (任何时钟配置下都常开, 不依赖外部晶振/PLL)。
 * 注意: 调试模式下看门狗自动暂停 (CS[DBG]=0), 方便单步调试不被复位。 */
void WDOG_Init(uint32_t timeout_ms);

/* 喂狗: 刷新看门狗计数器。必须在超时前周期性调用,
 * 正常放在 10ms 快任务的末尾。 */
void WDOG_Feed(void);

/* 上次复位是不是看门狗引起的 (读 RCM->SRS[WDOG])。
 * 返回 1 = 是, 0 = 否(上电/调试器/复位脚等)。 */
uint8_t WDOG_WasWdogReset(void);

#endif /* WDOG_H */
