/*
 * can_cmd.h
 * CAN远程命令: 让宿舍远程调试时, 不用跑到实验室去按板子上的按键。
 *
 * 协议 (CAN0, 500kbps, 标准帧):
 *   ID   = 0x10
 *   DLC  >= 1 (8字节也行, 只看data[0])
 *   data[0] bit0 = 1 : 翻转LED2一次 (等价于"按一次KEY1", 请用单次发送)
 *   data[0] bit1 = 1 : 停止喂狗 (等价于"按住KEY2")
 *   data[0] bit1 = 0 : 恢复喂狗 (等价于"松开KEY2")
 *   data[0] bit2 = 1 : 4个用户LED全灭, 心跳暂停 (一键关灯, 电平语义)
 *   data[0] bit2 = 0 : 恢复正常 (心跳继续, LED2回到关灯前状态)
 *
 * 用法 (CANalyst-II):
 *   翻转LED2 : 单次发送一帧 0x10, data[0]=0x01
 *   看门狗演示: 定时(比如100ms)发送 data[0]=0x03, 约1s后板子复位;
 *              想结束演示就停掉定时发送, 或发一帧 data[0]=0x00
 *   一键关灯 : 单次发送一帧 0x10, data[0]=0x04, 4个用户LED全灭;
 *              发一帧 data[0]=0x00 恢复正常
 *
 * 注意: 板子上的按键照样能用, 本地/远程两套输入是"或"的关系。
 */
#ifndef CAN_CMD_H
#define CAN_CMD_H

#include <stdint.h>

#define CANCMD_ID  (0x10u)

typedef struct
{
    uint8_t toggle_led2;  /* 本拍收到翻转命令=1 (边沿语义: 一帧=按一次) */
    uint8_t wdog_hold;    /* 1=要求停止喂狗 (电平语义: 跟随最新一帧的bit1) */
    uint8_t leds_off;     /* 1=4个用户LED全灭 (电平语义: 跟随最新一帧的bit2) */
} can_cmd_t;

void CANCMD_Init(void);            /* 上电初始化一次: CAN0 + 接收邮箱 + 中断回调 */
void CANCMD_Poll(can_cmd_t *cmd);  /* 每10ms调一次, 非阻塞, 把收到的命令取出来 */

#endif /* CAN_CMD_H */
