/*
 * app.h
 * 控制器应用层: 最小可扩展骨架
 *
 * 设计思想 (以后扩展到 PID HIL / MPC 时, 骨架一个字不用改):
 *   - app_input_t  : 控制器的全部输入。现在=2个按键, 以后=54个CAN信号。
 *   - app_output_t : 控制器的全部输出。现在=1个LED, 以后=11个CAN信号。
 *   - app_control(): 算法本体。现在=按键翻转LED, 以后把PID/MPC填进来。
 *   - 节拍/喂狗/耗时统计/故障处理全部由骨架管, 算法只管算。
 */
#ifndef APP_H
#define APP_H

#include <stdint.h>

/* ---------- 输入抽象 ----------
 * 本地按键和CAN远程命令是"或"的关系: 实验室现场用按键,
 * 宿舍远程用CAN (ID 0x10, 见 can_cmd.h), 两套都能驱动同一个算法。 */
typedef struct
{
    uint8_t key1_pressed;   /* KEY1 上升沿事件: 按一次=1 (边沿, 不是电平) */
    uint8_t key2_held;      /* KEY2 按住=1 (电平)。看门狗演示用 */
    uint8_t can_toggle;     /* CAN远程: 翻转LED2命令 (等价于KEY1按一次) */
    uint8_t can_wdog_hold;  /* CAN远程: 1=停止喂狗 (等价于按住KEY2) */
    uint8_t leds_off;       /* CAN远程: 1=4个用户LED全灭, 心跳暂停 (一键关灯) */
} app_input_t;

/* ---------- 输出抽象 ---------- */
typedef struct
{
    uint8_t led2;           /* LED2 期望状态: 1=亮, 0=灭 */
} app_output_t;

/* ---------- 运行统计 (可观测性: 出问题先看它) ---------- */
typedef struct
{
    uint32_t tick;          /* 10ms节拍计数 */
    uint32_t exec_max_us;   /* 单拍最大耗时, 微秒 */
    uint32_t overrun_cnt;   /* 单拍耗时超过10ms的次数 (MPC算力不够时这里先报警) */
    uint32_t feed_cnt;      /* 喂狗次数 */
} app_stat_t;

void APP_Init(void);                    /* 上电初始化一次 */
void APP_Step10ms(void);                /* 快任务: 每10ms调用一次 */
void APP_SlowTask1s(void);              /* 慢任务: 每1s调用一次 (心跳/打印) */
const app_stat_t *APP_GetStat(void);

#endif /* APP_H */
