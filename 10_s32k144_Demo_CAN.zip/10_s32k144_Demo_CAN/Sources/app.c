/*
 * app.c
 * 控制器应用层实现: 采集 -> 计算 -> 输出 -> 喂狗, 每10ms一拍
 *
 * 每一拍的固定流程 (以后PID/MPC也走这个流程):
 *   1. 输入采集  app_read_inputs()   : 读硬件/总线, 转成算法要的量, 非阻塞
 *   2. 控制计算  app_control()       : 算法本体, 以后PID/MPC只换这里
 *   3. 输出     app_write_outputs() : 限幅 -> 写硬件/总线
 *   4. 耗时统计                     : 量一拍用了多少us, 超10ms记overrun
 *   5. 喂狗      WDOG_Feed()        : 告诉看门狗"我还活着"
 */
#include "Cpu.h"
#include "uart.h"
#include "app.h"
#include "wdog.h"
#include "hil_timer.h"
#include "can_cmd.h"

#define LED1(x)  PINS_DRV_WritePin(PTD,16,!(x))
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!(x))
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!(x))
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!(x))

/* 按键原始电平 (高=按下, 与key.h里BTN定义一致, 这里直接读, 省掉key.c的阻塞消抖) */
#define BTN1_RAW  (((PINS_DRV_ReadPins(PTC)) >> 12) & 0x01u)
#define BTN2_RAW  (((PINS_DRV_ReadPins(PTC)) >> 13) & 0x01u)

static app_input_t  s_in;
static app_output_t s_out;
static app_stat_t   s_stat;
static uint32_t     s_counts_per_us = 48u;  /* DWT计数值转us换算系数, init时按实际主频修正 */

/* DWT周期计数器: 零成本的拍耗时测量
 * 说明: 这份SDK里没有CMSIS的core_cm4.h (S32K144.h只含外设寄存器),
 * 这里直接用Cortex-M4架构固定地址, 所有M4芯片通用。 */
#define DEMCR_REG      (*(volatile uint32_t *)0xE000EDFCu)  /* CoreDebug->DEMCR */
#define DWT_CTRL_REG   (*(volatile uint32_t *)0xE0001000u)  /* DWT->CTRL */
#define DWT_CYCCNT_REG (*(volatile uint32_t *)0xE0001004u)  /* DWT->CYCCNT */

static void dwt_init(void)
{
    DEMCR_REG      |= (1u << 24);  /* TRCENA: 使能DWT */
    DWT_CYCCNT_REG  = 0u;
    DWT_CTRL_REG   |= (1u << 0);   /* CYCCNTENA: 启动周期计数器 */
}

/* ---------- 1. 输入采集 ----------
 * 原则: 非阻塞。10ms采样一次, 天然带消抖, 不需要delay_ms。
 * 两路输入"或"合并: 本地按键 (实验室现场) + CAN远程命令 (宿舍远程)。
 * 以后: 这里换成"CAN收到的54个信号解包+量程检查", 签名不用变。 */
static void app_read_inputs(app_input_t *in)
{
    static uint8_t btn1_prev = 0u;
    uint8_t b1 = (BTN1_RAW != 0u) ? 1u : 0u;
    can_cmd_t cc;

    in->key1_pressed = ((b1 != 0u) && (btn1_prev == 0u)) ? 1u : 0u;  /* 上升沿检出 */
    btn1_prev = b1;

    in->key2_held = (BTN2_RAW != 0u) ? 1u : 0u;

    /* CAN远程命令并入: 和按键等价, 算法层分不清是本地按的还是远程发的 */
    CANCMD_Poll(&cc);
    in->can_toggle    = cc.toggle_led2;
    in->can_wdog_hold = cc.wdog_hold;
    in->leds_off      = cc.leds_off;
    if (cc.toggle_led2 != 0u)
    {
        in->key1_pressed = 1u;   /* 复用同一个边沿事件 */
    }
    if (cc.wdog_hold != 0u)
    {
        in->key2_held = 1u;      /* 复用同一个"按住"电平 */
    }
}

/* ---------- 2. 控制计算 (算法本体) ----------
 * 现在: 按一次KEY1, LED2翻转一次 (演示输入到计算到输出完整链路)。
 * 以后: PID的速度环就填在这里, 输入是app_input_t(54信号), 输出是app_output_t(11信号)。
 * 要求: 单拍必须算完 (<10ms), 里面不许有delay/死等/串口打印。 */
static void app_control(const app_input_t *in, app_output_t *out)
{
    static uint8_t led2_state = 0u;

    if (in->key1_pressed != 0u)
    {
        led2_state ^= 1u;
    }
    out->led2 = led2_state;
}

/* ---------- 3. 输出 ----------
 * 原则: 先限幅再输出。以后的11路电流命令也在这里统一钳0~1.6A。 */
static void app_write_outputs(const app_output_t *out)
{
    LED2(out->led2);
}

void APP_Init(void)
{
    uint32_t core_hz = 48000000u;

    (void)CLOCK_SYS_GetFreq(CORE_CLOCK, &core_hz);
    s_counts_per_us = core_hz / 1000000u;
    if (s_counts_per_us == 0u)
    {
        s_counts_per_us = 1u;
    }

    dwt_init();
    CANCMD_Init();    /* CAN0 500kbps: 远程命令接收 (ID 0x10) */
    WDOG_Init(1000u);   /* 看门狗: 1s超时, 每10ms喂一次, 裕量100倍 */

    s_stat.tick        = 0u;
    s_stat.exec_max_us = 0u;
    s_stat.overrun_cnt = 0u;
    s_stat.feed_cnt    = 0u;

    u1_printf("[APP] init ok, core=%lu Hz\r\n", (unsigned long)core_hz);
}

void APP_Step10ms(void)
{
    uint32_t t0 = DWT_CYCCNT_REG;
    uint32_t us;

    /* 1. 输入采集 */
    app_read_inputs(&s_in);

    /* 2. 控制计算 */
    app_control(&s_in, &s_out);

    /* 3. 输出 */
    app_write_outputs(&s_out);

    /* 一键关灯 (CAN远程 bit2, 电平语义): 4个用户LED强制全灭, 覆盖算法输出;
     * 发一帧 data[0]=0x00 即恢复, LED2回到关灯前的状态 */
    if (s_in.leds_off != 0u)
    {
        LED1(0);
        LED2(0);
        LED3(0);
        LED4(0);
    }

    /* 4. 耗时统计 */
    us = (DWT_CYCCNT_REG - t0) / s_counts_per_us;
    if (us > s_stat.exec_max_us)
    {
        s_stat.exec_max_us = us;
    }
    if (us > 10000u)
    {
        s_stat.overrun_cnt++;
    }

    s_stat.tick++;

    /* 5. 喂狗
     * 按住KEY2 = 模拟程序卡死: 故意跳过喂狗, 约1s后看门狗复位MCU。
     * (演示看门狗确实在工作, 不是摆设) */
    if (s_in.key2_held == 0u)
    {
        WDOG_Feed();
        s_stat.feed_cnt++;
    }
}

/* ---------- 慢任务: 1s一次 ----------
 * 心跳LED + 串口状态打印。重的、可阻塞的、慢的东西全放这里,
 * 绝不进10ms快任务。 */
void APP_SlowTask1s(void)
{
    static uint8_t hb = 0u;

    if (s_in.leds_off == 0u)
    {
        hb ^= 1u;
        LED1(hb);   /* 1Hz心跳: 灯在闪 = 主循环在转 */
    }
    else
    {
        LED1(0);    /* 一键关灯: 心跳暂停, LED1保持灭 */
    }

    u1_printf("[APP] tick=%lu max=%luus overrun=%lu feed=%lu\r\n",
              (unsigned long)s_stat.tick,
              (unsigned long)s_stat.exec_max_us,
              (unsigned long)s_stat.overrun_cnt,
              (unsigned long)s_stat.feed_cnt);
}

const app_stat_t *APP_GetStat(void)
{
    return &s_stat;
}
