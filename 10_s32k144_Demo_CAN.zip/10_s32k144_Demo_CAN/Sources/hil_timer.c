/*
 * hil_timer.c
 * LPIT0通道0: 10ms周期中断, 作为100Hz控制节拍。
 * 寄存器级配置, 不依赖SDK定时器驱动。
 * 注意: delay.c 占用了 SysTick, 这里刻意不用 SysTick, 避免冲突。
 */
#include "Cpu.h"
#include "interrupt_manager.h"
#include "hil_timer.h"

volatile uint8_t  g_hil_tick = 0;
volatile uint32_t g_hil_tick_cnt = 0;

/* LPIT0通道0中断服务函数 (启动文件向量表里已声明, 这里是强定义) */
void LPIT0_Ch0_IRQHandler(void)
{
    LPIT0->MSR |= LPIT_MSR_TIF0_MASK;  /* 写1清中断标志 */
    g_hil_tick_cnt++;
    g_hil_tick = 1;
}

void HIL_TimerInit(void)
{
    /* 1. 使能LPIT0外设时钟, 时钟源选 FIRC 48MHz
     *    clockMan1 配置里 FIRC 已使能(48M)。
     *    PCC PCS编码: 0=关 1=SOSC 2=SIRC 3=FIRC 6=SPLL_DIV2 */
    PCC->PCCn[PCC_LPIT_INDEX] &= ~PCC_PCCn_CGC_MASK;  /* 先关时钟再切时钟源 */
    PCC->PCCn[PCC_LPIT_INDEX] |= PCC_PCCn_PCS(3u);
    PCC->PCCn[PCC_LPIT_INDEX] |= PCC_PCCn_CGC_MASK;

    /* 2. LPIT模块时钟使能 */
    LPIT0->MCR |= LPIT_MCR_M_CEN_MASK;

    /* 3. 通道0: 32位周期计数模式(复位默认值), 装载10ms计数值 */
    LPIT0->TMR[0].TVAL = 480000u - 1u;  /* 48MHz * 10ms */
    LPIT0->TMR[0].TCTRL |= LPIT_TMR_TCTRL_T_EN_MASK;

    /* 4. 使能通道0中断 (中断向量由链接期强符号 LPIT0_Ch0_IRQHandler 直接覆盖,
     *    无需运行期 InstallHandler) */
    LPIT0->MIER |= LPIT_MIER_TIE0_MASK;
    INT_SYS_EnableIRQ(LPIT0_Ch0_IRQn);
}
