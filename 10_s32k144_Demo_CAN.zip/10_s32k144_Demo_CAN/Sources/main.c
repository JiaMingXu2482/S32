/*
 * main.c (lesson version)
 * The controller software's main() does only 3 things;
 * all business logic lives in app.c:
 *   1. Init (clock/IO/UART -> app layer -> tick timer)
 *   2. Fast task dispatch: 10ms tick -> APP_Step10ms()
 *   3. Slow task dispatch: 1s -> APP_SlowTask1s()
 *
 * Project must already contain: uart.c/uart.h, delay.c/delay.h,
 * pin_mux.c (button pins configured as inputs)
 * New files from this package:
 *   Sources/app.c, Sources/wdog.c, Sources/hil_timer.c, Sources/can_cmd.c
 *   include/app.h, include/wdog.h, include/hil_timer.h, include/can_cmd.h
 * Note: back up your original Sources/main.c before overwriting.
 */
#include "Cpu.h"
#include "uart.h"
#include "delay.h"
#include "app.h"
#include "wdog.h"
#include "hil_timer.h"

int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/
    uint32_t last_slow_tick = 0u;

    /* ---------- Init ---------- */
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                   g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
    (void)delay_init();
    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
    LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0);

    /* Report last reset cause first: a watchdog reset proves it works */
    if (WDOG_WasWdogReset() != 0u)
    {
        u1_printf("\r\n[BOOT] last reset: WDOG timeout\r\n");
    }
    else
    {
        u1_printf("\r\n[BOOT] power-on / debugger reset\r\n");
    }

    APP_Init();        /* app layer init (enables watchdog) */
    HIL_TimerInit();   /* LPIT0 10ms tick */

    u1_printf("[BOOT] ready. KEY1/0x10-bit0=toggle LED2, KEY2/0x10-bit1=hold=WDOG reset in ~1s\r\n");

    /* ---------- Main loop: dispatch only, no business logic ---------- */
    for (;;)
    {
        /* Fast task: every 10ms */
        if (g_hil_tick != 0u)
        {
            g_hil_tick = 0u;
            APP_Step10ms();
        }

        /* Slow task: every 1s */
        if ((g_hil_tick_cnt - last_slow_tick) >= 100u)
        {
            last_slow_tick = g_hil_tick_cnt;
            APP_SlowTask1s();
        }
    }
}
