/*
 * can_cmd.c
 * CAN远程命令接收实现。
 *
 * 做法照抄你原来 CAN 例程的套路: 接收邮箱 + 中断回调。
 * 中断里只做两件事: 把帧拷走、立标志、重新挂接收。
 * 真正的解包放在 CANCMD_Poll() 里 (主循环 10ms 调一次, 不在中断里干重活)。
 */
#include "Cpu.h"
#include "can_cmd.h"

#define CANCMD_RX_MB  (0u)   /* 接收用邮箱0, 和原来例程一样 */

static volatile uint8_t       s_new_frame = 0u;
static can_message_t          s_rx_msg;
static uint8_t                s_wdog_hold = 0u;  /* 跟随最新一帧的bit1 */
static uint8_t                s_leds_off  = 0u;  /* 跟随最新一帧的bit2 */

/* CAN0接收中断回调 (中断上下文: 只搬数据, 不解包) */
static void cancmd_rx_callback(uint32_t instance, can_event_t event,
                               uint32_t buffIdx, void *flexcanState)
{
    (void)instance;
    (void)buffIdx;
    (void)flexcanState;

    /* 先重新挂接收, 再处理事件: 保证不丢下一帧 (和原来例程一样的顺序) */
    (void)CAN_Receive(&can_pal0_instance, CANCMD_RX_MB, &s_rx_msg);

    if (event == CAN_EVENT_RX_COMPLETE)
    {
        s_new_frame = 1u;
    }
}

void CANCMD_Init(void)
{
    can_buff_config_t rxCfg =
    {
        .enableFD  = false,
        .enableBRS = false,
        .fdPadding = 0u,
        .idType    = CAN_MSG_ID_STD,
        .isRemote  = false
    };

    CAN_Init(&can_pal0_instance, &can_pal0_Config0);
    CAN_ConfigRxBuff(&can_pal0_instance, CANCMD_RX_MB, &rxCfg, 0x0u);
    /* 接收掩码=0: 全收, 用软件按ID过滤 (和原来例程一致) */
    CAN_SetRxFilter(&can_pal0_instance, CAN_MSG_ID_STD, CANCMD_RX_MB, 0u);
    CAN_InstallEventCallback(&can_pal0_instance, &cancmd_rx_callback, (void *)0);
    (void)CAN_Receive(&can_pal0_instance, CANCMD_RX_MB, &s_rx_msg);
}

void CANCMD_Poll(can_cmd_t *cmd)
{
    cmd->toggle_led2 = 0u;

    if (s_new_frame != 0u)
    {
        s_new_frame = 0u;

        if (s_rx_msg.id == CANCMD_ID)
        {
            uint8_t d0 = s_rx_msg.data[0];

            /* 每收到一帧bit0=1, 就算"按了一次": 单次发送=翻转一次 */
            if ((d0 & 0x01u) != 0u)
            {
                cmd->toggle_led2 = 1u;
            }
            /* bit1是电平语义: 1=停喂, 0=恢复。复位后RAM清零, 自动恢复喂狗。 */
            s_wdog_hold = ((d0 & 0x02u) != 0u) ? 1u : 0u;
            /* bit2是电平语义: 1=4个用户LED全灭(一键关灯), 0=恢复正常。 */
            s_leds_off = ((d0 & 0x04u) != 0u) ? 1u : 0u;
        }
    }

    cmd->wdog_hold = s_wdog_hold;
    cmd->leds_off  = s_leds_off;
}
