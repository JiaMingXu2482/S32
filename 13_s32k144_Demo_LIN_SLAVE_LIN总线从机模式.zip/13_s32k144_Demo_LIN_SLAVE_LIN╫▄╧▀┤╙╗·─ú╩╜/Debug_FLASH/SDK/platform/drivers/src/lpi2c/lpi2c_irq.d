SDK/platform/drivers/src/lpi2c/lpi2c_irq.o: \
 ../SDK/platform/drivers/src/lpi2c/lpi2c_irq.c \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/device_registers.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/devassert.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/drivers/inc/lpi2c_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/status.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/rtos/osif/osif.h \
 C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/callbacks.h \
 ../SDK/platform/drivers/src/lpi2c/lpi2c_irq.h

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/device_registers.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/devassert.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/drivers/inc/lpi2c_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/status.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/rtos/osif/osif.h:

C:/Users/Administrator/workspaceS32DS.ARM.2.2/s32k144_Demo_LIN_SLAVE/SDK/platform/devices/callbacks.h:

../SDK/platform/drivers/src/lpi2c/lpi2c_irq.h:
