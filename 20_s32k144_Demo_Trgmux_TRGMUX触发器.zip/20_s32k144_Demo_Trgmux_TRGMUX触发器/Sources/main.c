/*
 * Ʒ�ǿƼ�S32K144������
 *
 * TRGMUXʵ��
 * ��ʾ����:
 * ���ò���ʹ��TRGMUX IN3��PTB2 - KEY3��ͨ��,����LPIT0�����ж�,���ж���ʹLED4 ��ת��˸��
 *
 * IO����
 * KEY3 PTB2 TRGMUX IN3
 *
 * LED1 PTD16 FTM0_CH1
 * LED2 PTD15 FTM0_CH0
 * LED3 PTD1 FTM0_CH3
 * LED4 PTD0 FTM0_CH2
 *
*/
#include "Cpu.h"
#include "delay.h"
#include "uart.h"
#include"key.h"
#include"oled.h"
  volatile int exit_code = 0;

#define LPIT_CHANNEL        0UL
#define LPIT_Channel_IRQn   LPIT0_Ch0_IRQn



#define LED1(x)  PINS_DRV_WritePin(PTD,16,!x);
#define LED2(x)  PINS_DRV_WritePin(PTD,15,!x);
#define LED3(x)  PINS_DRV_WritePin(PTD,1,!x);
#define LED4(x)  PINS_DRV_WritePin(PTD,0,!x);


  void LPIT_ISR(void)
  {
      /* Clear LPIT channel flag */
      LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT1, (1 << LPIT_CHANNEL));
      /* Toggle LED */
      PINS_DRV_TogglePins(PTD, 1 << 0);
  }


//KEY3 ����trgmux 200����cd
int main(void)
{
  /* Write your local variable definition here */
	uint8_t pinstate;
	int MCU_Freq;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
	MCU_Freq = delay_init();//��ʼ��delay����
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr); //��ʼ��IO
	I2C_MasterInit(&i2c1_instance, &i2c1_MasterConfig0);//��ʼ��I2C����,����OLEDͨѶ
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0); //��ʼ������



    TRGMUX_DRV_Init(INST_TRGMUX1, &trgmux1_InitConfig0); //��ʼ��TRGMUX


    LPIT_DRV_Init(INST_LPIT1, &lpit1_InitConfig); //��ʼ��LPIT �͹��������ж�����

    LPIT_DRV_InitChannel(INST_LPIT1, LPIT_CHANNEL, &lpit1_ChnConfig0); //LPIT ͨ������
    /* Install LPIT_ISR as LPIT interrupt handler */
    INT_SYS_InstallHandler(LPIT_Channel_IRQn, &LPIT_ISR, (isr_t *)0); //��װ�ص�����

/*     - ͨ���������÷���
*      - with mask = 0x01U then channel 0 will be started
*      - with mask = 0x02U then channel 1 will be started
*      - with mask = 0x03U then channel 0 and channel 1 will be started*/

    LPIT_DRV_StartTimerChannels(INST_LPIT1, (1U << LPIT_CHANNEL)); //��ʼ��ʱ��

	oled_init(); //OLED���ò�����ʼ��
	OLED_TITLE((uint8_t*)"S32K144",(uint8_t*)"TRGMUX");//OLED��ʾ����
	OLED_ShowString(0,4,"  Press KEY 3",16,0);
	OLED_ShowString(0,6," Start TRGMUX",16,0);
	u1_printf("��ʼ�����,MCU����Ƶ��Ϊ %d Mhz \r\n",MCU_Freq);
    while(1)
    {
   	delay_ms(100);
    PINS_DRV_TogglePins(PTD, 1 << 16);
    }
  /*** Don't write any code pass th5is line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
