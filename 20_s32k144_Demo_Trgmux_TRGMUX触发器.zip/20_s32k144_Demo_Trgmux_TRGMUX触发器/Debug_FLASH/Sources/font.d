Sources/font.o: ../Sources/font.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/include/font.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/include/font.h:
