SDK/platform/drivers/src/lpit/lpit_driver.o: \
 ../SDK/platform/drivers/src/lpit/lpit_driver.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/lpit_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/lpit/lpit_hw_access.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/devassert.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/clock_manager.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/clock.h \
 d:\workspaces32ds.arm.2.2\s32k144_demo_trgmux\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/lpit_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/lpit/lpit_hw_access.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/devassert.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/interrupt_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/clock_manager.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/clock.h:

d:\workspaces32ds.arm.2.2\s32k144_demo_trgmux\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
