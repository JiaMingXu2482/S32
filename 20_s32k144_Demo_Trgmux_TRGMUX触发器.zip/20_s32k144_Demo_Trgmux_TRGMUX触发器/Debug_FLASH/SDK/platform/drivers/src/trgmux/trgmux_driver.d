SDK/platform/drivers/src/trgmux/trgmux_driver.o: \
 ../SDK/platform/drivers/src/trgmux/trgmux_driver.c \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/trgmux_driver.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/status.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/device_registers.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/common/s32_core_cm4.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/devassert.h \
 ../SDK/platform/drivers/src/trgmux/trgmux_hw_access.h

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/drivers/inc/trgmux_driver.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/status.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/device_registers.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/common/s32_core_cm4.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/workspaceS32DS.ARM.2.2/s32k144_Demo_Trgmux/SDK/platform/devices/devassert.h:

../SDK/platform/drivers/src/trgmux/trgmux_hw_access.h:
